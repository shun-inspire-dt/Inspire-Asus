import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$TypeIconFbSizeSm = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip_fb_sm_g)">
<rect width="20" height="20" rx="10" fill="white"></rect>
<path d="M19.9996 10.0369C19.9996 4.51422 15.5225 0.0371094 9.99979 0.0371094C4.47711 0.0371094 0 4.51422 0 10.0369C0 14.7264 3.22873 18.6615 7.58425 19.7423V13.0928H5.5223V10.0369H7.58425V8.72015C7.58425 5.31659 9.12463 3.73903 12.4662 3.73903C13.0997 3.73903 14.1929 3.86343 14.6401 3.98743V6.75738C14.4041 6.73256 13.9941 6.72015 13.4849 6.72015C11.8453 6.72015 11.2118 7.34136 11.2118 8.9561V10.0369H14.4781L13.9169 13.0928H11.2118V19.9635C16.1633 19.3655 19.9996 15.1496 19.9996 10.0369Z" fill="var(--color-facebook, #0866FF)"></path>
</g>
<defs>
<clipPath id="clip_fb_sm">
<rect width="20" height="20" rx="10" fill="white"></rect>
</clipPath>
</defs>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/social/svg-astro/type_icon_fb-size_sm.astro", void 0);

export { $$TypeIconFbSizeSm as default };
