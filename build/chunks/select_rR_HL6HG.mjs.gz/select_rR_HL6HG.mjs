import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
/* empty css                         */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Select = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Select;
  const {
    id,
    // 選擇器 ID
    data = [],
    // 選項資料，預設為空陣列
    className,
    // 自定義 CSS 類別
    required,
    // 是否必填
    disabled,
    // 是否禁用
    name,
    // 表單欄位名稱
    value,
    // 當前選中值
    placeholder = "\u8ACB\u9078\u64C7",
    // 佔位符文字，預設為「請選擇」
    title,
    // 無障礙標籤
    size = "md",
    // 尺寸，預設為 md
    status,
    // 狀態，預設為 value
    validClass,
    // 驗證類別，預設為 'form'
    validType,
    // 驗證類型
    validLabel,
    // 驗證標籤
    customValidText,
    // 自定義驗證成功訊息
    customInvalidText,
    // 自定義驗證失敗訊息
    onchange,
    // 值改變事件處理
    attribute = {},
    // 額外屬性，預設為空物件
    style = {}
    // 額外樣式，預設為空物件
  } = Astro2.props;
  const validAttribute = {
    "data-valid-class": validClass,
    // 驗證類別
    "data-valid-type": validType,
    // 驗證類型
    "data-valid-label": validLabel,
    // 驗證標籤
    "data-custom-valid-text": customValidText,
    // 自定義成功訊息
    "data-custom-invalid-text": customInvalidText
    // 自定義失敗訊息
  };
  const selectClasses = [
    "control-input",
    "control-select",
    { [`size_${size}`]: size },
    { [`status_${status}`]: status },
    className
  ].filter(Boolean);
  return renderTemplate`${maybeRenderHead()}<select${addAttribute(id, "id")}${addAttribute(selectClasses, "class:list")}${addAttribute(name, "name")}${addAttribute(value, "value")}${addAttribute(required, "required")}${addAttribute(disabled, "disabled")}${addAttribute(style, "style")}${addAttribute(onchange, "onchange")}${addAttribute(title, "aria-label")}${spreadAttributes(attribute)}${spreadAttributes(validAttribute)}>
    ${renderSlot($$result, $$slots["index"], renderTemplate`
        <option class="control-select-placeholder" value=""${addAttribute(!!value, "disabled")}${spreadAttributes(!value ? { selected: "" } : {})}>
            ${placeholder}
        </option>
    

    ${renderSlot($$result, $$slots["default"], renderTemplate`
        ${/*
   * 根據 data 屬性動態生成選項
   * - 遍歷 data 陣列
   * - 設定選項值和顯示文字
   * - 根據當前值自動選中對應選項
   * - 支援每個選項的自定義屬性
   */
  data.map((x) => renderTemplate`<option${addAttribute(x.value, "value")}${addAttribute(value === x.value, "selected")}${spreadAttributes(x.attribute)}>
                    ${x.text}
                </option>`)}
    `)}
`)}</select>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/select/select.astro", void 0);

export { $$Select as $ };
