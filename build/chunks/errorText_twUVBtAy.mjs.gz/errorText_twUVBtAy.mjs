import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, f as renderSlot, r as renderComponent, d as renderTemplate, F as Fragment } from './astro/server_v5wg8FJS.mjs';
import { $ as $$Checkbox } from './checkbox_CezxJCXT.mjs';
import { $ as $$NotificationIcon } from './notificationIcon_D_PqDPap.mjs';

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$CheckboxGroup = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$CheckboxGroup;
  const { IDName, className, style, attribute = {}, showTop = true, indeterminate = true } = Astro2.props;
  const TopId = IDName || `main-checkbox-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "checkbox-group",
    { "checkbox-group-main": showTop }
  ], "class:list")}${addAttribute(style, "style")} data-checkbox-group${spreadAttributes(attribute)}>
    ${showTop && renderTemplate`${renderComponent($$result, "Checkbox", $$Checkbox, { "id": TopId, "title": "Main Term", "attribute": { "data-checkbox-main": true } }, { "default": ($$result2) => renderTemplate`
                ${renderSlot($$result2, $$slots["title"])}
            ` })}`}
    <div class="checkbox-group-inner">
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/checkboxGroup.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$ErrorText = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ErrorText;
  const { IDName, className, style, attribute = {}, error, Tag = "span", showSolidErrorIcon = false } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "form-check-feedback-text", { "error-text": error }], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`${showSolidErrorIcon ? renderTemplate`${renderComponent($$result2, "ErrorIcon", $$NotificationIcon, {})}
            ${maybeRenderHead()}<span>${renderSlot($$result2, $$slots["default"])}</span>` : renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`${renderSlot($$result3, $$slots["default"])}` })}`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/checkboxs/errorText.astro", void 0);

export { $$CheckboxGroup as $, $$ErrorText as a };
