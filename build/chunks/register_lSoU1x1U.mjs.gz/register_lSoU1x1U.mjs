import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Register = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17.626 8.47363L12.2979 13.8018C12.2334 13.8662 12.1547 13.9147 12.0684 13.9443L9.37408 14.8711C9.21905 14.9244 9.06933 14.7785 9.11823 14.6221L9.95514 11.9424C9.98435 11.8489 10.036 11.7633 10.1055 11.6943L15.502 6.34961L17.626 8.47363ZM19.3965 2.49316C19.9591 1.93623 20.8596 1.91673 21.4454 2.44922C22.0741 3.02085 22.097 4.00264 21.4962 4.60352L18.4737 7.62598L16.3536 5.50586L19.3965 2.49316Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
<path d="M17.248 3C17.0891 3.00013 16.9366 3.06337 16.8242 3.17578L9.1123 10.8877C9.03875 10.9614 8.98547 11.0529 8.95801 11.1533L7.86816 15.1494C7.70542 15.7465 8.25348 16.2946 8.85059 16.1318L12.8467 15.042C12.9471 15.0145 13.0386 14.9613 13.1123 14.8877L20.8242 7.17578C20.9366 7.06337 20.9999 6.91091 21 6.75195V18.7998C21 20.0148 20.0148 21 18.7998 21H5.2002C3.98517 21 3 20.0148 3 18.7998V5.2002C3 3.98517 3.98517 3 5.2002 3H17.248Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/hover/register.astro", void 0);

export { $$Register as default };
