import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, e as renderSlot } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Form$1 } from './form_BfTbi7Kh.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {}, title, action } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "className": [className], "style": style, "attribute": attribute, "action": action }, { "default": ($$result2) => renderTemplate`${renderSlot($$result2, $$slots["default"])}
`, "sub-title": ($$result2) => renderTemplate`${title && renderTemplate`${maybeRenderHead()}<h2 class="auth-title">
                ${title}
            </h2>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/auth/form.astro", void 0);

export { $$Form as $ };
