import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { i as $$InputWrapper } from './layouts_C4hX5So7.mjs';
/* empty css                         */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$PasswordInput = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$PasswordInput;
  const {
    id,
    // 輸入框 ID
    inputId,
    // 輸入框 ID
    className,
    // 自定義 CSS 類別
    inputClassName,
    // 自定義 CSS 類別
    name,
    // 表單欄位名稱
    value,
    // 輸入框值
    maxLength,
    // 最大字元長度
    minLength,
    // 最小字元長度
    placeholder,
    // 佔位符文字，預設為密碼提示
    inputmode = "text",
    // 輸入模式，預設為文字
    required,
    // 是否必填
    disabled,
    // 是否禁用
    readonly,
    // 是否唯讀
    autocomplete = "current-password",
    // 自動完成，預設為當前密碼
    title,
    // 標題（用於無障礙）
    transparent,
    // 是否透明樣式
    size = "md",
    // 尺寸，預設為 md
    focus = false,
    // 是否顯示焦點邊框，預設為 false
    showPassword = false,
    // 初始是否顯示密碼，預設為 false
    attribute = {},
    // 其他 HTML 屬性，預設為空物件
    inputAttribute = {},
    // 其他 HTML 屬性，預設為空物件
    style = {},
    // 自定義 CSS 樣式
    inputStyle = {},
    // 自定義 CSS 樣式
    aria = {}
    // ARIA 屬性，預設為空物件
  } = Astro2.props;
  const componentId = id || `password-input-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${renderComponent($$result, "InputWrapper", $$InputWrapper, { "id": componentId, "inputId": inputId, "className": ["password-input-wrapper", className], "inputClassName": inputClassName, "type": showPassword ? "text" : "password", "name": name, "value": value, "maxLength": maxLength, "minLength": minLength, "placeholder": placeholder, "inputmode": inputmode, "required": required, "disabled": disabled, "readonly": readonly, "autocomplete": autocomplete, "title": title, "transparent": transparent, "size": size, "focus": focus, "pwdShowIcon": true, "pwdHideIcon": true, "aria": aria, "attribute": { "data-expand": showPassword ? "true" : "false", "data-component": "password-input", ...attribute }, "inputAttribute": inputAttribute, "style": style, "inputStyle": inputStyle })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/input/passwordInput.astro", void 0);

export { $$PasswordInput as $ };
