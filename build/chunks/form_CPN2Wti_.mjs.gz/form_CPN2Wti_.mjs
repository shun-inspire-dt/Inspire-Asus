import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, f as renderSlot, r as renderComponent, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';
import { $ as $$Title } from './title_C418meuI.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "",
    type = 1,
    display = "flex",
    block = false,
    action
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div id="section-form-container"${addAttribute([
    "section-form-container",
    { "section-form-container-BG": type === 1 },
    { "section-form-container-BG-Image": type === 2 }
  ], "class:list")}${addAttribute({ ...type === 2 ? { "--bg-image": `url("/assets/images/pages/feature-BG-2.png")` } : {}, ...style, "--footer-height": "4.1875rem" }, "style")}>
    <form${addAttribute(IDName ? `${IDName}Form` : void 0, "id")}${addAttribute(["section-form-container-inner", className], "class:list")}${addAttribute(action, "action")}${spreadAttributes(attribute)}>
        ${title && renderTemplate`${renderComponent($$result, "Title", $$Title, { "title": title })}`}
        ${renderSlot($$result, $$slots["top"])}
        <div${addAttribute([
    "section-form-body",
    {
      "section-form-normal": !block,
      "section-form-block": block
    }
  ], "class:list")}>
            ${renderSlot($$result, $$slots["sub-title"])}
            <div${addAttribute([
    {
      [`section-form-column`]: display === "flex"
    },
    {
      [`section-form-grid`]: display === "grid"
    }
  ], "class:list")}>
                ${renderSlot($$result, $$slots["default"])}
            </div>
        </div>
    </form>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/form.astro", void 0);

export { $$Form as $ };
