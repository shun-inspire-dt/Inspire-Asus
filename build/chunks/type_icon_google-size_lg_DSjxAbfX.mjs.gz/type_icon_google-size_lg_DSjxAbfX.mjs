import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$TypeIconGoogleSizeLg = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<clipPath id="clip_google_default_g" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="32" height="32">
<path d="M32 0H0V32H32V0Z" fill="white"></path>
</clipPath>
<g clip-path="url(#clip_google_default)">
<path d="M31.36 16.3637C31.36 15.229 31.2582 14.1382 31.0691 13.0908H16V19.2799H24.6109C24.24 21.2799 23.1129 22.9745 21.4182 24.109V28.1237H26.5891C29.6146 25.3382 31.36 21.2363 31.36 16.3637Z" fill="#4285F4"></path>
<path d="M15.9994 32C20.3194 32 23.9411 30.5672 26.5883 28.1237L21.4174 24.1091C19.9848 25.0691 18.152 25.6363 15.9994 25.6363C11.832 25.6363 8.30483 22.8217 7.04651 19.04H1.70105V23.1855C4.33392 28.4146 9.74483 32 15.9994 32Z" fill="#34A853"></path>
<path d="M7.04727 19.0399C6.72713 18.0799 6.54546 17.0545 6.54546 15.9999C6.54546 14.9452 6.72713 13.9199 7.04727 12.9599V8.81445H1.70182C0.618182 10.9745 0 13.4181 0 15.9999C0 18.5816 0.618182 21.0252 1.70182 23.1852L7.04727 19.0399Z" fill="#FBBC04"></path>
<path d="M15.9994 6.36364C18.3483 6.36364 20.4574 7.17091 22.1156 8.75636L26.7048 4.16727C23.9339 1.58545 20.312 0 15.9994 0C9.74483 0 4.33392 3.58545 1.70105 8.81454L7.04651 12.96C8.30483 9.17833 11.832 6.36364 15.9994 6.36364Z" fill="#E94235"></path>
</g>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/social/svg-astro/type_icon_google-size_lg.astro", void 0);

export { $$TypeIconGoogleSizeLg as default };
