import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Affiliateprograms = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3.60037 20.3998V16.5996C3.60037 14.9428 4.94351 13.5996 6.60037 13.5996H7.50039H12.5002C13.5496 13.5996 14.4004 14.4504 14.4004 15.4998C14.4004 16.5493 13.5496 17.4 12.5002 17.4H10.0004" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M3.625 20.4H17L19.9383 18.637C20.5586 18.2648 20.8372 17.5117 20.6085 16.8254C20.2962 15.8886 19.1968 15.4819 18.3501 15.99L16.475 17.115C16.1642 17.3015 15.8085 17.4 15.446 17.4H11" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<circle cx="10.5" cy="6.5" r="0.9" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></circle>
<circle cx="14.5" cy="10.5" r="0.9" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></circle>
<path d="M10 11L15 6" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M6.59961 13.4995V5.59961C6.59961 4.49504 7.49504 3.59961 8.59961 3.59961H16.3996C17.5042 3.59961 18.3996 4.49504 18.3996 5.59961V15.9995" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/affiliateprograms.astro", void 0);

export { $$Affiliateprograms as default };
