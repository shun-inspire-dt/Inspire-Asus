import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, F as Fragment, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const bannerImage = (text) => `/assets/images/pages/${text}-sm`;
const bannerImages = (text) => [
  {
    width: 1280,
    // 桌面版斷點 (1280px+)
    img: `/assets/images/pages/${text}-lg`,
    // 向後相容的預設圖片
    densities: {
      "1x": `/assets/images/pages/${text}-lg`,
      // 標準解析度
      "1.5x": `/assets/images/pages/${text}-lg`,
      // 1.5倍解析度
      "2x": `/assets/images/pages/${text}-lg`
      // 2倍解析度（高解析度螢幕）
    }
  },
  {
    width: 768,
    // 平板版斷點 (768px-1279px)
    img: `/assets/images/pages/${text}-md`,
    densities: {
      "1x": `/assets/images/pages/${text}-md`,
      "1.5x": `/assets/images/pages/${text}-md`,
      "2x": `/assets/images/pages/${text}-md`
    }
  },
  {
    width: 0,
    // 手機版斷點 (767px 以下)
    img: `/assets/images/pages/${text}-sm`,
    densities: {
      "1x": `/assets/images/pages/${text}-sm`,
      "1.5x": `/assets/images/pages/${text}-sm`,
      "2x": `/assets/images/pages/${text}-sm`
    }
  }
];

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Picture = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Picture;
  const {
    id,
    className = "",
    pictureClassName = "",
    width = null,
    height = null,
    img = "",
    blankWebpImg = "",
    alt = "",
    type = "png",
    loading = "lazy",
    decoding = "async",
    blank,
    noWebp = false,
    breakpoints,
    style,
    attribute = {}
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<picture${addAttribute([pictureClassName], "class:list")}>
    ${breakpoints && breakpoints?.map((x) => renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${!noWebp && renderTemplate`<source${addAttribute(
    x.densities ? Object.entries(x.densities).map(
      ([density, imgPath]) => !blank ? `${Astro2.url.origin}${imgPath}.webp ${density}` : `${imgPath}.webp ${density}`
    ).join(", ") : !blank ? `${Astro2.url.origin}${x.img}.webp` : `${x.blankWebpImg}`,
    "srcset"
  )}${addAttribute(`(min-width:${x.width}px)`, "media")} type="image/webp">`}<source${addAttribute(
    x.densities ? Object.entries(x.densities).map(
      ([density, imgPath]) => !blank ? `${Astro2.url.origin}${imgPath}.${x.type || type} ${density}` : `${imgPath} ${density}`
    ).join(", ") : !blank ? `${Astro2.url.origin}${x.img}.${x.type || type}` : `${x.img}`,
    "srcset"
  )}${addAttribute(`(min-width:${x.width}px)`, "media")}${addAttribute(`image/${x.type || type}`, "type")}>
                ` })}`)}
    ${!noWebp && renderTemplate`<source${addAttribute(!blank ? `${Astro2.url.origin}${img}.webp` : `${blankWebpImg}`, "srcset")} type="image/webp">`}
    <img${addAttribute(id, "id")}${addAttribute([className], "class:list")}${addAttribute(width, "width")}${addAttribute(height, "height")}${addAttribute(!blank ? `${Astro2.url.origin}${img}.${type}` : `${img}`, "src")}${addAttribute(alt, "alt")}${addAttribute(alt, "title")}${addAttribute(loading, "loading")}${addAttribute(decoding, "decoding")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
</picture>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/images/picture.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Banner = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Banner;
  const { IDName, className, style, title, img, mode = "light", attribute = {} } = Astro2.props;
  const imgBreakpoints = bannerImages(img);
  const image = bannerImage(img);
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "section-banner"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Picture", $$Picture, { "img": image, "className": "section-banner-image", "alt": title, "breakpoints": imgBreakpoints, "type": "png", "noWebp": true })}
    <div class="section-banner-head">
        <h2${addAttribute([
    "section-banner-title",
    mode === "dark" && "section-banner-title-dark"
  ], "class:list")}>
            ${title}
        </h2>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/banner/banner.astro", void 0);

export { $$Picture as $, $$Banner as a };
