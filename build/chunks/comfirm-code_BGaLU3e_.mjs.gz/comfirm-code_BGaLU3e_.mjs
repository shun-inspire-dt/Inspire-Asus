import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from './astro/server_Bjgbv9en.mjs';
import { e as $$Modal, b as $$Input, c as $$Link } from './layouts_k9LlQnqK.mjs';
import { $ as $$InputGroup } from './inputGroup_BwDyYgK3.mjs';
/* empty css                             */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$ComfirmCode = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ComfirmCode;
  const { IDName = "ComfirmCode", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Modal", $$Modal, { "id": IDName, "title": "\u8F38\u5165\u9A57\u8B49\u78BC", "Modalclass": className, "cancelVariant": "blue-outline", "cancelTitle": "\u53D6\u6D88", "okVariant": "blue", "okTitle": "\u78BA\u8A8D\u9A57\u8B49", "okAttribute": { type: "submit" }, "sizes": "xl", "center": true, "ContentTag": "form", "contentAttribute": {
    action: "",
    id: `${IDName}Form`,
    "data-report-validity": "false",
    novalidate: true
  }, "contentClass": "needs-validation", "hideColse": true, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<p>
        我們已發送驗證碼至您的信箱
        <strong id="verifyEmail"></strong>
        ，請輸入驗證碼以完成登入。
    </p>
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u8ACB\u8F38\u5165\u9A57\u8B49\u78BC", "infoText": "\u9A57\u8B49\u78BC\u6709\u6548\u671F\u9650\u70BA 5 \u5206\u9418", "error": true, "errorText": "\u9A57\u8B49\u78BC\u932F\u8AA4\u6216\u5DF2\u904E\u671F", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "id": "loginVerifyCode", "name": "loginVerifyCode", "required": true, "placeholder": "\u8ACB\u8F38\u51656\u4F4D\u6578\u9A57\u8B49\u78BC" })}
    ` })}
    <div style="margin: 0 auto;">
        <span style="color: var(--color-gray-600);">沒收到驗證碼？</span>
        ${renderComponent($$result2, "ALink", $$Link, { "IDName": "resendCodeBtn" }, { "default": ($$result3) => renderTemplate`重新發送` })}
        <span id="resendCountdown" style="display: none; color: var(--color-gray-600);">(1秒後可重新發送)</span>
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/modal/comfirm-code.astro", void 0);

export { $$ComfirmCode as $ };
