import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$Myproduct = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M19.4 9.99961V5.79961C19.4 5.13687 18.8627 4.59961 18.2 4.59961H3.79961C3.13687 4.59961 2.59961 5.13687 2.59961 5.79961V15.2C2.59961 15.8627 3.13687 16.4 3.79961 16.4H15.5" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M10.5996 17V20" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M11.4004 17V20" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M6 20.4004H16.5" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M15.5996 10.5996H21.3996V20.4H15.5996V10.5996Z" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></path>
<circle cx="18.5004" cy="12.6" r="0.6" fill="var(--color-gray-900, var(--color-gray-900, #181818))"></circle>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/myproduct.astro", void 0);

export { $$Myproduct as default };
