import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Contact = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.50021 15.4999C5.18298 12.1827 4.06646 9.30557 3.69066 7.74473C3.49875 6.94763 3.76593 6.14536 4.25787 5.48947C4.74797 4.83603 5.36019 4.28389 6.0606 3.86364L6.32832 3.70301C6.96035 3.32379 7.78145 3.5629 8.11108 4.22215L9.67768 7.35536C9.87017 7.74033 9.79472 8.20529 9.49038 8.50965L8.58594 9.41416C8.21086 9.78926 8.03617 10.3037 8.28927 10.7699C8.59359 11.3304 9.2182 12.2179 10.5002 13.4999C11.7822 14.7819 12.6697 15.4065 13.2302 15.7108C13.6963 15.9639 14.2107 15.7892 14.5858 15.4142L15.4903 14.5096C15.7947 14.2053 16.2597 14.1298 16.6447 14.3223L19.7779 15.8889C20.4371 16.2186 20.6762 17.0396 20.297 17.6717L20.1364 17.9393C19.7161 18.6398 19.1639 19.2521 18.5104 19.7422C17.8545 20.2341 17.0523 20.5013 16.2552 20.3094C14.6945 19.9336 11.8174 18.8171 8.50021 15.4999Z" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/contact.astro", void 0);

export { $$Contact as default };
