import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, d as renderTemplate, r as renderComponent, F as Fragment } from './astro/server_Bjgbv9en.mjs';
/* empty css                                  */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Tables = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Tables;
  const {
    IDName,
    className,
    style,
    attribute = {},
    field = [],
    data = [],
    scrollable,
    sticky,
    mobileTable,
    rouned,
    MobileComponent,
    EmptyComponent,
    emptyHideHead,
    emptyIcon,
    emptyText = "\u8CC7\u6599\u70BA\u7A7A",
    hideTitle,
    hideToolTip
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName ? `${IDName}Table` : void 0, "id")}${addAttribute([
    className,
    "tableContainer",
    {
      mobileTable: !!mobileTable,
      "mobileTable-sm": mobileTable === "sm",
      "mobileTable-md": mobileTable === "md",
      "mobileTable-lg": mobileTable === "lg",
      "mobileTable-xl": mobileTable === "xl",
      "mobileTable-2xl": mobileTable === "2xl"
    },
    { sticky },
    { scrollable },
    { rouned: rouned === "all" },
    { "rouned-top": rouned === "top" },
    { "rouned-bottom": rouned === "bottom" }
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${!hideTitle && renderTemplate`<div class="tableTitle">
                ${renderSlot($$result, $$slots["title"])}
            </div>`}
    ${!hideToolTip && renderTemplate`<div class="tableToolTip">
                ${renderSlot($$result, $$slots["tooltip"])}
            </div>`}
    <table class="table">
        ${!emptyHideHead && renderTemplate`<thead>
                    <tr>
                        ${field.map((x) => renderTemplate`<th scope="col"${addAttribute(x.colspan, "colspan")}${addAttribute(x.rowspan, "rowspan")}${spreadAttributes(x.attribute ? x.attribute : {})}>
                                ${x.text}
                            </th>`)}
                    </tr>
                </thead>`}
        <tbody>
            ${renderSlot($$result, $$slots["default"], renderTemplate`
                ${data.length ? data.map((x, i) => renderTemplate`<tr${spreadAttributes(x.attribute ? x.attribute : {})}>
                                ${x.items.map((y, j) => renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
                                        <td${addAttribute(j === 0 ? "row" : void 0, "scope")}${addAttribute(y.colspan, "colspan")}${addAttribute(y.rowspan, "rowspan")}${spreadAttributes(y.attribute ? y.attribute : {})}>
                                            ${j === 0 ? renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`${y.component ? renderTemplate`${renderComponent($$result3, "y.component", y.component, { "index": j, "data": y, "className": "TableFirstTdContent" })}` : renderTemplate`<div class="TableFirstTdContent">${y.text}</div>`}${j === 0 && MobileComponent && renderTemplate`${renderComponent($$result3, "MobileComponent", MobileComponent, { "className": "MobileTableContainer", "index": i, "field": field, "data": x.items })}`}` })}` : y.component ? renderTemplate`${renderComponent($$result2, "y.component", y.component, { "index": j, "data": y })}` : renderTemplate`<div>${y.text}</div>`}
                                        </td>
                                    ` })}`)}
                            </tr>`) : renderTemplate`<th${addAttribute(field.length, "colspan")}>
                            ${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${EmptyComponent ? renderTemplate`${renderComponent($$result2, "EmptyComponent", EmptyComponent, { "emptyIcon": emptyIcon, "emptyText": emptyText })}` : renderTemplate`<div class="emptyTd">${emptyText}</div>`}` })}
                        </th>`}
            `)}
        </tbody>
    </table>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/tables/tables.astro", void 0);

export { $$Tables as $ };
