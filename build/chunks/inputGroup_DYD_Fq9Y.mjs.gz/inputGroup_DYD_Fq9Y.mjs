import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, f as renderSlot, d as renderTemplate, r as renderComponent } from './astro/server_v5wg8FJS.mjs';
import { $ as $$NotificationIcon } from './notificationIcon_D_PqDPap.mjs';
/* empty css                             */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$InputGroup = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$InputGroup;
  const {
    id,
    // 群組容器 ID
    formGroupClassName,
    // 表單群組額外 CSS 類別
    labelClassName,
    // 標籤區域 CSS 類別
    contentClassName,
    // 內容區域 CSS 類別
    inputID,
    // 關聯輸入框 ID
    label,
    // 標籤文字
    attribute = {},
    // 額外 HTML 屬性，預設為空物件
    style,
    // 群組容器樣式
    labelStyle,
    // 標籤區域樣式
    contentStyle,
    // 內容區域樣式
    border,
    // 是否顯示底部邊框
    inline,
    // 大螢幕時是否水平排列
    block,
    // 最大寬度排列
    alwaysInline,
    // 是否總是水平排列
    inlineContent,
    // 內容區域是否水平排列
    inlineContentPadding,
    // 水平排列時內容上邊距調整
    inlineContentWrap,
    // 內容區域是否允許換行
    alwaysInlineContent,
    // 內容區域是否總是水平排列
    inlineLabelCenter = true,
    // 水平排列時標籤垂直置中，預設為 true
    /**
     * 水平排列時標籤內邊距調整，預設為 true
     * 注意：如果是 checkbox、radio 或其他沒有 input padding-y 的元素，應設為 false
     */
    inlineLabelPadding,
    // 水平排列時標籤內邊距調整
    required,
    // 是否為必填欄位
    inputSize,
    // 輸入框尺寸
    infoText,
    // 小字說明文字
    subTitle,
    // 副標題文字
    errorText,
    // 錯誤提示文字
    error,
    // 是否已錯誤顯示並提示
    showSolidErrorIcon
    // 是否以 inline-svg 的方式顯示錯誤圖示在 html 中
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(id, "id")}${addAttribute([
    "form-input-group",
    // 基礎樣式類別
    {
      "border-bottom": border,
      // 底部邊框
      "inline-group": inline,
      // 大螢幕時水平排列
      "block-group": block,
      // 垂直排列
      "always-inline-group": alwaysInline,
      // 總是水平排列
      "input-group-required": required,
      // 必填欄位標記
      "input-group-padding-label": (inline || alwaysInline) && inlineLabelPadding,
      // 水平排列時標籤內邊距
      "input-group-center-label": (inline || alwaysInline) && inlineLabelCenter,
      // 水平排列時標籤置中
      "inline-group-content-padding": inlineContentPadding,
      // 水平排列時內容上邊距
      [`size_${inputSize}`]: inputSize
      // 輸入框尺寸類別
    },
    formGroupClassName
    // 額外的自定義類別
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${(label || subTitle) && renderTemplate`<div class="input-group-head">
                ${label && renderTemplate`<label${addAttribute([
    "input-group-label",
    // 基礎標籤樣式
    { "input-group-required-label": required },
    // 必填標籤樣式
    labelClassName
    // 自定義標籤類別
  ], "class:list")}${addAttribute(inputID, "for")}${addAttribute(labelStyle, "style")}>
                        ${renderSlot($$result, $$slots["label-left"])}
                        ${label}
                        ${renderSlot($$result, $$slots["label-right"])}
                    </label>`}
                ${subTitle && renderTemplate`<span class="input-group-sub-title">
                        ${subTitle}
                        ${renderSlot($$result, $$slots["sub-title-right"])}
                    </span>`}
                ${renderSlot($$result, $$slots["head-extra"])}
            </div>`}

    <div${addAttribute([
    "input-group-content",
    // 基礎內容樣式
    { "input-group-inline-content": inlineContent },
    // 中螢幕以上水平排列
    { "input-group-always-inline-content": alwaysInlineContent },
    // 總是水平排列
    { "input-group-inline-content-wrap": inlineContentWrap },
    // 允許換行
    contentClassName
    // 自定義內容類別
  ], "class:list")}${addAttribute(contentStyle, "style")}>
        ${renderSlot($$result, $$slots["default"])}
        ${renderSlot($$result, $$slots["info-text"], renderTemplate`
            ${infoText && renderTemplate`<span class="info-text">
                        <span>${infoText}</span>
                    </span>`}
        `)}
        ${renderSlot($$result, $$slots["error-text"], renderTemplate`
            ${Boolean(error) && renderTemplate`<span class="info-text error-text">
                        ${showSolidErrorIcon ? renderTemplate`${renderComponent($$result, "ErrorIcon", $$NotificationIcon, {})}
                                <span>${errorText}</span>` : errorText}
                    </span>`}
        `)}
    </div>

    ${renderSlot($$result, $$slots["right"])}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/group/inputGroup.astro", void 0);

export { $$InputGroup as $ };
