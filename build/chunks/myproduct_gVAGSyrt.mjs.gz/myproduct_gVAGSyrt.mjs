import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Myproduct = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6 19.8004C5.66863 19.8004 5.4 20.069 5.4 20.4004C5.4 20.7318 5.66863 21.0004 6 21.0004V20.4004V19.8004ZM14.4 21.0004H15V19.8004H14.4V20.4004V21.0004ZM6 20.4004V21.0004H14.4V20.4004V19.8004H6V20.4004Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
<path d="M21.4004 11C21.7315 11.0002 21.9998 11.2685 22 11.5996V20.4004C21.9998 20.7315 21.7315 20.9998 21.4004 21H16.5996C16.2685 20.9998 16.0002 20.7315 16 20.4004V11.5996C16.0002 11.2685 16.2685 11.0002 16.5996 11H21.4004ZM19 12C18.6689 12.0002 18.4006 12.2685 18.4004 12.5996C18.4004 12.9309 18.6688 13.2 19 13.2002C19.3314 13.2002 19.6006 12.931 19.6006 12.5996C19.6004 12.2684 19.3312 12 19 12Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
<rect x="10" y="17" width="2" height="4" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></rect>
<path d="M18.7998 4C19.4625 4 20 4.53745 20 5.2002V10H16C15.4477 10 15 10.4477 15 11V17H3.2002C2.53745 17 2 16.4625 2 15.7998V5.2002C2 4.53745 2.53745 4 3.2002 4H18.7998Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/hover/myproduct.astro", void 0);

export { $$Myproduct as default };
