import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$OrderAocc = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17.7998 2C19.0148 2 20 2.98517 20 4.2002V19.7998C20 21.0148 19.0148 22 17.7998 22H6.2002C4.98517 22 4 21.0148 4 19.7998V8H10.4004C10.7315 7.99979 10.9998 7.73145 11 7.40039V2H17.7998ZM15.4238 10.5762C15.1895 10.3419 14.8105 10.3419 14.5762 10.5762L11 14.1523L9.42383 12.5762C9.18951 12.3419 8.81049 12.3419 8.57617 12.5762C8.34186 12.8105 8.34186 13.1895 8.57617 13.4238L10.5762 15.4238C10.8105 15.6581 11.1895 15.6581 11.4238 15.4238L15.4238 11.4238C15.6581 11.1895 15.6581 10.8105 15.4238 10.5762ZM9.7998 6.7998H4.47754L9.7998 2.33496V6.7998Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/hover/order aocc.astro", void 0);

export { $$OrderAocc as default };
