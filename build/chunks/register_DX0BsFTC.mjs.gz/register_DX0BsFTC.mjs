import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Register = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14 3.59961H5.19961C4.31595 3.59961 3.59961 4.31595 3.59961 5.19961V18.8C3.59961 19.6837 4.31595 20.4 5.19961 20.4H18.8C19.6837 20.4 20.4 19.6837 20.4 18.8V10" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></path>
<path d="M8.5 15.5L9.5 11.5L18.0858 2.91421C18.8668 2.13317 20.1332 2.13317 20.9142 2.91421L21.0858 3.08579C21.8668 3.86684 21.8668 5.13316 21.0858 5.91421L12.5 14.5L8.5 15.5Z" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M15.5 5.5L18.5 8.5" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/register.astro", void 0);

export { $$Register as default };
