import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$Events = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M19.7998 5C21.0148 5 22 5.98517 22 7.2002V17.7998C22 19.0148 21.0148 20 19.7998 20H4.2002C2.98517 20 2 19.0148 2 17.7998V7.2002C2 5.98517 2.98517 5 4.2002 5H19.7998ZM15.4238 10.1758C15.1895 9.94147 14.8105 9.94147 14.5762 10.1758L11 13.752L9.42383 12.1758C9.18951 11.9415 8.81049 11.9415 8.57617 12.1758C8.34186 12.4101 8.34186 12.7891 8.57617 13.0234L10.5762 15.0234C10.8105 15.2578 11.1895 15.2578 11.4238 15.0234L15.4238 11.0234C15.6581 10.7891 15.6581 10.4101 15.4238 10.1758Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
<path d="M8.5 3.59961V6.4" stroke="var(--color-blue-500, var(--color-blue-500, #006ce1))" stroke-width="1.2" stroke-linecap="round"></path>
<path d="M15.5 3.59961V6.4" stroke="var(--color-blue-500, var(--color-blue-500, #006ce1))" stroke-width="1.2" stroke-linecap="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/hover/events.astro", void 0);

export { $$Events as default };
