import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$TypeIconFbSizeLg = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip_fb_default_g)">
<rect width="32" height="32" rx="16" fill="white"></rect>
<path d="M31.9993 16.0583C31.9993 7.22197 24.836 0.0585938 15.9997 0.0585938C7.16337 0.0585938 0 7.22197 0 16.0583C0 23.5615 5.16597 29.8577 12.1348 31.5869V20.9478H8.83567V16.0583H12.1348V13.9515C12.1348 8.50576 14.5994 5.98167 19.9458 5.98167C20.9596 5.98167 22.7086 6.18071 23.4242 6.3791V10.811C23.0466 10.7713 22.3906 10.7515 21.5758 10.7515C18.9526 10.7515 17.9388 11.7454 17.9388 14.329V16.0583H23.165L22.267 20.9478H17.9388V31.9408C25.8612 30.9841 31.9993 24.2386 31.9993 16.0583Z" fill="var(--color-facebook, #0866FF)"></path>
</g>
<defs>
<clipPath id="clip_fb_default">
<rect width="32" height="32" rx="16" fill="white"></rect>
</clipPath>
</defs>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/social/svg-astro/type_icon_fb-size_lg.astro", void 0);

export { $$TypeIconFbSizeLg as default };
