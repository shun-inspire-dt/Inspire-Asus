import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, u as unescapeHTML, d as renderTemplate, r as renderComponent, F as Fragment, f as renderHead } from './astro/server_Bjgbv9en.mjs';
/* empty css                           */
/* empty css                         */
/* empty css                         */
/* empty css                        */

const data = [
  {
    title: "解決方案",
    links: [
      [
        { link: "/solutions?category=科技與製造", linkText: "科技與製造" },
        { link: "/solutions?category=教育與訓練", linkText: "教育與訓練" },
        { link: "/solutions?category=零售與電商", linkText: "零售與電商" },
        { link: "/solutions?category=建築與工程", linkText: "建築與工程" }
      ],
      [
        { link: "/solutions?category=餐飲與連鎖服務", linkText: "餐飲與連鎖服務" },
        { link: "/solutions?category=旅宿與觀光", linkText: "旅宿與觀光" },
        { link: "/solutions?category=醫療與照護", linkText: "醫療與照護" },
        { link: "/solutions?category=顧問服務", linkText: "顧問服務" }
      ]
    ]
  },
  {
    title: "服務",
    links: [
      [
        { link: "/ivy?category=雲端與基礎設施", linkText: "雲端與基礎設施" },
        { link: "/ivy?category=數據分析與智能應用", linkText: "數據分析與智能應用" },
        { link: "/ivy?category=資安與合規服務", linkText: "資安與合規服務" },
        { link: "/ivy?category=顧問與專案交付", linkText: "顧問與專案交付" }
      ],
      [
        { link: "/ivy?category=企業系統導入與整合", linkText: "企業系統導入與整合" },
        { link: "/ivy?category=IT資源與資產服務", linkText: "IT資源與資產服務" },
        { link: "/ivy?category=應用開發與客製化", linkText: "應用開發與客製化" }
      ]
    ]
  },
  {
    title: "資源",
    links: [
      [
        { link: "/news", linkText: "最新消息" },
        { link: "/success", linkText: "成功案例" }
      ]
    ]
  },
  {
    title: "關於我們",
    links: [
      [
        { link: "/aboutus", linkText: "關於我們" },
        { link: "/contactus", linkText: "聯絡我們" },
        { link: "https://www.asus.com/", linkText: "華碩官網", external: true }
      ]
    ]
  }
];

const ext = "";

const $$Astro$C = createAstro("https://www.Asus.com.tw");
const $$A = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$C, $$props, $$slots);
  Astro2.self = $$A;
  const {
    IDName,
    className,
    link,
    extend,
    target,
    title,
    html,
    variant,
    button,
    round = true,
    disabled,
    attribute = {},
    style,
    block
  } = Astro2.props;
  const href = link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#";
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(IDName, "id")}${addAttribute(className, "class:list")}${addAttribute(href, "href")}${addAttribute(target, "target")}${addAttribute(disabled, "disabled")}${addAttribute(variant, "data-variant")}${addAttribute(title, "title")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>${renderSlot($$result, $$slots["default"], renderTemplate`${title}`)}
${unescapeHTML(html)}</a>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/a.astro", void 0);

const $$Astro$B = createAstro("https://www.Asus.com.tw");
const $$CollapseArrow = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$B, $$props, $$slots);
  Astro2.self = $$CollapseArrow;
  const { IDName, className, style, attribute = {}, Tag = "span" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "collapseArrow"], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.5 0.5L6.00001 6.2L0.5 0.5" stroke="var(--color-gray-900, #181818)" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/collapseArrow.astro", void 0);

const $$Astro$A = createAstro("https://www.Asus.com.tw");
const $$Collapse = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$A, $$props, $$slots);
  Astro2.self = $$Collapse;
  const { IDName, className, buttonClassName, style, attribute = {}, title, show, parent, data = [] } = Astro2.props;
  const componentId = IDName || `collapse-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute([
    "Collapse",
    className
  ], "class:list")}${addAttribute({ ...style }, "style")} data-collapse${spreadAttributes(attribute)}>
    <button type="button"${addAttribute([
    "Collapse-button",
    buttonClassName
  ], "class:list")}${addAttribute(title, "title")} data-bs-toggle="collapse"${addAttribute(`#${componentId}`, "data-bs-target")}${addAttribute(show, "aria-expanded")}${addAttribute(componentId, "data-bs-controls")}>
        ${renderSlot($$result, $$slots["title"], renderTemplate`${title}`)}
        ${renderComponent($$result, "CollapseArrow", $$CollapseArrow, {})}
    </button>
    <div${addAttribute(componentId, "id")}${addAttribute(["collapse", { show }], "class:list")}${addAttribute(parent, "data-bs-parent")}>
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/collapse.astro", void 0);

const $$Logo$1 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="125" height="11" viewBox="0 0 125 11" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M11.4824 9.43648C11.0167 9.43648 10.6119 9.38104 10.2682 9.26461C9.92443 9.14818 9.64164 9.01513 9.41432 8.87098C9.15374 8.70465 8.93199 8.51057 8.74902 8.28879L9.56958 7.46824C9.68601 7.62902 9.84126 7.77317 10.0298 7.90623C10.1906 8.01712 10.3901 8.11694 10.6341 8.20565C10.8725 8.29436 11.1608 8.34426 11.4879 8.34426C11.7374 8.34426 11.9537 8.311 12.1422 8.25001C12.3307 8.18902 12.4915 8.10585 12.6245 8.00051C12.7576 7.89517 12.8518 7.77317 12.9184 7.63456C12.9849 7.49595 13.0182 7.35181 13.0182 7.19657C13.0182 6.98588 12.9627 6.81401 12.8463 6.6754C12.7299 6.54233 12.5746 6.4259 12.3861 6.33165C12.1976 6.2374 11.9814 6.15978 11.743 6.09325C11.5046 6.02671 11.2551 5.95463 11 5.87701C10.745 5.79939 10.4955 5.71068 10.2571 5.60534C10.0187 5.5 9.80245 5.36694 9.61394 5.20061C9.42544 5.03428 9.27018 4.83467 9.15375 4.59626C9.03732 4.35785 8.98188 4.05846 8.98188 3.69808C8.98188 3.41531 9.04287 3.14362 9.1593 2.88304C9.28128 2.62245 9.45315 2.39514 9.68047 2.20109C9.90779 2.00704 10.1795 1.85182 10.5066 1.73538C10.8282 1.6245 11.1941 1.56348 11.6044 1.56348C11.998 1.56348 12.3418 1.61339 12.6412 1.71874C12.9405 1.81853 13.19 1.93496 13.3952 2.05693C13.6336 2.20109 13.8387 2.36743 14.0051 2.55039L13.1845 3.37094C13.0681 3.23788 12.935 3.12145 12.7798 3.02165C12.6467 2.93294 12.4804 2.84977 12.2808 2.77769C12.0812 2.70007 11.8538 2.66128 11.5988 2.66128C11.1331 2.66128 10.7783 2.76663 10.5398 2.97177C10.3014 3.17691 10.1794 3.42086 10.1794 3.69808C10.1794 3.90876 10.2349 4.08064 10.3513 4.21925C10.4678 4.35231 10.623 4.46874 10.8115 4.563C11 4.65725 11.2162 4.73487 11.4546 4.8014C11.6931 4.86793 11.9426 4.94001 12.1976 5.01209C12.4526 5.08971 12.7022 5.17841 12.9406 5.28376C13.179 5.3891 13.3952 5.52215 13.5837 5.68849C13.7722 5.85482 13.9275 6.05443 14.0439 6.29284C14.1603 6.53124 14.2158 6.83064 14.2158 7.19102C14.2158 7.49042 14.1492 7.77317 14.0217 8.05039C13.8942 8.32206 13.7112 8.56049 13.4784 8.76563C13.2455 8.97078 12.9572 9.13157 12.619 9.25354C12.2863 9.37552 11.9038 9.43648 11.4824 9.43648Z" fill="currentColor"></path>
    <path d="M19.2281 9.43625C18.7458 9.43625 18.3078 9.35864 17.9141 9.20339C17.5205 9.04815 17.1822 8.82638 16.8995 8.54916C16.6167 8.2664 16.3949 7.93375 16.2397 7.55118C16.0844 7.16308 16.0068 6.74171 16.0068 6.27044V1.67969H17.21V6.27044C17.21 6.56983 17.2599 6.84705 17.3652 7.10209C17.465 7.35713 17.6092 7.57891 17.7921 7.76187C17.9751 7.94484 18.1913 8.08897 18.4353 8.19432C18.6848 8.29411 18.9509 8.34957 19.2337 8.34957C19.5053 8.34957 19.7604 8.2941 20.0099 8.18322C20.2594 8.07233 20.4701 7.92818 20.653 7.73967C20.836 7.55117 20.9801 7.33493 21.091 7.07989C21.2019 6.82485 21.2574 6.5532 21.2574 6.27044V1.67969H22.4605V6.27044C22.4605 6.73616 22.3829 7.16308 22.2276 7.55118C22.0724 7.93929 21.8506 8.27194 21.5679 8.54916C21.2851 8.83193 20.9469 9.04815 20.5532 9.20339C20.1429 9.35864 19.7049 9.43625 19.2281 9.43625Z" fill="currentColor"></path>
    <path d="M26.9727 9.43648C26.5069 9.43648 26.1022 9.38104 25.7584 9.26461C25.4147 9.14818 25.1319 9.01513 24.9046 8.87098C24.644 8.70465 24.4222 8.51057 24.2393 8.28879L25.0598 7.46824C25.1763 7.62902 25.3315 7.77317 25.52 7.90623C25.6808 8.01712 25.8804 8.11694 26.1244 8.20565C26.3628 8.29436 26.6511 8.34426 26.9782 8.34426C27.2277 8.34426 27.4439 8.311 27.6324 8.25001C27.821 8.18902 27.9817 8.10585 28.1148 8.00051C28.2479 7.89517 28.3421 7.77317 28.4086 7.63456C28.4752 7.49595 28.5084 7.35181 28.5084 7.19657C28.5084 6.98588 28.453 6.81401 28.3366 6.6754C28.2201 6.54233 28.0649 6.4259 27.8764 6.33165C27.6879 6.2374 27.4716 6.15978 27.2332 6.09325C26.9948 6.02671 26.7453 5.95463 26.4903 5.87701C26.2353 5.79939 25.9858 5.71068 25.7473 5.60534C25.5089 5.5 25.2927 5.36694 25.1042 5.20061C24.9157 5.03428 24.7605 4.83467 24.644 4.59626C24.5276 4.35785 24.4721 4.05846 24.4721 3.69808C24.4721 3.41531 24.5331 3.14362 24.6496 2.88304C24.7715 2.62245 24.9434 2.39514 25.1707 2.20109C25.3981 2.00704 25.6697 1.85182 25.9968 1.73538C26.3184 1.6245 26.6843 1.56348 27.0946 1.56348C27.4883 1.56348 27.832 1.61339 28.1314 1.71874C28.4308 1.81853 28.6803 1.93496 28.8854 2.05693C29.1239 2.20109 29.329 2.36743 29.4953 2.55039L28.6748 3.37094C28.5583 3.23788 28.4253 3.12145 28.27 3.02165C28.137 2.93294 27.9707 2.84977 27.7711 2.77769C27.5715 2.70007 27.3441 2.66128 27.0891 2.66128C26.6233 2.66128 26.2685 2.76663 26.0301 2.97177C25.7917 3.17691 25.6697 3.42086 25.6697 3.69808C25.6697 3.90876 25.7252 4.08064 25.8416 4.21925C25.958 4.35231 26.1133 4.46874 26.3018 4.563C26.4903 4.65725 26.7065 4.73487 26.9449 4.8014C27.1833 4.86793 27.4328 4.94001 27.6879 5.01209C27.9429 5.08971 28.1924 5.17841 28.4308 5.28376C28.6692 5.3891 28.8855 5.52215 29.074 5.68849C29.2625 5.85482 29.4177 6.05443 29.5342 6.29284C29.6506 6.53124 29.706 6.83064 29.706 7.19102C29.706 7.49042 29.6395 7.77317 29.512 8.05039C29.3844 8.32206 29.2015 8.56049 28.9686 8.76563C28.7358 8.97078 28.4475 9.13157 28.1093 9.25354C27.7766 9.37552 27.394 9.43648 26.9727 9.43648Z" fill="currentColor"></path>
    <path d="M6.17644 9.32553H7.43499L4.37452 1.67432H3.0605L0 9.32553H1.25858L1.90172 7.68997H5.53327L6.17644 9.32553ZM2.35636 6.54228L3.72029 3.09367L5.08418 6.54228H2.35636Z" fill="currentColor"></path>
    <path d="M121.31 0L124.737 5.49445L121.31 11H116.892L120.318 5.49445L116.892 0H121.31Z" fill="currentColor"></path>
    <path d="M47.986 5.33362L45.4744 1.67432H46.8938L48.7511 4.46315L50.6085 1.67432H52.0279L49.5107 5.33362L52.2441 9.32553H50.8247L48.7456 6.2096L46.6664 9.32553H45.2471L47.986 5.33362Z" fill="currentColor"></path>
    <path d="M77.0054 9.32571L75.015 6.43712C75.0538 6.42603 75.0982 6.41494 75.137 6.40385C75.453 6.27633 75.7191 6.10445 75.952 5.87713C76.1793 5.65536 76.3623 5.39479 76.4898 5.09539C76.6173 4.796 76.6838 4.4744 76.6838 4.13064C76.6838 3.78689 76.6173 3.46533 76.4898 3.17148C76.3623 2.87208 76.1849 2.61151 75.952 2.38974C75.7247 2.16797 75.453 1.99054 75.137 1.86302C74.821 1.7355 74.4827 1.66895 74.1113 1.66895H71.0508V9.3202H72.2539V7.29094V6.58683V5.49457V5.25617V2.7612H74.1113C74.2998 2.7612 74.4772 2.79447 74.6491 2.86655C74.8154 2.93862 74.9651 3.03289 75.0871 3.15486C75.209 3.27684 75.3089 3.42653 75.3754 3.59286C75.4475 3.75919 75.4807 3.93659 75.4807 4.13064C75.4807 4.31915 75.4475 4.49659 75.3754 4.66847C75.3089 4.8348 75.209 4.98448 75.0871 5.10646C74.9651 5.22843 74.8154 5.32824 74.6491 5.39478C74.4827 5.46685 74.3053 5.50012 74.1113 5.50012H72.9968L73.7564 6.59234H73.762L75.6471 9.32571H77.0054Z" fill="currentColor"></path>
    <path d="M59.7906 3.17148C59.6631 2.87208 59.4856 2.61151 59.2528 2.38974C59.0254 2.16797 58.7538 1.99054 58.4378 1.86302C58.1217 1.7355 57.7835 1.66895 57.412 1.66895H54.3516V9.3202H55.5547V7.29094V6.58683V5.49457V5.25617V2.7612H57.412C57.6005 2.7612 57.778 2.79447 57.9499 2.86655C58.1162 2.93862 58.2659 3.03289 58.3878 3.15486C58.5098 3.27684 58.6096 3.42653 58.6762 3.59286C58.7482 3.75919 58.7815 3.93659 58.7815 4.13064C58.7815 4.31915 58.7482 4.49659 58.6762 4.66847C58.6096 4.8348 58.5098 4.98448 58.3878 5.10646C58.2659 5.22843 58.1162 5.32824 57.9499 5.39478C57.7835 5.46685 57.6061 5.50012 57.412 5.50012H56.2976L57.0572 6.59234H57.412C57.7835 6.59234 58.1273 6.52582 58.4378 6.3983C58.7482 6.27078 59.0199 6.0989 59.2528 5.87158C59.4801 5.64981 59.6631 5.38924 59.7906 5.08984C59.9181 4.79045 59.9846 4.46888 59.9846 4.12513C59.9846 3.79247 59.9181 3.47088 59.7906 3.17148Z" fill="currentColor"></path>
    <path d="M43.1567 2.822V1.67432H37.751V2.822V4.92334V6.07099V8.17788V9.32553H43.1567V8.17788H38.8986V6.07099H43.1567V4.92334H38.8986V2.822H43.1567Z" fill="currentColor"></path>
    <path d="M67.7189 2.822V1.67432H62.3076V2.822V4.92334V6.07099V8.17788V9.32553H67.7189V8.17788H63.4553V6.07099H67.7189V4.92334H63.4553V2.822H67.7189Z" fill="currentColor"></path>
    <path d="M84.4247 1.67432H78.6309V1.68542L79.4126 2.822H80.9262V9.32553H82.1294V2.822H84.4247V1.67432Z" fill="currentColor"></path>
    <path d="M104.877 1.61865H107.938C108.282 1.61865 108.592 1.67409 108.869 1.78498C109.152 1.89586 109.39 2.04001 109.596 2.22297C109.801 2.40593 109.956 2.62218 110.067 2.86613C110.178 3.11563 110.233 3.37065 110.233 3.64233C110.233 3.93618 110.183 4.17461 110.083 4.36312C109.984 4.55163 109.878 4.70686 109.762 4.83438C109.629 4.97299 109.479 5.08387 109.302 5.17258C109.551 5.27237 109.767 5.41098 109.956 5.5884C110.122 5.73256 110.272 5.92662 110.411 6.15949C110.544 6.3979 110.61 6.68621 110.61 7.02996C110.61 7.32935 110.549 7.61211 110.422 7.88933C110.3 8.161 110.128 8.3994 109.9 8.60454C109.679 8.80968 109.413 8.97047 109.108 9.09244C108.803 9.21442 108.465 9.27542 108.093 9.27542H104.866V1.61865H104.877ZM107.938 4.73458C108.265 4.73458 108.531 4.64032 108.731 4.44626C108.93 4.25221 109.03 4.00273 109.03 3.69779C109.03 3.39285 108.93 3.14333 108.731 2.94928C108.531 2.75523 108.265 2.661 107.938 2.661H106.08V4.74013H107.938V4.73458ZM108.104 8.23308C108.492 8.23308 108.803 8.11109 109.052 7.87268C109.296 7.63427 109.418 7.33488 109.418 6.97449C109.418 6.61965 109.296 6.32026 109.052 6.07631C108.808 5.8379 108.492 5.71595 108.104 5.71595H106.08V8.22753H108.104V8.23308Z" fill="currentColor"></path>
    <path d="M98.9391 9.38107C98.4567 9.38107 98.0187 9.30346 97.625 9.14822C97.2314 8.99298 96.8932 8.77117 96.6104 8.49395C96.3276 8.21119 96.1059 7.87854 95.9506 7.49597C95.7954 7.10787 95.7178 6.6865 95.7178 6.21523V1.62451H96.9209V6.21523C96.9209 6.51462 96.9708 6.79184 97.0762 7.04688C97.176 7.30192 97.3201 7.5237 97.503 7.70666C97.686 7.88963 97.9023 8.0338 98.1462 8.13914C98.3902 8.24448 98.6618 8.29436 98.9446 8.29436C99.2163 8.29436 99.4713 8.23893 99.7208 8.12804C99.9703 8.01715 100.181 7.87301 100.364 7.6845C100.547 7.49599 100.691 7.27976 100.802 7.02472C100.913 6.76968 100.968 6.49799 100.968 6.21523V1.62451H102.171V6.21523C102.171 6.68095 102.094 7.10787 101.939 7.49597C101.783 7.88408 101.562 8.21674 101.279 8.49395C100.996 8.77672 100.658 8.99298 100.264 9.14822C99.8594 9.30346 99.4214 9.38107 98.9391 9.38107Z" fill="currentColor"></path>
    <path d="M87.0635 1.64111H88.261V4.84577H92.009V1.64111H93.2066V9.248H92.009V5.93245H88.261V9.248H87.0635V1.64111Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/footer/logo.astro", void 0);

const $$Astro$z = createAstro("https://www.Asus.com.tw");
const $$Footer = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$z, $$props, $$slots);
  Astro2.self = $$Footer;
  const { IDName = "footer", className, style, attribute = {}, pages = [], showBorderTop = false } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<footer${addAttribute(IDName, "id")}${addAttribute(["footer", className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="footer-top">
        ${showBorderTop && renderTemplate`<div class="footer-top-border"></div>`}
        <div class="footer-top-body">
            <div class="footer-top-body-top">
                ${renderComponent($$result, "A", $$A, { "link": "/", "className": "footer-logo", "title": "Asus", "target": "_self" }, { "default": ($$result2) => renderTemplate`
                    ${renderComponent($$result2, "Logo", $$Logo$1, {})}
                ` })}
                <div class="footer-breadcrumb">
                    ${pages.map((page) => renderTemplate`<span class="footer-breadcrumb-item">
                                <span>/ </span>
                                ${renderComponent($$result, "A", $$A, { "className": "footer-breadcrumb-item-link", "target": "_self", "title": page }, { "default": ($$result2) => renderTemplate`${page}` })}
                            </span>`)}
                </div>
            </div>
            <div class="footer-links">
                ${data.map((item, i) => renderTemplate`<div class="footer-links-item">
                            <strong class="footer-links-title">${item.title}</strong>
                            <div class="footer-links-body">
                                ${item.links.map((x) => renderTemplate`<ul class="footer-links-body-item">
                                        ${x.map((y) => renderTemplate`<li class="footer-links-body-item-li">
                                                ${renderComponent($$result, "A", $$A, { "className": "footer-links-body-item-link", "link": y.link, "title": y.linkText, "extend": y.external })}
                                            </li>`)}
                                    </ul>`)}
                            </div>
                        </div>`)}
            </div>
            <div id="FooterMobile" class="footer-mobile">
                ${data.map((item, i) => renderTemplate`${renderComponent($$result, "Collapse", $$Collapse, { "title": item.title, "buttonClassName": "footer-mobile-title", "style": { ...i === 0 ? { "--collapse-border-width": "0" } : {} }, "parent": "#FooterMobile" }, { "default": ($$result2) => renderTemplate`
                            <div class="footer-mobile-body">
                                ${item.links.map((x) => renderTemplate`<div class="footer-mobile-body-item">
                                        ${x.map((y) => renderTemplate`${renderComponent($$result2, "A", $$A, { "className": "footer-mobile-body-item-link", "link": y.link, "title": y.linkText, "extend": y.external })}`)}
                                    </div>`)}
                            </div>
                        ` })}`)}
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="footer-bottom-body">
            <span class="footer-copyright">© 2025 ASUSTeK Computer Inc. All rights reserved.</span>
            <div class="footer-bottom-body-links">
                ${renderComponent($$result, "A", $$A, { "className": "footer-bottom-body-links-item" }, { "default": ($$result2) => renderTemplate`Cookie 設定` })}
                <div class="footer-bottom-body-links-bar"></div>
                ${renderComponent($$result, "A", $$A, { "className": "footer-bottom-body-links-item" }, { "default": ($$result2) => renderTemplate`隱私權保護政策` })}
                <div class="footer-bottom-body-links-bar"></div>
                ${renderComponent($$result, "A", $$A, { "className": "footer-bottom-body-links-item" }, { "default": ($$result2) => renderTemplate`使用者條款` })}
            </div>
        </div>
    </div>
</footer>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/footer/footer.astro", void 0);

const $$Astro$y = createAstro("https://www.Asus.com.tw");
const $$MemberFooter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$y, $$props, $$slots);
  Astro2.self = $$MemberFooter;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<footer${addAttribute(IDName, "id")}${addAttribute([className, "member-footer"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="member-footer-inner">
        <div class="member-footer-body">
            <span class="member-footer-copyright">© 2025 ASUSTeK Computer Inc. All rights reserved.</span>
            <div class="member-footer-body-links">
                ${renderComponent($$result, "A", $$A, { "className": "member-footer-body-links-item" }, { "default": ($$result2) => renderTemplate`使用者條款` })}
                <div class="member-footer-body-links-bar"></div>
                ${renderComponent($$result, "A", $$A, { "className": "member-footer-body-links-item" }, { "default": ($$result2) => renderTemplate`隱私權保護政策` })}
            </div>
        </div>
    </div>
</footer>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/footer/memberFooter.astro", void 0);

const NavsData = [
  {
    title: "解決方案",
    link: "/solution",
    children: [
      {
        title: "解決方案",
        subTitle: "選擇 ASUS Business，不只是選擇技術，更是選擇可靠的合作夥伴。我們以創新、穩定與安全為核心，助力企業持續成長。",
        linkText: "探索解決方案",
        link: "/solution",
        children: [
          {
            title: "依產業",
            links: [
              [{ linkText: "科技與製造" }, { linkText: "零售與電商" }, { linkText: "餐飲與連鎖服務" }, { linkText: "医療與照護" }, { linkText: "科技照護設備及智慧居家系統" }],
              [{ linkText: "教育與訓練" }, { linkText: "建築與工程" }, { linkText: "旅宿與觀光" }, { linkText: "顧問服務" }, { linkText: "策略規劃與企業流程再造" }]
            ]
          },
          {
            title: "依企業規模",
            links: [
              [{ linkText: "微型 (1-10人)" }, { linkText: "小型 (10-49人)" }, { linkText: "中型 (50-199人)" }, { linkText: "大型 (200-500人)" }],
              [{ linkText: "巨型 (500人以上)" }, { linkText: "全球企業 (超過五百名以上)" }]
            ]
          }
        ]
      }
    ]
  },
  {
    title: "合作夥伴",
    link: "/ivy",
    children: [
      {
        title: "合作夥伴",
        subTitle: "我們與各領域的專業夥伴攜手合作，建立跨產業的生態系，為企業提供更完整、更具價值的解決方案。",
        linkText: "探索合作夥伴",
        link: "/ivy",
        children: [
          {
            title: "依照類型",
            links: [
              [{ linkText: "雲端與基礎設施" }, { linkText: "資安與合規服務" }, { linkText: "企業系統導入整合" }, { linkText: "應用開發與客製化" }],
              [{ linkText: "數據分析與智能應用" }, { linkText: "顧問與專案交付服務" }, { linkText: "IT資源與資產服務" }]
            ]
          },
          {
            title: "依服務地區",
            links: [
              [{ linkText: "北部地區" }, { linkText: "中部地區" }, { linkText: "南部地區" }, { linkText: "東部地區" }],
              [{ linkText: "離島地區" }]
            ]
          }
        ]
      }
    ]
  },
  {
    title: "成功案例",
    link: "/success"
  },
  {
    title: "最新消息",
    link: "/news"
  },
  {
    title: "關於我們",
    link: "/aboutus"
  }
];

const $$Astro$x = createAstro("https://www.Asus.com.tw");
const $$MegaMenu$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$x, $$props, $$slots);
  Astro2.self = $$MegaMenu$1;
  const {
    IDName,
    className,
    style,
    attribute = {},
    data = [],
    position = "left",
    type = "dropdown",
    transition = true
  } = Astro2.props;
  return renderTemplate`<!-- Mega Menu Container - 大型選單容器 -->${maybeRenderHead()}<div${addAttribute(IDName ? `${IDName}mega-menu` : void 0, "id")}${addAttribute(["mega-menu", className], "class:list")}${addAttribute(style, "style")} data-mega-menu${addAttribute(position, "data-mega-menu-position")}${addAttribute(type, "data-mega-menu-type")}${spreadAttributes(transition ? { "data-mega-menu-transition": "" } : {})}${spreadAttributes(attribute)}>
    
    <div class="mega-menu-body">
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/megaMenu/megaMenu.astro", void 0);

const $$Arrow12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="4" height="7" viewBox="0 0 4 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.146751 0.14169C0.240501 0.0518466 0.349876 0.00497159 0.474876 0.00106534C0.603782 -0.00674716 0.719016 0.0284091 0.820579 0.106534L0.855735 0.14169L3.68581 2.97177C3.73269 3.01864 3.76784 3.07333 3.79128 3.13583C3.81863 3.19442 3.8323 3.25692 3.8323 3.32333C3.8323 3.38974 3.81863 3.45419 3.79128 3.51669C3.76784 3.57919 3.73269 3.63388 3.68581 3.68075L0.855735 6.50497C0.758079 6.60263 0.638938 6.65146 0.498313 6.65146C0.361594 6.65146 0.244407 6.60263 0.146751 6.50497C0.0490945 6.40732 0.000266335 6.29013 0.000266335 6.15341C0.000266335 6.01669 0.0490945 5.8995 0.146751 5.80185L2.62527 3.32333L0.146751 0.850675L0.117454 0.809659C0.0354226 0.712003 -0.00363991 0.600675 0.000266335 0.475675C0.00807884 0.346768 0.056907 0.23544 0.146751 0.14169Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-12.astro", void 0);

const $$Arrow13 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="5" height="8" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.15898 0.153498C0.260542 0.0561671 0.379032 0.00538589 0.514449 0.00115412C0.654097 -0.00730942 0.778934 0.0307765 0.88896 0.115412L0.927046 0.153498L3.99296 3.21942C4.04375 3.2702 4.08183 3.32944 4.10722 3.39715C4.13684 3.46063 4.15166 3.52834 4.15166 3.60028C4.15166 3.67222 4.13684 3.74204 4.10722 3.80975C4.08183 3.87746 4.04375 3.9367 3.99296 3.98748L0.927046 7.04705C0.821252 7.15285 0.692183 7.20574 0.539839 7.20574C0.391727 7.20574 0.264774 7.15285 0.15898 7.04705C0.0531857 6.94126 0.00028853 6.8143 0.00028853 6.66619C0.00028853 6.51808 0.0531857 6.39113 0.15898 6.28533L2.84404 3.60028L0.15898 0.921564L0.127242 0.877131C0.0383745 0.771336 -0.00394324 0.650731 0.00028853 0.515314C0.00875207 0.375666 0.0616492 0.25506 0.15898 0.153498Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-13.astro", void 0);

const $$Arrow14 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="5" height="8" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.171209 0.165305C0.280584 0.0604877 0.408188 0.00580019 0.554022 0.0012429C0.704412 -0.00787169 0.838852 0.0331439 0.957342 0.12429L0.998358 0.165305L4.30012 3.46706C4.3548 3.52175 4.39582 3.58555 4.42316 3.65847C4.45506 3.72683 4.47101 3.79975 4.47101 3.87722C4.47101 3.95469 4.45506 4.02989 4.42316 4.10281C4.39582 4.17572 4.3548 4.23952 4.30012 4.29421L0.998358 7.58913C0.884425 7.70307 0.745428 7.76003 0.581365 7.76003C0.42186 7.76003 0.285141 7.70307 0.171209 7.58913C0.0572769 7.4752 0.000310724 7.33848 0.000310724 7.17898C0.000310724 7.01947 0.0572769 6.88275 0.171209 6.76882L3.06281 3.87722L0.171209 0.992454L0.137029 0.944602C0.0413263 0.83067 -0.00424657 0.700787 0.000310724 0.554954C0.00942531 0.404563 0.0663914 0.27468 0.171209 0.165305Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-14.astro", void 0);

const $$Arrow16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="9" viewBox="0 0 6 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.195668 0.18892C0.320668 0.0691288 0.466501 0.00662879 0.633168 0.00142045C0.805043 -0.00899621 0.958688 0.0378788 1.09411 0.142045L1.14098 0.18892L4.91442 3.96236C4.97692 4.02486 5.02379 4.09777 5.05504 4.18111C5.0915 4.25923 5.10973 4.34257 5.10973 4.43111C5.10973 4.51965 5.0915 4.60559 5.05504 4.68892C5.02379 4.77225 4.97692 4.84517 4.91442 4.90767L1.14098 8.6733C1.01077 8.8035 0.851918 8.86861 0.664418 8.86861C0.482126 8.86861 0.325876 8.8035 0.195668 8.6733C0.0654593 8.54309 0.000355114 8.38684 0.000355114 8.20455C0.000355114 8.02225 0.0654593 7.866 0.195668 7.7358L3.50036 4.43111L0.195668 1.13423L0.156605 1.07955C0.0472301 0.949337 -0.00485322 0.8009 0.000355114 0.634233C0.0107718 0.462358 0.0758759 0.31392 0.195668 0.18892Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-16.astro", void 0);

const $$Arrow18 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.220126 0.212536C0.360751 0.0777699 0.524814 0.00745739 0.712314 0.00159801C0.905673 -0.0101207 1.07852 0.0426136 1.23087 0.159801L1.2836 0.212536L5.52872 4.45765C5.59903 4.52797 5.65177 4.61 5.68692 4.70375C5.72794 4.79164 5.74845 4.88539 5.74845 4.985C5.74845 5.08461 5.72794 5.18129 5.68692 5.27504C5.65177 5.36879 5.59903 5.45082 5.52872 5.52113L1.2836 9.75746C1.13712 9.90394 0.958407 9.97718 0.74747 9.97718C0.542392 9.97718 0.36661 9.90394 0.220126 9.75746C0.0736417 9.61097 0.000399503 9.43519 0.000399503 9.23011C0.000399503 9.02504 0.0736417 8.84925 0.220126 8.70277L3.9379 4.985L0.220126 1.27601L0.176181 1.21449C0.0531339 1.068 -0.00545987 0.901012 0.000399503 0.713512C0.0121183 0.520153 0.0853604 0.353161 0.220126 0.212536Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-18.astro", void 0);

const $$Arrow20 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.244585 0.236151C0.400835 0.086411 0.583126 0.00828598 0.79146 0.00177557C1.0063 -0.0112453 1.19836 0.0473485 1.36763 0.177557L1.42623 0.236151L6.14302 4.95295C6.22115 5.03107 6.27974 5.12222 6.3188 5.22639C6.36438 5.32404 6.38716 5.42821 6.38716 5.53889C6.38716 5.64956 6.36438 5.75698 6.3188 5.86115C6.27974 5.96532 6.22115 6.05646 6.14302 6.13459L1.42623 10.8416C1.26346 11.0044 1.0649 11.0858 0.830522 11.0858C0.602657 11.0858 0.407345 11.0044 0.244585 10.8416C0.0818241 10.6789 0.000443892 10.4835 0.000443892 10.2557C0.000443892 10.0278 0.0818241 9.8325 0.244585 9.66974L4.37544 5.53889L0.244585 1.41779L0.195756 1.34943C0.0590376 1.18667 -0.00606652 1.00112 0.000443892 0.792791C0.0134647 0.577947 0.0948449 0.392401 0.244585 0.236151Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-20.astro", void 0);

const $$Arrow24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.293501 0.283381C0.481001 0.103693 0.699751 0.00994318 0.949751 0.00213068C1.20756 -0.0134943 1.43803 0.0568182 1.64116 0.213068L1.71147 0.283381L7.37163 5.94354C7.46538 6.03729 7.53569 6.14666 7.58256 6.27166C7.63725 6.38885 7.6646 6.51385 7.6646 6.64666C7.6646 6.77947 7.63725 6.90838 7.58256 7.03338C7.53569 7.15838 7.46538 7.26776 7.37163 7.36151L1.71147 13.0099C1.51616 13.2053 1.27788 13.3029 0.996626 13.3029C0.723189 13.3029 0.488814 13.2053 0.293501 13.0099C0.0981889 12.8146 0.00053267 12.5803 0.00053267 12.3068C0.00053267 12.0334 0.0981889 11.799 0.293501 11.6037L5.25053 6.64666L0.293501 1.70135L0.234908 1.61932C0.0708452 1.42401 -0.00727983 1.20135 0.00053267 0.951349C0.0161577 0.693537 0.113814 0.470881 0.293501 0.283381Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-24.astro", void 0);

const $$Astro$w = createAstro("https://www.Asus.com.tw");
const $$Link = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$w, $$props, $$slots);
  Astro2.self = $$Link;
  const {
    IDName,
    className,
    link,
    extend,
    target,
    title,
    html,
    variant,
    button,
    round,
    disabled,
    attribute = {},
    style,
    block,
    showArrow = false,
    webFontInstalled = false,
    size = "16",
    font = "roboto",
    weight = "regular",
    status = "default",
    Tag = "a",
    back = false
  } = Astro2.props;
  const href = link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#";
  const linkClasses = [
    "link-with-arrow",
    `size_${size}`,
    `font_${font}`,
    showArrow ? "" : "no-arrow",
    webFontInstalled ? "web-font" : "svg-arrow",
    { btn: button },
    { "btn-block": block, "btn-round": round },
    status && status !== "default" && status,
    disabled && "disabled",
    back && "back-link",
    className
  ].filter(Boolean);
  const arrowComponents = {
    "12": $$Arrow12,
    "13": $$Arrow13,
    "14": $$Arrow14,
    "16": $$Arrow16,
    "18": $$Arrow18,
    "20": $$Arrow20,
    "24": $$Arrow24
  };
  const ArrowComponent = arrowComponents[size] || $$Arrow16;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": linkClasses, "href": href, "target": target, "disabled": disabled, "data-variant": variant, "title": Tag === "a" ? title : void 0, "aria-label": title, ...attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<span${addAttribute(["link-text", `weight_${weight}`], "class:list")}>
        ${html ? renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`${unescapeHTML(html)}` })}` : renderTemplate`${renderSlot($$result2, $$slots["default"], renderTemplate`${title}`)}`}
    </span>
    ${showArrow && (webFontInstalled ? renderTemplate`<span class="link-arrow web-font-arrow"></span>` : renderTemplate`<span class="link-arrow svg-arrow">
                ${renderComponent($$result2, "ArrowComponent", ArrowComponent, {})}
            </span>`)}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/link.astro", void 0);

const $$Astro$v = createAstro("https://www.Asus.com.tw");
const $$MegaMenu = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$v, $$props, $$slots);
  Astro2.self = $$MegaMenu;
  const {
    IDName,
    className,
    style,
    attribute = {},
    data = [],
    position = "left",
    type = "dropdown",
    transition = true
  } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyMegaMenu", $$MegaMenu$1, { "IDName": IDName, "className": className, "style": style, "attribute": attribute, "data": data, "position": position, "type": type, "transition": transition }, { "default": ($$result2) => renderTemplate`${data.map((x, i) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`
                ${maybeRenderHead()}<div class="mega-menu-item">
                    <div class="mega-menu-head">
                        <strong class="mega-menu-title">${x.title}</strong>
                        <span class="mega-menu-text">${x.subTitle}</span>
                    </div>
                    ${renderComponent($$result3, "ALink", $$Link, { "link": x.link, "title": x.linkText, "showArrow": true })}
                </div>
                ${x.children && x.children.map((y, j) => renderTemplate`<div class="menu-links">
                            <span class="menu-link-title">
                                ${y.title}
                            </span>
                            <div class="menu-link-list">
                                ${y.links.map((z, k) => renderTemplate`<div class="menu-link-ul">
                                        ${z.map((u, v) => renderTemplate`${renderComponent($$result3, "A", $$A, { "link": u.link, "title": u.linkText })}`)}
                                    </div>`)}
                            </div>
                        </div>`)}` })}`)}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/megaMenu.astro", void 0);

const $$Astro$u = createAstro("https://www.Asus.com.tw");
const $$Nav = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$u, $$props, $$slots);
  Astro2.self = $$Nav;
  const { IDName = "headerNav", className, style, attribute = {}, data = [], type = "dropdown" } = Astro2.props;
  return renderTemplate`<!-- Navigation Container - 導航容器 -->${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <nav>
        ${/**
   * 遍歷導航資料陣列，渲染每個導航項目
   * 如果有子選單，添加 mega menu trigger 屬性
   * */
  data.map((x, i) => renderTemplate`<div class="headerNavItem"${spreadAttributes(x.hasOwnProperty("children") ? { "data-mega-menu-trigger": "", "data-mega-menu-type": type } : {})}>
                    
                    ${x.hasOwnProperty("children") ? renderTemplate`<div class="headerNavLink" role="button" tabindex="0">
                            <p>${x.title}</p>
                            ${x.subTitle && renderTemplate`<span>${x.subTitle}</span>`}
                        </div>` : renderTemplate`${renderComponent($$result, "ALink", $$A, { "link": x.link, "className": "headerNavLink", "attribute": { tabindex: "0", role: "link" } }, { "default": ($$result2) => renderTemplate`
                            <p>${x.title}</p>
                            ${x.subTitle && renderTemplate`<span>${x.subTitle}</span>`}` })}`}

                    
                    ${x.hasOwnProperty("children") && renderTemplate`${renderComponent($$result, "MegaMenu", $$MegaMenu, { "position": "center", "type": type, "attribute": {
    /* 第一個選單項目添加特殊標記 */
    "data-first": i === 0 ? "" : void 0
  }, "data": x.children })}`}
                </div>`)}
    </nav>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/nav.astro", void 0);

const $$Astro$t = createAstro("https://www.Asus.com.tw");
const $$TriggerButton = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$t, $$props, $$slots);
  Astro2.self = $$TriggerButton;
  const {
    IDName = "headerOffcanvas",
    className,
    style,
    attribute = {}
  } = Astro2.props;
  return renderTemplate`<!-- Mobile Menu Trigger Button - 手機版選單觸發按鈕 -->${maybeRenderHead()}<button${addAttribute(`${IDName}TriggerButton`, "id")} type="button"${addAttribute(["relative", className], "class:list")} data-bs-toggle="offcanvas" data-bs-target="#headerOffcanvas" aria-controls="headerOffcanvas"${addAttribute(style, "style")} title="header Offcanvas Trigger Button"${spreadAttributes(attribute)}>
    
    <span class="line"></span>
    <span class="line"></span>
</button>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/offcanvas/triggerButton.astro", void 0);

const $$BusinessHorizontalLight = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="190" height="17" viewBox="0 0 190 17" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17.4906 14.3735C16.7812 14.3735 16.1647 14.2891 15.6411 14.1117C15.1175 13.9344 14.6868 13.7317 14.3405 13.5121C13.9436 13.2588 13.6058 12.9632 13.3271 12.6254L14.577 11.3755C14.7544 11.6204 14.9909 11.84 15.278 12.0427C15.5229 12.2116 15.8269 12.3636 16.1985 12.4987C16.5616 12.6338 17.0008 12.7098 17.499 12.7098C17.8791 12.7098 18.2085 12.6591 18.4956 12.5663C18.7827 12.4734 19.0276 12.3467 19.2303 12.1862C19.433 12.0257 19.5766 11.84 19.6779 11.6288C19.7792 11.4177 19.8299 11.1981 19.8299 10.9617C19.8299 10.6408 19.7455 10.3789 19.5681 10.1678C19.3908 9.96513 19.1543 9.78779 18.8672 9.64422C18.5801 9.50065 18.2507 9.38243 17.8875 9.28108C17.5244 9.17974 17.1444 9.06994 16.7559 8.95171C16.3674 8.83348 15.9874 8.69836 15.6242 8.5379C15.2611 8.37744 14.9317 8.17475 14.6446 7.92139C14.3575 7.66804 14.121 7.36401 13.9436 7.00087C13.7663 6.63773 13.6818 6.18169 13.6818 5.63275C13.6818 5.20205 13.7747 4.78823 13.9521 4.39131C14.1379 3.99438 14.3997 3.64812 14.7459 3.35254C15.0922 3.05696 15.506 2.8205 16.0043 2.64315C16.4941 2.47424 17.0514 2.38135 17.6764 2.38135C18.276 2.38135 18.7996 2.45735 19.2556 2.61781C19.7117 2.76983 20.0917 2.94716 20.4042 3.13296C20.7673 3.35253 21.0798 3.6059 21.3332 3.88459L20.0833 5.13449C19.906 4.93181 19.7032 4.75445 19.4668 4.60244C19.2641 4.46732 19.0108 4.34064 18.7067 4.23085C18.4027 4.11261 18.0564 4.05351 17.6679 4.05351C16.9585 4.05351 16.4181 4.21396 16.0549 4.52643C15.6918 4.83891 15.506 5.21049 15.506 5.63275C15.506 5.95367 15.5904 6.21547 15.7678 6.4266C15.9451 6.62929 16.1816 6.80663 16.4687 6.9502C16.7559 7.09377 17.0852 7.212 17.4484 7.31334C17.8115 7.41468 18.1916 7.52447 18.58 7.63426C18.9685 7.75249 19.3486 7.88761 19.7117 8.04807C20.0749 8.20853 20.4042 8.41122 20.6913 8.66458C20.9785 8.91793 21.215 9.22196 21.3923 9.5851C21.5696 9.94824 21.6541 10.4043 21.6541 10.9532C21.6541 11.4093 21.5527 11.84 21.3585 12.2622C21.1642 12.6761 20.8856 13.0392 20.5309 13.3516C20.1762 13.6641 19.737 13.909 19.2219 14.0948C18.7152 14.2806 18.1325 14.3735 17.4906 14.3735Z" fill="#231815"></path>
<path d="M29.2885 14.3734C28.5538 14.3734 27.8866 14.2552 27.287 14.0187C26.6874 13.7823 26.1722 13.4445 25.7415 13.0222C25.3108 12.5915 24.973 12.0848 24.7365 11.5021C24.5001 10.9109 24.3818 10.2691 24.3818 9.55122V2.55859H26.2144V9.55122C26.2144 10.0073 26.2905 10.4295 26.4509 10.818C26.6029 11.2065 26.8225 11.5443 27.1012 11.823C27.3799 12.1017 27.7092 12.3212 28.0808 12.4817C28.4524 12.6422 28.8662 12.7182 29.2969 12.7182C29.7108 12.7182 30.0993 12.6337 30.4793 12.4648C30.8593 12.2959 31.1802 12.0763 31.4589 11.7892C31.7376 11.5021 31.9572 11.1727 32.1261 10.7842C32.295 10.3958 32.3795 9.98192 32.3795 9.55122V2.55859H34.2121V9.55122C34.2121 10.2606 34.0938 10.9109 33.8574 11.5021C33.6209 12.0932 33.2831 12.5999 32.8524 13.0222C32.4217 13.4529 31.9065 13.7823 31.3069 14.0187C30.682 14.2552 30.0148 14.3734 29.2885 14.3734Z" fill="#231815"></path>
<path d="M41.0854 14.3735C40.376 14.3735 39.7595 14.2891 39.2359 14.1117C38.7123 13.9344 38.2816 13.7317 37.9353 13.5121C37.5384 13.2588 37.2006 12.9632 36.9219 12.6254L38.1718 11.3755C38.3491 11.6204 38.5856 11.84 38.8728 12.0427C39.1177 12.2116 39.4217 12.3636 39.7933 12.4987C40.1564 12.6338 40.5955 12.7098 41.0938 12.7098C41.4738 12.7098 41.8032 12.6591 42.0904 12.5663C42.3775 12.4734 42.6224 12.3467 42.8251 12.1862C43.0278 12.0257 43.1713 11.84 43.2727 11.6288C43.374 11.4177 43.4247 11.1981 43.4247 10.9617C43.4247 10.6408 43.3402 10.3789 43.1629 10.1678C42.9855 9.96513 42.7491 9.78779 42.462 9.64422C42.1748 9.50065 41.8454 9.38243 41.4823 9.28108C41.1192 9.17974 40.7392 9.06994 40.3507 8.95171C39.9622 8.83348 39.5821 8.69836 39.219 8.5379C38.8559 8.37744 38.5265 8.17475 38.2394 7.92139C37.9522 7.66804 37.7158 7.36401 37.5384 7.00087C37.3611 6.63773 37.2766 6.18169 37.2766 5.63275C37.2766 5.20205 37.3695 4.78823 37.5469 4.39131C37.7327 3.99438 37.9945 3.64812 38.3407 3.35254C38.687 3.05696 39.1008 2.8205 39.599 2.64315C40.0889 2.47424 40.6462 2.38135 41.2712 2.38135C41.8708 2.38135 42.3944 2.45735 42.8504 2.61781C43.3065 2.77827 43.6865 2.94716 43.999 3.13296C44.3621 3.35253 44.6746 3.6059 44.928 3.88459L43.678 5.13449C43.5007 4.93181 43.298 4.75445 43.0615 4.60244C42.8589 4.46732 42.6055 4.34064 42.3015 4.23085C41.9975 4.11261 41.6512 4.05351 41.2627 4.05351C40.5533 4.05351 40.0129 4.21396 39.6497 4.52643C39.2866 4.83891 39.1008 5.21049 39.1008 5.63275C39.1008 5.95367 39.1852 6.21547 39.3625 6.4266C39.5399 6.62929 39.7764 6.80663 40.0635 6.9502C40.3507 7.09377 40.68 7.212 41.0431 7.31334C41.4063 7.41468 41.7863 7.52447 42.1748 7.63426C42.5633 7.75249 42.9433 7.88761 43.3065 8.04807C43.6696 8.20853 43.999 8.41122 44.2861 8.66458C44.5732 8.91793 44.8097 9.22196 44.9871 9.5851C45.1644 9.94824 45.2489 10.4043 45.2489 10.9532C45.2489 11.4093 45.1475 11.84 44.9533 12.2622C44.759 12.6761 44.4804 13.0392 44.1257 13.3516C43.771 13.6641 43.3318 13.909 42.8167 14.0948C42.3099 14.2806 41.7272 14.3735 41.0854 14.3735Z" fill="#231815"></path>
<path d="M9.40796 14.2047H11.325L6.66327 2.55029H4.66176L0 14.2047H1.91708L2.8967 11.7133H8.42829L9.40796 14.2047ZM3.58921 9.9736L5.66674 4.72069L7.74423 9.9736H3.58921Z" fill="#231815"></path>
<path d="M184.781 0L190 8.36919L184.781 16.7553H178.05L183.269 8.36919L178.05 0H184.781Z" fill="#008DD3"></path>
<path d="M73.0928 8.13243L69.2672 2.55859H71.4291L74.2583 6.80653L77.0874 2.55859H79.2494L75.4153 8.13243L79.5787 14.213H77.4168L74.2498 9.46676L71.0829 14.213H68.9209L73.0928 8.13243Z" fill="#231815"></path>
<path d="M117.295 14.2048L114.263 9.80487C114.322 9.78798 114.39 9.77109 114.449 9.7542C114.93 9.55996 115.335 9.29815 115.69 8.95189C116.036 8.61408 116.315 8.21716 116.509 7.76112C116.704 7.30508 116.805 6.81526 116.805 6.29166C116.805 5.76806 116.704 5.27823 116.509 4.83063C116.315 4.37459 116.045 3.97767 115.69 3.63986C115.344 3.30205 114.93 3.03182 114.449 2.83758C113.967 2.64334 113.452 2.54199 112.886 2.54199H108.225V14.1964H110.057V11.1054V10.0329V8.36917V8.00603V4.2057H112.886C113.173 4.2057 113.444 4.25637 113.706 4.36616C113.967 4.47595 114.187 4.6195 114.373 4.8053C114.558 4.99109 114.711 5.21912 114.812 5.47248C114.922 5.72583 114.972 5.99608 114.972 6.29166C114.972 6.5788 114.922 6.84905 114.812 7.11085C114.711 7.3642 114.558 7.5922 114.373 7.778C114.187 7.96379 113.959 8.11582 113.706 8.21716C113.452 8.32695 113.182 8.37763 112.886 8.37763H111.189L112.346 10.0413H112.354L115.226 14.2048H117.295Z" fill="#231815"></path>
<path d="M91.0728 4.83063C90.8786 4.37459 90.6083 3.97767 90.2536 3.63986C89.9074 3.30205 89.4936 3.03182 89.0122 2.83758C88.5308 2.64334 88.0156 2.54199 87.4498 2.54199H82.7881V14.1964H84.6207V11.1054V10.0329V8.36917V8.00603V4.2057H87.4498C87.7369 4.2057 88.0072 4.25637 88.269 4.36616C88.5308 4.47595 88.7504 4.6195 88.9362 4.8053C89.122 4.99109 89.274 5.21912 89.3753 5.47248C89.4851 5.72583 89.5358 5.99608 89.5358 6.29166C89.5358 6.5788 89.4851 6.84905 89.3753 7.11085C89.274 7.3642 89.122 7.5922 88.9362 7.778C88.7504 7.96379 88.5224 8.11582 88.269 8.21716C88.0157 8.32695 87.7454 8.37763 87.4498 8.37763H85.7523L86.9093 10.0413H87.4498C88.0156 10.0413 88.5393 9.93998 89.0122 9.74574C89.4936 9.5515 89.8989 9.28969 90.2536 8.94344C90.5999 8.60563 90.8786 8.2087 91.0728 7.75266C91.2671 7.29662 91.3684 6.80681 91.3684 6.28321C91.3684 5.7765 91.2671 5.28667 91.0728 4.83063Z" fill="#231815"></path>
<path d="M65.737 4.29843V2.55029H57.5029V4.29843V7.50762V9.25575V12.4565V14.2047H65.737V12.4565H59.251V9.25575H65.737V7.50762H59.251V4.29843H65.737Z" fill="#231815"></path>
<path d="M103.15 4.29843V2.55029H94.9072V4.29843V7.50762V9.25575V12.4565V14.2047H103.15V12.4565H96.6554V9.25575H103.15V7.50762H96.6554V4.29843H103.15Z" fill="#231815"></path>
<path d="M128.596 2.55029H119.771V2.56717L120.961 4.29843H123.267V14.2047H125.099V4.29843H128.596V2.55029Z" fill="#231815"></path>
<path d="M159.749 2.46582H164.411C164.935 2.46582 165.408 2.55026 165.83 2.71917C166.261 2.88807 166.624 3.10765 166.936 3.38634C167.249 3.66503 167.485 3.9944 167.654 4.36599C167.823 4.74602 167.907 5.1345 167.907 5.54831C167.907 5.99591 167.831 6.35904 167.679 6.64618C167.527 6.93331 167.367 7.16978 167.189 7.36402C166.987 7.57515 166.759 7.74407 166.489 7.87919C166.869 8.03121 167.198 8.24234 167.485 8.51258C167.738 8.73216 167.966 9.02774 168.178 9.38244C168.38 9.74558 168.482 10.1847 168.482 10.7083C168.482 11.1644 168.389 11.5951 168.194 12.0173C168.009 12.4311 167.747 12.7943 167.401 13.1068C167.063 13.4192 166.657 13.6641 166.193 13.8499C165.728 14.0357 165.213 14.1286 164.648 14.1286H159.732V2.46582H159.749ZM164.411 7.21202C164.909 7.21202 165.315 7.06846 165.619 6.77288C165.923 6.47729 166.075 6.09725 166.075 5.63277C166.075 5.16828 165.923 4.78824 165.619 4.49266C165.315 4.19708 164.909 4.05352 164.411 4.05352H161.582V7.22047H164.411V7.21202ZM164.664 12.5409C165.256 12.5409 165.729 12.3551 166.109 11.992C166.48 11.6289 166.666 11.1728 166.666 10.6239C166.666 10.0834 166.48 9.62733 166.109 9.25574C165.737 8.8926 165.256 8.70681 164.664 8.70681H161.582V12.5325H164.664V12.5409Z" fill="#231815"></path>
<path d="M150.705 14.289C149.97 14.289 149.303 14.1707 148.703 13.9343C148.103 13.6978 147.588 13.36 147.158 12.9377C146.727 12.507 146.389 12.0003 146.153 11.4176C145.916 10.8264 145.798 10.1846 145.798 9.46674V2.47412H147.63V9.46674C147.63 9.92278 147.706 10.345 147.867 10.7335C148.019 11.122 148.238 11.4598 148.517 11.7385C148.796 12.0172 149.125 12.2368 149.497 12.3972C149.877 12.5492 150.282 12.6337 150.713 12.6337C151.127 12.6337 151.515 12.5492 151.895 12.3803C152.275 12.2114 152.596 11.9919 152.875 11.7047C153.154 11.4176 153.373 11.0882 153.542 10.6998C153.711 10.3113 153.795 9.89745 153.795 9.46674V2.47412H155.628V9.46674C155.628 10.1761 155.51 10.8264 155.273 11.4176C155.037 12.0088 154.699 12.5155 154.268 12.9377C153.838 13.3684 153.323 13.6978 152.723 13.9343C152.106 14.1707 151.439 14.289 150.705 14.289Z" fill="#231815"></path>
<path d="M132.615 2.49951H134.439V7.38086H140.148V2.49951H141.972V14.0863H140.148V9.03611H134.439V14.0863H132.615V2.49951Z" fill="#231815"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/logo/svg-astro/Business-Horizontal-Light.astro", void 0);

const $$Astro$s = createAstro("https://www.Asus.com.tw");
const $$Logo = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$s, $$props, $$slots);
  Astro2.self = $$Logo;
  const { IDName = "headerLogo", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "A", $$A, { "IDName": IDName, "className": className, "style": style, ...attribute, "link": "/", "title": "Asus" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "ImageDesktop", $$BusinessHorizontalLight, {})}
    ${renderComponent($$result2, "ImageDesktop", $$BusinessHorizontalLight, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/logo.astro", void 0);

const $$Astro$r = createAstro("https://www.Asus.com.tw");
const $$HeaderTop = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$r, $$props, $$slots);
  Astro2.self = $$HeaderTop;
  const { IDName = "headerTop", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderSlot($$result, $$slots["default"])}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/headerTop.astro", void 0);

const $$Astro$q = createAstro("https://www.Asus.com.tw");
const $$HeaderBottom = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$q, $$props, $$slots);
  Astro2.self = $$HeaderBottom;
  const { IDName = "headerBottom", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderSlot($$result, $$slots["default"])}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/headerBottom.astro", void 0);

const $$Astro$p = createAstro("https://www.Asus.com.tw");
const $$Offcanvas$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$p, $$props, $$slots);
  Astro2.self = $$Offcanvas$1;
  const {
    IDName,
    className,
    title,
    headerClassName,
    hideHeader,
    titleClassName,
    hideTitle,
    closeClassName,
    hideClose,
    bodyClassName,
    postion = "start",
    scrollable,
    backdrop = void 0,
    attribute = {},
    style,
    sizes = "default"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName ? `${IDName}Offcanvas` : void 0, "id")}${addAttribute([
    {
      offcanvas: sizes === "default",
      "offcanvas-xxl": sizes === "xxl",
      "offcanvas-xl": sizes === "xl",
      "offcanvas-lg": sizes === "lg",
      "offcanvas-md": sizes === "md",
      "offcanvas-sm": sizes === "sm"
    },
    {
      "offcanvas-start": postion === "start",
      "offcanvas-end": postion === "end",
      "offcanvas-top": postion === "top",
      "offcanvas-bottom": postion === "bottom"
    },
    className
  ], "class:list")} tabindex="-1"${addAttribute(IDName ? `${IDName}OffcanvasLabel` : void 0, "aria-labelledby")}${spreadAttributes(scrollable ? { "data-bs-scroll": "true" } : {})}${spreadAttributes(backdrop ? { "data-bs-backdrop": backdrop } : {})}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${!hideHeader && renderTemplate`<div${addAttribute(["offcanvas-header", headerClassName], "class:list")}>
                ${renderSlot($$result, $$slots["header"], renderTemplate`
                    ${!hideTitle && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
                            ${renderSlot($$result2, $$slots["title-left"])}
                            ${renderSlot($$result2, $$slots["title"], renderTemplate`
                                <strong${addAttribute(IDName ? `${IDName}OffcanvasLabel` : void 0, "id")}${addAttribute(["offcanvas-title", titleClassName], "class:list")}>
                                    ${title}
                                </strong>
                            `)}
                            ${renderSlot($$result2, $$slots["title-right"])}
                        ` })}`}
                    ${!hideClose && renderTemplate`<button type="button"${addAttribute(["offcanvas-close-button", closeClassName], "class:list")} data-bs-dismiss="offcanvas" aria-label="Close"></button>`}
                `)}
            </div>`}
    <div${addAttribute(["offcanvas-body", bodyClassName], "class:list")}>
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/offcanvas/offcanvas.astro", void 0);

const $$Astro$o = createAstro("https://www.Asus.com.tw");
const $$Offcanvas = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$o, $$props, $$slots);
  Astro2.self = $$Offcanvas;
  const { IDName = "header", className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`

${renderComponent($$result, "MyOffcanvas", $$Offcanvas$1, { "IDName": IDName, "postion": "end", "hideHeader": true, "className": className, "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`${data.map((x) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`${Boolean(x.children && x.children.length > 0) ? renderTemplate`${renderComponent($$result3, "Collapse", $$Collapse, { "title": x.title, "parent": IDName ? `#${IDName}Offcanvas` : void 0, "buttonClassName": "header-offcanvas-collapse-button" }, { "default": ($$result4) => renderTemplate`
                        ${maybeRenderHead()}<div class="header-offcanvas-link-container">
                            <div class="header-offcanvas-link-content">
                                ${x.children?.flatMap((y) => y.children).map((y) => renderTemplate`<div class="menu-links">
                                            <span class="menu-link-title">${y?.title}</span>
                                            <div class="menu-link-list">
                                                ${y?.links.map((z) => renderTemplate`<div class="menu-link-ul">
                                                        ${z?.map((u) => renderTemplate`${renderComponent($$result4, "A", $$A, { "link": u.link, "title": u.linkText })}`)}
                                                    </div>`)}
                                            </div>
                                        </div>`)}
                            </div>
                            ${x.children?.[0].link && renderTemplate`<div class="header-offcanvas-main-link">
                                    ${renderComponent($$result4, "ALink", $$Link, { "link": x.children?.[0].link, "title": x.children?.[0].linkText, "showArrow": true })}
                                </div>`}
                        </div>
                    ` })}` : renderTemplate`${renderComponent($$result3, "A", $$A, { "link": x.link, "className": "header-offcanvas-link", "title": x.title })}`}` })}`)}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/offcanvas/offcanvas.astro", void 0);

const $$Astro$n = createAstro("https://www.Asus.com.tw");
const $$Input = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$n, $$props, $$slots);
  Astro2.self = $$Input;
  const {
    id,
    // 輸入框 ID
    className,
    // 自定義 CSS 類別
    type = "text",
    // 輸入框類型，預設為文字輸入
    name,
    // 表單欄位名稱
    value,
    // 輸入框值
    placeholder,
    // 佔位符文字
    inputmode = "text",
    // 輸入模式，預設為文字
    maxLength,
    // 最大字元長度
    minLength,
    // 最小字元長度
    max,
    // 最大數值
    min,
    // 最小數值
    required,
    // 是否必填
    disabled,
    // 是否禁用
    readonly,
    // 是否唯讀
    pattern,
    // 驗證樣式
    autocomplete,
    // 自動完成
    title,
    // 標題（用於無障礙）
    transparent,
    // 是否透明樣式
    size,
    // 尺寸
    focus = false,
    // 是否顯示焦點邊框，預設為 false
    attribute = {},
    // 其他 HTML 屬性，預設為空物件
    aria = {},
    // ARIA 屬性，預設為空物件
    style = {}
    // 自定義樣式
  } = Astro2.props;
  const inputClasses = [
    "control-input",
    // 基礎輸入框類別
    { [`size_${size}`]: size },
    // 尺寸類別
    { "input-transparent": transparent },
    // 透明樣式
    { "has-focus": focus },
    // 焦點狀態
    className
    // 自定義類別
  ].filter(Boolean);
  return renderTemplate`${maybeRenderHead()}<input${addAttribute(id, "id")}${addAttribute(inputClasses, "class:list")}${addAttribute(value, "value")}${addAttribute(type, "type")}${addAttribute(name, "name")}${addAttribute(max, "max")}${addAttribute(min, "min")}${addAttribute(maxLength, "maxlength")}${addAttribute(minLength, "minlength")}${addAttribute(placeholder, "placeholder")}${addAttribute(inputmode, "inputmode")}${addAttribute(required, "required")}${addAttribute(disabled, "disabled")}${addAttribute(readonly, "readonly")}${addAttribute(autocomplete, "autocomplete")}${addAttribute(title, "aria-label")}${addAttribute(pattern, "pattern")}${spreadAttributes(attribute)}${spreadAttributes(aria)}${addAttribute(style, "style")}>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/input/input.astro", void 0);

const $$Astro$m = createAstro("https://www.Asus.com.tw");
const $$HideShowIcon = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$m, $$props, $$slots);
  Astro2.self = $$HideShowIcon;
  const {
    Tag = "span",
    state = "show",
    class: className = "",
    attribute = {},
    aria = {}
  } = Astro2.props;
  const getVariantClass = () => {
    const baseClass = "hide-show-icon";
    const stateClass = `hide-show-icon--${state}`;
    return `${baseClass} ${stateClass}`.trim();
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "class": `${getVariantClass()} ${className}`, "data-state": state, ...attribute, ...aria }, { "default": ($$result2) => renderTemplate`${state === "show" ? renderTemplate`<!-- Show State SVG -->
        ${maybeRenderHead()}<svg width="22" height="15" viewBox="0 0 22 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4.70778 14.1459C4.58699 14.0423 4.51228 13.895 4.50009 13.7363C4.4879 13.5776 4.53923 13.4205 4.64278 13.2997L15.8423 0.209533C15.9458 0.0886944 16.0931 0.0139587 16.2518 0.00176508C16.4104 -0.0104285 16.5674 0.0409188 16.6882 0.144512C16.8087 0.248088 16.8832 0.395244 16.8954 0.553703C16.9076 0.712163 16.8565 0.868988 16.7532 0.98978L5.55374 14.0799C5.49772 14.1462 5.42785 14.1993 5.34907 14.2356C5.27028 14.2719 5.1845 14.2905 5.09776 14.29C4.95476 14.29 4.81646 14.2389 4.70778 14.1459ZM7.58864 13.2377C7.515 13.2094 7.44765 13.1669 7.39044 13.1126C7.33324 13.0583 7.2873 12.9932 7.25526 12.9211C7.22321 12.849 7.2057 12.7713 7.20371 12.6924C7.20172 12.6135 7.2153 12.535 7.24366 12.4614C7.272 12.3877 7.31459 12.3203 7.36901 12.2631C7.42342 12.2059 7.48858 12.16 7.56076 12.1281C7.63293 12.0961 7.71071 12.0787 7.78962 12.0768C7.86853 12.075 7.94703 12.0887 8.02063 12.1173C9.62327 12.7693 11.3839 12.9285 13.0774 12.5744C14.4673 12.2493 15.768 11.6204 16.8862 10.7329C18.0667 9.80876 19.0948 8.70498 19.9331 7.46183C18.7401 5.94631 17.2835 4.6586 15.6333 3.66063C15.5648 3.6215 15.5048 3.56927 15.4565 3.50691C15.4083 3.44456 15.3728 3.3733 15.3521 3.29722C15.3314 3.22114 15.3259 3.14172 15.3358 3.0635C15.3458 2.98528 15.3711 2.9098 15.4103 2.84137C15.4494 2.77291 15.5016 2.71283 15.5639 2.66456C15.6263 2.6163 15.6975 2.58079 15.7736 2.56008C15.8496 2.53936 15.929 2.53384 16.0072 2.54383C16.0854 2.55382 16.1608 2.57912 16.2292 2.6183C18.1333 3.76975 19.8017 5.27211 21.146 7.0457L21.4 7.3668L21.195 7.71991C20.249 9.24293 19.0391 10.585 17.6222 11.6832C15.8402 13.1268 13.6243 13.9284 11.3315 13.9589C10.0501 13.9512 8.78118 13.7067 7.58864 13.2377ZM5.00277 11.9462C3.27807 10.8295 1.70998 9.48755 0.339984 7.95599L0 7.58687L0.299986 7.18674C1.36389 5.86509 2.60446 4.6961 3.98681 3.71264C5.22537 2.80823 6.60305 2.11188 8.06562 1.65099C9.73113 1.13108 11.5034 1.05488 13.2074 1.42992C13.2844 1.44718 13.3572 1.47946 13.4217 1.52492C13.4862 1.57037 13.5411 1.62811 13.5833 1.69483C13.6255 1.76154 13.6541 1.83592 13.6675 1.91371C13.6809 1.9915 13.6788 2.07116 13.6614 2.14815C13.6441 2.22517 13.6118 2.29803 13.5664 2.36256C13.521 2.42709 13.4632 2.48202 13.3966 2.52421C13.3299 2.56639 13.2555 2.595 13.1777 2.6084C13.1 2.6218 13.0204 2.61972 12.9434 2.60229C11.4415 2.27261 9.87959 2.34158 8.41261 2.80235C7.07542 3.22521 5.81599 3.86309 4.68378 4.69095C3.54203 5.51252 2.49944 6.46385 1.57693 7.52585C2.78328 8.8243 4.14712 9.96684 5.63674 10.9269C5.70351 10.9688 5.7614 11.0234 5.80708 11.0876C5.85277 11.1518 5.88536 11.2244 5.90301 11.3012C5.92065 11.378 5.92299 11.4576 5.9099 11.5353C5.89682 11.613 5.86855 11.6874 5.82673 11.7542C5.77257 11.8405 5.69733 11.9116 5.60811 11.9608C5.51889 12.0099 5.41862 12.0356 5.31675 12.0353C5.20486 12.0358 5.09506 12.0049 4.99977 11.9462H5.00277ZM9.39056 11.3671C9.31665 11.3395 9.2489 11.2976 9.19119 11.2438C9.13348 11.19 9.08695 11.1253 9.05426 11.0535C9.02156 10.9816 9.00335 10.9041 9.00066 10.8252C8.99797 10.7463 9.01085 10.6677 9.03858 10.5938C9.06615 10.5199 9.10804 10.4521 9.16183 10.3944C9.21562 10.3367 9.28026 10.2901 9.35206 10.2574C9.42386 10.2247 9.5014 10.2065 9.58024 10.2038C9.65908 10.2011 9.73768 10.214 9.81154 10.2417C10.1664 10.3751 10.5424 10.4429 10.9215 10.4418C11.7366 10.4511 12.5222 10.1368 13.1061 9.56773C13.69 8.99865 14.0245 8.22121 14.0363 7.40581C14.0359 6.87461 13.8936 6.35317 13.6244 5.89533C13.5842 5.82749 13.5579 5.7524 13.5467 5.67435C13.5356 5.59631 13.54 5.51684 13.5596 5.44048C13.5792 5.36412 13.6136 5.29238 13.6609 5.22934C13.7083 5.1663 13.7675 5.1132 13.8354 5.07307C13.9032 5.03297 13.9783 5.00665 14.0564 4.9956C14.1345 4.98456 14.2139 4.98901 14.2903 5.00871C14.3666 5.0284 14.4383 5.06295 14.5013 5.11038C14.5643 5.15782 14.6173 5.2172 14.6573 5.28514C15.0357 5.92815 15.2352 6.66068 15.2353 7.40681C15.2234 8.54057 14.7625 9.62332 13.9536 10.4175C13.1446 11.2117 12.0539 11.6525 10.9205 11.6432C10.3981 11.6433 9.87995 11.5498 9.39056 11.3671ZM6.84668 8.79625C6.68902 8.34965 6.60854 7.87945 6.60869 7.40581C6.62057 6.27206 7.08152 5.18931 7.89043 4.39511C8.69933 3.60092 9.79012 3.16014 10.9235 3.16947C11.2149 3.16923 11.5057 3.19805 11.7914 3.2555C11.9472 3.2871 12.084 3.3792 12.1719 3.5116C12.2598 3.644 12.2917 3.80588 12.2604 3.96172C12.2448 4.03906 12.2141 4.11256 12.17 4.17801C12.126 4.24346 12.0694 4.29957 12.0037 4.34315C11.9379 4.38672 11.8642 4.4169 11.7868 4.43195C11.7094 4.44701 11.6297 4.44664 11.5525 4.43087C11.3457 4.38963 11.1353 4.36885 10.9245 4.36885C10.1093 4.35976 9.32367 4.6743 8.73983 5.24354C8.15598 5.81279 7.82149 6.59032 7.80964 7.40581C7.80936 7.74312 7.86651 8.07801 7.97863 8.39613C8.03149 8.54603 8.02275 8.71079 7.95432 8.85425C7.8859 8.99771 7.76338 9.10816 7.61364 9.16137C7.54964 9.18513 7.48192 9.19733 7.41365 9.19738C7.28912 9.19751 7.16763 9.15886 7.06603 9.08681C6.96444 9.01475 6.88778 8.91386 6.84668 8.79625Z" fill="currentColor"></path>
        </svg>` : renderTemplate`<!-- Hide State SVG -->
        <svg width="22" height="13" viewBox="0 0 22 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0.339952 6.6724L0 6.30349L0.304957 5.90358C1.18408 4.80961 2.18809 3.82215 3.29653 2.96129C5.43743 1.14873 8.1242 0.106092 10.9274 0C14.4679 0 17.8025 1.93953 20.84 5.76662L21.1 6.09454L20.884 6.45045C20.1595 7.57003 19.2882 8.5875 18.2934 9.47573C16.3391 11.3617 13.7495 12.4477 11.0344 12.52C7.50693 12.52 3.91044 10.5525 0.339952 6.6724ZM4.06142 3.88707C3.1618 4.59224 2.33089 5.3809 1.57978 6.2425C4.79232 9.6117 7.97087 11.3203 11.0354 11.3203C13.4443 11.2588 15.741 10.2897 17.4655 8.60694C18.2748 7.87928 19.0003 7.06341 19.6282 6.17452C16.9076 2.87531 13.982 1.20071 10.9294 1.20071C8.40797 1.32139 5.99553 2.26499 4.06142 3.88707ZM6.51207 6.12453C6.52369 5.00617 6.97841 3.93805 7.77652 3.15445C8.57463 2.37085 9.65097 1.93574 10.7695 1.94453C11.8881 1.93574 12.9645 2.37082 13.7628 3.15439C14.561 3.93796 15.016 5.00607 15.0279 6.12453C15.016 7.2429 14.561 8.31091 13.7627 9.09432C12.9644 9.87773 11.888 10.3126 10.7695 10.3035C9.65114 10.3123 8.57495 9.87735 7.77687 9.09397C6.97879 8.31058 6.52395 7.24273 6.51207 6.12453ZM7.7119 6.12453C7.7235 6.92463 8.05184 7.6875 8.62496 8.24595C9.19809 8.80441 9.96926 9.1129 10.7695 9.10382C11.57 9.11343 12.3417 8.80518 12.9153 8.24667C13.4888 7.68815 13.8174 6.92498 13.829 6.12453C13.8177 5.32391 13.4892 4.56048 12.9156 4.00175C12.342 3.44303 11.5702 3.13463 10.7695 3.14425C9.96909 3.13517 9.19777 3.4438 8.62462 4.00247C8.05146 4.56114 7.72323 5.32426 7.7119 6.12453Z" fill="currentColor"></path>
        </svg>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/hidden/HideShowIcon.astro", void 0);

const $$Astro$l = createAstro("https://www.Asus.com.tw");
const $$Cross = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$l, $$props, $$slots);
  Astro2.self = $$Cross;
  const { IDName, className, style, attribute = {}, size, color, mode = "light", Tag = "span", aria = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "cross-icon", `mode-${mode}`], "style": {
    ...style,
    "--icon-size": size ? `${size}px` : void 0,
    "--icon-color": color ? color.charAt(0) === "#" ? color : `var(--color-${color})` : void 0
  }, ...attribute, ...aria }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="cross-svg">
        <path d="M12.6 0.599609L0.599976 12.5996M0.599976 0.599609L12.6 12.5996" stroke="var(--icon-color)" stroke-width="1" stroke-linecap="round"></path>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/header-menu/cross.astro", void 0);

const $$Astro$k = createAstro("https://www.Asus.com.tw");
const $$Search$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$k, $$props, $$slots);
  Astro2.self = $$Search$1;
  const {
    IDName,
    className,
    style,
    attribute = {},
    mode = "light",
    state = "normal",
    width,
    color,
    Tag = "span",
    aria = {}
  } = Astro2.props;
  const searchPath = "M10.5364 10.5359L13.6001 13.5996M12.0217 6.30986C12.0217 9.46453 9.46501 12.0212 6.31035 12.0212C3.15785 12.0212 0.600098 9.46453 0.600098 6.30986C0.600098 3.15736 3.15676 0.599609 6.31035 0.599609C9.46501 0.599609 12.0217 3.15628 12.0217 6.30986Z";
  const svgClass = ["search-icon", { [`mode-${mode}`]: mode }, { [`state-${state}`]: state }, className];
  const iconStyle = {
    ...width ? { "--icon-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": svgClass, ...attribute, ...aria, "style": iconStyle }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" class="search-svg">
        <path${addAttribute(searchPath, "d")} fill="none" stroke="var(--icon-color)" stroke-width="1.2" stroke-linecap="round"></path>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/search/search.astro", void 0);

const $$Astro$j = createAstro("https://www.Asus.com.tw");
const $$InputWrapper = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$j, $$props, $$slots);
  Astro2.self = $$InputWrapper;
  const {
    id,
    // 輸入框 ID
    className,
    // 自定義 CSS 類別
    attribute = {},
    // 其他 HTML 屬性，預設為空物件
    style = {},
    // 自定義 CSS 樣式，預設為空物件
    pwdShowIcon,
    // 是否顯示密碼顯示圖標，預設為 false
    pwdHideIcon,
    // 是否顯示密碼隱藏圖標，預設為 false
    closeIcon,
    // 是否顯示清除圖標，預設為 false
    searchIcon,
    // 是否顯示搜尋圖標，預設為 false
    /** Input 屬性 */
    inputId,
    // Input ID
    inputClassName,
    // Input CSS 類別
    name,
    // 表單欄位名稱
    value,
    // 輸入框值
    type = "text",
    // 輸入框類型
    maxLength,
    // 最大字元長度
    minLength,
    // 最小字元長度
    placeholder,
    // 佔位符文字，預設為密碼提示
    inputmode = "text",
    // 輸入模式，預設為文字
    required,
    // 是否必填
    disabled,
    // 是否禁用
    readonly,
    // 是否唯讀
    autocomplete = "current-password",
    // 自動完成，預設為當前密碼
    title,
    // 標題（用於無障礙）
    transparent,
    // 是否透明樣式
    size,
    // 輸入框尺寸，預設為 xl
    focus,
    // 是否顯示焦點邊框，預設為 false
    aria = {},
    // ARIA 屬性，預設為空物件
    inputAttribute = {},
    // Input 屬性，預設為空物件
    inputStyle = {}
    // Input 樣式，預設為空物件
  } = Astro2.props;
  const componentId = id || `input-wrapper-${Math.random().toString(36).substr(2, 9)}`;
  const inputID = inputId || `input-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`
${maybeRenderHead()}<div${addAttribute(id || componentId, "id")}${addAttribute(["input-wrapper", className], "class:list")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>
    ${renderComponent($$result, "Input", $$Input, { "id": inputID, "className": {
    inputClassName,
    ...{
      "has-search-icon": searchIcon,
      "has-pwd-show-icon": pwdShowIcon,
      "has-pwd-hide-icon": pwdHideIcon,
      "has-cross-icon": closeIcon
    }
  }, "type": type, "name": name, "value": value, "maxLength": maxLength, "minLength": minLength, "placeholder": placeholder, "inputmode": inputmode, "required": required, "disabled": disabled, "readonly": readonly, "autocomplete": autocomplete, "title": title, "transparent": transparent, "size": size, "focus": focus, "aria": aria, "attribute": inputAttribute, "style": inputStyle })}
    ${(pwdShowIcon || pwdHideIcon || closeIcon || searchIcon) && renderTemplate`<div class="input-icons">
                ${pwdShowIcon && renderTemplate`${renderComponent($$result, "HideShowIcon", $$HideShowIcon, { "state": "show", "Tag": "button", "attribute": { type: "button", "data-pwd-expand": "true" }, "aria": { "aria-label": "\u986F\u793A\u5BC6\u78BC" } })}`}
                ${pwdHideIcon && renderTemplate`${renderComponent($$result, "HideShowIcon", $$HideShowIcon, { "state": "hide", "Tag": "button", "attribute": { type: "button", "data-pwd-expand": "false" }, "aria": { "aria-label": "\u96B1\u85CF\u5BC6\u78BC" } })}`}
                ${closeIcon && renderTemplate`${renderComponent($$result, "CrossIcon", $$Cross, { "Tag": "button", "attribute": { type: "button" }, "aria": { "aria-label": "\u6E05\u9664\u8F38\u5165" } })}`}
                ${searchIcon && renderTemplate`${renderComponent($$result, "SearchIcon", $$Search$1, { "Tag": "button", "attribute": { type: "submit" }, "aria": { "aria-label": "\u641C\u5C0B" } })}`}
            </div>`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/input/inputWrapper.astro", void 0);

const $$Astro$i = createAstro("https://www.Asus.com.tw");
const $$Search = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$i, $$props, $$slots);
  Astro2.self = $$Search;
  const { IDName = "headerSearch", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`

${renderComponent($$result, "MyOffcanvas", $$Offcanvas$1, { "IDName": IDName, "postion": "top", "hideHeader": true, "className": className, "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<form class="header-search-from">
        <div class="header-search-from-body">
            ${renderComponent($$result2, "InputWrapper", $$InputWrapper, { "size": "lg", "name": "products", "placeholder": "\u641C\u5C0B ASUS.com/business", "searchIcon": true })}
            ${renderComponent($$result2, "Link", $$Link, { "title": "\u95DC\u9589", "className": "header-search-from-body-close", "attribute": { "data-bs-dismiss": "offcanvas", "aria-label": "Close" } }, { "default": ($$result3) => renderTemplate`關閉` })}
        </div>
    </form>
` })}

`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/offcanvas/search.astro", void 0);

const $$Astro$h = createAstro("https://www.Asus.com.tw");
const icons = {};
const $$Icons = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$h, $$props, $$slots);
  Astro2.self = $$Icons;
  const {
    IDName,
    className,
    style,
    attribute = {},
    icon,
    width,
    height,
    fill,
    strokeWidth = 0,
    strokeColor,
    custom
  } = Astro2.props;
  const MyIcon = icons[icon];
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${MyIcon && renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "fa-Icons", icon, { customStyle: custom }], "class:list")}${addAttribute({
    ...style,
    ...!isNaN(width) ? { "--width": `${width / 16}rem` } : {},
    ...!isNaN(height) ? { "--height": `${height / 16}rem` } : {},
    ...fill ? { "--fill": fill.charAt(0) === "#" ? fill : `var(--color-${fill})` } : {},
    ...!isNaN(strokeWidth) ? { "--strokeWidth": `${strokeWidth / 16}rem` } : {},
    ...strokeColor ? { "--stroke": strokeColor.charAt(0) === "#" ? strokeColor : `var(--color-${strokeColor})` } : {}
  }, "style")}${spreadAttributes(attribute)}>
                
            </div>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/icons.astro", void 0);

const $$Astro$g = createAstro("https://www.Asus.com.tw");
const $$Button = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$g, $$props, $$slots);
  Astro2.self = $$Button;
  const {
    IDName,
    type = "button",
    Tag = "button",
    size,
    title,
    className,
    variant,
    disabled,
    block,
    button = true,
    round = true,
    rounded = false,
    role,
    link,
    extend,
    target,
    noFocus,
    attribute = {},
    style,
    icon,
    iconPosition = "right",
    iconWidth,
    iconHeight,
    iconFill,
    iconStrokeColor,
    iconStrokeWidth = 0,
    CustomIconColor = true,
    IconAttribute = {},
    IconStyle
  } = Astro2.props;
  const href = link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#";
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "type": Tag === "button" ? type : void 0, "class:list": [
    {
      btn: button,
      "btn-xs": size === "xs",
      "btn-sm": size === "sm",
      "btn-md": size === "md",
      "btn-lg": size === "lg",
      "btn-xl": size === "xl",
      "btn-block": block,
      "btn-round": round,
      "btn-rounded": rounded,
      "no-focus": noFocus
    },
    className
  ], "title": title, "disabled": disabled, "data-variant": variant, ...attribute, "style": style, "href": Tag === "a" ? href : void 0, "target": Tag === "a" ? target : void 0, "role": Tag !== "button" ? role : void 0 }, { "default": ($$result2) => renderTemplate`
    ${renderSlot($$result2, $$slots["icon-left"], renderTemplate`
        ${Boolean(icon && iconPosition === "left") && renderTemplate`${renderComponent($$result2, "Icons", $$Icons, { "icon": icon, "width": iconWidth, "height": iconHeight, "fill": iconFill, "strokeColor": iconStrokeColor, "strokeWidth": iconStrokeWidth, "custom": CustomIconColor, "attribute": IconAttribute, "style": IconStyle })}`}
    `)}
    ${renderSlot($$result2, $$slots["default"])}
    ${renderSlot($$result2, $$slots["icon-right"], renderTemplate`
        ${Boolean(icon && iconPosition === "right") && renderTemplate`${renderComponent($$result2, "Icons", $$Icons, { "icon": icon, "width": iconWidth, "height": iconHeight, "fill": iconFill, "stroke-color": iconStrokeColor, "stroke-width": iconStrokeWidth, "custom": CustomIconColor, "attribute": IconAttribute, "style": IconStyle })}`}
    `)}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/button/button.astro", void 0);

const $$Astro$f = createAstro("https://www.Asus.com.tw");
const $$Quantity = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$f, $$props, $$slots);
  Astro2.self = $$Quantity;
  const { quantity = "2", class: className = "" } = Astro2.props;
  const displayQuantity = String(quantity);
  return renderTemplate`${maybeRenderHead()}<span${addAttribute(`quantity-label ${className}`, "class")}>
    ${displayQuantity}
</span>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/quantity/quantity.astro", void 0);

const $$Astro$e = createAstro("https://www.Asus.com.tw");
const $$HeaderInquery = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$e, $$props, $$slots);
  Astro2.self = $$HeaderInquery;
  const {
    haveItems = "false",
    status = "normal",
    colorMode = "light",
    state = "normal",
    mode = "light",
    quantity = "2",
    className = "",
    Tag = "span",
    attribute = {},
    aria = {},
    style = {}
  } = Astro2.props;
  const getVariantClass = () => {
    const baseClass = "header-inquery";
    const itemsClass = `header-inquery--${haveItems.toLowerCase()}`;
    const statusClass = `header-inquery--${status.toLowerCase()}`;
    const colorClass = `header-inquery--${colorMode.toLowerCase()}`;
    const stateClass = `header-inquery--${state}`;
    const modeClass = `header-inquery--${mode.toLowerCase()}`;
    return `${baseClass} ${itemsClass} ${statusClass} ${colorClass} ${stateClass} ${modeClass}`;
  };
  const hasQuantityLabel = haveItems === "true" || haveItems === "header" && colorMode === "true";
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "class": `${getVariantClass()} ${className}`, ...attribute, ...aria, "style": style }, { "default": ($$result2) => renderTemplate`
    
    ${maybeRenderHead()}<svg width="12" height="15" viewBox="0 0 12 15" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0.887134 4.04628H4.76471V0.886767M3.75941 8.06747L5.19555 9.50361L8.06784 6.63133M0.599976 4.11815L4.83659 0.599609H10.0788C10.7133 0.599609 11.2277 1.114 11.2277 1.74852V12.9507C11.2277 13.5852 10.7133 14.0996 10.0788 14.0996H1.74889C1.11436 14.0996 0.599976 13.5852 0.599976 12.9507V4.11815Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>

    
    ${hasQuantityLabel && renderTemplate`${renderComponent($$result2, "QuantityLabel", $$Quantity, { "quantity": quantity })}`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/header-inquery/HeaderInquery.astro", void 0);

const $$Astro$d = createAstro("https://www.Asus.com.tw");
const $$HeaderMember = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$d, $$props, $$slots);
  Astro2.self = $$HeaderMember;
  const {
    logIn = "False",
    status = "normal",
    colorMode = "light",
    className = "",
    color,
    width,
    Tag = "span",
    attribute = {},
    aria = {},
    style = {}
  } = Astro2.props;
  const isActive = logIn === "True";
  const getVariantClass = () => {
    const baseClass = "header-member";
    const loginClass = logIn === "True" ? "header-member--active" : "header-member--inactive";
    const statusClass = status === "hover" ? "header-member--hover" : "header-member--normal";
    const colorClass = colorMode === "Dark" ? "header-member--dark" : "header-member--light";
    return [baseClass, loginClass, statusClass, colorClass, className];
  };
  const iconStyle = {
    ...width ? { "--icon-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "class:list": getVariantClass(), ...attribute, ...aria, "style": iconStyle }, { "default": ($$result2) => renderTemplate`${isActive ? renderTemplate`<!-- Active member icon with green dot -->
    ${maybeRenderHead()}<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="6.59998" cy="3.97461" r="3.375" stroke="currentColor" stroke-width="1.2"></circle>
      <path d="M6.59961 6.75C7.92886 6.75 9.16538 7.14527 10.2012 7.82129C9.81087 8.02254 9.45475 8.28095 9.14648 8.58789C8.38782 8.18115 7.52073 7.94922 6.59961 7.94922C3.82027 7.94942 1.53187 10.0502 1.2334 12.75H8.05469C8.17566 13.1813 8.36157 13.5851 8.60352 13.9492H0.599609C0.268418 13.949 0 13.6808 0 13.3496C0.000211066 9.70484 2.95484 6.75021 6.59961 6.75Z" fill="currentColor"></path>
      <circle cx="11.9827" cy="11.5996" r="3" class="header-member__dot"></circle>
    </svg>` : renderTemplate`<!-- Inactive member icon -->
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="6.59998" cy="3.97461" r="3.375" stroke="currentColor" stroke-width="1.2"></circle>
      <path d="M6.59961 6.75C10.2446 6.75 13.199 9.70471 13.1992 13.3496C13.1992 13.681 12.931 13.9492 12.5996 13.9492H0.599609C0.268418 13.949 0 13.6808 0 13.3496C0.000211066 9.70484 2.95484 6.75021 6.59961 6.75ZM6.59961 7.94922C3.82027 7.94942 1.53187 10.0502 1.2334 12.75H11.9658C11.6673 10.0501 9.3791 7.94922 6.59961 7.94922Z" fill="currentColor"></path>
    </svg>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/header-member/HeaderMember.astro", void 0);

const $$Astro$c = createAstro("https://www.Asus.com.tw");
const $$Header = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$c, $$props, $$slots);
  Astro2.self = $$Header;
  const { IDName = "header", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`<!-- Header -->${maybeRenderHead()}<header${addAttribute(IDName, "id")}${addAttribute(["header", className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div id="header-body">
        ${renderComponent($$result, "Left", $$HeaderTop, {}, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Logo", $$Logo, {})}
            ${renderComponent($$result2, "Navs", $$Nav, { "type": "megaMenu", "data": NavsData })}
        ` })}
        ${renderComponent($$result, "Right", $$HeaderBottom, {}, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Button", $$Button, { "Tag": "a", "link": "/isv", "variant": "blue-outline", "size": "sm", "title": "\u6210\u70BAISV\u5925\u4F34", "rounded": true, "className": "header-control-button" }, { "default": ($$result3) => renderTemplate`
                成為ISV夥伴
            ` })}
            ${renderComponent($$result2, "IconSearch", $$Search$1, { "Tag": "button", "attribute": {
    type: "button",
    title: "search",
    "data-bs-toggle": "offcanvas",
    "data-bs-target": "#headerSearchOffcanvas",
    "data-bs-expended": "false",
    "aria-controls": "headerSearchOffcanvas"
  }, "className": "header-control" })}
            ${renderComponent($$result2, "IconHeaderInquery", $$HeaderInquery, { "haveItems": "header", "colorMode": "true", "Tag": "a", "attribute": { type: "button", title: "inquery", href: "/inquery" }, "className": "header-control" })}
            <div class="header-control-member">
                ${renderComponent($$result2, "IconHeaderMember", $$HeaderMember, { "logIn": "True", "Tag": "button", "attribute": {
    type: "button",
    title: "member",
    "data-bs-toggle": "dropdown",
    "aria-expanded": "false",
    "data-bs-offset": "0,4"
  }, "className": "header-control" })}
                <ul class="header-dropdown dropdown-menu">
                    <div class="menu-links">
                        <span class="menu-link-title"> 用戶選單 </span>
                        <div class="menu-link-list">
                            <div class="menu-link-ul">
                                ${[
    { title: "\u57FA\u672C\u8CC7\u6599", link: "/member/basic-info" },
    { title: "\u8A0A\u606F\u4E2D\u5FC3(10)", link: "/member/message-center" },
    { title: "\u6211\u7684\u8AEE\u8A62\u593E(10)", link: "/member/order-aocc" },
    { title: "\u6211\u7684\u6536\u85CF\u6E05\u55AE(10)", link: "/member/my-wishlist" },
    { title: "\u767B\u51FA", link: "" }
  ].map((z) => renderTemplate`${renderComponent($$result2, "A", $$A, { "link": z.link, "title": z.title })}`)}
                            </div>
                        </div>
                    </div>
                </ul>
            </div>
            ${renderComponent($$result2, "TriggerButton", $$TriggerButton, {})}
        ` })}
    </div>
</header>
${renderComponent($$result, "Offcanvas", $$Offcanvas, { "data": NavsData })}
${renderComponent($$result, "SearchOffcanvas", $$Search, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/header.astro", void 0);

const $$Astro$b = createAstro("https://www.Asus.com.tw");
const $$Modal = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$b, $$props, $$slots);
  Astro2.self = $$Modal;
  const {
    id = "example",
    sizes = "md",
    center = true,
    scrollable = false,
    title = "",
    attribute = {},
    Modalclass = "",
    bodyClass = "",
    titleClass = "",
    dialogClass = "",
    contentClass = "",
    footerClass = "",
    ContentTag = "div",
    contentAttribute = {},
    hideHeader = false,
    hideTitle = false,
    headerClass = "",
    hideColse = false,
    hideFooter = false,
    cancelTitle = "\u53D6\u6D88",
    cancelVariant,
    cancelDisabled = false,
    cancelClass = "",
    cancelAttribute = { "data-bs-dismiss": "modal" },
    cancelOnly = false,
    okTitle = "\u5132\u5B58",
    okVariant,
    okDisabled = false,
    okClass = "",
    okAttribute = {},
    okOnly = false
  } = Astro2.props;
  const modalSizes = {
    sm: "modal-sm",
    md: "",
    lg: "modal-lg",
    xl: "modal-xl"
  };
  const modalSize = modalSizes?.[sizes];
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(["modal fade", Modalclass], "class:list")}${addAttribute(`${id}Modal`, "id")} tabindex="-1"${addAttribute(`${id}ModalLabel`, "aria-labelledby")} aria-hidden="false" data-bs-focus="false"${spreadAttributes(attribute)}>
    <div${addAttribute([
    "modal-dialog",
    modalSize,
    { "modal-dialog-centered": center },
    { "modal-dialog-scrollable": scrollable },
    dialogClass
  ], "class:list")}>
        ${renderComponent($$result, "ContentTag", ContentTag, { "class:list": ["modal-content", contentClass], ...contentAttribute }, { "default": ($$result2) => renderTemplate`${!hideHeader && renderTemplate`<div${addAttribute(["modal-header", { hideHeader: hideTitle }, headerClass], "class:list")}>
                        ${renderSlot($$result2, $$slots["title"], renderTemplate`
                            ${!hideTitle && renderTemplate`<div${addAttribute(["modal-title", titleClass], "class:list")}${addAttribute(`${id}ModalLabel`, "id")}>
                                    ${renderSlot($$result2, $$slots["title-left"])}
                                    <span>${title}</span>
                                    ${renderSlot($$result2, $$slots["title-right"])}
                                </div>`}
                        `)}
                        ${renderSlot($$result2, $$slots["header-right"])}
                        ${!hideColse && renderTemplate`${renderComponent($$result2, "Button", $$Button, { "IDName": id ? `${id}ModalCloseButton` : "", "className": `modal-close-button`, "attribute": {
    "data-bs-dismiss": "modal",
    "aria-label": "Close"
  }, "button": false })}`}
                    </div>`}<div${addAttribute(["modal-body", { hideFooter }, { hideTitle }, bodyClass], "class:list")}>
                ${renderSlot($$result2, $$slots["default"])}
            </div>
            ${!hideFooter && renderTemplate`<div${addAttribute(["modal-footer", footerClass], "class:list")}>
                        ${renderSlot($$result2, $$slots["footer"], renderTemplate`
                            ${!okOnly && renderTemplate`${renderComponent($$result2, "Button", $$Button, { "className": [cancelClass], "variant": cancelVariant, "attribute": cancelAttribute, "disabled": cancelDisabled }, { "default": ($$result3) => renderTemplate`${cancelTitle}` })}`}
                            ${!cancelOnly && renderTemplate`${renderComponent($$result2, "Button", $$Button, { "className": [okClass], "variant": okVariant, "disabled": okDisabled, "attribute": okAttribute }, { "default": ($$result3) => renderTemplate`${okTitle}` })}`}
                        `)}
                    </div>`}` })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/modal/modal.astro", void 0);

const $$Toast = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`<!-- Alert -->${renderComponent($$result, "Modal", $$Modal, { "id": "toast", "title": "", "sizes": "xl", "center": true, "hideFooter": true }, { "default": ($$result2) => renderTemplate`
    
    ${maybeRenderHead()}<div class="toast-body">
        <div class="toast-text" style="display: none;"></div>
        <div class="toast-footer" style="display: none;">
            ${renderComponent($$result2, "ALink", $$Button, { "className": "toast-button", "Tag": "a", "link": "#", "button": true, "attribute": { "data-toast-button-primary": "" }, "style": { display: "none" }, "round": true })}
            ${renderComponent($$result2, "ALink", $$Button, { "className": "toast-button", "Tag": "a", "link": "#", "button": true, "attribute": { "data-toast-button-secondary": "" }, "style": { display: "none" }, "round": true })}
        </div>
    </div>
`, "title-left": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "title-left" }, { "default": ($$result3) => renderTemplate`
        <div class="toast-icon" style="display: none;">
            <div class="icon-close" data-toast-icon="error" style="display: none;"></div>
            <div class="icon-check" data-toast-icon="success" style="display: none;"></div>
        </div>
    ` })}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/toast/toast.astro", void 0);

const $$CssVariable = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`<style type="text/css">
</style>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/css-variable.astro", void 0);

const $$Astro$a = createAstro("https://www.Asus.com.tw");
const $$Meta = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$Meta;
  const { title, description, keywords, themeColor, colorScheme } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${title && renderTemplate`<title>${title}</title>`}${description && renderTemplate`<meta name="description"${addAttribute(description, "content")}>`}${keywords && renderTemplate`<meta name="keywords"${addAttribute(keywords.join(", "), "content")}>`}${colorScheme && renderTemplate`<meta name="color-scheme"${addAttribute(colorScheme, "content")}>`}${themeColor && renderTemplate`<meta name="theme-color"${addAttribute(themeColor, "content")}>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Meta.astro", void 0);

const $$Astro$9 = createAstro("https://www.Asus.com.tw");
const $$Facebook = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$Facebook;
  const { url, type, title, description, image } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${url && renderTemplate`<meta property="og:url"${addAttribute(url, "content")}>`}${type && renderTemplate`<meta property="og:type"${addAttribute(type, "content")}>`}${title && renderTemplate`<meta property="og:title"${addAttribute(title, "content")}>`}${description && renderTemplate`<meta property="og:description"${addAttribute(description, "content")}>`}${image && renderTemplate`<meta property="og:image"${addAttribute(image, "content")}>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Facebook.astro", void 0);

const $$Astro$8 = createAstro("https://www.Asus.com.tw");
const $$Twitter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$Twitter;
  const { card, site, title, description, image } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${card && renderTemplate`<meta name="twitter:card"${addAttribute(card, "content")}>`}${site && renderTemplate`<meta name="twitter:site"${addAttribute(site, "content")}>`}${title && renderTemplate`<meta name="twitter:title"${addAttribute(title, "content")}>`}${description && renderTemplate`<meta name="twitter:description"${addAttribute(description, "content")}>`}${image && renderTemplate`<meta name="twitter:image"${addAttribute(image, "content")}>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Twitter.astro", void 0);

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Google = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Google;
  const { description, author = "", copyright = "", applicationName = "", verification = "" } = Astro2.props;
  return renderTemplate`${description && renderTemplate`<meta name="description"${addAttribute(description, "content")}>`}
${author && renderTemplate`<meta name="author"${addAttribute(author, "content")}>`}
${copyright && renderTemplate`<meta name="copyright"${addAttribute(copyright, "content")}>`}
${applicationName && renderTemplate`<meta name="application-name"${addAttribute(applicationName, "content")}>`}
${verification && renderTemplate`<meta name="google-site-verification"${addAttribute(verification, "content")}>`}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Google.astro", void 0);

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$Icon = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Icon;
  const { favicon = [], appleTouchIcon = [] } = Astro2.props;
  return renderTemplate`
${favicon.map((x) => renderTemplate`<link${addAttribute(x.rel, "rel")}${addAttribute(x.href, "href")}${addAttribute(x.type, "type")}${addAttribute(x.sizes, "sizes")}>`)}

${appleTouchIcon.map((x) => renderTemplate`<link${addAttribute(x?.rel ?? "apple-touch-icon", "rel")}${addAttribute(x.sizes, "sizes")}${addAttribute(x.href, "href")}>`)}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/icon/icon.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Robots = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Robots;
  const { content } = Astro2.props;
  return renderTemplate`${content && renderTemplate`<meta name="robots"${addAttribute(content, "content")}>`}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/robots/robots.astro", void 0);

function JsonLd(item, space) {
  return JSON.stringify(item, safeJsonLdReplacer, space);
}
const ESCAPE_ENTITIES = Object.freeze({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&apos;"
});
const ESCAPE_REGEX = new RegExp(
  `[${Object.keys(ESCAPE_ENTITIES).join("")}]`,
  "g"
);
const ESCAPE_REPLACER = (t) => ESCAPE_ENTITIES[t];
const safeJsonLdReplacer = /* @__PURE__ */ (() => {
  return (_, value) => {
    switch (typeof value) {
      case "object":
        if (value === null) {
          return void 0;
        }
        return value;
      // JSON.stringify will recursively call replacer.
      case "number":
      case "boolean":
      case "bigint":
        return value;
      // These values are not risky.
      case "string":
        return value.replace(ESCAPE_REGEX, ESCAPE_REPLACER);
      default: {
        return void 0;
      }
    }
  };
})();

var __freeze$1 = Object.freeze;
var __defProp$1 = Object.defineProperty;
var __template$1 = (cooked, raw) => __freeze$1(__defProp$1(cooked, "raw", { value: __freeze$1(cooked.slice()) }));
var _a$1;
const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Schema$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Schema$1;
  const { item, space } = Astro2.props;
  return renderTemplate(_a$1 || (_a$1 = __template$1(['<script type="application/ld+json">', "<\/script>"])), unescapeHTML(JsonLd(item, space)));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/node_modules/.pnpm/astro-seo-schema@5.1.0_astro@4.16.19_@types+node@20.14.2_less@4.2.0_lightningcss@1.25.1_a4db162a8c3d07006d0bab4a650ffa08/node_modules/astro-seo-schema/dist/Schema.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$Schema = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Schema;
  const { schemas = [] } = Astro2.props;
  return renderTemplate`${schemas.map((item) => renderTemplate`${renderComponent($$result, "SeoSchema", $$Schema$1, { "item": item })}`)}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/schema/schema.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Font = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Font;
  const { google, custom, icon } = Astro2.props;
  const defaultFontsPath = `${Astro2.url.origin}/assets/fonts`;
  return renderTemplate`${google && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link rel="preload" as="style"${addAttribute(google, "href")} onload="this.onload = null; this.rel = 'stylesheet'">
            ${maybeRenderHead()}<noscript>
                <link${addAttribute(google, "href")} rel="stylesheet" type="text/css">
            </noscript>
        ` })}`}
${icon && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <link rel="preload" as="style"${addAttribute(icon, "href")}${addAttribute(`this.onload = null; this.rel = 'stylesheet'`, "onload")}>
            <noscript>
                <link rel="stylesheet"${addAttribute(icon, "href")}>
            </noscript>
        ` })}`}
${custom && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${custom?.fonts?.map((x) => renderTemplate`<link rel="preload"${addAttribute(`${custom?.fontsPath ?? defaultFontsPath}/${x}`, "href")} as="font"${addAttribute(`font/${custom?.type}`, "type")} crossorigin>`)}` })}`}
${custom && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <link rel="preload" as="style"${addAttribute(custom.css, "href")}${addAttribute(`this.onload = null; this.rel = 'stylesheet'`, "onload")}>
            <noscript>
                <link rel="stylesheet"${addAttribute(custom.css, "href")}>
            </noscript>
        ` })}`}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/font/font.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Seo = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Seo;
  const {
    title,
    description,
    keywords,
    themeColor,
    colorScheme,
    facebook,
    twitter,
    google,
    robots,
    schemas,
    font,
    favicon,
    appleTouchIcon
  } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Meta", $$Meta, { "title": title, "description": description, "keywords": keywords, "themeColor": themeColor, "colorScheme": colorScheme })}

    ${renderComponent($$result2, "Icon", $$Icon, { "favicon": favicon, "appleTouchIcon": appleTouchIcon })}

    ${renderComponent($$result2, "Facebook", $$Facebook, { "title": title, "description": description, "image": facebook?.image, "url": facebook?.url, "type": facebook?.type })}
    ${renderComponent($$result2, "Twitter", $$Twitter, { "title": title, "description": description, "image": twitter?.image, "site": twitter?.site, "card": twitter?.card })}
    ${renderComponent($$result2, "Google", $$Google, { "description": description, "author": google?.author, "copyright": google?.copyright, "applicationName": google?.applicationName, "verification": google?.verification })}

    ${renderComponent($$result2, "Robots", $$Robots, { "content": robots?.content })}
    ${renderComponent($$result2, "Schema", $$Schema, { "schemas": schemas })}

    

    ${renderComponent($$result2, "Font", $$Font, { "google": font?.google, "custom": font?.custom, "icon": font?.icon })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/seo.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Script = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["<script>\n    document.addEventListener('DOMContentLoaded', () => {\n        /**\n         * \u570B\u969B\u5316\u8A0A\u606F\u914D\u7F6E\n         */\n        const I18N_MESSAGES = {\n            'zh-TW': {\n                required: '\u6B64\u6B04\u4F4D\u70BA\u5FC5\u586B',\n                pattern: '\u8ACB\u7B26\u5408\u8981\u6C42\u683C\u5F0F',\n                tel: '\u8ACB\u8F38\u5165\u6B63\u78BA\u7684\u96FB\u8A71\u865F\u78BC',\n                phone: '\u8ACB\u8F38\u5165\u6B63\u78BA\u7684\u96FB\u8A71\u865F\u78BC',\n                email: (value) => {\n                    if (!value.includes('@')) {\n                        return `\u8ACB\u5728\u96FB\u5B50\u90F5\u4EF6\u5730\u5740\u4E2D\u5305\u62EC\u300C@\u300D\u3002\u300C${value}\u300D\u672A\u5305\u542B\u300C@\u300D`;\n                    } else {\n                        return `\u8ACB\u8F38\u5165\u300C@\u300D\u5F8C\u9762\u7684\u90E8\u5206\u3002\u300C${value}\u300D\u4E0D\u662F\u5B8C\u6574\u503C\u3002`;\n                    }\n                },\n                minLength: (minLength, currentLength) =>\n                    `\u8ACB\u5C07\u9019\u6BB5\u6587\u5B57\u52A0\u9577\u5230 ${minLength} \u500B\u5B57\u5143\u4EE5\u4E0A (\u76EE\u524D\u5DF2\u6709 ${currentLength} \u500B\u5B57\u5143\u6578)`,\n                maxLength: (maxLength, currentLength) =>\n                    `\u8ACB\u5C07\u9019\u6BB5\u6587\u5B57\u7E2E\u77ED\u5230 ${maxLength} \u500B\u5B57\u5143\u4EE5\u4E0B (\u76EE\u524D\u5DF2\u6709 ${currentLength} \u500B\u5B57\u5143\u6578)`,\n                min: (min) => `\u503C\u5FC5\u9808\u5927\u65BC\u6216\u7B49\u65BC ${min}\u3002`,\n                max: (max) => `\u503C\u5FC5\u9808\u5C0F\u65BC\u6216\u7B49\u65BC ${max}\u3002`,\n                regex: '',\n                passwordConfirm: '\u8207\u5BC6\u78BC\u4E0D\u7B26\u5408'\n            },\n            'en-US': {\n                required: 'This field is required',\n                pattern: 'Please match the required format',\n                tel: 'Please enter a valid phone number',\n                phone: 'Please enter a valid phone number',\n                email: (value) => {\n                    if (!value.includes('@')) {\n                        return `Please include an '@' in the email address. '${value}' is missing an '@'`;\n                    } else {\n                        return `Please enter the part following '@'. '${value}' is not a complete value.`;\n                    }\n                },\n                minLength: (minLength, currentLength) =>\n                    `Please lengthen this text to ${minLength} characters or more (you are currently using ${currentLength} characters)`,\n                maxLength: (maxLength, currentLength) =>\n                    `Please shorten this text to ${maxLength} characters or less (you are currently using ${currentLength} characters)`,\n                min: (min) => `Value must be greater than or equal to ${min}.`,\n                max: (max) => `Value must be less than or equal to ${max}.`,\n                regex: '',\n                passwordConfirm: 'Passwords do not match'\n            },\n            'ja-JP': {\n                required: '\u3053\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044',\n                pattern: '\u8981\u6C42\u3055\u308C\u305F\u5F62\u5F0F\u306B\u4E00\u81F4\u3055\u305B\u3066\u304F\u3060\u3055\u3044',\n                tel: '\u6B63\u3057\u3044\u96FB\u8A71\u756A\u53F7\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044',\n                phone: '\u6B63\u3057\u3044\u96FB\u8A71\u756A\u53F7\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044',\n                email: (value) => {\n                    if (!value.includes('@')) {\n                        return `\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306B\u300C@\u300D\u3092\u542B\u3081\u3066\u304F\u3060\u3055\u3044\u3002\u300C${value}\u300D\u306B\u306F\u300C@\u300D\u304C\u3042\u308A\u307E\u305B\u3093`;\n                    } else {\n                        return `\u300C@\u300D\u306E\u5F8C\u306E\u90E8\u5206\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u300C${value}\u300D\u306F\u5B8C\u5168\u306A\u5024\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002`;\n                    }\n                },\n                minLength: (minLength, currentLength) =>\n                    `\u3053\u306E\u30C6\u30AD\u30B9\u30C8\u3092${minLength}\u6587\u5B57\u4EE5\u4E0A\u306B\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u73FE\u5728${currentLength}\u6587\u5B57\u3067\u3059\uFF09`,\n                maxLength: (maxLength, currentLength) =>\n                    `\u3053\u306E\u30C6\u30AD\u30B9\u30C8\u3092${maxLength}\u6587\u5B57\u4EE5\u4E0B\u306B\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u73FE\u5728${currentLength}\u6587\u5B57\u3067\u3059\uFF09`,\n                min: (min) => `\u5024\u306F${min}\u4EE5\u4E0A\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059\u3002`,\n                max: (max) => `\u5024\u306F${max}\u4EE5\u4E0B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059\u3002`,\n                regex: '',\n                passwordConfirm: '\u30D1\u30B9\u30EF\u30FC\u30C9\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093'\n            }\n        };\n\n        /**\n         * \u8868\u55AE\u9A57\u8B49\u5668\u985E\u5225\n         */\n        class FormValidator {\n            constructor(form, locale = 'zh-TW', options = {}) {\n                this.form = form;\n                this.locale = locale;\n                this.messages = I18N_MESSAGES[locale] || I18N_MESSAGES['zh-TW'];\n                this.options = {\n                    reportValidity: true, // \u9810\u8A2D\u555F\u7528\u539F\u751F\u9A57\u8B49\u63D0\u793A\n                    ...options\n                };\n                this.cacheOriginFeedbackText();\n                this.setupEventListeners();\n            }\n\n            /**\n             * \u662F\u5426\u555F\u7528\u5373\u6642\u9A57\u8B49\n             * \u7576\u8868\u55AE\u672A\u901A\u904E checkValidity \u6642\uFF0Cinput/select \u7684\u8B8A\u66F4\u6703\u89F8\u767C\u9A57\u8B49\n             */\n            isLiveValidateEnabled() {\n                const value = this.form.dataset.liveValidate;\n                // \u53EA\u8981\u6709 data-live-validate\uFF0C\u6216\u503C\u70BA 'true' \u90FD\u8996\u70BA\u555F\u7528\n                return value === '' || value === 'true';\n            }\n\n            /**\n             * \u5FEB\u53D6\u9801\u9762\u4E0A\u9810\u8A2D\u7684\u932F\u8AA4\u6587\u6848\n             * \u907F\u514D resetErrorMessages \u5C07\u300C\u539F\u672C\u5C31\u5B58\u5728\u7684\u63D0\u793A\u6587\u5B57\u300D\u6E05\u7A7A\n             */\n            cacheOriginFeedbackText() {\n                const errorTextEls = this.form.querySelectorAll('.error-text');\n                errorTextEls.forEach((errorTextEl) => {\n                    if (errorTextEl.hasAttribute('data-valid-origin-feedback')) return;\n                    const originText = (errorTextEl.textContent || '').trim();\n                    if (originText) {\n                        errorTextEl.setAttribute('data-valid-origin-feedback', originText);\n                    }\n                });\n            }\n\n            /**\n             * \u91CD\u7F6E\u6240\u6709\u932F\u8AA4\u8A0A\u606F\n             */\n            resetErrorMessages() {\n                const errorTextEls = this.form.querySelectorAll('.error-text');\n                errorTextEls.forEach((errorTextEl) => {\n                    const originFeedback = errorTextEl.getAttribute('data-valid-origin-feedback');\n                    errorTextEl.textContent = originFeedback || '';\n                });\n            }\n\n            /**\n             * \u57F7\u884C\u8868\u55AE\u7684\u6240\u6709\u9A57\u8B49\u6D41\u7A0B\n             * - \u5148\u91CD\u7F6E\u932F\u8AA4\u8A0A\u606F\uFF08\u4F9D data-valid-origin-feedback \u9084\u539F\u6216\u6E05\u7A7A\uFF09\n             * - \u4F9D\u5E8F\u57F7\u884C\u539F\u751F\u9A57\u8B49\u3001checkbox/radio \u9A57\u8B49\u3001\u5BA2\u88FD\u5316\u9A57\u8B49\u8207 wrapper \u72C0\u614B\u66F4\u65B0\n             */\n            runAllValidations() {\n                /** \u91CD\u7F6E\u932F\u8AA4\u8A0A\u606F */\n                this.resetErrorMessages();\n                /** \u57F7\u884C\u539F\u751F\u9A57\u8B49 */\n                this.handleNativeValidation();\n                /** \u57F7\u884C checkbox/radio \u9A57\u8B49 */\n                this.handleCheckboxValidation();\n                /** \u57F7\u884C\u5BA2\u88FD\u5316\u9A57\u8B49 */\n                this.handleCustomValidation();\n                /** \u66F4\u65B0 wrapper \u72C0\u614B */\n                this.handleWrapperValidation();\n            }\n\n            /**\n             * \u53D6\u5F97\u932F\u8AA4\u8A0A\u606F\u5143\u7D20\n             */\n            getErrorElement(input, isSpecialInput = false) {\n                if (isSpecialInput) {\n                    const parent = input.closest('.form-check, .password-input-wrapper');\n                    return (() => {\n                        let errorTextEl = parent?.closest('.form-input-group')?.querySelector('.error-text');\n                        if (errorTextEl) return errorTextEl || null;\n                        else {\n                            const nextSibling = parent?.nextElementSibling;\n                            if (nextSibling?.matches('.form-check-feedback-text.error-text')) return nextSibling;\n                            else return parent?.parentElement?.querySelector('.form-check-feedback-text.error-text') || null;\n                        }\n                    })();\n                }\n                return input?.closest('.form-input-group')?.querySelector('.error-text') || null;\n            }\n\n            /**\n             * \u5224\u65B7\u5143\u7D20\u7684\u6587\u5B57\u5167\u5BB9\u662F\u5426\u70BA\u7A7A\n             * \u4F9B\u932F\u8AA4\u8A0A\u606F\u66F4\u65B0\u6D41\u7A0B\u5171\u7528\uFF0C\u907F\u514D\u91CD\u8907\u7684 textContent/trim \u5224\u65B7\n             */\n            isEmptyTextContent(element) {\n                const text = element?.textContent;\n                return !text || text.trim() === '';\n            }\n\n            /**\n             * \u66F4\u65B0\u932F\u8AA4\u8A0A\u606F\n             * \u50C5\u5728\u932F\u8AA4\u8A0A\u606F\u5143\u7D20\u539F\u672C\u70BA\u7A7A\u6642\uFF0C\u624D\u5BEB\u5165 feedback\n             * \u82E5\u932F\u8AA4\u8A0A\u606F\u5143\u7D20\u672C\u4F86\u5C31\u6709\u6587\u6848\uFF0C\u5247\u6C38\u9060\u4E0D\u8986\u84CB\uFF08\u4FDD\u7559\u8A2D\u8A08\u7A3F/\u9801\u9762\u539F\u59CB\u6587\u6848\uFF09\n             */\n            updateErrorMessage(errorTextEl, feedback) {\n                if (!errorTextEl) return;\n\n                // \u5982\u679C\u9801\u9762\u672C\u4F86\u5C31\u6709\u932F\u8AA4\u6587\u6848\uFF0C\u6C38\u9060\u4E0D\u8986\u84CB\n                if (!this.isEmptyTextContent(errorTextEl)) return;\n\n                // \u6C92\u6709 feedback \u76F4\u63A5\u7565\u904E\n                if (!feedback) return;\n\n                errorTextEl.textContent = feedback;\n            }\n\n            /**\n             * \u8A2D\u5B9A\u9A57\u8B49\u72C0\u614B\n             */\n            setValidationState(input, isInvalid, feedback = '', element = null) {\n                const targetElement = element || input;\n\n                if (!this.form.classList.contains('was-validated')) {\n                    this.form.classList.toggle('was-validated', isInvalid);\n                }\n\n                if (!targetElement.classList.contains('is-invalid')) {\n                    targetElement.classList.toggle('is-invalid', !isInvalid);\n                }\n\n                if (input.setCustomValidity) {\n                    input.setCustomValidity(isInvalid ? feedback : '');\n                }\n            }\n\n            /**\n             * \u901A\u7528\u9A57\u8B49\u8655\u7406\u5668\n             */\n            handleValidation(input, isInvalid, feedback, element = null) {\n                this.setValidationState(input, isInvalid, feedback, element);\n\n                if (isInvalid) {\n                    const errorTextEl = this.getErrorElement(input, !!element);\n                    this.updateErrorMessage(errorTextEl, feedback);\n                }\n            }\n\n            /**\n             * \u70BA\u539F\u751F\u9A57\u8B49\u5C6C\u6027\u6DFB\u52A0\u4E8B\u4EF6\u76E3\u807D\u5668\n             */\n            addNativeValidationListener(selector, feedbackGenerator) {\n                const inputs = this.form.querySelectorAll(selector);\n                inputs.forEach((input) => {\n                    if (input.value) {\n                        input.addEventListener(\n                            'invalid',\n                            () => {\n                                const feedback = feedbackGenerator(input);\n                                const errorTextEl = this.getErrorElement(input);\n                                this.updateErrorMessage(errorTextEl, feedback);\n                            },\n                            { once: true }\n                        );\n                    }\n                });\n            }\n\n            /**\n             * \u8655\u7406\u539F\u751F HTML5 \u9A57\u8B49\n             */\n            handleNativeValidation() {\n                const nativeInputs = this.form.querySelectorAll(\n                    'input[required]:not([data-valid]):not([type=\"checkbox\"], [type=\"radio\"])',\n                    'select[required]:not([data-valid])'\n                );\n                const rules = this.getValidationRules();\n\n                nativeInputs.forEach((input) => {\n                    const value = input.value;\n\n                    // \u5B9A\u7FA9\u9A57\u8B49\u9806\u5E8F\uFF08\u512A\u5148\u9806\u5E8F\u5F9E\u9AD8\u5230\u4F4E\uFF09\n                    const validationOrder = [\n                        {\n                            condition: () => !value,\n                            rule: rules.required,\n                            getDefaultMessage: () => rules.required.getDefaultMessage()\n                        },\n                        {\n                            condition: () => value && input.type === 'email' && !/^\\S+@\\S+\\.\\S+$/.test(value),\n                            rule: rules.email,\n                            getDefaultMessage: () => rules.email.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.minLength > 0 && value.length < parseInt(input.minLength),\n                            rule: rules.minLength,\n                            getDefaultMessage: () => rules.minLength.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.maxLength > 0 && value.length > parseInt(input.maxLength),\n                            rule: rules.maxLength,\n                            getDefaultMessage: () => rules.maxLength.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.min && parseFloat(value) < parseFloat(input.min),\n                            rule: rules.min,\n                            getDefaultMessage: () => rules.min.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.max && parseFloat(value) > parseFloat(input.max),\n                            rule: rules.max,\n                            getDefaultMessage: () => rules.max.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.pattern && !new RegExp(input.pattern).test(value),\n                            rule: rules.pattern,\n                            getDefaultMessage: () => rules.pattern.getDefaultMessage()\n                        }\n                    ];\n\n                    // \u6309\u9806\u5E8F\u6AA2\u67E5\u9A57\u8B49\u898F\u5247\uFF0C\u53EA\u8655\u7406\u7B2C\u4E00\u500B\u5931\u6557\u7684\u898F\u5247\n                    for (let i = 0; i < validationOrder.length; i++) {\n                        const validation = validationOrder[i];\n                        if (validation.condition()) {\n                            const feedback = validation.getDefaultMessage();\n                            const isRequired = i === 0; // \u7B2C\u4E00\u500B\u9A57\u8B49\u662F required\n                            this.handleValidation(input, true, feedback, null, isRequired);\n                            return; // \u627E\u5230\u7B2C\u4E00\u500B\u5931\u6557\u7684\u9A57\u8B49\u5C31\u505C\u6B62\n                        }\n                    }\n\n                    // \u5982\u679C\u6240\u6709\u9A57\u8B49\u90FD\u901A\u904E\uFF0C\u6E05\u9664\u932F\u8AA4\u72C0\u614B\n                    this.handleValidation(input, false, '');\n                });\n            }\n\n            /**\n             * \u8655\u7406\u5305\u88DD\u5BB9\u5668\u7684\u9A57\u8B49\u72C0\u614B\n             * \u91DD\u5C0D .form-check \u548C .password-input-wrapper \u5E95\u4E0B\u7684 input\n             */\n            handleWrapperValidation() {\n                const wrapperInputs = this.form.querySelectorAll(\n                    '.form-check input[required], .password-input-wrapper input[required]'\n                );\n                wrapperInputs.forEach((input) => {\n                    const isInvalid = !input.checkValidity();\n\n                    // \u627E\u5230\u6700\u8FD1\u7684\u5305\u88DD\u5BB9\u5668\n                    const wrapper = input.closest('.form-check, .password-input-wrapper');\n                    if (wrapper) {\n                        wrapper.classList.toggle('is-invalid', isInvalid);\n                    }\n                });\n            }\n\n            /**\n             * \u8655\u7406\u8907\u9078\u6846\u9A57\u8B49\n             */\n            handleCheckboxValidation() {\n                const checkboxInputs = this.form.querySelectorAll(\n                    'input[type=\"checkbox\"][required], input[type=\"radio\"][required]'\n                );\n                checkboxInputs.forEach((input) => {\n                    const { validFeedback: feedback = '' } = input.dataset;\n                    const isInvalid = !input.checkValidity();\n\n                    if (isInvalid) {\n                        const errorTextEl = this.getErrorElement(input, true);\n                        this.updateErrorMessage(errorTextEl, errorTextEl.textContent || feedback || this.messages.required);\n                    }\n                });\n            }\n\n            /**\n             * \u9A57\u8B49\u898F\u5247\u914D\u7F6E\n             */\n            getValidationRules() {\n                return {\n                    required: {\n                        validate: (value) => !value,\n                        getDefaultMessage: () => this.messages.required\n                    },\n                    pattern: {\n                        validate: (value, input) => value && input.pattern && !new RegExp(input.pattern).test(value),\n                        getDefaultMessage: () => this.messages.pattern\n                    },\n                    tel: {\n                        validate: (value) => value && !/^09\\d{8}$/.test(value),\n                        getDefaultMessage: () => this.messages.tel\n                    },\n                    phone: {\n                        validate: (value) => value && !/^09\\d{8}$/.test(value),\n                        getDefaultMessage: () => this.messages.phone\n                    },\n                    email: {\n                        validate: (value) => value && !/^\\S+@\\S+\\.\\S+$/.test(value),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.email === 'function' ? this.messages.email(input.value) : this.messages.email\n                    },\n                    minLength: {\n                        validate: (value, input) => value && value.length < parseInt(input.minLength),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.minLength === 'function'\n                                ? this.messages.minLength(input.minLength, input.value.length)\n                                : this.messages.minLength\n                    },\n                    maxLength: {\n                        validate: (value, input) => value && value.length > parseInt(input.maxLength),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.maxLength === 'function'\n                                ? this.messages.maxLength(input.maxLength, input.value.length)\n                                : this.messages.maxLength\n                    },\n                    min: {\n                        validate: (value, input) => value && parseFloat(value) < parseFloat(input.min),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.min === 'function' ? this.messages.min(input.min) : this.messages.min\n                    },\n                    max: {\n                        validate: (value, input) => value && parseFloat(value) > parseFloat(input.max),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.max === 'function' ? this.messages.max(input.max) : this.messages.max\n                    },\n                    regex: {\n                        validate: (value, input) => {\n                            const regex = new RegExp(input.dataset.validRegex);\n                            return value && !regex.test(value);\n                        },\n                        getDefaultMessage: () => this.messages.regex\n                    },\n                    confirm: {\n                        validate: (value, input) => {\n                            const target = input.dataset.target;\n                            if (!target) return false;\n                            const targetInput = document.querySelector(target);\n                            const targetValue = targetInput?.value || '';\n                            return value && targetValue !== value;\n                        },\n                        getDefaultMessage: () => this.messages.passwordConfirm\n                    }\n                };\n            }\n\n            /**\n             * \u8655\u7406\u5BA2\u88FD\u5316\u9A57\u8B49\n             */\n            handleCustomValidation() {\n                const validInputs = this.form.querySelectorAll(\n                    'input[data-valid][required]:not([type=\"checkbox\"], [type=\"radio\"])',\n                    'select[data-valid][required]'\n                );\n                const rules = this.getValidationRules();\n\n                validInputs.forEach((input) => {\n                    const { valid = '', validFeedback = '' } = input.dataset;\n                    const valids = valid.split(',');\n                    const feedbacks = validFeedback.split(',');\n                    const value = input.value;\n\n                    // \u8655\u7406 required \u9A57\u8B49\uFF08\u512A\u5148\u8655\u7406\uFF09\n                    if (valids.includes('required') || input.required) {\n                        const validIndex = valids.indexOf('required');\n                        const rule = rules.required;\n                        const isInvalid = rule.validate(value);\n                        const feedback = feedbacks[validIndex] || rule.getDefaultMessage();\n\n                        this.handleValidation(input, isInvalid, feedback);\n                        if (isInvalid) return; // \u5982\u679C required \u9A57\u8B49\u5931\u6557\uFF0C\u4E0D\u7E7C\u7E8C\u5176\u4ED6\u9A57\u8B49\n                    }\n\n                    // \u5982\u679C\u6C92\u6709\u503C\uFF0C\u8DF3\u904E\u5176\u4ED6\u9A57\u8B49\n                    if (!value && !valids.includes('confirm')) return;\n\n                    // \u8655\u7406\u5176\u4ED6\u9A57\u8B49\u898F\u5247\n                    for (const validType of valids) {\n                        if (validType === 'required') continue; // \u5DF2\u8655\u7406\u904E\n\n                        const rule = rules[validType];\n                        if (!rule) continue;\n\n                        const validIndex = valids.indexOf(validType);\n                        const isInvalid = rule.validate(value, input);\n                        const feedback = feedbacks[validIndex] || rule.getDefaultMessage(input);\n\n                        // \u7279\u6B8A\u8655\u7406 confirm \u9A57\u8B49\u7684\u5143\u7D20\u9078\u64C7\n                        if (validType === 'confirm') {\n                            const parent = input.closest('.password-input-wrapper');\n                            this.handleValidation(input, isInvalid, feedback, parent);\n                        } else {\n                            this.handleValidation(input, isInvalid, feedback);\n                        }\n\n                        if (isInvalid) return; // \u4E00\u65E6\u6709\u9A57\u8B49\u5931\u6557\uFF0C\u505C\u6B62\u5F8C\u7E8C\u9A57\u8B49\n                    }\n                });\n            }\n\n            /**\n             * \u8A2D\u7F6E\u4E8B\u4EF6\u76E3\u807D\u5668\n             */\n            setupEventListeners() {\n                this.form.addEventListener('submit', (event) => {\n                    this.runAllValidations();\n\n                    // \u6AA2\u67E5\u8868\u55AE\u662F\u5426\u6709\u6548\n                    if (!this.form.checkValidity()) {\n                        event.preventDefault();\n                        event.stopPropagation();\n                        this.form.classList.add('was-validated');\n\n                        // \u53EF\u9078\u7684\u539F\u751F\u9A57\u8B49\u63D0\u793A\n                        if (this.options.reportValidity) {\n                            this.form.reportValidity();\n                        }\n                    }\n                });\n\n                // \u5373\u6642\u9A57\u8B49\uFF1A\u7576\u8868\u55AE\u4ECD\u7121\u6548\u6642\uFF0Cinput/select \u7684\u8B8A\u66F4\u6703\u7ACB\u5373\u89F8\u767C\u9A57\u8B49\n                if (this.isLiveValidateEnabled()) {\n                    const handleLiveValidate = (event) => {\n                        const target = event.target;\n                        if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement)) return;\n\n                        // \u53EA\u6709\u5728\u8868\u55AE\u4ECD\u7136\u7121\u6548\u6642\u624D\u89F8\u767C\uFF0C\u907F\u514D\u904E\u5EA6\u5E72\u64FE\n                        if (this.form.checkValidity()) return;\n\n                        this.runAllValidations();\n                    };\n\n                    // input\uFF1A\u6587\u5B57\u8F38\u5165\u5373\u6642\n                    this.form.addEventListener('input', handleLiveValidate);\n                    // change\uFF1Aselect/checkbox/radio\n                    this.form.addEventListener('change', handleLiveValidate);\n                }\n            }\n        }\n\n        /**\n         * \u53D6\u5F97\u7576\u524D\u8A9E\u7CFB\n         */\n        function getCurrentLocale() {\n            // \u512A\u5148\u9806\u5E8F\uFF1Adata-locale \u5C6C\u6027 > html lang \u5C6C\u6027 > navigator.language > \u9810\u8A2D\u503C\n            const htmlElement = document.documentElement;\n            return htmlElement.dataset.locale || htmlElement.lang || navigator.language || 'zh-TW';\n        }\n\n        // \u521D\u59CB\u5316\u6240\u6709\u9700\u8981\u9A57\u8B49\u7684\u8868\u55AE\n        const needsValidationForms = document.querySelectorAll('form.needs-validation[novalidate]');\n        const currentLocale = getCurrentLocale();\n\n        needsValidationForms.forEach((form) => {\n            // \u53EF\u4EE5\u900F\u904E form \u7684 data-locale \u5C6C\u6027\u8986\u84CB\u5168\u57DF\u8A9E\u7CFB\u8A2D\u5B9A\n            const formLocale = form.dataset.locale || currentLocale;\n\n            // \u53EF\u4EE5\u900F\u904E form \u7684 data-report-validity \u5C6C\u6027\u63A7\u5236\u662F\u5426\u986F\u793A\u539F\u751F\u9A57\u8B49\u63D0\u793A\n            const reportValidity = form.dataset.reportValidity !== 'false';\n\n            new FormValidator(form, formLocale, { reportValidity });\n        });\n    });\n<\/script>"], ["<script>\n    document.addEventListener('DOMContentLoaded', () => {\n        /**\n         * \u570B\u969B\u5316\u8A0A\u606F\u914D\u7F6E\n         */\n        const I18N_MESSAGES = {\n            'zh-TW': {\n                required: '\u6B64\u6B04\u4F4D\u70BA\u5FC5\u586B',\n                pattern: '\u8ACB\u7B26\u5408\u8981\u6C42\u683C\u5F0F',\n                tel: '\u8ACB\u8F38\u5165\u6B63\u78BA\u7684\u96FB\u8A71\u865F\u78BC',\n                phone: '\u8ACB\u8F38\u5165\u6B63\u78BA\u7684\u96FB\u8A71\u865F\u78BC',\n                email: (value) => {\n                    if (!value.includes('@')) {\n                        return \\`\u8ACB\u5728\u96FB\u5B50\u90F5\u4EF6\u5730\u5740\u4E2D\u5305\u62EC\u300C@\u300D\u3002\u300C\\${value}\u300D\u672A\u5305\u542B\u300C@\u300D\\`;\n                    } else {\n                        return \\`\u8ACB\u8F38\u5165\u300C@\u300D\u5F8C\u9762\u7684\u90E8\u5206\u3002\u300C\\${value}\u300D\u4E0D\u662F\u5B8C\u6574\u503C\u3002\\`;\n                    }\n                },\n                minLength: (minLength, currentLength) =>\n                    \\`\u8ACB\u5C07\u9019\u6BB5\u6587\u5B57\u52A0\u9577\u5230 \\${minLength} \u500B\u5B57\u5143\u4EE5\u4E0A (\u76EE\u524D\u5DF2\u6709 \\${currentLength} \u500B\u5B57\u5143\u6578)\\`,\n                maxLength: (maxLength, currentLength) =>\n                    \\`\u8ACB\u5C07\u9019\u6BB5\u6587\u5B57\u7E2E\u77ED\u5230 \\${maxLength} \u500B\u5B57\u5143\u4EE5\u4E0B (\u76EE\u524D\u5DF2\u6709 \\${currentLength} \u500B\u5B57\u5143\u6578)\\`,\n                min: (min) => \\`\u503C\u5FC5\u9808\u5927\u65BC\u6216\u7B49\u65BC \\${min}\u3002\\`,\n                max: (max) => \\`\u503C\u5FC5\u9808\u5C0F\u65BC\u6216\u7B49\u65BC \\${max}\u3002\\`,\n                regex: '',\n                passwordConfirm: '\u8207\u5BC6\u78BC\u4E0D\u7B26\u5408'\n            },\n            'en-US': {\n                required: 'This field is required',\n                pattern: 'Please match the required format',\n                tel: 'Please enter a valid phone number',\n                phone: 'Please enter a valid phone number',\n                email: (value) => {\n                    if (!value.includes('@')) {\n                        return \\`Please include an '@' in the email address. '\\${value}' is missing an '@'\\`;\n                    } else {\n                        return \\`Please enter the part following '@'. '\\${value}' is not a complete value.\\`;\n                    }\n                },\n                minLength: (minLength, currentLength) =>\n                    \\`Please lengthen this text to \\${minLength} characters or more (you are currently using \\${currentLength} characters)\\`,\n                maxLength: (maxLength, currentLength) =>\n                    \\`Please shorten this text to \\${maxLength} characters or less (you are currently using \\${currentLength} characters)\\`,\n                min: (min) => \\`Value must be greater than or equal to \\${min}.\\`,\n                max: (max) => \\`Value must be less than or equal to \\${max}.\\`,\n                regex: '',\n                passwordConfirm: 'Passwords do not match'\n            },\n            'ja-JP': {\n                required: '\u3053\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044',\n                pattern: '\u8981\u6C42\u3055\u308C\u305F\u5F62\u5F0F\u306B\u4E00\u81F4\u3055\u305B\u3066\u304F\u3060\u3055\u3044',\n                tel: '\u6B63\u3057\u3044\u96FB\u8A71\u756A\u53F7\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044',\n                phone: '\u6B63\u3057\u3044\u96FB\u8A71\u756A\u53F7\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044',\n                email: (value) => {\n                    if (!value.includes('@')) {\n                        return \\`\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306B\u300C@\u300D\u3092\u542B\u3081\u3066\u304F\u3060\u3055\u3044\u3002\u300C\\${value}\u300D\u306B\u306F\u300C@\u300D\u304C\u3042\u308A\u307E\u305B\u3093\\`;\n                    } else {\n                        return \\`\u300C@\u300D\u306E\u5F8C\u306E\u90E8\u5206\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u300C\\${value}\u300D\u306F\u5B8C\u5168\u306A\u5024\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\\`;\n                    }\n                },\n                minLength: (minLength, currentLength) =>\n                    \\`\u3053\u306E\u30C6\u30AD\u30B9\u30C8\u3092\\${minLength}\u6587\u5B57\u4EE5\u4E0A\u306B\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u73FE\u5728\\${currentLength}\u6587\u5B57\u3067\u3059\uFF09\\`,\n                maxLength: (maxLength, currentLength) =>\n                    \\`\u3053\u306E\u30C6\u30AD\u30B9\u30C8\u3092\\${maxLength}\u6587\u5B57\u4EE5\u4E0B\u306B\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u73FE\u5728\\${currentLength}\u6587\u5B57\u3067\u3059\uFF09\\`,\n                min: (min) => \\`\u5024\u306F\\${min}\u4EE5\u4E0A\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059\u3002\\`,\n                max: (max) => \\`\u5024\u306F\\${max}\u4EE5\u4E0B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059\u3002\\`,\n                regex: '',\n                passwordConfirm: '\u30D1\u30B9\u30EF\u30FC\u30C9\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093'\n            }\n        };\n\n        /**\n         * \u8868\u55AE\u9A57\u8B49\u5668\u985E\u5225\n         */\n        class FormValidator {\n            constructor(form, locale = 'zh-TW', options = {}) {\n                this.form = form;\n                this.locale = locale;\n                this.messages = I18N_MESSAGES[locale] || I18N_MESSAGES['zh-TW'];\n                this.options = {\n                    reportValidity: true, // \u9810\u8A2D\u555F\u7528\u539F\u751F\u9A57\u8B49\u63D0\u793A\n                    ...options\n                };\n                this.cacheOriginFeedbackText();\n                this.setupEventListeners();\n            }\n\n            /**\n             * \u662F\u5426\u555F\u7528\u5373\u6642\u9A57\u8B49\n             * \u7576\u8868\u55AE\u672A\u901A\u904E checkValidity \u6642\uFF0Cinput/select \u7684\u8B8A\u66F4\u6703\u89F8\u767C\u9A57\u8B49\n             */\n            isLiveValidateEnabled() {\n                const value = this.form.dataset.liveValidate;\n                // \u53EA\u8981\u6709 data-live-validate\uFF0C\u6216\u503C\u70BA 'true' \u90FD\u8996\u70BA\u555F\u7528\n                return value === '' || value === 'true';\n            }\n\n            /**\n             * \u5FEB\u53D6\u9801\u9762\u4E0A\u9810\u8A2D\u7684\u932F\u8AA4\u6587\u6848\n             * \u907F\u514D resetErrorMessages \u5C07\u300C\u539F\u672C\u5C31\u5B58\u5728\u7684\u63D0\u793A\u6587\u5B57\u300D\u6E05\u7A7A\n             */\n            cacheOriginFeedbackText() {\n                const errorTextEls = this.form.querySelectorAll('.error-text');\n                errorTextEls.forEach((errorTextEl) => {\n                    if (errorTextEl.hasAttribute('data-valid-origin-feedback')) return;\n                    const originText = (errorTextEl.textContent || '').trim();\n                    if (originText) {\n                        errorTextEl.setAttribute('data-valid-origin-feedback', originText);\n                    }\n                });\n            }\n\n            /**\n             * \u91CD\u7F6E\u6240\u6709\u932F\u8AA4\u8A0A\u606F\n             */\n            resetErrorMessages() {\n                const errorTextEls = this.form.querySelectorAll('.error-text');\n                errorTextEls.forEach((errorTextEl) => {\n                    const originFeedback = errorTextEl.getAttribute('data-valid-origin-feedback');\n                    errorTextEl.textContent = originFeedback || '';\n                });\n            }\n\n            /**\n             * \u57F7\u884C\u8868\u55AE\u7684\u6240\u6709\u9A57\u8B49\u6D41\u7A0B\n             * - \u5148\u91CD\u7F6E\u932F\u8AA4\u8A0A\u606F\uFF08\u4F9D data-valid-origin-feedback \u9084\u539F\u6216\u6E05\u7A7A\uFF09\n             * - \u4F9D\u5E8F\u57F7\u884C\u539F\u751F\u9A57\u8B49\u3001checkbox/radio \u9A57\u8B49\u3001\u5BA2\u88FD\u5316\u9A57\u8B49\u8207 wrapper \u72C0\u614B\u66F4\u65B0\n             */\n            runAllValidations() {\n                /** \u91CD\u7F6E\u932F\u8AA4\u8A0A\u606F */\n                this.resetErrorMessages();\n                /** \u57F7\u884C\u539F\u751F\u9A57\u8B49 */\n                this.handleNativeValidation();\n                /** \u57F7\u884C checkbox/radio \u9A57\u8B49 */\n                this.handleCheckboxValidation();\n                /** \u57F7\u884C\u5BA2\u88FD\u5316\u9A57\u8B49 */\n                this.handleCustomValidation();\n                /** \u66F4\u65B0 wrapper \u72C0\u614B */\n                this.handleWrapperValidation();\n            }\n\n            /**\n             * \u53D6\u5F97\u932F\u8AA4\u8A0A\u606F\u5143\u7D20\n             */\n            getErrorElement(input, isSpecialInput = false) {\n                if (isSpecialInput) {\n                    const parent = input.closest('.form-check, .password-input-wrapper');\n                    return (() => {\n                        let errorTextEl = parent?.closest('.form-input-group')?.querySelector('.error-text');\n                        if (errorTextEl) return errorTextEl || null;\n                        else {\n                            const nextSibling = parent?.nextElementSibling;\n                            if (nextSibling?.matches('.form-check-feedback-text.error-text')) return nextSibling;\n                            else return parent?.parentElement?.querySelector('.form-check-feedback-text.error-text') || null;\n                        }\n                    })();\n                }\n                return input?.closest('.form-input-group')?.querySelector('.error-text') || null;\n            }\n\n            /**\n             * \u5224\u65B7\u5143\u7D20\u7684\u6587\u5B57\u5167\u5BB9\u662F\u5426\u70BA\u7A7A\n             * \u4F9B\u932F\u8AA4\u8A0A\u606F\u66F4\u65B0\u6D41\u7A0B\u5171\u7528\uFF0C\u907F\u514D\u91CD\u8907\u7684 textContent/trim \u5224\u65B7\n             */\n            isEmptyTextContent(element) {\n                const text = element?.textContent;\n                return !text || text.trim() === '';\n            }\n\n            /**\n             * \u66F4\u65B0\u932F\u8AA4\u8A0A\u606F\n             * \u50C5\u5728\u932F\u8AA4\u8A0A\u606F\u5143\u7D20\u539F\u672C\u70BA\u7A7A\u6642\uFF0C\u624D\u5BEB\u5165 feedback\n             * \u82E5\u932F\u8AA4\u8A0A\u606F\u5143\u7D20\u672C\u4F86\u5C31\u6709\u6587\u6848\uFF0C\u5247\u6C38\u9060\u4E0D\u8986\u84CB\uFF08\u4FDD\u7559\u8A2D\u8A08\u7A3F/\u9801\u9762\u539F\u59CB\u6587\u6848\uFF09\n             */\n            updateErrorMessage(errorTextEl, feedback) {\n                if (!errorTextEl) return;\n\n                // \u5982\u679C\u9801\u9762\u672C\u4F86\u5C31\u6709\u932F\u8AA4\u6587\u6848\uFF0C\u6C38\u9060\u4E0D\u8986\u84CB\n                if (!this.isEmptyTextContent(errorTextEl)) return;\n\n                // \u6C92\u6709 feedback \u76F4\u63A5\u7565\u904E\n                if (!feedback) return;\n\n                errorTextEl.textContent = feedback;\n            }\n\n            /**\n             * \u8A2D\u5B9A\u9A57\u8B49\u72C0\u614B\n             */\n            setValidationState(input, isInvalid, feedback = '', element = null) {\n                const targetElement = element || input;\n\n                if (!this.form.classList.contains('was-validated')) {\n                    this.form.classList.toggle('was-validated', isInvalid);\n                }\n\n                if (!targetElement.classList.contains('is-invalid')) {\n                    targetElement.classList.toggle('is-invalid', !isInvalid);\n                }\n\n                if (input.setCustomValidity) {\n                    input.setCustomValidity(isInvalid ? feedback : '');\n                }\n            }\n\n            /**\n             * \u901A\u7528\u9A57\u8B49\u8655\u7406\u5668\n             */\n            handleValidation(input, isInvalid, feedback, element = null) {\n                this.setValidationState(input, isInvalid, feedback, element);\n\n                if (isInvalid) {\n                    const errorTextEl = this.getErrorElement(input, !!element);\n                    this.updateErrorMessage(errorTextEl, feedback);\n                }\n            }\n\n            /**\n             * \u70BA\u539F\u751F\u9A57\u8B49\u5C6C\u6027\u6DFB\u52A0\u4E8B\u4EF6\u76E3\u807D\u5668\n             */\n            addNativeValidationListener(selector, feedbackGenerator) {\n                const inputs = this.form.querySelectorAll(selector);\n                inputs.forEach((input) => {\n                    if (input.value) {\n                        input.addEventListener(\n                            'invalid',\n                            () => {\n                                const feedback = feedbackGenerator(input);\n                                const errorTextEl = this.getErrorElement(input);\n                                this.updateErrorMessage(errorTextEl, feedback);\n                            },\n                            { once: true }\n                        );\n                    }\n                });\n            }\n\n            /**\n             * \u8655\u7406\u539F\u751F HTML5 \u9A57\u8B49\n             */\n            handleNativeValidation() {\n                const nativeInputs = this.form.querySelectorAll(\n                    'input[required]:not([data-valid]):not([type=\"checkbox\"], [type=\"radio\"])',\n                    'select[required]:not([data-valid])'\n                );\n                const rules = this.getValidationRules();\n\n                nativeInputs.forEach((input) => {\n                    const value = input.value;\n\n                    // \u5B9A\u7FA9\u9A57\u8B49\u9806\u5E8F\uFF08\u512A\u5148\u9806\u5E8F\u5F9E\u9AD8\u5230\u4F4E\uFF09\n                    const validationOrder = [\n                        {\n                            condition: () => !value,\n                            rule: rules.required,\n                            getDefaultMessage: () => rules.required.getDefaultMessage()\n                        },\n                        {\n                            condition: () => value && input.type === 'email' && !/^\\\\S+@\\\\S+\\\\.\\\\S+$/.test(value),\n                            rule: rules.email,\n                            getDefaultMessage: () => rules.email.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.minLength > 0 && value.length < parseInt(input.minLength),\n                            rule: rules.minLength,\n                            getDefaultMessage: () => rules.minLength.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.maxLength > 0 && value.length > parseInt(input.maxLength),\n                            rule: rules.maxLength,\n                            getDefaultMessage: () => rules.maxLength.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.min && parseFloat(value) < parseFloat(input.min),\n                            rule: rules.min,\n                            getDefaultMessage: () => rules.min.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.max && parseFloat(value) > parseFloat(input.max),\n                            rule: rules.max,\n                            getDefaultMessage: () => rules.max.getDefaultMessage(input)\n                        },\n                        {\n                            condition: () => value && input.pattern && !new RegExp(input.pattern).test(value),\n                            rule: rules.pattern,\n                            getDefaultMessage: () => rules.pattern.getDefaultMessage()\n                        }\n                    ];\n\n                    // \u6309\u9806\u5E8F\u6AA2\u67E5\u9A57\u8B49\u898F\u5247\uFF0C\u53EA\u8655\u7406\u7B2C\u4E00\u500B\u5931\u6557\u7684\u898F\u5247\n                    for (let i = 0; i < validationOrder.length; i++) {\n                        const validation = validationOrder[i];\n                        if (validation.condition()) {\n                            const feedback = validation.getDefaultMessage();\n                            const isRequired = i === 0; // \u7B2C\u4E00\u500B\u9A57\u8B49\u662F required\n                            this.handleValidation(input, true, feedback, null, isRequired);\n                            return; // \u627E\u5230\u7B2C\u4E00\u500B\u5931\u6557\u7684\u9A57\u8B49\u5C31\u505C\u6B62\n                        }\n                    }\n\n                    // \u5982\u679C\u6240\u6709\u9A57\u8B49\u90FD\u901A\u904E\uFF0C\u6E05\u9664\u932F\u8AA4\u72C0\u614B\n                    this.handleValidation(input, false, '');\n                });\n            }\n\n            /**\n             * \u8655\u7406\u5305\u88DD\u5BB9\u5668\u7684\u9A57\u8B49\u72C0\u614B\n             * \u91DD\u5C0D .form-check \u548C .password-input-wrapper \u5E95\u4E0B\u7684 input\n             */\n            handleWrapperValidation() {\n                const wrapperInputs = this.form.querySelectorAll(\n                    '.form-check input[required], .password-input-wrapper input[required]'\n                );\n                wrapperInputs.forEach((input) => {\n                    const isInvalid = !input.checkValidity();\n\n                    // \u627E\u5230\u6700\u8FD1\u7684\u5305\u88DD\u5BB9\u5668\n                    const wrapper = input.closest('.form-check, .password-input-wrapper');\n                    if (wrapper) {\n                        wrapper.classList.toggle('is-invalid', isInvalid);\n                    }\n                });\n            }\n\n            /**\n             * \u8655\u7406\u8907\u9078\u6846\u9A57\u8B49\n             */\n            handleCheckboxValidation() {\n                const checkboxInputs = this.form.querySelectorAll(\n                    'input[type=\"checkbox\"][required], input[type=\"radio\"][required]'\n                );\n                checkboxInputs.forEach((input) => {\n                    const { validFeedback: feedback = '' } = input.dataset;\n                    const isInvalid = !input.checkValidity();\n\n                    if (isInvalid) {\n                        const errorTextEl = this.getErrorElement(input, true);\n                        this.updateErrorMessage(errorTextEl, errorTextEl.textContent || feedback || this.messages.required);\n                    }\n                });\n            }\n\n            /**\n             * \u9A57\u8B49\u898F\u5247\u914D\u7F6E\n             */\n            getValidationRules() {\n                return {\n                    required: {\n                        validate: (value) => !value,\n                        getDefaultMessage: () => this.messages.required\n                    },\n                    pattern: {\n                        validate: (value, input) => value && input.pattern && !new RegExp(input.pattern).test(value),\n                        getDefaultMessage: () => this.messages.pattern\n                    },\n                    tel: {\n                        validate: (value) => value && !/^09\\\\d{8}$/.test(value),\n                        getDefaultMessage: () => this.messages.tel\n                    },\n                    phone: {\n                        validate: (value) => value && !/^09\\\\d{8}$/.test(value),\n                        getDefaultMessage: () => this.messages.phone\n                    },\n                    email: {\n                        validate: (value) => value && !/^\\\\S+@\\\\S+\\\\.\\\\S+$/.test(value),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.email === 'function' ? this.messages.email(input.value) : this.messages.email\n                    },\n                    minLength: {\n                        validate: (value, input) => value && value.length < parseInt(input.minLength),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.minLength === 'function'\n                                ? this.messages.minLength(input.minLength, input.value.length)\n                                : this.messages.minLength\n                    },\n                    maxLength: {\n                        validate: (value, input) => value && value.length > parseInt(input.maxLength),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.maxLength === 'function'\n                                ? this.messages.maxLength(input.maxLength, input.value.length)\n                                : this.messages.maxLength\n                    },\n                    min: {\n                        validate: (value, input) => value && parseFloat(value) < parseFloat(input.min),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.min === 'function' ? this.messages.min(input.min) : this.messages.min\n                    },\n                    max: {\n                        validate: (value, input) => value && parseFloat(value) > parseFloat(input.max),\n                        getDefaultMessage: (input) =>\n                            typeof this.messages.max === 'function' ? this.messages.max(input.max) : this.messages.max\n                    },\n                    regex: {\n                        validate: (value, input) => {\n                            const regex = new RegExp(input.dataset.validRegex);\n                            return value && !regex.test(value);\n                        },\n                        getDefaultMessage: () => this.messages.regex\n                    },\n                    confirm: {\n                        validate: (value, input) => {\n                            const target = input.dataset.target;\n                            if (!target) return false;\n                            const targetInput = document.querySelector(target);\n                            const targetValue = targetInput?.value || '';\n                            return value && targetValue !== value;\n                        },\n                        getDefaultMessage: () => this.messages.passwordConfirm\n                    }\n                };\n            }\n\n            /**\n             * \u8655\u7406\u5BA2\u88FD\u5316\u9A57\u8B49\n             */\n            handleCustomValidation() {\n                const validInputs = this.form.querySelectorAll(\n                    'input[data-valid][required]:not([type=\"checkbox\"], [type=\"radio\"])',\n                    'select[data-valid][required]'\n                );\n                const rules = this.getValidationRules();\n\n                validInputs.forEach((input) => {\n                    const { valid = '', validFeedback = '' } = input.dataset;\n                    const valids = valid.split(',');\n                    const feedbacks = validFeedback.split(',');\n                    const value = input.value;\n\n                    // \u8655\u7406 required \u9A57\u8B49\uFF08\u512A\u5148\u8655\u7406\uFF09\n                    if (valids.includes('required') || input.required) {\n                        const validIndex = valids.indexOf('required');\n                        const rule = rules.required;\n                        const isInvalid = rule.validate(value);\n                        const feedback = feedbacks[validIndex] || rule.getDefaultMessage();\n\n                        this.handleValidation(input, isInvalid, feedback);\n                        if (isInvalid) return; // \u5982\u679C required \u9A57\u8B49\u5931\u6557\uFF0C\u4E0D\u7E7C\u7E8C\u5176\u4ED6\u9A57\u8B49\n                    }\n\n                    // \u5982\u679C\u6C92\u6709\u503C\uFF0C\u8DF3\u904E\u5176\u4ED6\u9A57\u8B49\n                    if (!value && !valids.includes('confirm')) return;\n\n                    // \u8655\u7406\u5176\u4ED6\u9A57\u8B49\u898F\u5247\n                    for (const validType of valids) {\n                        if (validType === 'required') continue; // \u5DF2\u8655\u7406\u904E\n\n                        const rule = rules[validType];\n                        if (!rule) continue;\n\n                        const validIndex = valids.indexOf(validType);\n                        const isInvalid = rule.validate(value, input);\n                        const feedback = feedbacks[validIndex] || rule.getDefaultMessage(input);\n\n                        // \u7279\u6B8A\u8655\u7406 confirm \u9A57\u8B49\u7684\u5143\u7D20\u9078\u64C7\n                        if (validType === 'confirm') {\n                            const parent = input.closest('.password-input-wrapper');\n                            this.handleValidation(input, isInvalid, feedback, parent);\n                        } else {\n                            this.handleValidation(input, isInvalid, feedback);\n                        }\n\n                        if (isInvalid) return; // \u4E00\u65E6\u6709\u9A57\u8B49\u5931\u6557\uFF0C\u505C\u6B62\u5F8C\u7E8C\u9A57\u8B49\n                    }\n                });\n            }\n\n            /**\n             * \u8A2D\u7F6E\u4E8B\u4EF6\u76E3\u807D\u5668\n             */\n            setupEventListeners() {\n                this.form.addEventListener('submit', (event) => {\n                    this.runAllValidations();\n\n                    // \u6AA2\u67E5\u8868\u55AE\u662F\u5426\u6709\u6548\n                    if (!this.form.checkValidity()) {\n                        event.preventDefault();\n                        event.stopPropagation();\n                        this.form.classList.add('was-validated');\n\n                        // \u53EF\u9078\u7684\u539F\u751F\u9A57\u8B49\u63D0\u793A\n                        if (this.options.reportValidity) {\n                            this.form.reportValidity();\n                        }\n                    }\n                });\n\n                // \u5373\u6642\u9A57\u8B49\uFF1A\u7576\u8868\u55AE\u4ECD\u7121\u6548\u6642\uFF0Cinput/select \u7684\u8B8A\u66F4\u6703\u7ACB\u5373\u89F8\u767C\u9A57\u8B49\n                if (this.isLiveValidateEnabled()) {\n                    const handleLiveValidate = (event) => {\n                        const target = event.target;\n                        if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement)) return;\n\n                        // \u53EA\u6709\u5728\u8868\u55AE\u4ECD\u7136\u7121\u6548\u6642\u624D\u89F8\u767C\uFF0C\u907F\u514D\u904E\u5EA6\u5E72\u64FE\n                        if (this.form.checkValidity()) return;\n\n                        this.runAllValidations();\n                    };\n\n                    // input\uFF1A\u6587\u5B57\u8F38\u5165\u5373\u6642\n                    this.form.addEventListener('input', handleLiveValidate);\n                    // change\uFF1Aselect/checkbox/radio\n                    this.form.addEventListener('change', handleLiveValidate);\n                }\n            }\n        }\n\n        /**\n         * \u53D6\u5F97\u7576\u524D\u8A9E\u7CFB\n         */\n        function getCurrentLocale() {\n            // \u512A\u5148\u9806\u5E8F\uFF1Adata-locale \u5C6C\u6027 > html lang \u5C6C\u6027 > navigator.language > \u9810\u8A2D\u503C\n            const htmlElement = document.documentElement;\n            return htmlElement.dataset.locale || htmlElement.lang || navigator.language || 'zh-TW';\n        }\n\n        // \u521D\u59CB\u5316\u6240\u6709\u9700\u8981\u9A57\u8B49\u7684\u8868\u55AE\n        const needsValidationForms = document.querySelectorAll('form.needs-validation[novalidate]');\n        const currentLocale = getCurrentLocale();\n\n        needsValidationForms.forEach((form) => {\n            // \u53EF\u4EE5\u900F\u904E form \u7684 data-locale \u5C6C\u6027\u8986\u84CB\u5168\u57DF\u8A9E\u7CFB\u8A2D\u5B9A\n            const formLocale = form.dataset.locale || currentLocale;\n\n            // \u53EF\u4EE5\u900F\u904E form \u7684 data-report-validity \u5C6C\u6027\u63A7\u5236\u662F\u5426\u986F\u793A\u539F\u751F\u9A57\u8B49\u63D0\u793A\n            const reportValidity = form.dataset.reportValidity !== 'false';\n\n            new FormValidator(form, formLocale, { reportValidity });\n        });\n    });\n<\/script>"])));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/script/script.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Layouts = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Layouts;
  const site = Astro2.url.origin;
  const OGImage = `${site}/assets/meta/Open-Graph-Image.jpg`;
  const favicon = [
    {
      rel: "shortcut icon",
      sizes: "16x16",
      type: "image/ico",
      href: `${site}/assets/meta/favicon.ico`
    },
    {
      rel: "icon",
      sizes: "16x16",
      type: "image/ico",
      href: `${site}/assets/meta/favicon.ico`
    },
    {
      rel: "icon",
      sizes: "192x192",
      type: "image/png",
      href: `${site}/assets/meta/android-icon-192x192.png`
    },
    {
      rel: "icon",
      sizes: "32x32",
      type: "image/png",
      href: `${site}/assets/meta/favicon-32x32.png`
    },
    {
      rel: "icon",
      sizes: "96x96",
      type: "image/png",
      href: `${site}/assets/meta/favicon-96x96.png`
    },
    {
      rel: "icon",
      sizes: "16x16",
      type: "image/png",
      href: `${site}/assets/meta/favicon-16x16.png`
    },
    {
      rel: "bookmark",
      sizes: "32x32",
      type: "image/png",
      href: `${site}/assets/meta/favicon-32x32.png`
    }
  ];
  const appleTouchIcon = [
    {
      type: "image/png",
      sizes: "57x57",
      href: `${site}/assets/meta/apple-icon-57x57.png`
    },
    {
      type: "image/png",
      sizes: "60x60",
      href: `${site}/assets/meta/apple-icon-60x60.png`
    },
    {
      type: "image/png",
      sizes: "72x72",
      href: `${site}/assets/meta/apple-icon-72x72.png`
    },
    {
      type: "image/png",
      sizes: "76x76",
      href: `${site}/assets/meta/apple-icon-76x76.png`
    },
    {
      type: "image/png",
      sizes: "114x114",
      href: `${site}/assets/meta/apple-icon-114x114.png`
    },
    {
      type: "image/png",
      sizes: "120x120",
      href: `${site}/assets/meta/apple-icon-120x120.png`
    },
    {
      type: "image/png",
      sizes: "144x144",
      href: `${site}/assets/meta/apple-icon-144x144.png`
    },
    {
      type: "image/png",
      sizes: "152x152",
      href: `${site}/assets/meta/apple-icon-152x152.png`
    },
    {
      type: "image/png",
      sizes: "167x167",
      href: `${site}/assets/meta/apple-icon-167x167.png`
    },
    {
      type: "image/png",
      sizes: "180x180",
      href: `${site}/assets/meta/apple-icon-180x180.png`
    }
  ];
  const googleFont = "https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;500;700&display=swap";
  const customFont = {
    css: `${Astro2.url.origin}/assets/fonts/fonts.css`,
    fonts: [
      "TTNormsProNormal_normal_normal.woff2",
      "TTNormsProNormal_normal_normal.woff",
      "TTNormsProMedium_normal_normal.woff2",
      "TTNormsProMedium_normal_normal.woff"
    ],
    type: "woff2"
  };
  const {
    IDName,
    className,
    bodyClassName,
    footerShowBorderTop = false,
    footerPages = [],
    minMarginHeader = false,
    isMemberFooter = false
  } = Astro2.props;
  return renderTemplate`<html lang="zh-TW">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        ${renderComponent($$result, "Seo", $$Seo, { "title": "Asus", "description": "Asus", "keywords": "Asus".split(","), "favicon": favicon, "appleTouchIcon": appleTouchIcon, "themeColor": "#", "colorScheme": "light", "facebook": {
    image: OGImage,
    url: site,
    type: "website"
  }, "twitter": {
    image: OGImage,
    site,
    card: "summary"
  }, "google": {
    author: "Asus",
    copyright: "Asus",
    applicationName: "Asus"
  }, "robots": {
    content: "all"
  }, "font": {
    google: googleFont,
    custom: customFont
  }, "schemas": [
    {
      "@context": "https://schema.org",
      "@type": "WorkersUnion",
      url: `${site}`,
      logo: `${site}/assets/logos/logo-text.png`,
      address: {
        "@type": "PostalAddress",
        streetAddress: "",
        addressLocality: "",
        addressRegion: "",
        postalCode: "",
        addressCountry: "Taiwan"
      },
      contactPoint: {
        "@type": "ContactPoint",
        telephone: "",
        contactType: ""
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      url: `${site}`,
      name: "",
      alternateName: ""
    }
  ] })}
        ${renderComponent($$result, "CssVariable", $$CssVariable, {})}
        <link rel="preload" href="https://dlcdnimgs.asus.com/vendor/public/fonts/js/roboto.js" as="script">
        <link rel="preload" href="https://dlcdnimgs.asus.com/vendor/public/fonts/js/roboto-condensed.js" as="script">
        ${renderSlot($$result, $$slots["link"])}
    ${renderHead()}</head>
    <body${addAttribute(bodyClassName, "class:list")}>
        ${renderComponent($$result, "Header", $$Header, {})}
        <main${addAttribute(IDName, "id")}${addAttribute([className, { "margin-top": minMarginHeader }], "class:list")}${addAttribute(IDName, "data-name")}>
            ${renderSlot($$result, $$slots["default"])}
        </main>
        ${isMemberFooter ? renderTemplate`${renderComponent($$result, "MemberFooter", $$MemberFooter, {})}` : renderTemplate`${renderComponent($$result, "Footer", $$Footer, { "pages": footerPages, "showBorderTop": footerShowBorderTop })}`}
        ${renderComponent($$result, "Script", $$Script, {})}
        ${renderComponent($$result, "Toast", $$Toast, {})}
        ${renderSlot($$result, $$slots["script"])}
    </body></html>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/layouts/layouts.astro", void 0);

export { $$Button as $, $$Layouts as a, $$Input as b, $$Link as c, $$A as d, $$Modal as e, $$CollapseArrow as f, ext as g, $$Offcanvas$1 as h, $$InputWrapper as i, $$Collapse as j };
