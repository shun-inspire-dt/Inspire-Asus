import { c as createAstro, a as createComponent, d as renderTemplate, r as renderComponent, m as maybeRenderHead, b as addAttribute } from './astro/server_Bjgbv9en.mjs';
import { e as $$Modal } from './layouts_Bzy3aiqY.mjs';
/* empty css                         */

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Video = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Video;
  const { IDName = "Video", className, style, attribute = {}, defaultVideoId } = Astro2.props;
  return renderTemplate(_a || (_a = __template(["", `


<script>
    /**
     * YouTube \u52D5\u614B\u64AD\u653E\u5668\u7BA1\u7406\u5668
     */
    class YouTubePlayerManager {
        constructor() {
            this.player = null;
            this.triggerButton = null;
            this.currentVideoId = null;
            this.isAPIReady = false;
            this.defaultVideoId = null;
            this.modal = document.getElementById('VideoModal');
            
            this.init();
        }

        /**
         * \u521D\u59CB\u5316 YouTube API
         */
        init() {
            // \u53D6\u5F97\u9810\u8A2D\u5F71\u7247 ID
            const container = document.getElementById('youtube-player-container');
            this.defaultVideoId = container?.dataset?.defaultVideoId;

            // \u8F09\u5165 YouTube IFrame API
            if (!window.YT) {
                const tag = document.createElement('script');
                tag.src = 'https://www.youtube.com/iframe_api';
                const firstScriptTag = document.getElementsByTagName('script')[0];
                firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
            }

            // \u8A2D\u7F6E API \u6E96\u5099\u5B8C\u6210\u56DE\u8ABF
            window.onYouTubeIframeAPIReady = () => {
                this.isAPIReady = true;
                // \u5982\u679C\u6709\u9810\u8A2D\u5F71\u7247\u4E14\u5DF2\u7D93\u6709 iframe\uFF0C\u521D\u59CB\u5316\u64AD\u653E\u5668
                this.initializeDefaultPlayer();
            };

            this.setupModalEvents();
        }

        /**
         * \u521D\u59CB\u5316\u9810\u8A2D\u64AD\u653E\u5668
         */
        initializeDefaultPlayer() {
            const existingPlayer = document.getElementById('youtube-player');
            if (existingPlayer && this.defaultVideoId) {
                this.currentVideoId = this.defaultVideoId;
                this.player = new YT.Player('youtube-player', {
                    events: {
                        'onReady': (event) => {
                            // \u9810\u8A2D\u4E0D\u81EA\u52D5\u64AD\u653E
                        },
                        'onError': (event) => {
                            console.error('YouTube Player Error:', event.data);
                        }
                    }
                });
            }
        }

        /**
         * \u8A2D\u7F6E Modal \u4E8B\u4EF6\u76E3\u807D\u5668
         */
        setupModalEvents() {
            
            this.modal.addEventListener('show.bs.modal', (e) => {
                this.triggerButton = e.relatedTarget;
                
                // \u53D6\u5F97 video-id
                const videoId = this.triggerButton?.dataset?.videoId || this.triggerButton?.getAttribute('data-video-id');
                
                if (videoId) {
                    this.loadVideo(videoId);
                } else if (this.defaultVideoId && this.player) {
                    // \u5982\u679C\u6C92\u6709\u6307\u5B9A\u5F71\u7247 ID\uFF0C\u4F46\u6709\u9810\u8A2D\u5F71\u7247\uFF0C\u5C31\u64AD\u653E\u9810\u8A2D\u5F71\u7247
                    this.playVideo();
                }
                
                if (this.triggerButton && !this.triggerButton.classList.contains('active')) {
                    this.triggerButton.classList.add('active');
                }
            });
            
            this.modal.addEventListener('hidden.bs.modal', (e) => {
                if (this.triggerButton && this.triggerButton.classList.contains('active')) {
                    this.triggerButton.classList.remove('active');
                }
                
                this.triggerButton = null;
                
                // \u5982\u679C\u7576\u524D\u64AD\u653E\u7684\u4E0D\u662F\u9810\u8A2D\u5F71\u7247\uFF0C\u5C31\u92B7\u6BC0\u64AD\u653E\u5668\u4E26\u56DE\u5230\u9810\u8A2D\u5F71\u7247
                if (this.currentVideoId !== this.defaultVideoId) {
                    this.destroyPlayer();
                    if (this.defaultVideoId) {
                        // \u91CD\u65B0\u8F09\u5165\u9810\u8A2D\u5F71\u7247\u4F46\u4E0D\u81EA\u52D5\u64AD\u653E
                        setTimeout(() => this.initializeDefaultPlayer(), 100);
                    }
                } else {
                    // \u5982\u679C\u662F\u9810\u8A2D\u5F71\u7247\uFF0C\u53EA\u66AB\u505C\u4E0D\u92B7\u6BC0
                    this.pauseVideo();
                }
            });
        }

        /**
         * \u8F09\u5165\u6307\u5B9A\u7684 YouTube \u5F71\u7247
         */
        loadVideo(videoId) {
            if (!videoId || this.currentVideoId === videoId) return;
            
            this.currentVideoId = videoId;
            
            // \u5982\u679C API \u9084\u6C92\u6E96\u5099\u597D\uFF0C\u7B49\u5F85\u4E00\u4E0B\u518D\u8A66
            if (!this.isAPIReady) {
                setTimeout(() => this.loadVideo(videoId), 100);
                return;
            }

            // \u92B7\u6BC0\u73FE\u6709\u64AD\u653E\u5668
            this.destroyPlayer();

            // \u5EFA\u7ACB\u65B0\u7684\u64AD\u653E\u5668
            this.createPlayer(videoId);
        }

        /**
         * \u5EFA\u7ACB YouTube \u64AD\u653E\u5668
         */
        createPlayer(videoId) {
            const container = document.getElementById('youtube-player-container');
            if (!container) return;

            // \u6E05\u7A7A\u5BB9\u5668\u4E26\u5EFA\u7ACB\u65B0\u7684 div
            container.innerHTML = '<div id="youtube-player"></div>';

            this.player = new YT.Player('youtube-player', {
                height: '315',
                width: '560',
                videoId: videoId,
                playerVars: {
                    'enablejsapi': 1,
                    'origin': window.location.origin
                },
                events: {
                    'onReady': (event) => {
                        // \u64AD\u653E\u5668\u6E96\u5099\u5B8C\u6210\uFF0C\u53EF\u4EE5\u81EA\u52D5\u64AD\u653E
                        event.target.playVideo();
                    },
                    'onError': (event) => {
                        console.error('YouTube Player Error:', event.data);
                    }
                }
            });
        }

        /**
         * \u92B7\u6BC0\u64AD\u653E\u5668
         */
        destroyPlayer() {
            if (this.player && typeof this.player.destroy === 'function') {
                this.player.destroy();
                this.player = null;
            }
            
            // \u6E05\u7A7A\u5BB9\u5668
            const container = document.getElementById('youtube-player-container');
            if (container) {
                container.innerHTML = '';
            }
            
            this.currentVideoId = null;
        }

        /**
         * \u66AB\u505C\u5F71\u7247
         */
        pauseVideo() {
            if (this.player && typeof this.player.pauseVideo === 'function') {
                this.player.pauseVideo();
            }
        }

        /**
         * \u64AD\u653E\u5F71\u7247
         */
        playVideo() {
            if (this.player && typeof this.player.playVideo === 'function') {
                this.player.playVideo();
            }
        }
    }

    // \u521D\u59CB\u5316 YouTube \u64AD\u653E\u5668\u7BA1\u7406\u5668
    document.addEventListener('DOMContentLoaded', () => {
        window.youtubeManager = new YouTubePlayerManager();
    });
<\/script>`])), renderComponent($$result, "Modal", $$Modal, { "id": IDName, "sizes": "xl", "Modalclass": className, "center": true, "hideFooter": true, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div id="youtube-player-container"${addAttribute(defaultVideoId, "data-default-video-id")}>
        ${defaultVideoId && renderTemplate`<iframe id="youtube-player" width="560" height="315"${addAttribute(`https://www.youtube.com/embed/${defaultVideoId}?enablejsapi=1`, "src")} title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen>
            </iframe>`}
    </div>
` }));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/modal/video.astro", void 0);

export { $$Video as $ };
