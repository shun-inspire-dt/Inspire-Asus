import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$Referral = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="8" cy="7" r="2.4" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></circle>
<path d="M8 9.40039C5.79086 9.40039 4 11.1911 4 13.4004" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></path>
<circle cx="15" cy="11" r="3.4" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></circle>
<path d="M15 14.4004C18.3137 14.4004 21 17.0867 21 20.4004H15" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M9 16C9 16 9.5 18 12.5 20.5C9 20.5 7.66667 19 7 18L5.5 19.5V14.5H10.5L9 16Z" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/referral.astro", void 0);

export { $$Referral as default };
