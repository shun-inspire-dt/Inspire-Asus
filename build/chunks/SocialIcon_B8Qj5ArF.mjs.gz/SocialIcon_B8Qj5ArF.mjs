import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
/* empty css                         */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$SocialIcon = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$SocialIcon;
  const { width, type = "icon_google", size = "lg", class: className = "", Tag = "span", ...rest } = Astro2.props;
  const iconMap = {
    "icon_microsoft-lg": (await import('./type_icon_microsoft-size_lg_o_WQGZhh.mjs')).default,
    "icon_microsoft-md": (await import('./type_icon_microsoft-size_md_CuHUr6wn.mjs')).default,
    "icon_microsoft-sm": (await import('./type_icon_microsoft-size_sm_X-L8y8Bi.mjs')).default,
    "icon_line-lg": (await import('./type_icon_line-size_lg_CUbD1GX_.mjs')).default,
    "icon_line-md": (await import('./type_icon_line-size_md_DyjVx62b.mjs')).default,
    "icon_line-sm": (await import('./type_icon_line-size_sm_BonSvwUz.mjs')).default,
    "icon_google-lg": (await import('./type_icon_google-size_lg_DTSQDL1m.mjs')).default,
    "icon_google-md": (await import('./type_icon_google-size_md_DmL1VGCd.mjs')).default,
    "icon_google-sm": (await import('./type_icon_google-size_sm_DW4ocRxn.mjs')).default,
    "icon_fb-lg": (await import('./type_icon_fb-size_lg_B14k0n5v.mjs')).default,
    "icon_fb-md": (await import('./type_icon_fb-size_md_CWbOTMCr.mjs')).default,
    "icon_fb-sm": (await import('./type_icon_fb-size_sm_DaLNAPsL.mjs')).default,
    "icon_apple-lg": (await import('./type_icon_apple-size_lg_33OwtkVP.mjs')).default,
    "icon_apple-md": (await import('./type_icon_apple-size_md_CNIp6Ow9.mjs')).default,
    "icon_apple-sm": (await import('./type_icon_apple-size_sm_-DPvSmFB.mjs')).default
  };
  const iconKey = `${type}-${size}`;
  const IconComponent = iconMap[iconKey] || iconMap["icon_google-lg"];
  const classes = ["social-icon", `social-icon--${type.replace("icon_", "")}`, `social-icon--${size.toLowerCase()}`, className].filter(Boolean).join(" ");
  const widthVar = !isNaN(width) ? `${parseInt(width) / 16}rem` : void 0;
  const style = {
    "--social-icon-size-lg": widthVar,
    "--social-icon-size-md": widthVar,
    "--social-icon-size-sm": widthVar
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "class": classes, "data-social-icon": true, "data-type": type, "data-size": size, "role": "img", "style": style, ...rest }, { "default": async ($$result2) => renderTemplate`
    ${renderComponent($$result2, "IconComponent", IconComponent, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/social/SocialIcon.astro", void 0);

export { $$SocialIcon as $ };
