import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { c as $$Link } from './layouts_Bzy3aiqY.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$TableLink = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$TableLink;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "ALink", $$Link, { "IDName": IDName, "link": `/member/order-aocc/${data?.data?.id}`, "className": [className], "style": style, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    查看明細
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/order-aocc/tableLink.astro", void 0);

const data = [
  ["O20250915001", "2025/09/15", "iERP｜智慧採購叫貨系統", "1", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "1", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"],
  ["O20250915002", "2025/09/14", "iERP｜智慧採購叫貨系統", "3", "待處理", "查看明細"]
].flatMap((x) => ({
  items: x.flatMap((y) => ({
    text: y,
    attribute: { style: { "text-align": !isNaN(y) || y === "待處理" ? "center" : "" } },
    component: y === "查看明細" ? $$TableLink : void 0,
    data: y === "查看明細" ? { id: x[0] } : void 0
  }))
}));
const width = {
  詢問單號: "9rem",
  詢問日期: "7.375rem",
  產品名稱: "auto",
  數量: "4rem",
  狀態: "5rem",
  "": "6rem"
};
const field = ["詢問單號", "詢問日期", "產品名稱", "數量", "狀態", ""].map((x) => ({
  text: x,
  attribute: { style: { width: width[x], "text-align": ["數量", "狀態"].includes(x) ? "center" : "" } }
}));

export { data as d, field as f };
