import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Companyprofile = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11 20.4H6.60001V4.59961H14.4V11" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></path>
<path d="M7 11.5996H3.59961V20.4H7" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></path>
<path d="M15.7389 15.6692C17.1664 15.6692 18.3235 14.5121 18.3235 13.0846C18.3235 11.6572 17.1664 10.5 15.7389 10.5C14.3115 10.5 13.1543 11.6572 13.1543 13.0846C13.1543 14.5121 14.3115 15.6692 15.7389 15.6692Z" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M15.7383 16.0996V15.4996H15.7383L15.7383 16.0996ZM20.4766 20.4072V21.0072C20.6357 21.0072 20.7883 20.944 20.9008 20.8315C21.0134 20.719 21.0766 20.5663 21.0766 20.4072L20.4766 20.4072ZM11 20.4072L10.4 20.4072C10.4 20.5663 10.4632 20.719 10.5757 20.8315C10.6883 20.944 10.8409 21.0072 11 21.0072V20.4072ZM15.7383 16.0996V16.6996C18.0789 16.6996 19.8765 18.4121 19.8766 20.4072L20.4766 20.4072L21.0766 20.4072C21.0765 17.6443 18.6315 15.4996 15.7383 15.4996V16.0996ZM20.4766 20.4072V19.8072H11V20.4072V21.0072H20.4766V20.4072ZM11 20.4072L11.6 20.4072C11.6 18.4121 13.3977 16.6997 15.7383 16.6996L15.7383 16.0996L15.7383 15.4996C12.8451 15.4997 10.4001 17.6443 10.4 20.4072L11 20.4072Z" fill="var(--color-gray-900, var(--color-gray-900, #181818))"></path>
<rect x="9.39999" y="7" width="0" height="1" fill="var(--color-gray-900, var(--color-gray-900, #181818))" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></rect>
<rect x="11.6" y="7" width="0" height="1" fill="var(--color-gray-900, var(--color-gray-900, #181818))" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></rect>
<rect x="9.39999" y="10" width="0" height="1" fill="var(--color-gray-900, var(--color-gray-900, #181818))" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></rect>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/companyprofile.astro", void 0);

export { $$Companyprofile as default };
