import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot } from './astro/server_Bjgbv9en.mjs';
/* empty css                        */

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Calendar = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Calendar;
  const { IDName, className, style, attribute = {}, Tag = "span", width, color } = Astro2.props;
  const cardStyle = {
    ...width ? { "--icon-size": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "calendar-icon"], "style": cardStyle, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1.5 2.09961H16.5C16.9971 2.09961 17.4004 2.50294 17.4004 3V17C17.4004 17.4971 16.9971 17.9004 16.5 17.9004H1.5C1.00294 17.9004 0.599609 17.4971 0.599609 17V3C0.59961 2.50294 1.00294 2.09961 1.5 2.09961Z" stroke="currentColor" stroke-width="1.2"></path>
        <line y1="6.9" x2="18" y2="6.9" stroke="currentColor" stroke-width="1.2"></line>
        <line x1="5.4" y1="3.9" x2="5.4" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
        <line x1="12.9" y1="3.9" x2="12.9" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/calendar.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Date = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Date;
  const { IDName, className, style, attribute = {}, date, fontSize, width, color, mode = "light" } = Astro2.props;
  const cardStyle = {
    ...width ? { "--icon-size": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...fontSize ? { "--icon-font-size": fontSize } : {},
    ...style
  };
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute(["date-card", { "date-card--dark": mode === "dark" }, className], "class:list")}${addAttribute(cardStyle, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Calendar", $$Calendar, {})}
    <span class="date-card-text">
        ${renderSlot($$result, $$slots["default"], renderTemplate`${date}`)}
    </span>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/date.astro", void 0);

export { $$Date as $ };
