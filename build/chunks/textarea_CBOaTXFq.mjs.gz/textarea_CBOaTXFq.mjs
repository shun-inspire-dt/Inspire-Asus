import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
/* empty css                             */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Textarea = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Textarea;
  const {
    id,
    className,
    name,
    title,
    value,
    cols = 2,
    rows = 2,
    maxlength,
    minlength,
    placeholder,
    required,
    disabled,
    readonly,
    attribute = {},
    style,
    size,
    noResize
  } = Astro2.props;
  const inputClasses = [
    "control-input",
    // 基礎輸入框類別
    { [`size_${size}`]: size },
    // 尺寸類別
    { noresize: noResize },
    // 是否禁止調整大小
    className
    // 自定義類別
  ].filter(Boolean);
  return renderTemplate`${maybeRenderHead()}<textarea${addAttribute(id, "id")}${addAttribute(inputClasses, "class:list")}${addAttribute(name, "name")}${addAttribute(cols, "cols")}${addAttribute(rows, "rows")}${addAttribute(maxlength, "maxlength")}${addAttribute(minlength, "minlength")}${addAttribute(placeholder, "placeholder")}${addAttribute(required, "required")}${addAttribute(disabled, "disabled")}${addAttribute(readonly, "readonly")}${addAttribute(title, "aria-label")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>    ${value?.trim()}
</textarea>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/textarea.astro", void 0);

export { $$Textarea as $ };
