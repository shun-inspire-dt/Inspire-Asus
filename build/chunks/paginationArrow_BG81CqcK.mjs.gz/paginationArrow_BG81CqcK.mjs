import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, f as renderSlot, m as maybeRenderHead, b as addAttribute, s as spreadAttributes } from './astro/server_v5wg8FJS.mjs';
/* empty css                         */

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Badge = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Badge;
  const { IDName, className, style, attribute = {}, Tag = "span", showCross, status } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "badge", { [`badge-${status}`]: status }], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${renderSlot($$result2, $$slots["default"])}
    ${showCross && renderTemplate`${maybeRenderHead()}<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg" role="presentation" aria-hidden="true" class="badge-close">
                <path d="M1.16992 1.1698L8.83025 8.83012M1.16992 8.83012L8.83025 1.1698" stroke="var(--color-neutral-800, #4b4b4d)" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/badges/badge.astro", void 0);

const $$PaginationArrowDown12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="12" height="6" viewBox="0 0 12 6" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L5.625 4.875L10.5 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-12.astro", void 0);

const $$PaginationArrowDown16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="15" height="7" viewBox="0 0 15 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L7.25 6.25L13.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-16.astro", void 0);

const $$PaginationArrowDown24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="21" height="10" viewBox="0 0 21 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L10.25 9.25L19.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-24.astro", void 0);

const $$PaginationArrowDown40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="32" height="14" viewBox="0 0 32 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L15.75 12.75L30.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-40.astro", void 0);

const $$PaginationArrowLeft12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="12" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4.875 10.5L0.75 5.625L4.875 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-12.astro", void 0);

const $$PaginationArrowLeft16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="7" height="15" viewBox="0 0 7 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.25 13.75L0.75 7.25L6.25 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-16.astro", void 0);

const $$PaginationArrowLeft24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="10" height="21" viewBox="0 0 10 21" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M9.25 0.75L0.75 10.25L9.25 19.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-24.astro", void 0);

const $$PaginationArrowLeft40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="14" height="32" viewBox="0 0 14 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12.75 30.75L0.75 15.75L12.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-40.astro", void 0);

const $$PaginationArrowRight12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="12" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 10.5L4.875 5.625L0.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-Right-12.astro", void 0);

const $$PaginationArrowRight16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="7" height="15" viewBox="0 0 7 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 13.75L6.25 7.25L0.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-right-16.astro", void 0);

const $$PaginationArrowRight24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="10" height="21" viewBox="0 0 10 21" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L9.25 10.25L0.749999 19.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-right-24.astro", void 0);

const $$PaginationArrowRight40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="14" height="32" viewBox="0 0 14 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 30.75L12.75 15.75L0.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-right-40.astro", void 0);

const $$PaginationArrowUp12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="12" height="6" viewBox="0 0 12 6" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.5 4.875L5.625 0.75L0.75 4.875" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-12.astro", void 0);

const $$PaginationArrowUp16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="15" height="7" viewBox="0 0 15 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M13.75 6.25L7.25 0.75L0.75 6.25" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-16.astro", void 0);

const $$PaginationArrowUp24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="21" height="10" viewBox="0 0 21 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 9.25L10.25 0.75L19.75 9.25" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-24.astro", void 0);

const $$PaginationArrowUp40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="32" height="14" viewBox="0 0 32 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M30.75 12.75L15.75 0.75L0.75 12.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-40.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$PaginationArrow = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$PaginationArrow;
  const { size = "12", direction = "down", color, width, className, style, ...rest } = Astro2.props;
  const classes = ["pagination-arrow", `pagination-arrow--${size}`, `pagination-arrow--${direction}`, className].filter(Boolean).join(" ");
  const getSvgComponent = () => {
    const key = `${size}-${direction}`;
    const componentMap = {
      "12-up": $$PaginationArrowUp12,
      "12-down": $$PaginationArrowDown12,
      "12-left": $$PaginationArrowLeft12,
      "12-right": $$PaginationArrowRight12,
      "16-up": $$PaginationArrowUp16,
      "16-down": $$PaginationArrowDown16,
      "16-left": $$PaginationArrowLeft16,
      "16-right": $$PaginationArrowRight16,
      "24-up": $$PaginationArrowUp24,
      "24-down": $$PaginationArrowDown24,
      "24-left": $$PaginationArrowLeft24,
      "24-right": $$PaginationArrowRight24,
      "40-up": $$PaginationArrowUp40,
      "40-down": $$PaginationArrowDown40,
      "40-left": $$PaginationArrowLeft40,
      "40-right": $$PaginationArrowRight40
    };
    return componentMap[key];
  };
  const SvgComponent = getSvgComponent();
  const iconStyle = {
    ...width ? { "--icon-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${maybeRenderHead()}<span${addAttribute(classes, "class")} data-pagination-arrow${addAttribute(size, "data-size")}${addAttribute(direction, "data-direction")}${addAttribute(iconStyle, "style")}${spreadAttributes(rest)}>
    ${renderComponent($$result, "SvgComponent", SvgComponent, {})}
</span>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/paginationArrow.astro", void 0);

export { $$Badge as $, $$PaginationArrow as a };
