import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, F as Fragment, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Select } from './select_Bjnkvu7j.mjs';
/* empty css                         */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$CustomSelect = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$CustomSelect;
  const {
    id,
    data = [],
    className,
    selectClassName,
    required,
    disabled,
    name,
    value,
    placeholder = "\u8ACB\u9078\u64C7",
    title,
    size = "md",
    status,
    validClass,
    validType,
    validLabel,
    customValidText,
    customInvalidText,
    onchange,
    attribute = {},
    selectAttribute = {},
    style = {},
    selectStyle = {},
    custom = true,
    prebuiltStructure = false
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute([{ "custom-select": custom }, className], "class:list")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>
    ${renderComponent($$result, "Select", $$Select, { "id": id, "data": data, "className": [{ "custom-origin-select": custom }, selectClassName], "required": required, "disabled": disabled, "name": name, "value": value, "title": title, "size": size, "status": status, "placeholder": placeholder, "validClass": validClass, "validType": validType, "validLabel": validLabel, "customValidText": customValidText, "customInvalidText": customInvalidText, "onchange": onchange, "attribute": selectAttribute, "style": selectStyle })}
    ${prebuiltStructure && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <div class="select-selected select-selected-placeholder"></div>
            <div class="select-items select-hide"></div>
        ` })}`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/select/customSelect.astro", void 0);

export { $$CustomSelect as $ };
