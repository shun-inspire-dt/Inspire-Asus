import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, d as renderTemplate, r as renderComponent } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Button } from './layouts_DEqYUbYc.mjs';
/* empty css                        */

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Modal = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Modal;
  const {
    id = "example",
    sizes = "md",
    center = true,
    scrollable = false,
    title = "",
    attribute = {},
    Modalclass = "",
    bodyClass = "",
    titleClass = "",
    dialogClass = "",
    contentClass = "",
    hideHeader = false,
    hideTitle = false,
    headerClass = "",
    hideColse = false,
    hideFooter = false,
    footerClass = "",
    cancelTitle = "\u53D6\u6D88",
    cancelVariant,
    cancelDisabled = false,
    cancelClass = "",
    cancelOnly = false,
    okTitle = "\u5132\u5B58",
    okVariant,
    okDisabled = false,
    okClass = "",
    okAttribute = [],
    okOnly = false
  } = Astro2.props;
  const modalSizes = {
    sm: "modal-sm",
    md: "",
    lg: "modal-lg",
    xl: "modal-xl"
  };
  const modalSize = modalSizes?.[sizes];
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(["modal fade", Modalclass], "class:list")}${addAttribute(`${id}Modal`, "id")} tabindex="-1"${addAttribute(`${id}ModalLabel`, "aria-labelledby")} aria-hidden="false" data-bs-focus="false"${spreadAttributes(attribute)}>
    <div${addAttribute([
    "modal-dialog",
    modalSize,
    { "modal-dialog-centered": center },
    { "modal-dialog-scrollable": scrollable },
    dialogClass
  ], "class:list")}>
        <div${addAttribute(["modal-content", contentClass], "class:list")}>
            ${!hideHeader && renderTemplate`<div${addAttribute(["modal-header", { hideHeader: hideTitle }, headerClass], "class:list")}>
                        ${renderSlot($$result, $$slots["title"], renderTemplate`
                            ${!hideTitle && renderTemplate`<div${addAttribute(["modal-title", titleClass], "class:list")}${addAttribute(`${id}ModalLabel`, "id")}>
                                    ${renderSlot($$result, $$slots["title-left"])}
                                    <span>${title}</span>
                                    ${renderSlot($$result, $$slots["title-right"])}
                                </div>`}
                        `)}
                        ${renderSlot($$result, $$slots["header-right"])}
                        ${!hideColse && renderTemplate`${renderComponent($$result, "Button", $$Button, { "IDName": id ? `${id}ModalCloseButton` : "", "className": `modal-close-button`, "attribute": {
    "data-bs-dismiss": "modal",
    "aria-label": "Close"
  }, "button": false })}`}
                    </div>`}
            <div${addAttribute(["modal-body", { hideFooter }, { hideTitle }, bodyClass], "class:list")}>
                ${renderSlot($$result, $$slots["default"])}
            </div>
            ${!hideFooter && renderTemplate`<div${addAttribute(["modal-footer", footerClass], "class:list")}>
                        ${renderSlot($$result, $$slots["footer"], renderTemplate`
                            ${!okOnly && renderTemplate`${renderComponent($$result, "Button", $$Button, { "className": [cancelClass], "variant": cancelVariant, "attribute": { "data-bs-dismiss": "modal" }, "disabled": cancelDisabled }, { "default": ($$result2) => renderTemplate`${cancelTitle}` })}`}
                            ${!cancelOnly && renderTemplate`${renderComponent($$result, "Button", $$Button, { "className": [okClass], "variant": okVariant, "disabled": okDisabled, ...okAttribute }, { "default": ($$result2) => renderTemplate`${okTitle}` })}`}
                        `)}
                    </div>`}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/modal/modal.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Video = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Video;
  const { IDName = "Video", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Modal", $$Modal, { "id": IDName, "sizes": "xl", "Modalclass": className, "center": true, "hideFooter": true, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<iframe id="youtube-player" width="560" height="315" src="https://www.youtube.com/embed/3vDjjvBYOLM?si=zo0wzAeuYuy8O7BT&enablejsapi=1" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/modal/video.astro", void 0);

export { $$Video as $ };
