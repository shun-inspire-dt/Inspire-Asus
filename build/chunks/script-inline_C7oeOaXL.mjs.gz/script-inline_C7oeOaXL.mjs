import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, f as renderSlot, d as renderTemplate, r as renderComponent, F as Fragment, e as defineScriptVars } from './astro/server_v5wg8FJS.mjs';
import { $ as $$Form$1 } from './form_CPN2Wti_.mjs';
import { $ as $$InputGroup } from './inputGroup_DYD_Fq9Y.mjs';
import { b as $$Input, $ as $$Button } from './layouts_CAx5rqF_.mjs';
import { $ as $$CustomSelect } from './customSelect_C2FrwOlA.mjs';
import { $ as $$Textarea } from './textarea_UiomSGMK.mjs';
import { $ as $$Checkbox } from './checkbox_CezxJCXT.mjs';
/* empty css                             */
import { $ as $$Card } from './card_9JeEmzXH.mjs';

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Radio = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Radio;
  const {
    id,
    name,
    label,
    value,
    title,
    checked,
    required,
    disabled,
    readonly,
    attribute = {},
    aria = {}
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="form-check form-radio">
    <div class="form-check-input-container">
        <input${addAttribute(id, "id")} class="form-radio-input" type="radio"${addAttribute(value, "value")}${addAttribute(name, "name")}${addAttribute(checked, "checked")}${addAttribute(disabled, "disabled")}${addAttribute(readonly, "readonly")}${addAttribute(required, "required")} autocomplete="off"${addAttribute(title, "aria-label")}${spreadAttributes(attribute)}${spreadAttributes(aria)}>
    </div>
    <label class="form-check-label"${addAttribute(id, "for")}>
        ${renderSlot($$result, $$slots["default"], renderTemplate`${label}`)}
    </label>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/checkboxs/radio.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "Inquery", className, style, attribute = {}, data = [], display = "grid" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "type": 2, "display": display, "title": "\u8AEE\u8A62\u6E05\u55AE", "block": true, "className": ["needs-validation", className], "attribute": { novalidate: "", "data-needs-loading": "true", "data-report-validity": "false", ...attribute }, "style": style }, { "default": ($$result2) => renderTemplate`
    
    
    ${maybeRenderHead()}<div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "companyName", "label": "\u516C\u53F8\u540D\u7A31", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "companyName", "name": "companyName", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "taxId", "label": "\u516C\u53F8\u7D71\u7DE8", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "taxId", "name": "taxId", "type": "text", "inputmode": "numeric", "minLength": 8, "maxLength": 8, "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "companyAddress", "label": "\u516C\u53F8\u5730\u5740", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "companyAddress", "name": "companyAddress", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "companyIndustry", "label": "\u7522\u696D\u985E\u5225", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Select", $$CustomSelect, { "id": "companyIndustry", "name": "companyIndustry", "data": [
    { text: "\u96F2\u7AEF\u8207\u57FA\u790E\u8A2D\u65BD", value: "\u96F2\u7AEF\u8207\u57FA\u790E\u8A2D\u65BD" },
    { text: "\u4F01\u696D\u61C9\u7528", value: "\u4F01\u696D\u61C9\u7528" },
    { text: "\u8CC7\u6599\u4E2D\u5FC3", value: "\u8CC7\u6599\u4E2D\u5FC3" },
    { text: "\u5132\u5B58", value: "\u5132\u5B58" },
    { text: "\u5B89\u5168", value: "\u5B89\u5168" },
    { text: "\u5132\u5B58", value: "\u5132\u5B58" }
  ], "value": "IT\u90E8\u9580" })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "companySize", "label": "\u54E1\u5DE5\u898F\u6A21", "error": true, "alwaysInlineContent": true, "inlineContentWrap": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "companySize-1", "name": "companySize", "value": "1-10", "required": true }, { "default": ($$result4) => renderTemplate`1-10` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "companySize-2", "name": "companySize", "value": "10-49", "required": true }, { "default": ($$result4) => renderTemplate`10-49` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "companySize-3", "name": "companySize", "value": "50-199", "required": true }, { "default": ($$result4) => renderTemplate`50-199` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "companySize-4", "name": "companySize", "value": "200-500", "required": true }, { "default": ($$result4) => renderTemplate`200-500` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "companySize-5", "name": "companySize", "value": "500+", "required": true }, { "default": ($$result4) => renderTemplate`500+` })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "name", "label": "\u59D3\u540D", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "name", "name": "name", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "id": "positionInputGroup", "inputID": "position", "label": "\u8077\u7A31", "error": true, "alwaysInlineContent": true, "inlineContentWrap": true, "block": true, "attribute": { "data-toggle-container": "" } }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-1", "name": "position", "value": "\u8001\u95C6", "required": true }, { "default": ($$result4) => renderTemplate`老闆` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-2", "name": "position", "value": "\u9AD8\u968E\u4E3B\u7BA1", "required": true }, { "default": ($$result4) => renderTemplate`高階主管` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-3", "name": "position", "value": "IT", "required": true }, { "default": ($$result4) => renderTemplate`IT` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-4", "name": "position", "value": "\u6578\u4F4D", "required": true }, { "default": ($$result4) => renderTemplate`數位` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-5", "name": "position", "value": "\u71DF\u904B", "required": true }, { "default": ($$result4) => renderTemplate`營運` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-6", "name": "position", "value": "\u696D\u52D9", "required": true }, { "default": ($$result4) => renderTemplate`業務` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-7", "name": "position", "value": "\u884C\u92B7", "required": true }, { "default": ($$result4) => renderTemplate`行銷` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "position-8", "name": "position", "value": "\u5176\u4ED6", "required": true, "attribute": { "data-toggle": '[data-toggle-item="position-8-infomation"]' } }, { "default": ($$result4) => renderTemplate`其他` })}
            <p data-toggle-item="position-8-infomation" style="width: 100%; margin-top: 10px; margin-bottom: 10px;">
                備注：以下兩種選一種。單一 「class="control-input」 或是 一整組 「class="form-input-group」
            </p>
            
            ${renderComponent($$result3, "Input", $$Input, { "id": "position-8-infomation", "name": "information", "placeholder": "\u8ACB\u8AAA\u660E", "attribute": { "data-valid": "required", "data-toggle-item": "position-8-infomation" } })}
            
            ${renderComponent($$result3, "InputGroup", $$InputGroup, { "inputID": "position-8-infomation-2", "label": "\u8ACB\u8AAA\u660E", "alwaysInline": true, "block": true, "attribute": { "data-toggle-item": "position-8-infomation" } }, { "default": ($$result4) => renderTemplate`
                ${renderComponent($$result4, "Input", $$Input, { "id": "position-8-infomation-2", "name": "information", "placeholder": "\u8ACB\u8AAA\u660E", "attribute": { "data-valid": "required" } })}
            ` })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "email", "label": "\u806F\u7D61\u4FE1\u7BB1", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "email", "name": "email", "type": "email", "inputmode": "email", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "cellphone", "label": "\u806F\u7D61\u96FB\u8A71", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "cellphone", "name": "cellphone", "type": "tel", "inputmode": "tel", "required": true })}
        ` })}
    </div>
    <div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "improve", "label": "\u60A8\u9019\u6B21\u6700\u60F3\u6539\u5584\u6216\u5C0E\u5165\u7684\u662F?", "alwaysInlineContent": true, "inlineContentWrap": true, "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "improve-1", "name": "improve", "value": "\u7522(\u71DF\u904B/\u88FD\u9020/\u4F9B\u61C9\u93C8/\u8A2D\u5099)" }, { "default": ($$result4) => renderTemplate`產 (營運/製造/供應鏈/設備)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "improve-2", "name": "improve", "value": "\u92B7(\u92B7\u552E/\u884C\u92B7/\u5BA2\u6236/\u901A\u8DEF)" }, { "default": ($$result4) => renderTemplate`銷 (銷售/行銷/客戶/通路)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "improve-3", "name": "improve", "value": "\u4EBA(\u4EBA\u8CC7/\u7D44\u7E54/\u5354\u4F5C/\u57F9\u8A13)" }, { "default": ($$result4) => renderTemplate`人 (人資/組織/協作/培訓)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "improve-4", "name": "improve", "value": "\u767C(IT/\u7CFB\u7D71\u6574\u5408/\u96F2\u7AEF/\u8CC7\u5B89/AI)" }, { "default": ($$result4) => renderTemplate`發 (IT/系統整合/雲端/資安/AI)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "improve-5", "name": "improve", "value": "\u8CA1(\u8CA1\u52D9/\u6703\u8A08/\u6210\u672C/\u5167\u63A7)" }, { "default": ($$result4) => renderTemplate`財 (財務/會計/成本/內控)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "improve-6", "name": "improve", "value": "\u8CC7(\u8CC7\u6599/BI/AI\u5206\u6790/\u6C7A\u7B56)" }, { "default": ($$result4) => renderTemplate`資 (資料/BI/AI分析/決策)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "improve-7", "name": "improve", "value": "\u6C38\u7E8C(ESG/\u78B3\u7BA1\u7406/\u80FD\u6E90/\u6CBB\u7406)" }, { "default": ($$result4) => renderTemplate`永續 (ESG/碳管理/能源/治理)` })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "problem", "label": "\u8ACB\u7C21\u8FF0\u76EE\u524D\u9047\u5230\u7684\u554F\u984C\u6216\u60F3\u6539\u5584\u7684\u60C5\u5883", "infoText": "\u63D0\u793A: \u8A02\u55AE\u6D41\u7A0B\u5206\u6563\u3001\u8CC7\u6599\u7121\u6CD5\u6574\u5408\u3001\u60F3\u5C0E\u5165AI\u5206\u6790\u3001\u7F3A\u4E4F\u5373\u6642\u71DF\u904B\u5831\u8868...", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            
            ${renderComponent($$result3, "Textarea", $$Textarea, { "id": "problem", "name": "problem", "minLength": 20, "placeholder": "\u5FC5\u586B\uFF0C\u81F3\u5C1120\u5B57", "style": { "min-height": "120px" }, "required": true })}
        `, "label-right": ($$result3) => renderTemplate`${renderComponent($$result3, "Fragment", Fragment, { "slot": "label-right" }, { "default": ($$result4) => renderTemplate`
                <small>&nbsp;(必填，至少20字)</small>
            ` })}` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "progress", "label": "\u5C08\u6848\u9032\u5EA6\u5230\u54EA?", "error": true, "alwaysInlineContent": true, "inlineContentWrap": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "progress-1", "name": "progress", "value": "\u5DF2\u7D93\u78BA\u5B9A\u8981\u5C0E\u5165\uFF0C\u6B63\u5728\u627E\u65B9\u6848" }, { "default": ($$result4) => renderTemplate`已經確定要導入，正在找方案` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "progress-2", "name": "progress", "value": "\u6B63\u5728\u8A55\u4F30\u53EF\u884C\u6027\u8207\u9810\u7B97" }, { "default": ($$result4) => renderTemplate`正在評估可行性與預算` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "progress-3", "name": "progress", "value": "\u5148\u4E86\u89E3\u65B9\u5411\uFF0C\u672A\u4F86\u518D\u8AAA" }, { "default": ($$result4) => renderTemplate`先了解方向，未來再說` })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "launchTime", "label": "\u9810\u8A08\u4F55\u6642\u555F\u52D5?", "error": true, "alwaysInlineContent": true, "inlineContentWrap": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "launchTime-1", "name": "launchTime", "value": "3 \u500B\u6708\u5167" }, { "default": ($$result4) => renderTemplate`3 個月內` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "launchTime-2", "name": "launchTime", "value": "3-6 \u500B\u6708" }, { "default": ($$result4) => renderTemplate`3-6 個月` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "launchTime-3", "name": "launchTime", "value": "6-12 \u500B\u6708" }, { "default": ($$result4) => renderTemplate`6-12 個月` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "launchTime-4", "name": "launchTime", "value": "\u5C1A\u672A\u78BA\u5B9A" }, { "default": ($$result4) => renderTemplate`尚未確定` })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "budget", "label": "\u9810\u7B97\u5340\u9593", "error": true, "alwaysInlineContent": true, "inlineContentWrap": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "budget-1", "name": "budget", "value": "\u5C1A\u672A\u898F\u5283" }, { "default": ($$result4) => renderTemplate`尚未規劃` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "budget-2", "name": "budget", "value": "50 \u842C\u4EE5\u4E0B" }, { "default": ($$result4) => renderTemplate`50 萬以下` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "budget-3", "name": "budget", "value": "50-200\u842C" }, { "default": ($$result4) => renderTemplate`50-200萬` })}
            ${renderComponent($$result3, "Radio", $$Radio, { "id": "budget-4", "name": "budget", "value": "200 \u842C\u4EE5\u4E0A" }, { "default": ($$result4) => renderTemplate`200 萬以上` })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "id": "fromInputGroup", "inputID": "from", "label": "\u8ACB\u554F\u60A8\u662F\u900F\u904E\u4F55\u7A2E\u7BA1\u9053\u5F97\u77E5 ExpertHub \u5E73\u53F0?", "alwaysInlineContent": true, "inlineContentWrap": true, "error": true, "block": true, "attribute": { "data-toggle-container": "" } }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "from-1", "name": "from", "value": "\u83EF\u78A9ASUS(\u6216\u696D\u52D9\u5925\u4F34\u63A8\u85A6)" }, { "default": ($$result4) => renderTemplate`華碩ASUS(或業務夥伴推薦)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "from-2", "name": "from", "value": "\u83EF\u78A9\u5BE6\u9AD4/\u7DDA\u4E0A\u884C\u92B7\u6D3B\u92B7\u6D3B\u52D5(\u7814\u8A0E\u6703)" }, { "default": ($$result4) => renderTemplate`華碩實體/線上行銷活銷活動(研討會)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "from-3", "name": "from", "value": "\u641C\u5C0B\u5F15\u64CE(Google\u7B49)" }, { "default": ($$result4) => renderTemplate`搜尋引擎(Google等)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "from-4", "name": "from", "value": "\u793E\u7FA4\u5A92\u9AD4" }, { "default": ($$result4) => renderTemplate`社群媒體` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "from-5", "name": "from", "value": "\u516C\u5354\u6703/\u7522\u696D\u55AE\u4F4D(\u5982:\u96FB\u8166\u516C\u6703)" }, { "default": ($$result4) => renderTemplate`公協會/產業單位(如:電腦公會)` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "from-6", "name": "from", "value": "\u540C\u696D\u63A8\u85A6" }, { "default": ($$result4) => renderTemplate`同業推薦` })}
            ${renderComponent($$result3, "Checkbox", $$Checkbox, { "id": "from-7", "name": "from", "value": "\u5176\u4ED6 (\u8ACB\u8AAA\u660E)", "attribute": { "data-toggle": '[data-toggle-item="from-7-infomation"]' } }, { "default": ($$result4) => renderTemplate`
                其他 (請說明)
            ` })}
            <p data-toggle-item="from-7-infomation" style="width: 100%; margin-top: 10px; margin-bottom: 10px;">
                備注：以下兩種選一種。單一 「class="control-input」 或是 一整組 「class="form-input-group」
            </p>
            
            ${renderComponent($$result3, "Input", $$Input, { "id": "from-7-infomation", "name": "information", "placeholder": "\u8ACB\u8AAA\u660E\u900F\u904E\u4F55\u7A2E\u7BA1\u9053\u5F97\u77E5 ExpertHub \u5E73\u53F0", "attribute": { "data-valid": "required", "data-toggle-item": "from-7-infomation" } })}
            
            ${renderComponent($$result3, "InputGroup", $$InputGroup, { "inputID": "where", "label": "\u8ACB\u8AAA\u660E", "alwaysInline": true, "block": true, "attribute": { "data-toggle-item": "from-7-infomation" } }, { "default": ($$result4) => renderTemplate`
                ${renderComponent($$result4, "Input", $$Input, { "id": "from-7-infomation-2", "name": "information", "placeholder": "\u8ACB\u8AAA\u660E\u900F\u904E\u4F55\u7A2E\u7BA1\u9053\u5F97\u77E5 ExpertHub \u5E73\u53F0", "attribute": { "data-valid": "required" } })}
            ` })}
        ` })}
        <div class="form-button-container">
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "className": "form-button", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`
                送出
            ` })}
        </div>
    </div>
`, "sub-title": ($$result2) => renderTemplate`<div class="inquery-form-head">
        <h2 class="inquery-title">聯絡資訊</h2>
    </div>`, "top": ($$result2) => renderTemplate`<div class="inquery-cart">
        <div class="inquery-form-head" slot="sub-title">
            <h2 class="inquery-title">
                方案清單
            </h2>
            <span class="inquery-cart-amount">
                合計詢問
                <b class="inquery-cart-amount-number">2</b>
                個方案
            </span>
        </div>
        <div class="w-full flex flex-col items-center gap-1.5rem">
            ${data.map((x) => renderTemplate`${renderComponent($$result2, "Card", $$Card, { "id": x.id, "title": x.title, "label": x.label, "brief": x.brief, "amount": x.amount, "img": x.img, "required": true })}`)}
        </div>
    </div>` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/inquery/form.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$ScriptInline = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["<script>(function(){", "\n    const authClient = new AuthClient({ baseURL, cookies });\n    const Fetch = authClient.fetchWithAuth.bind(authClient);\n    /** ---------- 實作 ---------- */\n    // 全局 Toast 實例\n    const toastEl = document.getElementById('toastModal');\n\n    /**\n     * API 請求封裝\n     * @description 統一處理此頁面所需的 API 呼叫與 headers 設定\n     */\n    class API {\n        headers = new Headers({\n            'Content-Type': 'application/json',\n            Authorization: `Bearer ${authClient.cookies.get('access_token')}`\n        });\n\n        /**\n         * 範例 API（目前用於 demo）\n         * @param {Record<string, any>} data - 表單送出時整理出的資料\n         * @returns {Promise<{success: boolean, message?: string}>} API 回應\n         */\n        exampleAPI = async (data) => {\n            console.log('data', data);\n            const requestOptions = {\n                method: 'GET',\n                headers: this.headers\n            };\n\n            return await Fetch(baseURL + '/api/form/example-success', requestOptions)\n                .then((response) => response.json())\n                .then((result) => result)\n                .catch((error) => {\n                    console.error('Error:', error);\n                    return { success: false, message: error.message || '失敗' };\n                });\n        };\n    }\n\n    /**\n     * 諮詢表單流程\n     * @description 綁定表單驗證、組裝表單資料並呼叫 API，最後用 Toast 顯示結果\n     */\n    class Form extends API {\n        form = document.querySelector('#InqueryForm');\n\n        /**\n         * 初始化\n         * @description 建立實例後立即綁定事件\n         */\n        constructor() {\n            super();\n            this.bindEvents();\n        }\n\n        /**\n         * 建立表單驗證器\n         * @description 使用 FormValidator 綁定 submit 驗證與 onValidSubmit 行為\n         * @returns {FormValidator}\n         */\n        validator = () =>\n            new FormValidator(this.form, {\n                onValidSubmit: async ({ controls }) => {\n                    /**\n                     *  Form Data 資料會如下：\n                     *  const formDataExample = {\n                        isAll: '1',\n                        data: {\n                            name: 'asd',\n                            tel: '0912345678',\n                            department: 'IT部門',\n                            position: '12312312',\n                            cellphone: '0912345678',\n                            email: '12@gmail.com',\n                            comment: 'asdasdasd',\n                            companyName: '123',\n                            taxId: '12312313',\n                            products: [\n                                { id: 1, qty: 2 },\n                                { id: 2, qty: 1 },\n                                { id: 3, qty: 3 }\n                            ]\n                        }\n                    }; */\n                    /**\n                     * 組裝送出資料\n                     * @param {Record<string, HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>} controls - 表單控制項集合\n                     * @returns {{isAll: string, data: Record<string, string | {id: number, qty: number}[]>}} 送出 payload\n                     */\n                    const formData = (controls) => {\n                        const formData = {\n                            isAll: '1',\n                            data: {}\n                        };\n                        const products = [];\n                        Object.entries(controls || {}).forEach(([key, el]) => {\n                            if (!key || !el) return;\n\n                            if (key.includes('inquery-amount-')) {\n                                const id = Number(el.dataset.id);\n                                const qty = Number(el.value);\n                                if (isFinite(id) && isFinite(qty)) {\n                                    products.push({ id, qty });\n                                }\n                                return;\n                            }\n                            formData['data'][key] = el.value;\n                        });\n                        formData['data']['products'] = products;\n                        return formData;\n                    };\n                    try {\n                        const response = await this.exampleAPI(formData(controls));\n                        if (response.success) {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'success',\n                                        title: '表單已送出',\n                                        text: '謝謝詢問，我們會透過Email或電話與您聯繫',\n                                        link: {\n                                            primaryText: '回首頁',\n                                            primaryLink: '/',\n                                            primaryVariant: 'blue'\n                                        },\n                                        hidePrevented: true\n                                    }\n                                })\n                            );\n                        } else {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'error',\n                                        title: response.message || '失敗'\n                                    }\n                                })\n                            );\n                        }\n                    } catch (error) {\n                        console.error('Error From Submit:', error);\n                        toastEl.dispatchEvent(\n                            new CustomEvent('fire', {\n                                detail: {\n                                    icon: 'error',\n                                    title: error.message || '失敗'\n                                }\n                            })\n                        );\n                    }\n                }\n            });\n        /**\n         * 綁定所有事件監聽器\n         * @description 為各個 Form 和 Modal 綁定相應的事件處理器\n         */\n        bindEvents = () => {\n            this.validator && this.validator();\n        };\n    }\n\n    // 等待 DOM 加載完成後初始化\n    if (document.readyState === 'loading') {\n        document.addEventListener('DOMContentLoaded', () => new Form());\n    } else {\n        new Form();\n    }\n})();</script>"], ["<script>(function(){", "\n    const authClient = new AuthClient({ baseURL, cookies });\n    const Fetch = authClient.fetchWithAuth.bind(authClient);\n    /** ---------- 實作 ---------- */\n    // 全局 Toast 實例\n    const toastEl = document.getElementById('toastModal');\n\n    /**\n     * API 請求封裝\n     * @description 統一處理此頁面所需的 API 呼叫與 headers 設定\n     */\n    class API {\n        headers = new Headers({\n            'Content-Type': 'application/json',\n            Authorization: \\`Bearer \\${authClient.cookies.get('access_token')}\\`\n        });\n\n        /**\n         * 範例 API（目前用於 demo）\n         * @param {Record<string, any>} data - 表單送出時整理出的資料\n         * @returns {Promise<{success: boolean, message?: string}>} API 回應\n         */\n        exampleAPI = async (data) => {\n            console.log('data', data);\n            const requestOptions = {\n                method: 'GET',\n                headers: this.headers\n            };\n\n            return await Fetch(baseURL + '/api/form/example-success', requestOptions)\n                .then((response) => response.json())\n                .then((result) => result)\n                .catch((error) => {\n                    console.error('Error:', error);\n                    return { success: false, message: error.message || '失敗' };\n                });\n        };\n    }\n\n    /**\n     * 諮詢表單流程\n     * @description 綁定表單驗證、組裝表單資料並呼叫 API，最後用 Toast 顯示結果\n     */\n    class Form extends API {\n        form = document.querySelector('#InqueryForm');\n\n        /**\n         * 初始化\n         * @description 建立實例後立即綁定事件\n         */\n        constructor() {\n            super();\n            this.bindEvents();\n        }\n\n        /**\n         * 建立表單驗證器\n         * @description 使用 FormValidator 綁定 submit 驗證與 onValidSubmit 行為\n         * @returns {FormValidator}\n         */\n        validator = () =>\n            new FormValidator(this.form, {\n                onValidSubmit: async ({ controls }) => {\n                    /**\n                     *  Form Data 資料會如下：\n                     *  const formDataExample = {\n                        isAll: '1',\n                        data: {\n                            name: 'asd',\n                            tel: '0912345678',\n                            department: 'IT部門',\n                            position: '12312312',\n                            cellphone: '0912345678',\n                            email: '12@gmail.com',\n                            comment: 'asdasdasd',\n                            companyName: '123',\n                            taxId: '12312313',\n                            products: [\n                                { id: 1, qty: 2 },\n                                { id: 2, qty: 1 },\n                                { id: 3, qty: 3 }\n                            ]\n                        }\n                    }; */\n                    /**\n                     * 組裝送出資料\n                     * @param {Record<string, HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>} controls - 表單控制項集合\n                     * @returns {{isAll: string, data: Record<string, string | {id: number, qty: number}[]>}} 送出 payload\n                     */\n                    const formData = (controls) => {\n                        const formData = {\n                            isAll: '1',\n                            data: {}\n                        };\n                        const products = [];\n                        Object.entries(controls || {}).forEach(([key, el]) => {\n                            if (!key || !el) return;\n\n                            if (key.includes('inquery-amount-')) {\n                                const id = Number(el.dataset.id);\n                                const qty = Number(el.value);\n                                if (isFinite(id) && isFinite(qty)) {\n                                    products.push({ id, qty });\n                                }\n                                return;\n                            }\n                            formData['data'][key] = el.value;\n                        });\n                        formData['data']['products'] = products;\n                        return formData;\n                    };\n                    try {\n                        const response = await this.exampleAPI(formData(controls));\n                        if (response.success) {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'success',\n                                        title: '表單已送出',\n                                        text: '謝謝詢問，我們會透過Email或電話與您聯繫',\n                                        link: {\n                                            primaryText: '回首頁',\n                                            primaryLink: '/',\n                                            primaryVariant: 'blue'\n                                        },\n                                        hidePrevented: true\n                                    }\n                                })\n                            );\n                        } else {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'error',\n                                        title: response.message || '失敗'\n                                    }\n                                })\n                            );\n                        }\n                    } catch (error) {\n                        console.error('Error From Submit:', error);\n                        toastEl.dispatchEvent(\n                            new CustomEvent('fire', {\n                                detail: {\n                                    icon: 'error',\n                                    title: error.message || '失敗'\n                                }\n                            })\n                        );\n                    }\n                }\n            });\n        /**\n         * 綁定所有事件監聽器\n         * @description 為各個 Form 和 Modal 綁定相應的事件處理器\n         */\n        bindEvents = () => {\n            this.validator && this.validator();\n        };\n    }\n\n    // 等待 DOM 加載完成後初始化\n    if (document.readyState === 'loading') {\n        document.addEventListener('DOMContentLoaded', () => new Form());\n    } else {\n        new Form();\n    }\n})();</script>"])), defineScriptVars({ baseURL: "https://shun-fast-api.zeabur.app" }));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/inquery/script-inline.astro", void 0);

export { $$ScriptInline as $, $$Form as a };
