import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, F as Fragment, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Picture = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Picture;
  const {
    id,
    className = "",
    pictureClassName = "",
    width = null,
    height = null,
    img = "",
    blankWebpImg = "",
    alt = "",
    type = "png",
    loading = "lazy",
    decoding = "async",
    blank,
    noWebp = false,
    breakpoints,
    style,
    attribute = {}
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<picture${addAttribute([pictureClassName], "class:list")}>
    ${breakpoints && breakpoints?.map((x) => renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${!noWebp && renderTemplate`<source${addAttribute(
    x.densities ? Object.entries(x.densities).map(
      ([density, imgPath]) => !blank ? `${Astro2.url.origin}${imgPath}.webp ${density}` : `${imgPath}.webp ${density}`
    ).join(", ") : !blank ? `${Astro2.url.origin}${x.img}.webp` : `${x.blankWebpImg}`,
    "srcset"
  )}${addAttribute(`(min-width:${x.width}px)`, "media")} type="image/webp">`}<source${addAttribute(
    x.densities ? Object.entries(x.densities).map(
      ([density, imgPath]) => !blank ? `${Astro2.url.origin}${imgPath}.${x.type || type} ${density}` : `${imgPath} ${density}`
    ).join(", ") : !blank ? `${Astro2.url.origin}${x.img}.${x.type || type}` : `${x.img}`,
    "srcset"
  )}${addAttribute(`(min-width:${x.width}px)`, "media")}${addAttribute(`image/${x.type || type}`, "type")}>
                ` })}`)}
    ${!noWebp && renderTemplate`<source${addAttribute(!blank ? `${Astro2.url.origin}${img}.webp` : `${blankWebpImg}`, "srcset")} type="image/webp">`}
    <img${addAttribute(id, "id")}${addAttribute([className], "class:list")}${addAttribute(width, "width")}${addAttribute(height, "height")}${addAttribute(!blank ? `${Astro2.url.origin}${img}.${type}` : `${img}`, "src")}${addAttribute(alt, "alt")}${addAttribute(alt, "title")}${addAttribute(loading, "loading")}${addAttribute(decoding, "decoding")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
</picture>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/images/picture.astro", void 0);

export { $$Picture as $ };
