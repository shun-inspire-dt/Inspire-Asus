import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Button$1 } from './layouts_DEVhm48G.mjs';
import { $ as $$SocialIcon } from './SocialIcon_6ODmP4Ig.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Button = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Button;
  const { IDName, className, style, attribute = {}, type = "google", status = "register" } = Astro2.props;
  const socialIcons = {
    microsoft: "icon_microsoft",
    line: "icon_line",
    google: "icon_google",
    fb: "icon_fb",
    apple: "icon_apple"
  };
  const title = (icon, status2) => {
    const key = `${icon}_${status2}`;
    const titles = {
      microsoft_register: "\u4F7F\u7528 Microsoft \u8A3B\u518A",
      line_register: "\u4F7F\u7528 LINE \u8A3B\u518A",
      google_register: "\u4F7F\u7528 Google \u8A3B\u518A",
      fb_register: "\u4F7F\u7528 Facebook \u8A3B\u518A",
      apple_register: "\u4F7F\u7528 Apple \u8A3B\u518A",
      microsoft_login: "\u4F7F\u7528 Microsoft \u767B\u5165",
      line_login: "\u4F7F\u7528 LINE \u767B\u5165",
      google_login: "\u4F7F\u7528 Google \u767B\u5165",
      fb_login: "\u4F7F\u7528 Facebook \u767B\u5165",
      apple_login: "\u4F7F\u7528 Apple \u767B\u5165",
      microsoft_registed: "\u76EE\u524D\u4F7F\u7528 Microsoft \u5E33\u865F\u505A\u8A3B\u518A",
      line_registed: "\u76EE\u524D\u4F7F\u7528 LINE \u5E33\u865F\u505A\u8A3B\u518A",
      google_registed: "\u76EE\u524D\u4F7F\u7528 Google \u5E33\u865F\u505A\u8A3B\u518A",
      fb_registed: "\u76EE\u524D\u4F7F\u7528 Facebook \u5E33\u865F\u505A\u8A3B\u518A",
      apple_registed: "\u76EE\u524D\u4F7F\u7528 Apple \u5E33\u865F\u505A\u8A3B\u518A"
    };
    return titles[key];
  };
  const socialIconType = socialIcons[type];
  return renderTemplate`${renderComponent($$result, "MyButton", $$Button$1, { "IDName": IDName, "variant": "neutral-outline", "className": [className], "style": style, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "SocialIcon", $$SocialIcon, { "type": socialIconType, "size": "md" })}
    ${title(type, status)}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/auth/button.astro", void 0);

export { $$Button as $ };
