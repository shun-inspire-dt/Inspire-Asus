import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate, r as renderComponent, e as renderSlot } from './astro/server_Bjgbv9en.mjs';
/* empty css                         */
import { $ as $$Title } from './title_oZPX-wc9.mjs';
import { $ as $$CustomSelect } from './customSelect_BeRGKv_P.mjs';
import { $ as $$NotificationIcon } from './notificationIcon_Dzg8kcFt.mjs';
import { c as $$Link, j as $$Collapse, $ as $$Button, h as $$Offcanvas } from './layouts_k9LlQnqK.mjs';
import { $ as $$Badge, a as $$PaginationArrow } from './paginationArrow_Cu6rjPMr.mjs';
import { $ as $$Checkbox } from './checkbox_wf8xSkG5.mjs';

const $$Astro$a = createAstro("https://www.Asus.com.tw");
const $$Follower = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$Follower;
  const { IDName = "Follower", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "follower"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Go Top" class="follower-button">
        <svg width="25" height="15" viewBox="0 0 25 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.0879 12.4816L12.4813 1.875L1.87469 12.4816" stroke="white" stroke-width="3.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
        <svg width="19" height="11" viewBox="0 0 19 11" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.9316 9.15317L9.15347 1.375L1.37529 9.15317" stroke="white" stroke-width="2.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/follower/follower.astro", void 0);

const $$Astro$9 = createAstro("https://www.Asus.com.tw");
const $$SortSelector = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$SortSelector;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  const componentId = IDName || `sort-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "sort-selector"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <label class="sort-selector-label"${addAttribute(componentId, "for")}>排序：</label>
    ${renderComponent($$result, "Select", $$CustomSelect, { "id": componentId, "status": "sort", "className": "sort-selector-select", "size": "sm", "name": "sort", "data": data, "value": data && data?.[0] ? data[0].value : void 0, "selectAttribute": { "data-sort": "" }, "style": { minWidth: "9.5rem" } })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sortSelector.astro", void 0);

const $$Astro$8 = createAstro("https://www.Asus.com.tw");
const $$Sort = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$Sort;
  const { IDName, className, style, attribute = {}, total, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "sort"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <span class="sort-result">篩選結果: ${total} 結果</span>
    <div class="sort-selector-container">
        ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": data })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sort.astro", void 0);

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Notice = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Notice;
  const {
    IDName,
    className,
    style,
    attribute = {},
    text = "\u9078\u64C7\u7BE9\u9078\u689D\u4EF6\u6703\u91CD\u6574\u7D50\u679C\uFF0C\u4E26\u53EF\u80FD\u5F71\u97FF\u5176\u4ED6\u9078\u9805\u7684\u53EF\u7528\u6027\u3002"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "filter-notification"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Icon", $$NotificationIcon, { "size": "16", "style": { "--color": "var(--color-blue-600, #0051A8)" } })}
    <span class="flex-1">${text}</span>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/notice/notice.astro", void 0);

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$Badges = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Badges;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute({ display: "none", ...style }, "style")}${spreadAttributes(attribute)} data-filter-badges>
    <div class="category-badges">
        <div class="category-badges-header">
            排序與篩選
            ${renderComponent($$result, "ALink", $$Link, { "title": "\u6E05\u9664\u5168\u90E8", "attribute": { "data-category-clear": "" } }, { "default": ($$result2) => renderTemplate`清除全部` })}
        </div>
        <template>
            ${renderComponent($$result, "Badge", $$Badge, { "Tag": "span", "status": "filter", "showCross": true }, { "default": ($$result2) => renderTemplate`<span></span>` })}
        </template>
        <div class="category-badges-list" data-filter-badges-list></div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/badges.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Filter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Filter;
  const { IDName, className, style, attribute = {}, title, show, more, data = [] } = Astro2.props;
  const componentId = IDName || `filter-${Math.random().toString(36).substr(2, 9)}`;
  const inputId = `filter-input-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${renderComponent($$result, "Collapse", $$Collapse, { "IDName": componentId, "className": className, "style": style, "attribute": attribute, "title": title, "show": show }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="filter-content">
        ${data?.map((item, index) => renderTemplate`${renderComponent($$result2, "Checkbox", $$Checkbox, { "id": `${inputId}-${index}`, "label": `${item.label}${item.count ? `(${item.count})` : ""}`, "name": item.name, "value": item.value, "checked": item.checked, "disabled": item.disabled, "style": {
    ...more && index > 4 ? { display: "none" } : {}
  }, "attribute": {
    "data-count": item.count,
    "data-title": item.label
  } })}`)}
        ${more && renderTemplate`<div>
                    ${renderComponent($$result2, "Button", $$Button, { "variant": "blue-outline", "title": "\u66F4\u591A", "size": "sm", "attribute": {
    "data-toggle": "toggle",
    "data-target": "filter-collapse"
  } }, { "default": ($$result3) => renderTemplate`
                        更多
                    ` })}
                </div>`}
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/filter.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Category = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Category;
  const { IDName, className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "category"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Notice", $$Notice, {})}
    ${renderComponent($$result, "Badges", $$Badges, {})}
    <div data-filter>
        ${data?.map((item) => renderTemplate`${renderComponent($$result, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children })}`)}
    </div>
    ${renderComponent($$result, "Button", $$Button, { "variant": "blue", "className": "category-back-button", "size": "lg", "title": "\u8FD4\u56DE\u7BE9\u9078", "block": true, "attribute": { "data-toggle": "back", "data-target": "[data-filter]" }, "style": { visibility: "hidden" } }, { "default": ($$result2) => renderTemplate`
        返回篩選
    ` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/category.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$ArticleOffcanvas = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$ArticleOffcanvas;
  const { IDName = "sectionArticle", className, style, attribute = {}, category } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyOffcanvas", $$Offcanvas, { "IDName": IDName, "postion": "bottom", "hideHeader": true, "className": ["section-article-offcanvas", className], "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<form action="" class="article-offcanvas-form">
        <div class="article-offcanvas-form-header">
            <div class="article-offcanvas-form-header-top">
                <strong class="article-offcanvas-form-header-title">篩選結果</strong>
                ${renderComponent($$result2, "ALink", $$Link, { "title": "\u6E05\u9664\u5168\u90E8", "attribute": { "data-category-clear": "" } }, { "default": ($$result3) => renderTemplate`清除全部` })}
            </div>
            <div data-filter-badges>
                <template>
                    ${renderComponent($$result2, "Badge", $$Badge, { "Tag": "span", "status": "filter", "showCross": true }, { "default": ($$result3) => renderTemplate`<span></span>` })}
                </template>
                <div class="category-badges-list" data-filter-badges-list></div>
            </div>
        </div>
        <div class="article-offcanvas-form-body scrollbar" data-filter>
            ${category?.map((item, index) => renderTemplate`${renderComponent($$result2, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children, "style": {
    ...index === 0 ? { "--collapse-border-width": "0" } : {}
  } })}`)}
        </div>
        <div class="article-offcanvas-form-footer">
            ${renderComponent($$result2, "Button", $$Button, { "type": "reset", "size": "sm", "variant": "blue-outline", "title": "\u53D6\u6D88", "block": true, "attribute": { "data-bs-dismiss": "offcanvas" } }, { "default": ($$result3) => renderTemplate`取消` })}
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "size": "sm", "variant": "blue", "title": "\u63D0\u4EA4", "block": true, "attribute": { "data-title": "\u63D0\u4EA4", "data-category-button": "" } }, { "default": ($$result3) => renderTemplate`
                提交
            ` })}
        </div>
    </form>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articleOffcanvas.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$ShowMore = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ShowMore;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "show-more"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Show More"${addAttribute(["show-more-button"], "class:list")}>
        Show More
        ${renderComponent($$result, "PaginationArrow", $$PaginationArrow, { "size": "12", "direction": "down", "color": "blue-500" })}
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/showMore.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Loading = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Loading;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "section-loading"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="loader"></div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/loading.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$ArticlesList = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ArticlesList;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "",
    total = 0,
    sortDate = [],
    category = [],
    mode = "gray"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "section-articles-list",
    { "section-articles-dark-list": mode === "gray" },
    { "section-articles-light-list": mode === "white" }
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="section-articles-list-inner">
        ${renderComponent($$result, "Title", $$Title, { "title": title })}
        <div class="article-mobile-category">
            <div class="article-mobile-sort-selector">
                ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": sortDate })}
            </div>
            ${renderComponent($$result, "Button", $$Button, { "variant": "blue", "size": "sm", "title": "\u7BE9\u9078", "attribute": {
    "data-bs-toggle": "offcanvas",
    "data-bs-target": `#${IDName}ArticleOffcanvas`,
    "aria-controls": `${IDName}ArticleOffcanvas`,
    "data-title": "\u7BE9\u9078",
    "data-category-button": ""
  } }, { "default": ($$result2) => renderTemplate`
                篩選
            ` })}
        </div>
        <div class="article-list-container">
            ${renderComponent($$result, "Sort", $$Sort, { "total": total, "data": sortDate })}
            <div class="article-list-content">
                ${renderComponent($$result, "Category", $$Category, { "className": "article-category", "data": category })}
                <div class="article-list-grid-container">
                    <div class="article-list-grid">
                        ${renderSlot($$result, $$slots["default"])}
                    </div>
                    ${renderComponent($$result, "ShowMore", $$ShowMore, {})}
                    ${renderComponent($$result, "Loading", $$Loading, {})}
                </div>
            </div>
        </div>
    </div>
</div>
${renderComponent($$result, "ArticleOffcanvas", $$ArticleOffcanvas, { "IDName": `${IDName}Article`, "category": category })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articlesList.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Script = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template([`<script>
    /**
     * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
     * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
     */
    (function () {
        'use strict';

        // URL \u53C3\u6578\u7BA1\u7406\u5DE5\u5177
        const URLManager = {
            /**
             * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
             */
            getParams() {
                const params = new URLSearchParams(window.location.search);
                const result = {};

                // \u8655\u7406\u5169\u7A2E\u683C\u5F0F\uFF1A
                // 1. industry=food-service&industry=healthcare (\u591A\u500B\u540C\u540D\u53C3\u6578)
                // 2. industry=food-service,healthcare (\u9017\u865F\u5206\u9694)

                for (const [key, value] of params) {
                    if (result[key]) {
                        // \u5DF2\u7D93\u5B58\u5728\u8A72 key\uFF0C\u8868\u793A\u662F\u683C\u5F0F1\uFF08\u591A\u500B\u540C\u540D\u53C3\u6578\uFF09
                        if (Array.isArray(result[key])) {
                            result[key].push(value);
                        } else {
                            result[key] = [result[key], value];
                        }
                    } else {
                        // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C\uFF08\u683C\u5F0F2\uFF09
                        if (value.includes(',')) {
                            result[key] = value
                                .split(',')
                                .map((v) => v.trim())
                                .filter((v) => v);
                        } else {
                            result[key] = value;
                        }
                    }
                }
                return result;
            },

            /**
             * \u66F4\u65B0 URL \u53C3\u6578
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string|string[]} value - \u53C3\u6578\u503C
             */
            updateParam(name, value) {
                const url = new URL(window.location);

                if (Array.isArray(value) && value.length > 0) {
                    // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                    url.searchParams.set(name, value.join(','));
                } else if (value) {
                    // \u55AE\u500B\u503C
                    url.searchParams.set(name, value);
                } else {
                    // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                    url.searchParams.delete(name);
                }

                // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
                window.history.replaceState({}, '', url);
            },

            /**
             * \u6DFB\u52A0 URL \u53C3\u6578\u503C
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
             */
            addParamValue(name, value) {
                const currentParam = new URLSearchParams(window.location.search).get(name);
                let values = [];

                if (currentParam) {
                    values = currentParam.includes(',')
                        ? currentParam
                              .split(',')
                              .map((v) => v.trim())
                              .filter((v) => v)
                        : [currentParam];
                }

                if (!values.includes(value)) {
                    values.push(value);
                    this.updateParam(name, values);
                }
            },

            /**
             * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
             */
            removeParamValue(name, value) {
                const currentParam = new URLSearchParams(window.location.search).get(name);

                if (!currentParam) return;

                let values = currentParam.includes(',')
                    ? currentParam
                          .split(',')
                          .map((v) => v.trim())
                          .filter((v) => v)
                    : [currentParam];

                values = values.filter((v) => v !== value);

                if (values.length > 0) {
                    this.updateParam(name, values);
                } else {
                    this.updateParam(name, null);
                }
            }
        };

        // Checkbox \u7BA1\u7406\u5668
        const CheckboxManager = {
            /**
             * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
             */
            init() {
                const filterContainers = document.querySelectorAll('[data-filter]');

                filterContainers.forEach((container) => {
                    const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');

                    checkboxes.forEach((checkbox) => {
                        checkbox.addEventListener('change', this.handleChange.bind(this));
                    });
                });
            },

            /**
             * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
             * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
             */
            handleChange(event) {
                const checkbox = event.target;
                const name = checkbox.name;
                const value = checkbox.value;

                if (checkbox.checked) {
                    // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                    URLManager.addParamValue(name, value);
                } else {
                    // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                    URLManager.removeParamValue(name, value);
                }

                // \u66F4\u65B0\u7BE9\u9078 badges
                FilterBadgeManager.updateFilterBadges();
            },

            /**
             * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
             */
            restoreState() {
                const params = URLManager.getParams();

                Object.keys(params).forEach((name) => {
                    const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                    values.forEach((value) => {
                        const checkboxs = document.querySelectorAll(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
                        checkboxs.forEach((checkbox) => {
                            if (checkbox) {
                                checkbox.checked = true;
                                // \u89F8\u767C change \u4E8B\u4EF6\u4EE5\u78BA\u4FDD\u5176\u4ED6\u76F8\u95DC\u908F\u8F2F\u57F7\u884C
                                checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                        });
                    });
                });
            }
        };

        // Select \u7BA1\u7406\u5668
        const SelectManager = {
            /**
             * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
             */
            init() {
                const selects = document.querySelectorAll('select[data-sort][name]');

                selects.forEach((select) => {
                    select.addEventListener('change', this.handleChange.bind(this));
                });
            },

            /**
             * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
             * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
             */
            handleChange(event) {
                const select = event.target;
                const name = select.name;
                const value = select.value;

                if (value) {
                    URLManager.updateParam(name, value);
                } else {
                    URLManager.updateParam(name, null);
                }
            },

            /**
             * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
             */
            restoreState() {
                const params = URLManager.getParams();

                Object.keys(params).forEach((name) => {
                    const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                    const selects = document.querySelectorAll(\`select[data-sort][name="\${name}"]\`);

                    selects.forEach((select) => {
                        if (select && value) {
                            // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                            let targetIndex = -1;
                            for (let i = 0; i < select.options.length; i++) {
                                if (select.options[i].value === value) {
                                    targetIndex = i;
                                    break;
                                }
                            }

                            if (targetIndex !== -1) {
                                // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                                select.selectedIndex = targetIndex;
                                // \u89F8\u767C change \u4E8B\u4EF6
                                select.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                        }
                    });
                });
            }
        };

        // \u7BE9\u9078\u6578\u91CF\u7BA1\u7406\u5668
        const FilterCountManager = {
            /**
             * \u8A08\u7B97\u7576\u524D\u7BE9\u9078\u6578\u91CF\uFF08\u4E0D\u5305\u542B sort\uFF09
             */
            getFilterCount() {
                const params = URLManager.getParams();
                let count = 0;

                // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
                Object.keys(params).forEach((name) => {
                    // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578\uFF08\u901A\u904E\u6AA2\u67E5\u662F\u5426\u6709\u5C0D\u61C9\u7684 select[data-sort] \u5143\u7D20\uFF09
                    const isSort = document.querySelector(\`select[data-sort][name="\${name}"]\`);

                    if (!isSort) {
                        // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u8A08\u7B97\u6578\u91CF
                        const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                        count += values.filter((v) => v && v.trim()).length;
                    }
                });

                return count;
            },

            /**
             * \u66F4\u65B0\u6240\u6709 data-category-button \u6309\u9215\u7684\u6587\u5B57
             */
            updateButtonTexts() {
                const buttons = document.querySelectorAll('[data-category-button]');
                const count = this.getFilterCount();

                buttons.forEach((button) => {
                    const originalTitle = button.getAttribute('data-title');
                    if (originalTitle) {
                        if (count > 0) {
                            button.textContent = \`\${originalTitle}(\${count})\`;
                        } else {
                            button.textContent = originalTitle;
                        }
                    }
                });
            },

            /**
             * \u521D\u59CB\u5316\u7BE9\u9078\u6578\u91CF\u986F\u793A
             */
            init() {
                // \u521D\u59CB\u66F4\u65B0
                this.updateButtonTexts();

                // \u76E3\u807D URL \u8B8A\u5316
                const originalReplaceState = window.history.replaceState;
                window.history.replaceState = (...args) => {
                    originalReplaceState.apply(window.history, args);
                    // URL \u66F4\u65B0\u5F8C\u91CD\u65B0\u8A08\u7B97\u6578\u91CF
                    setTimeout(() => this.updateButtonTexts(), 0);
                };
            }
        };

        // \u6E05\u9664\u7BE9\u9078\u7BA1\u7406\u5668
        const ClearFilterManager = {
            /**
             * \u6E05\u9664\u6240\u6709\u7BE9\u9078\u53C3\u6578\uFF0C\u4F46\u4FDD\u7559\u6392\u5E8F\u53C3\u6578
             */
            clearAllFilters() {
                const params = URLManager.getParams();
                const url = new URL(window.location);

                // \u6E05\u9664\u6240\u6709\u53C3\u6578
                url.searchParams.forEach((value, key) => {
                    const isSort = document.querySelector(\`select[data-sort][name="\${key}"]\`);
                    if (isSort) return;
                    url.searchParams.delete(key);
                });

                // \u66F4\u65B0 URL
                window.history.replaceState({}, '', url);

                // \u91CD\u7F6E\u6240\u6709 checkbox \u72C0\u614B
                const checkboxes = document.querySelectorAll('input[type="checkbox"][name]');
                checkboxes.forEach((checkbox) => {
                    checkbox.checked = false;
                });

                // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
                FilterCountManager.updateButtonTexts();

                // \u66F4\u65B0\u7BE9\u9078 badges
                FilterBadgeManager.updateFilterBadges();
            },

            /**
             * \u521D\u59CB\u5316\u6E05\u9664\u6309\u9215\u4E8B\u4EF6\u76E3\u807D
             */
            init() {
                const clearButtons = document.querySelectorAll('[data-category-clear]');

                clearButtons.forEach((button) => {
                    button.addEventListener('click', (e) => {
                        e.preventDefault();
                        this.clearAllFilters();
                    });
                });
            }
        };

        // \u7BE9\u9078 Badge \u7BA1\u7406\u5668
        const FilterBadgeManager = {
            /**
             * \u7372\u53D6\u7BE9\u9078\u53C3\u6578\u7684\u986F\u793A\u6587\u5B57
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u53C3\u6578\u503C
             */
            getFilterDisplayText(name, value) {
                // \u5617\u8A66\u5F9E\u5C0D\u61C9\u7684 checkbox \u7684 data-title \u5C6C\u6027\u7372\u53D6\u986F\u793A\u6587\u5B57
                const checkbox = document.querySelector(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
                if (checkbox) {
                    // \u512A\u5148\u4F7F\u7528 data-title \u5C6C\u6027
                    const dataTitle = checkbox.getAttribute('data-title');
                    if (dataTitle) {
                        return dataTitle.trim();
                    }
                }

                // \u5982\u679C\u627E\u4E0D\u5230\u5C0D\u61C9\u7684 checkbox \u6216 data-title\uFF0C\u8FD4\u56DE\u539F\u59CB\u503C
                return value;
            },

            /**
             * \u66F4\u65B0\u6240\u6709\u7BE9\u9078 badges
             */
            updateFilterBadges() {
                const badgeContainers = document.querySelectorAll('[data-filter-badges]');
                const params = URLManager.getParams();

                badgeContainers.forEach((container) => {
                    const badgesList = container.querySelector('[data-filter-badges-list]');
                    const template = container.querySelector('template');

                    if (!badgesList || !template) return;

                    // \u6E05\u7A7A\u73FE\u6709\u7684 badges
                    badgesList.innerHTML = '';

                    let hasFilters = false;

                    // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
                    Object.keys(params).forEach((name) => {
                        // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578
                        const isSort = document.querySelector(\`select[data-sort][name="\${name}"]\`);

                        if (!isSort) {
                            // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u5275\u5EFA badge
                            const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                            values.forEach((value) => {
                                if (value && value.trim()) {
                                    hasFilters = true;

                                    // \u8907\u88FD\u6A21\u677F\u5167\u5BB9
                                    const badgeClone = template.content.cloneNode(true);
                                    const badge = badgeClone.querySelector('.badge');
                                    const textSpan = badge?.querySelector('span:not(.badge-close)');

                                    if (badge && textSpan) {
                                        // \u8A2D\u7F6E data \u5C6C\u6027
                                        badge.setAttribute('data-key', name);
                                        badge.setAttribute('data-value', value);

                                        // \u8A2D\u7F6E\u986F\u793A\u6587\u5B57
                                        const displayText = this.getFilterDisplayText(name, value);
                                        textSpan.textContent = displayText;

                                        // \u6DFB\u52A0\u9EDE\u64CA\u4E8B\u4EF6\u4F86\u522A\u9664\u7BE9\u9078
                                        badge.addEventListener('click', (e) => {
                                            e.preventDefault();
                                            this.removeFilter(name, value);
                                        });

                                        // \u6DFB\u52A0\u5230\u5217\u8868
                                        badgesList.appendChild(badgeClone);
                                    }
                                }
                            });
                        }
                    });

                    // \u986F\u793A\u6216\u96B1\u85CF\u6574\u500B badge \u5BB9\u5668
                    if (hasFilters) {
                        container.style.display = '';
                    } else {
                        container.style.display = 'none';
                    }
                });
            },

            /**
             * \u79FB\u9664\u7279\u5B9A\u7684\u7BE9\u9078\u53C3\u6578
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u53C3\u6578\u503C
             */
            removeFilter(name, value) {
                // \u79FB\u9664 URL \u53C3\u6578
                URLManager.removeParamValue(name, value);

                // \u66F4\u65B0\u5C0D\u61C9\u7684 checkbox \u72C0\u614B
                const checkboxes = document.querySelectorAll(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
                checkboxes.forEach((checkbox) => {
                    checkbox.checked = false;
                    // \u89F8\u767C change \u4E8B\u4EF6
                    checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                });

                // \u66F4\u65B0 badges \u986F\u793A
                this.updateFilterBadges();

                // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
                FilterCountManager.updateButtonTexts();
            },

            /**
             * \u521D\u59CB\u5316\u7BE9\u9078 badge \u529F\u80FD
             */
            init() {
                // \u521D\u59CB\u66F4\u65B0
                this.updateFilterBadges();
            }
        };

        // \u4E3B\u521D\u59CB\u5316\u51FD\u6578
        function initialize() {
            // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
            CheckboxManager.init();
            SelectManager.init();
            FilterCountManager.init();
            ClearFilterManager.init();
            FilterBadgeManager.init();

            // \u6062\u5FA9\u9801\u9762\u72C0\u614B
            CheckboxManager.restoreState();
            SelectManager.restoreState();

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            FilterCountManager.updateButtonTexts();

            // \u66F4\u65B0\u7BE9\u9078 badges
            FilterBadgeManager.updateFilterBadges();
        }

        // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initialize);
        } else {
            initialize();
        }

        // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
        const observer = new MutationObserver(function (mutations) {
            let shouldReinit = false;

            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1) {
                        // Element node
                        const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                        const hasSort = node.querySelector && node.querySelector('[data-sort]');

                        if (hasFilter || hasSort) {
                            shouldReinit = true;
                        }
                    }
                });
            });

            if (shouldReinit) {
                // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
                setTimeout(() => {
                    CheckboxManager.init();
                    SelectManager.init();
                    ClearFilterManager.init();
                    FilterBadgeManager.init();
                    FilterCountManager.updateButtonTexts();
                    FilterBadgeManager.updateFilterBadges();
                }, 100);
            }
        });

        // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
        window.FilterSortManager = {
            URLManager,
            CheckboxManager,
            SelectManager,
            FilterCountManager,
            ClearFilterManager,
            FilterBadgeManager,
            initialize
        };
    })();
<\/script>`], [`<script>
    /**
     * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
     * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
     */
    (function () {
        'use strict';

        // URL \u53C3\u6578\u7BA1\u7406\u5DE5\u5177
        const URLManager = {
            /**
             * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
             */
            getParams() {
                const params = new URLSearchParams(window.location.search);
                const result = {};

                // \u8655\u7406\u5169\u7A2E\u683C\u5F0F\uFF1A
                // 1. industry=food-service&industry=healthcare (\u591A\u500B\u540C\u540D\u53C3\u6578)
                // 2. industry=food-service,healthcare (\u9017\u865F\u5206\u9694)

                for (const [key, value] of params) {
                    if (result[key]) {
                        // \u5DF2\u7D93\u5B58\u5728\u8A72 key\uFF0C\u8868\u793A\u662F\u683C\u5F0F1\uFF08\u591A\u500B\u540C\u540D\u53C3\u6578\uFF09
                        if (Array.isArray(result[key])) {
                            result[key].push(value);
                        } else {
                            result[key] = [result[key], value];
                        }
                    } else {
                        // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C\uFF08\u683C\u5F0F2\uFF09
                        if (value.includes(',')) {
                            result[key] = value
                                .split(',')
                                .map((v) => v.trim())
                                .filter((v) => v);
                        } else {
                            result[key] = value;
                        }
                    }
                }
                return result;
            },

            /**
             * \u66F4\u65B0 URL \u53C3\u6578
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string|string[]} value - \u53C3\u6578\u503C
             */
            updateParam(name, value) {
                const url = new URL(window.location);

                if (Array.isArray(value) && value.length > 0) {
                    // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                    url.searchParams.set(name, value.join(','));
                } else if (value) {
                    // \u55AE\u500B\u503C
                    url.searchParams.set(name, value);
                } else {
                    // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                    url.searchParams.delete(name);
                }

                // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
                window.history.replaceState({}, '', url);
            },

            /**
             * \u6DFB\u52A0 URL \u53C3\u6578\u503C
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
             */
            addParamValue(name, value) {
                const currentParam = new URLSearchParams(window.location.search).get(name);
                let values = [];

                if (currentParam) {
                    values = currentParam.includes(',')
                        ? currentParam
                              .split(',')
                              .map((v) => v.trim())
                              .filter((v) => v)
                        : [currentParam];
                }

                if (!values.includes(value)) {
                    values.push(value);
                    this.updateParam(name, values);
                }
            },

            /**
             * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
             */
            removeParamValue(name, value) {
                const currentParam = new URLSearchParams(window.location.search).get(name);

                if (!currentParam) return;

                let values = currentParam.includes(',')
                    ? currentParam
                          .split(',')
                          .map((v) => v.trim())
                          .filter((v) => v)
                    : [currentParam];

                values = values.filter((v) => v !== value);

                if (values.length > 0) {
                    this.updateParam(name, values);
                } else {
                    this.updateParam(name, null);
                }
            }
        };

        // Checkbox \u7BA1\u7406\u5668
        const CheckboxManager = {
            /**
             * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
             */
            init() {
                const filterContainers = document.querySelectorAll('[data-filter]');

                filterContainers.forEach((container) => {
                    const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');

                    checkboxes.forEach((checkbox) => {
                        checkbox.addEventListener('change', this.handleChange.bind(this));
                    });
                });
            },

            /**
             * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
             * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
             */
            handleChange(event) {
                const checkbox = event.target;
                const name = checkbox.name;
                const value = checkbox.value;

                if (checkbox.checked) {
                    // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                    URLManager.addParamValue(name, value);
                } else {
                    // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                    URLManager.removeParamValue(name, value);
                }

                // \u66F4\u65B0\u7BE9\u9078 badges
                FilterBadgeManager.updateFilterBadges();
            },

            /**
             * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
             */
            restoreState() {
                const params = URLManager.getParams();

                Object.keys(params).forEach((name) => {
                    const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                    values.forEach((value) => {
                        const checkboxs = document.querySelectorAll(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
                        checkboxs.forEach((checkbox) => {
                            if (checkbox) {
                                checkbox.checked = true;
                                // \u89F8\u767C change \u4E8B\u4EF6\u4EE5\u78BA\u4FDD\u5176\u4ED6\u76F8\u95DC\u908F\u8F2F\u57F7\u884C
                                checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                        });
                    });
                });
            }
        };

        // Select \u7BA1\u7406\u5668
        const SelectManager = {
            /**
             * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
             */
            init() {
                const selects = document.querySelectorAll('select[data-sort][name]');

                selects.forEach((select) => {
                    select.addEventListener('change', this.handleChange.bind(this));
                });
            },

            /**
             * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
             * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
             */
            handleChange(event) {
                const select = event.target;
                const name = select.name;
                const value = select.value;

                if (value) {
                    URLManager.updateParam(name, value);
                } else {
                    URLManager.updateParam(name, null);
                }
            },

            /**
             * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
             */
            restoreState() {
                const params = URLManager.getParams();

                Object.keys(params).forEach((name) => {
                    const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                    const selects = document.querySelectorAll(\\\`select[data-sort][name="\\\${name}"]\\\`);

                    selects.forEach((select) => {
                        if (select && value) {
                            // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                            let targetIndex = -1;
                            for (let i = 0; i < select.options.length; i++) {
                                if (select.options[i].value === value) {
                                    targetIndex = i;
                                    break;
                                }
                            }

                            if (targetIndex !== -1) {
                                // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                                select.selectedIndex = targetIndex;
                                // \u89F8\u767C change \u4E8B\u4EF6
                                select.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                        }
                    });
                });
            }
        };

        // \u7BE9\u9078\u6578\u91CF\u7BA1\u7406\u5668
        const FilterCountManager = {
            /**
             * \u8A08\u7B97\u7576\u524D\u7BE9\u9078\u6578\u91CF\uFF08\u4E0D\u5305\u542B sort\uFF09
             */
            getFilterCount() {
                const params = URLManager.getParams();
                let count = 0;

                // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
                Object.keys(params).forEach((name) => {
                    // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578\uFF08\u901A\u904E\u6AA2\u67E5\u662F\u5426\u6709\u5C0D\u61C9\u7684 select[data-sort] \u5143\u7D20\uFF09
                    const isSort = document.querySelector(\\\`select[data-sort][name="\\\${name}"]\\\`);

                    if (!isSort) {
                        // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u8A08\u7B97\u6578\u91CF
                        const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                        count += values.filter((v) => v && v.trim()).length;
                    }
                });

                return count;
            },

            /**
             * \u66F4\u65B0\u6240\u6709 data-category-button \u6309\u9215\u7684\u6587\u5B57
             */
            updateButtonTexts() {
                const buttons = document.querySelectorAll('[data-category-button]');
                const count = this.getFilterCount();

                buttons.forEach((button) => {
                    const originalTitle = button.getAttribute('data-title');
                    if (originalTitle) {
                        if (count > 0) {
                            button.textContent = \\\`\\\${originalTitle}(\\\${count})\\\`;
                        } else {
                            button.textContent = originalTitle;
                        }
                    }
                });
            },

            /**
             * \u521D\u59CB\u5316\u7BE9\u9078\u6578\u91CF\u986F\u793A
             */
            init() {
                // \u521D\u59CB\u66F4\u65B0
                this.updateButtonTexts();

                // \u76E3\u807D URL \u8B8A\u5316
                const originalReplaceState = window.history.replaceState;
                window.history.replaceState = (...args) => {
                    originalReplaceState.apply(window.history, args);
                    // URL \u66F4\u65B0\u5F8C\u91CD\u65B0\u8A08\u7B97\u6578\u91CF
                    setTimeout(() => this.updateButtonTexts(), 0);
                };
            }
        };

        // \u6E05\u9664\u7BE9\u9078\u7BA1\u7406\u5668
        const ClearFilterManager = {
            /**
             * \u6E05\u9664\u6240\u6709\u7BE9\u9078\u53C3\u6578\uFF0C\u4F46\u4FDD\u7559\u6392\u5E8F\u53C3\u6578
             */
            clearAllFilters() {
                const params = URLManager.getParams();
                const url = new URL(window.location);

                // \u6E05\u9664\u6240\u6709\u53C3\u6578
                url.searchParams.forEach((value, key) => {
                    const isSort = document.querySelector(\\\`select[data-sort][name="\\\${key}"]\\\`);
                    if (isSort) return;
                    url.searchParams.delete(key);
                });

                // \u66F4\u65B0 URL
                window.history.replaceState({}, '', url);

                // \u91CD\u7F6E\u6240\u6709 checkbox \u72C0\u614B
                const checkboxes = document.querySelectorAll('input[type="checkbox"][name]');
                checkboxes.forEach((checkbox) => {
                    checkbox.checked = false;
                });

                // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
                FilterCountManager.updateButtonTexts();

                // \u66F4\u65B0\u7BE9\u9078 badges
                FilterBadgeManager.updateFilterBadges();
            },

            /**
             * \u521D\u59CB\u5316\u6E05\u9664\u6309\u9215\u4E8B\u4EF6\u76E3\u807D
             */
            init() {
                const clearButtons = document.querySelectorAll('[data-category-clear]');

                clearButtons.forEach((button) => {
                    button.addEventListener('click', (e) => {
                        e.preventDefault();
                        this.clearAllFilters();
                    });
                });
            }
        };

        // \u7BE9\u9078 Badge \u7BA1\u7406\u5668
        const FilterBadgeManager = {
            /**
             * \u7372\u53D6\u7BE9\u9078\u53C3\u6578\u7684\u986F\u793A\u6587\u5B57
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u53C3\u6578\u503C
             */
            getFilterDisplayText(name, value) {
                // \u5617\u8A66\u5F9E\u5C0D\u61C9\u7684 checkbox \u7684 data-title \u5C6C\u6027\u7372\u53D6\u986F\u793A\u6587\u5B57
                const checkbox = document.querySelector(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
                if (checkbox) {
                    // \u512A\u5148\u4F7F\u7528 data-title \u5C6C\u6027
                    const dataTitle = checkbox.getAttribute('data-title');
                    if (dataTitle) {
                        return dataTitle.trim();
                    }
                }

                // \u5982\u679C\u627E\u4E0D\u5230\u5C0D\u61C9\u7684 checkbox \u6216 data-title\uFF0C\u8FD4\u56DE\u539F\u59CB\u503C
                return value;
            },

            /**
             * \u66F4\u65B0\u6240\u6709\u7BE9\u9078 badges
             */
            updateFilterBadges() {
                const badgeContainers = document.querySelectorAll('[data-filter-badges]');
                const params = URLManager.getParams();

                badgeContainers.forEach((container) => {
                    const badgesList = container.querySelector('[data-filter-badges-list]');
                    const template = container.querySelector('template');

                    if (!badgesList || !template) return;

                    // \u6E05\u7A7A\u73FE\u6709\u7684 badges
                    badgesList.innerHTML = '';

                    let hasFilters = false;

                    // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
                    Object.keys(params).forEach((name) => {
                        // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578
                        const isSort = document.querySelector(\\\`select[data-sort][name="\\\${name}"]\\\`);

                        if (!isSort) {
                            // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u5275\u5EFA badge
                            const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                            values.forEach((value) => {
                                if (value && value.trim()) {
                                    hasFilters = true;

                                    // \u8907\u88FD\u6A21\u677F\u5167\u5BB9
                                    const badgeClone = template.content.cloneNode(true);
                                    const badge = badgeClone.querySelector('.badge');
                                    const textSpan = badge?.querySelector('span:not(.badge-close)');

                                    if (badge && textSpan) {
                                        // \u8A2D\u7F6E data \u5C6C\u6027
                                        badge.setAttribute('data-key', name);
                                        badge.setAttribute('data-value', value);

                                        // \u8A2D\u7F6E\u986F\u793A\u6587\u5B57
                                        const displayText = this.getFilterDisplayText(name, value);
                                        textSpan.textContent = displayText;

                                        // \u6DFB\u52A0\u9EDE\u64CA\u4E8B\u4EF6\u4F86\u522A\u9664\u7BE9\u9078
                                        badge.addEventListener('click', (e) => {
                                            e.preventDefault();
                                            this.removeFilter(name, value);
                                        });

                                        // \u6DFB\u52A0\u5230\u5217\u8868
                                        badgesList.appendChild(badgeClone);
                                    }
                                }
                            });
                        }
                    });

                    // \u986F\u793A\u6216\u96B1\u85CF\u6574\u500B badge \u5BB9\u5668
                    if (hasFilters) {
                        container.style.display = '';
                    } else {
                        container.style.display = 'none';
                    }
                });
            },

            /**
             * \u79FB\u9664\u7279\u5B9A\u7684\u7BE9\u9078\u53C3\u6578
             * @param {string} name - \u53C3\u6578\u540D\u7A31
             * @param {string} value - \u53C3\u6578\u503C
             */
            removeFilter(name, value) {
                // \u79FB\u9664 URL \u53C3\u6578
                URLManager.removeParamValue(name, value);

                // \u66F4\u65B0\u5C0D\u61C9\u7684 checkbox \u72C0\u614B
                const checkboxes = document.querySelectorAll(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
                checkboxes.forEach((checkbox) => {
                    checkbox.checked = false;
                    // \u89F8\u767C change \u4E8B\u4EF6
                    checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                });

                // \u66F4\u65B0 badges \u986F\u793A
                this.updateFilterBadges();

                // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
                FilterCountManager.updateButtonTexts();
            },

            /**
             * \u521D\u59CB\u5316\u7BE9\u9078 badge \u529F\u80FD
             */
            init() {
                // \u521D\u59CB\u66F4\u65B0
                this.updateFilterBadges();
            }
        };

        // \u4E3B\u521D\u59CB\u5316\u51FD\u6578
        function initialize() {
            // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
            CheckboxManager.init();
            SelectManager.init();
            FilterCountManager.init();
            ClearFilterManager.init();
            FilterBadgeManager.init();

            // \u6062\u5FA9\u9801\u9762\u72C0\u614B
            CheckboxManager.restoreState();
            SelectManager.restoreState();

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            FilterCountManager.updateButtonTexts();

            // \u66F4\u65B0\u7BE9\u9078 badges
            FilterBadgeManager.updateFilterBadges();
        }

        // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initialize);
        } else {
            initialize();
        }

        // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
        const observer = new MutationObserver(function (mutations) {
            let shouldReinit = false;

            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1) {
                        // Element node
                        const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                        const hasSort = node.querySelector && node.querySelector('[data-sort]');

                        if (hasFilter || hasSort) {
                            shouldReinit = true;
                        }
                    }
                });
            });

            if (shouldReinit) {
                // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
                setTimeout(() => {
                    CheckboxManager.init();
                    SelectManager.init();
                    ClearFilterManager.init();
                    FilterBadgeManager.init();
                    FilterCountManager.updateButtonTexts();
                    FilterBadgeManager.updateFilterBadges();
                }, 100);
            }
        });

        // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
        window.FilterSortManager = {
            URLManager,
            CheckboxManager,
            SelectManager,
            FilterCountManager,
            ClearFilterManager,
            FilterBadgeManager,
            initialize
        };
    })();
<\/script>`])));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/script.astro", void 0);

export { $$Follower as $, $$Script as a, $$ArticlesList as b };
