import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$TypeIconGoogleSizeMd = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip_google_md_g)">
<mask id="mask0_2663_37410" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
<path d="M24 0H0V24H24V0Z" fill="white"></path>
</mask>
<g mask="url(#mask0_2663_37410)">
<path d="M23.52 12.273C23.52 11.422 23.4436 10.6039 23.3018 9.81836H12V14.4602H18.4582C18.18 15.9602 17.3347 17.2311 16.0636 18.082V21.093H19.9418C22.2109 19.0039 23.52 15.9274 23.52 12.273Z" fill="#4285F4"></path>
<path d="M11.9994 24.0003C15.2394 24.0003 17.9556 22.9256 19.9411 21.093L16.0629 18.0821C14.9885 18.8021 13.6138 19.2274 11.9994 19.2274C8.87382 19.2274 6.22847 17.1165 5.28473 14.2803H1.27563V17.3894C3.25029 21.3112 7.30847 24.0003 11.9994 24.0003Z" fill="#34A853"></path>
<path d="M5.28546 14.2804C5.04535 13.5604 4.90909 12.7913 4.90909 12.0004C4.90909 11.2094 5.04535 10.4404 5.28546 9.72042V6.61133H1.27636C0.463637 8.23133 0 10.0641 0 12.0004C0 13.9367 0.463637 15.7694 1.27636 17.3894L5.28546 14.2804Z" fill="#FBBC04"></path>
<path d="M11.9994 4.77273C13.7611 4.77273 15.3429 5.37818 16.5865 6.56727L20.0285 3.12545C17.9503 1.18909 15.2338 0 11.9994 0C7.30847 0 3.25029 2.68909 1.27563 6.61091L5.28473 9.72C6.22847 6.88375 8.87382 4.77273 11.9994 4.77273Z" fill="#E94235"></path>
</g>
</g>
<defs>
<clipPath id="clip_google_md">
<rect width="24" height="24" fill="white"></rect>
</clipPath>
</defs>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/social/svg-astro/type_icon_google-size_md.astro", void 0);

export { $$TypeIconGoogleSizeMd as default };
