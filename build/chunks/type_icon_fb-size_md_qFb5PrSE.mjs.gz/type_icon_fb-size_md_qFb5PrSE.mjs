import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$TypeIconFbSizeMd = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip_fb_md_g)">
<rect width="24" height="24" rx="12" fill="white"></rect>
<path d="M23.9995 12.0437C23.9995 5.41648 18.627 0.0439453 11.9998 0.0439453C5.37253 0.0439453 0 5.41648 0 12.0437C0 17.6711 3.87448 22.3933 9.1011 23.6902V15.7108H6.62675V12.0437H9.1011V10.4636C9.1011 6.37932 10.9496 4.48625 14.9594 4.48625C15.7197 4.48625 17.0315 4.63553 17.5681 4.78433V8.10827C17.2849 8.07848 16.7929 8.06359 16.1819 8.06359C14.2144 8.06359 13.4541 8.80905 13.4541 10.7467V12.0437H17.3737L16.7003 15.7108H13.4541V23.9556C19.3959 23.238 23.9995 18.1789 23.9995 12.0437Z" fill="var(--color-facebook, #0866FF)"></path>
</g>
<defs>
<clipPath id="clip_fb_md">
<rect width="24" height="24" rx="12" fill="white"></rect>
</clipPath>
</defs>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/social/svg-astro/type_icon_fb-size_md.astro", void 0);

export { $$TypeIconFbSizeMd as default };
