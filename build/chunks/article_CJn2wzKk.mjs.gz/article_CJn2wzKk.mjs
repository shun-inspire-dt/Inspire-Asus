import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, F as Fragment, d as renderTemplate, u as unescapeHTML } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Date } from './date_ClEZtioF.mjs';
import { d as $$A, $ as $$Button } from './layouts_BCWl4s7t.mjs';
/* empty css                        */

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Breadcrumb = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Breadcrumb;
  const { IDName, className, style, attribute = {}, items } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<ul${addAttribute(IDName, "id")}${addAttribute(["article-breadcrumb", className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${items?.map((item, index) => renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
                ${renderComponent($$result2, "A", $$A, { "link": item.href, "title": item.name, "className": "article-breadcrumb-item" }, { "default": ($$result3) => renderTemplate`${item.name}` })}
                ${index < items.length - 1 && renderTemplate`<span>·</span>`}` })}`)}
</ul>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/breadcrumb.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Article = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Article;
  const { IDName, className, style, attribute = {}, title, date, breadcrumb, html, buttonText, buttonLink } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "my-article"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${Boolean(title || date || breadcrumb) && renderTemplate`<div class="my-article-head">
                ${date && renderTemplate`<div class="my-article-date">
                        ${renderComponent($$result, "Date", $$Date, { "date": date })}
                    </div>`}
                ${title && renderTemplate`<h1 class="my-article-title">
                        ${title}
                    </h1>`}
                ${breadcrumb && renderTemplate`<div class="my-article-breadcrumb">
                        ${renderComponent($$result, "Breadcrumb", $$Breadcrumb, { "items": breadcrumb })}
                    </div>`}
            </div>`}
    <div class=":uno-my-article-body:">
        <article class="article">${unescapeHTML(html)}</article>
    </div>
    ${buttonText && buttonLink && renderTemplate`<div class="my-article-button">
                ${renderComponent($$result, "Button", $$Button, { "Tag": "a", "variant": "blue", "size": "lg", "link": buttonLink, "title": buttonText }, { "default": ($$result2) => renderTemplate`${buttonText}` })}
            </div>`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/article.astro", void 0);

export { $$Article as $ };
