import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
/* empty css                        */

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Swiper = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Swiper;
  const { IDName, className, swiperClassName, style, attribute = {}, pagination, navigation, swiperAttribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName ? `${IDName}SwiperContainer` : void 0, "id")}${addAttribute(["swiper-container", className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderSlot($$result, $$slots["outspace-left"])}
    ${navigation && navigation === "outside" && renderTemplate`<div class="swiper-buttons">
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>`}
    ${pagination && pagination === "outside" && renderTemplate`<div class="swiper-pagination"></div>`}
    <div${addAttribute(IDName ? `${IDName}Swiper` : void 0, "id")}${addAttribute(["swiper", swiperClassName], "class:list")}${spreadAttributes(swiperAttribute)}>
        ${pagination && pagination === "inside" && renderTemplate`<div class="swiper-pagination"></div>`}
        ${navigation && navigation === "inside" && renderTemplate`<div class="swiper-buttons">
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>`}
        <div class="swiper-wrapper">
            ${renderSlot($$result, $$slots["default"])}
        </div>
        ${renderSlot($$result, $$slots["outside"])}
    </div>
    ${renderSlot($$result, $$slots["outspace"])}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/swiper/swiper.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$NavigatiorArrow = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$NavigatiorArrow;
  const { IDName, className, style, attribute = {}, direction = "left" } = Astro2.props;
  const componentId = IDName || `navigatior-arrow-${Math.random().toString(36).substr(2, 9)}`;
  const svgStyle = {
    "up": "rotate(-90deg)",
    "down": "rotate(90deg)",
    "left": "rotate(0deg)",
    "right": "rotate(180deg)"
  };
  return renderTemplate`${maybeRenderHead()}<button${addAttribute(componentId, "id")} type="button"${addAttribute([
    "navigatior-arrow",
    className
  ], "class:list")} title="navigator"${spreadAttributes(attribute)}${addAttribute({ ...style }, "style")}>
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"${addAttribute({ transform: svgStyle[direction] }, "style")}>
        <path d="M8.64994 2.0498L3.7002 6.99955L8.64994 11.9493" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
</button>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/navigatiorArrow.astro", void 0);

export { $$Swiper as $, $$NavigatiorArrow as a };
