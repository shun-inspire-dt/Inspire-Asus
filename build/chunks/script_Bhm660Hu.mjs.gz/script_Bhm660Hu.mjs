import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate, r as renderComponent, e as renderSlot, F as Fragment } from './astro/server_Bjgbv9en.mjs';
/* empty css                       */
import { d as $$Collapse, a as $$Button, e as $$Offcanvas, c as $$Link } from './layouts_Dei3z7tc.mjs';

const $$Astro$f = createAstro("https://www.Asus.com.tw");
const $$Follower = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$f, $$props, $$slots);
  Astro2.self = $$Follower;
  const { IDName = "Follower", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "follower"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Go Top" class="follower-button">
        <svg width="25" height="15" viewBox="0 0 25 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.0879 12.4816L12.4813 1.875L1.87469 12.4816" stroke="white" stroke-width="3.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
        <svg width="19" height="11" viewBox="0 0 19 11" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.9316 9.15317L9.15347 1.375L1.37529 9.15317" stroke="white" stroke-width="2.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/follower/follower.astro", void 0);

const $$Astro$e = createAstro("https://www.Asus.com.tw");
const $$Title = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$e, $$props, $$slots);
  Astro2.self = $$Title;
  const { IDName, className, style, attribute = {}, Tag = "h1", title = "Title" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [
    className,
    "section-title"
  ], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`${title}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/title.astro", void 0);

const $$Astro$d = createAstro("https://www.Asus.com.tw");
const $$Select = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$d, $$props, $$slots);
  Astro2.self = $$Select;
  const {
    id,
    // 選擇器 ID
    data = [],
    // 選項資料，預設為空陣列
    className,
    // 自定義 CSS 類別
    required,
    // 是否必填
    disabled,
    // 是否禁用
    name,
    // 表單欄位名稱
    value,
    // 當前選中值
    placeholder = "\u8ACB\u9078\u64C7",
    // 佔位符文字，預設為「請選擇」
    title,
    // 無障礙標籤
    size = "md",
    // 尺寸，預設為 md
    status,
    // 狀態，預設為 value
    validClass,
    // 驗證類別，預設為 'form'
    validType,
    // 驗證類型
    validLabel,
    // 驗證標籤
    customValidText,
    // 自定義驗證成功訊息
    customInvalidText,
    // 自定義驗證失敗訊息
    onchange,
    // 值改變事件處理
    attribute = {},
    // 額外屬性，預設為空物件
    style = {}
    // 額外樣式，預設為空物件
  } = Astro2.props;
  const validAttribute = {
    "data-valid-class": validClass,
    // 驗證類別
    "data-valid-type": validType,
    // 驗證類型
    "data-valid-label": validLabel,
    // 驗證標籤
    "data-custom-valid-text": customValidText,
    // 自定義成功訊息
    "data-custom-invalid-text": customInvalidText
    // 自定義失敗訊息
  };
  const selectClasses = [
    "control-input",
    "control-select",
    { [`size_${size}`]: size },
    { [`status_${status}`]: status },
    className
  ].filter(Boolean);
  return renderTemplate`${maybeRenderHead()}<select${addAttribute(id, "id")}${addAttribute(selectClasses, "class:list")}${addAttribute(name, "name")}${addAttribute(value, "value")}${addAttribute(required, "required")}${addAttribute(disabled, "disabled")}${addAttribute(style, "style")}${addAttribute(onchange, "onchange")}${addAttribute(title, "aria-label")}${spreadAttributes(attribute)}${spreadAttributes(validAttribute)}>
    ${renderSlot($$result, $$slots["index"], renderTemplate`
        <option class="control-select-placeholder" value=""${addAttribute(!!value, "disabled")}${spreadAttributes(!value ? { selected: "" } : {})}>
            ${placeholder}
        </option>
    

    ${renderSlot($$result, $$slots["default"], renderTemplate`
        ${/*
   * 根據 data 屬性動態生成選項
   * - 遍歷 data 陣列
   * - 設定選項值和顯示文字
   * - 根據當前值自動選中對應選項
   * - 支援每個選項的自定義屬性
   */
  data.map((x) => renderTemplate`<option${addAttribute(x.value, "value")}${addAttribute(value === x.value, "selected")}${spreadAttributes(x.attribute)}>
                    ${x.text}
                </option>`)}
    `)}
`)}</select>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/select/select.astro", void 0);

const $$Astro$c = createAstro("https://www.Asus.com.tw");
const $$CustomSelect = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$c, $$props, $$slots);
  Astro2.self = $$CustomSelect;
  const {
    id,
    data = [],
    className,
    selectClassName,
    required,
    disabled,
    name,
    value,
    placeholder = "\u8ACB\u9078\u64C7",
    title,
    size = "md",
    status,
    validClass,
    validType,
    validLabel,
    customValidText,
    customInvalidText,
    onchange,
    attribute = {},
    selectAttribute = {},
    style = {},
    selectStyle = {},
    custom = true,
    prebuiltStructure = false
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute([{ "custom-select": custom }, className], "class:list")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>
    ${renderComponent($$result, "Select", $$Select, { "id": id, "data": data, "className": [{ "custom-origin-select": custom }, selectClassName], "required": required, "disabled": disabled, "name": name, "value": value, "title": title, "size": size, "status": status, "placeholder": placeholder, "validClass": validClass, "validType": validType, "validLabel": validLabel, "customValidText": customValidText, "customInvalidText": customInvalidText, "onchange": onchange, "attribute": selectAttribute, "style": selectStyle })}
    ${prebuiltStructure && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <div class="select-selected select-selected-placeholder"></div>
            <div class="select-items select-hide"></div>
        ` })}`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/select/customSelect.astro", void 0);

const $$Astro$b = createAstro("https://www.Asus.com.tw");
const $$SortSelector = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$b, $$props, $$slots);
  Astro2.self = $$SortSelector;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  const componentId = IDName || `sort-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "sort-selector"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <label class="sort-selector-label"${addAttribute(componentId, "for")}>排序：</label>
    ${renderComponent($$result, "Select", $$CustomSelect, { "id": componentId, "status": "sort", "className": "sort-selector-select", "size": "sm", "name": "sort", "data": data, "selectAttribute": { "data-sort": "" }, "style": { minWidth: "9.5rem" } })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sortSelector.astro", void 0);

const $$Astro$a = createAstro("https://www.Asus.com.tw");
const $$Sort = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$Sort;
  const { IDName, className, style, attribute = {}, total, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "sort"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <span class="sort-result">篩選結果: ${total} 結果</span>
    <div class="sort-selector-container">
        ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": data })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sort.astro", void 0);

const $$Astro$9 = createAstro("https://www.Asus.com.tw");
const $$NotificationIcon = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$NotificationIcon;
  const { IDName, className, size = "16", status = "solid", style, attribute = {} } = Astro2.props;
  const selectClasses = ["notification-icon", { [`size_${size}`]: size }, { [`status_${status}`]: status }, className].filter(
    Boolean
  );
  return renderTemplate`${maybeRenderHead()}<span${addAttribute(IDName, "id")}${addAttribute(selectClasses, "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <span>
        ${size === "13" && renderTemplate`<svg width="2" height="9" viewBox="0 0 2 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.75 3.75C1.75 3.33579 1.41421 3 1 3C0.585786 3 0.25 3.33579 0.25 3.75V7.75C0.25 8.16421 0.585786 8.5 1 8.5C1.41421 8.5 1.75 8.16421 1.75 7.75V3.75Z" fill="var(--color-white, #fff)"></path>
                    <path d="M2 1C2 0.447715 1.55228 0 1 0C0.447715 0 0 0.447715 0 1C0 1.55228 0.447715 2 1 2C1.55228 2 2 1.55228 2 1Z" fill="var(--color-white, #fff)"></path>
                </svg>`}
        ${size === "16" && renderTemplate`<svg width="2" height="9" viewBox="0 0 2 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="1.75" y="5.5" width="1.5" height="5.5" rx="0.75" transform="rotate(-180 1.75 5.5)" fill="var(--color-white, #fff)"></rect>
                    <rect x="2" y="8.5" width="2" height="2" rx="1" transform="rotate(-180 2 8.5)" fill="var(--color-white, #fff)"></rect>
                </svg>`}
        ${size === "24" && renderTemplate`<svg width="2" height="14" viewBox="0 0 2 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 1L1 8" stroke="var(--color-white, #fff)" stroke-width="2" stroke-linecap="round"></path>
                    <path d="M1 12L1 13" stroke="var(--color-white, #fff)" stroke-width="2" stroke-linecap="round"></path>
                </svg>`}
    </span>
</span>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/notification/notificationIcon.astro", void 0);

const $$Astro$8 = createAstro("https://www.Asus.com.tw");
const $$Notice = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$Notice;
  const {
    IDName,
    className,
    style,
    attribute = {},
    text = "\u9078\u64C7\u7BE9\u9078\u689D\u4EF6\u6703\u91CD\u6574\u7D50\u679C\uFF0C\u4E26\u53EF\u80FD\u5F71\u97FF\u5176\u4ED6\u9078\u9805\u7684\u53EF\u7528\u6027\u3002"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "filter-notification"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Icon", $$NotificationIcon, { "size": "16", "style": { "--color": "var(--color-blue-600, #0051A8)" } })}
    <span class="flex-1">${text}</span>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/notice/notice.astro", void 0);

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Checkbox = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Checkbox;
  const {
    id,
    className,
    name,
    required,
    disabled,
    readonly,
    label,
    value,
    checked,
    title,
    rounded,
    validClass,
    validType,
    validLabel,
    customValidText,
    customInvalidText,
    setRequired,
    attribute = {},
    aria = {},
    style,
    indeterminate,
    alignment
  } = Astro2.props;
  const validAttribute = {
    "data-valid-class": validClass,
    "data-valid-type": validType ? `${validType}|checkbox` : void 0,
    "data-valid-label": validLabel,
    "data-custom-valid-text": customValidText,
    "data-custom-invalid-text": customInvalidText
  };
  return renderTemplate`
${maybeRenderHead()}<div${addAttribute(["form-check", { "rounded-check": rounded, "indeterminate-check": indeterminate, "form-check-right": alignment === "right" }, className], "class:list")}${addAttribute(style, "style")}>
    <div class="form-check-input-container">
        
        <input${addAttribute(id, "id")} class="form-check-input" type="checkbox"${addAttribute(value, "value")}${addAttribute(name, "name")}${addAttribute(disabled, "disabled")}${addAttribute(required, "required")}${addAttribute(checked, "checked")} autocomplete="off"${spreadAttributes(readonly ? { onclick: "return false;" } : {})}${addAttribute(setRequired, "data-set-required")}${spreadAttributes(attribute)}${spreadAttributes(aria)}${addAttribute(title, "aria-label")}${spreadAttributes(validAttribute)}>
    </div>
    
    <label class="form-check-label"${addAttribute(id, "for")}>
        ${renderSlot($$result, $$slots["default"], renderTemplate`${label}`)}
    </label>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/checkboxs/checkbox.astro", void 0);

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$Filter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Filter;
  const { IDName, className, style, attribute = {}, title, show, more, data = [] } = Astro2.props;
  const componentId = IDName || `filter-${Math.random().toString(36).substr(2, 9)}`;
  const inputId = `filter-input-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${renderComponent($$result, "Collapse", $$Collapse, { "IDName": componentId, "className": className, "style": style, "attribute": attribute, "title": title, "show": show }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="filter-content">
        ${data?.map((item, index) => renderTemplate`${renderComponent($$result2, "Checkbox", $$Checkbox, { "id": `${inputId}-${index}`, "label": item.label, "name": item.name, "value": item.value, "checked": item.checked, "disabled": item.disabled, "style": {
    ...more && index > 4 ? { display: "none" } : {}
  } })}`)}
        ${more && renderTemplate`<div>
                    ${renderComponent($$result2, "Button", $$Button, { "variant": "blue-outline", "title": "\u66F4\u591A", "size": "sm", "attribute": {
    "data-toggle": "toggle",
    "data-target": "filter-collapse"
  } }, { "default": ($$result3) => renderTemplate`
                        更多
                    ` })}
                </div>`}
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/filter.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Category = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Category;
  const { IDName, className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "category"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Notice", $$Notice, {})}
    <div data-filter>
        ${data?.map((item) => renderTemplate`${renderComponent($$result, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children })}`)}
    </div>
    ${renderComponent($$result, "Button", $$Button, { "variant": "blue", "className": "category-back-button", "size": "lg", "title": "\u8FD4\u56DE\u7BE9\u9078", "block": true, "attribute": { "data-toggle": "back", "data-target": "[data-filter]" }, "style": { visibility: "hidden" } }, { "default": ($$result2) => renderTemplate`
        返回篩選
    ` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/category.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$ArticleOffcanvas = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$ArticleOffcanvas;
  const { IDName = "sectionArticle", className, style, attribute = {}, category } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyOffcanvas", $$Offcanvas, { "IDName": IDName, "postion": "bottom", "hideHeader": true, "className": ["section-article-offcanvas", className], "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<form action="" class="article-offcanvas-form">
        <div class="article-offcanvas-form-header">
            <strong class="article-offcanvas-form-header-title">篩選結果</strong>
            ${renderComponent($$result2, "ALink", $$Link, { "title": "\u6E05\u9664\u5168\u90E8" }, { "default": ($$result3) => renderTemplate`清除全部` })}
        </div>
        <div class="article-offcanvas-form-body scrollbar" data-filter>
            ${category?.map((item, index) => renderTemplate`${renderComponent($$result2, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children, "style": {
    ...index === 0 ? { "--collapse-border-width": "0" } : {}
  } })}`)}
        </div>
        <div class="article-offcanvas-form-footer">
            ${renderComponent($$result2, "Button", $$Button, { "type": "reset", "size": "sm", "variant": "blue-outline", "title": "\u53D6\u6D88", "block": true, "attribute": { "data-bs-dismiss": "offcanvas" } }, { "default": ($$result3) => renderTemplate`取消` })}
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "size": "sm", "variant": "blue", "title": "\u63D0\u4EA4", "block": true }, { "default": ($$result3) => renderTemplate`提交` })}
        </div>
    </form>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articleOffcanvas.astro", void 0);

const $$PaginationArrowDown12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="12" height="6" viewBox="0 0 12 6" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L5.625 4.875L10.5 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-12.astro", void 0);

const $$PaginationArrowDown16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="15" height="7" viewBox="0 0 15 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L7.25 6.25L13.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-16.astro", void 0);

const $$PaginationArrowDown24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="21" height="10" viewBox="0 0 21 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L10.25 9.25L19.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-24.astro", void 0);

const $$PaginationArrowDown40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="32" height="14" viewBox="0 0 32 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L15.75 12.75L30.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-down-40.astro", void 0);

const $$PaginationArrowLeft12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="12" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4.875 10.5L0.75 5.625L4.875 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-12.astro", void 0);

const $$PaginationArrowLeft16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="7" height="15" viewBox="0 0 7 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.25 13.75L0.75 7.25L6.25 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-16.astro", void 0);

const $$PaginationArrowLeft24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="10" height="21" viewBox="0 0 10 21" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M9.25 0.75L0.75 10.25L9.25 19.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-24.astro", void 0);

const $$PaginationArrowLeft40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="14" height="32" viewBox="0 0 14 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12.75 30.75L0.75 15.75L12.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-left-40.astro", void 0);

const $$PaginationArrowRight12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="12" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 10.5L4.875 5.625L0.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-Right-12.astro", void 0);

const $$PaginationArrowRight16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="7" height="15" viewBox="0 0 7 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 13.75L6.25 7.25L0.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-right-16.astro", void 0);

const $$PaginationArrowRight24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="10" height="21" viewBox="0 0 10 21" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 0.75L9.25 10.25L0.749999 19.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-right-24.astro", void 0);

const $$PaginationArrowRight40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="14" height="32" viewBox="0 0 14 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 30.75L12.75 15.75L0.75 0.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-right-40.astro", void 0);

const $$PaginationArrowUp12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="12" height="6" viewBox="0 0 12 6" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.5 4.875L5.625 0.75L0.75 4.875" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-12.astro", void 0);

const $$PaginationArrowUp16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="15" height="7" viewBox="0 0 15 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M13.75 6.25L7.25 0.75L0.75 6.25" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-16.astro", void 0);

const $$PaginationArrowUp24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="21" height="10" viewBox="0 0 21 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.75 9.25L10.25 0.75L19.75 9.25" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-24.astro", void 0);

const $$PaginationArrowUp40 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="32" height="14" viewBox="0 0 32 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M30.75 12.75L15.75 0.75L0.75 12.75" stroke="var(--color-gray-900, #181818)" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/svg-astro/Pagination-Arrow-up-40.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$PaginationArrow = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$PaginationArrow;
  const { size = "12", direction = "down", color, width, className, style, ...rest } = Astro2.props;
  const classes = ["pagination-arrow", `pagination-arrow--${size}`, `pagination-arrow--${direction}`, className].filter(Boolean).join(" ");
  const getSvgComponent = () => {
    const key = `${size}-${direction}`;
    const componentMap = {
      "12-up": $$PaginationArrowUp12,
      "12-down": $$PaginationArrowDown12,
      "12-left": $$PaginationArrowLeft12,
      "12-right": $$PaginationArrowRight12,
      "16-up": $$PaginationArrowUp16,
      "16-down": $$PaginationArrowDown16,
      "16-left": $$PaginationArrowLeft16,
      "16-right": $$PaginationArrowRight16,
      "24-up": $$PaginationArrowUp24,
      "24-down": $$PaginationArrowDown24,
      "24-left": $$PaginationArrowLeft24,
      "24-right": $$PaginationArrowRight24,
      "40-up": $$PaginationArrowUp40,
      "40-down": $$PaginationArrowDown40,
      "40-left": $$PaginationArrowLeft40,
      "40-right": $$PaginationArrowRight40
    };
    return componentMap[key];
  };
  const SvgComponent = getSvgComponent();
  const iconStyle = {
    ...width ? { "--icon-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${maybeRenderHead()}<span${addAttribute(classes, "class")} data-pagination-arrow${addAttribute(size, "data-size")}${addAttribute(direction, "data-direction")}${addAttribute(iconStyle, "style")}${spreadAttributes(rest)}>
    ${renderComponent($$result, "SvgComponent", SvgComponent, {})}
</span>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/paginationArrow.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$ShowMore = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ShowMore;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "show-more"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Show More"${addAttribute(["show-more-button"], "class:list")}>
        Show More
        ${renderComponent($$result, "PaginationArrow", $$PaginationArrow, { "size": "12", "direction": "down", "color": "blue-500" })}
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/showMore.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Loading = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Loading;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "section-loading"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="loader"></div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/loading.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$ArticlesList = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ArticlesList;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "",
    total = 0,
    sortDate = [],
    category = [],
    mode = "gray"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "section-articles-list",
    { "section-articles-dark-list": mode === "gray" },
    { "section-articles-light-list": mode === "white" }
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="section-articles-list-inner">
        ${renderComponent($$result, "Title", $$Title, { "title": title })}
        <div class="article-mobile-category">
            <div class="article-mobile-sort-selector">
                ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": sortDate })}
            </div>
            ${renderComponent($$result, "Button", $$Button, { "variant": "blue", "size": "sm", "title": "\u7BE9\u9078", "attribute": {
    "data-bs-toggle": "offcanvas",
    "data-bs-target": `#${IDName}ArticleOffcanvas`,
    "aria-controls": `${IDName}ArticleOffcanvas`
  } }, { "default": ($$result2) => renderTemplate`
                篩選
            ` })}
        </div>
        <div class="article-list-container">
            ${renderComponent($$result, "Sort", $$Sort, { "total": total, "data": sortDate })}
            <div class="article-list-content">
                ${renderComponent($$result, "Category", $$Category, { "className": "article-category", "data": category })}
                <div class="article-list-grid-container">
                    <div class="article-list-grid">
                        ${renderSlot($$result, $$slots["default"])}
                    </div>
                    ${renderComponent($$result, "ShowMore", $$ShowMore, {})}
                    ${renderComponent($$result, "Loading", $$Loading, {})}
                </div>
            </div>
        </div>
    </div>
</div>
${renderComponent($$result, "ArticleOffcanvas", $$ArticleOffcanvas, { "IDName": `${IDName}Article`, "category": category })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articlesList.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Script = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template([`<script>
/**
 * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
 * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
 */
(function() {
    'use strict';

    // URL \u53C3\u6578\u7BA1\u7406\u5DE5\u5177
    const URLManager = {
        /**
         * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
         */
        getParams() {
            const params = new URLSearchParams(window.location.search);
            const result = {};
            for (const [key, value] of params) {
                // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C
                if (value.includes(',')) {
                    result[key] = value.split(',').map(v => v.trim()).filter(v => v);
                } else {
                    result[key] = value;
                }
            }
            return result;
        },

        /**
         * \u66F4\u65B0 URL \u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string|string[]} value - \u53C3\u6578\u503C
         */
        updateParam(name, value) {
            const url = new URL(window.location);
            
            if (Array.isArray(value) && value.length > 0) {
                // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                url.searchParams.set(name, value.join(','));
            } else if (value) {
                // \u55AE\u500B\u503C
                url.searchParams.set(name, value);
            } else {
                // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                url.searchParams.delete(name);
            }
            
            // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
            window.history.replaceState({}, '', url);
        },

        /**
         * \u6DFB\u52A0 URL \u53C3\u6578\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
         */
        addParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            let values = [];
            
            if (currentParam) {
                values = currentParam.includes(',') 
                    ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                    : [currentParam];
            }
            
            if (!values.includes(value)) {
                values.push(value);
                this.updateParam(name, values);
            }
        },

        /**
         * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
         */
        removeParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            
            if (!currentParam) return;
            
            let values = currentParam.includes(',') 
                ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                : [currentParam];
            
            values = values.filter(v => v !== value);
            
            if (values.length > 0) {
                this.updateParam(name, values);
            } else {
                this.updateParam(name, null);
            }
        }
    };

    // Checkbox \u7BA1\u7406\u5668
    const CheckboxManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const filterContainers = document.querySelectorAll('[data-filter]');
            
            filterContainers.forEach(container => {
                const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');
                
                checkboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', this.handleChange.bind(this));
                });
            });
        },

        /**
         * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const checkbox = event.target;
            const name = checkbox.name;
            const value = checkbox.value;
            
            if (checkbox.checked) {
                // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                URLManager.addParamValue(name, value);
            } else {
                // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                URLManager.removeParamValue(name, value);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                
                values.forEach(value => {
                    const checkbox = document.querySelector(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
                    if (checkbox) {
                        checkbox.checked = true;
                        // \u89F8\u767C change \u4E8B\u4EF6\u4EE5\u78BA\u4FDD\u5176\u4ED6\u76F8\u95DC\u908F\u8F2F\u57F7\u884C
                        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                });
            });
        }
    };

    // Select \u7BA1\u7406\u5668
    const SelectManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const selects = document.querySelectorAll('select[data-sort][name]');
            
            selects.forEach(select => {
                select.addEventListener('change', this.handleChange.bind(this));
            });
        },

        /**
         * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const select = event.target;
            const name = select.name;
            const value = select.value;
            
            if (value) {
                URLManager.updateParam(name, value);
            } else {
                URLManager.updateParam(name, null);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                const selects = document.querySelectorAll(\`select[data-sort][name="\${name}"]\`);
                
                selects.forEach(select => {
                    if (select && value) {
                        // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                        let targetIndex = -1;
                        for (let i = 0; i < select.options.length; i++) {
                            if (select.options[i].value === value) {
                                targetIndex = i;
                                break;
                            }
                        }
                        
                        if (targetIndex !== -1) {
                            // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                            select.selectedIndex = targetIndex;
                            // \u89F8\u767C change \u4E8B\u4EF6
                            select.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    }
                });
            });
        }
    };

    // \u4E3B\u521D\u59CB\u5316\u51FD\u6578
    function initialize() {
        // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
        CheckboxManager.init();
        SelectManager.init();
        
        // \u6062\u5FA9\u9801\u9762\u72C0\u614B
        CheckboxManager.restoreState();
        SelectManager.restoreState();
    }

    // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

    // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
    const observer = new MutationObserver(function(mutations) {
        let shouldReinit = false;
        
        mutations.forEach(function(mutation) {
            mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1) { // Element node
                    const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                    const hasSort = node.querySelector && node.querySelector('[data-sort]');
                    
                    if (hasFilter || hasSort) {
                        shouldReinit = true;
                    }
                }
            });
        });
        
        if (shouldReinit) {
            // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
            setTimeout(() => {
                CheckboxManager.init();
                SelectManager.init();
            }, 100);
        }
    });

    // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
    window.FilterSortManager = {
        URLManager,
        CheckboxManager,
        SelectManager,
        initialize
    };

})();
<\/script>`], [`<script>
/**
 * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
 * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
 */
(function() {
    'use strict';

    // URL \u53C3\u6578\u7BA1\u7406\u5DE5\u5177
    const URLManager = {
        /**
         * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
         */
        getParams() {
            const params = new URLSearchParams(window.location.search);
            const result = {};
            for (const [key, value] of params) {
                // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C
                if (value.includes(',')) {
                    result[key] = value.split(',').map(v => v.trim()).filter(v => v);
                } else {
                    result[key] = value;
                }
            }
            return result;
        },

        /**
         * \u66F4\u65B0 URL \u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string|string[]} value - \u53C3\u6578\u503C
         */
        updateParam(name, value) {
            const url = new URL(window.location);
            
            if (Array.isArray(value) && value.length > 0) {
                // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                url.searchParams.set(name, value.join(','));
            } else if (value) {
                // \u55AE\u500B\u503C
                url.searchParams.set(name, value);
            } else {
                // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                url.searchParams.delete(name);
            }
            
            // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
            window.history.replaceState({}, '', url);
        },

        /**
         * \u6DFB\u52A0 URL \u53C3\u6578\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
         */
        addParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            let values = [];
            
            if (currentParam) {
                values = currentParam.includes(',') 
                    ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                    : [currentParam];
            }
            
            if (!values.includes(value)) {
                values.push(value);
                this.updateParam(name, values);
            }
        },

        /**
         * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
         */
        removeParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            
            if (!currentParam) return;
            
            let values = currentParam.includes(',') 
                ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                : [currentParam];
            
            values = values.filter(v => v !== value);
            
            if (values.length > 0) {
                this.updateParam(name, values);
            } else {
                this.updateParam(name, null);
            }
        }
    };

    // Checkbox \u7BA1\u7406\u5668
    const CheckboxManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const filterContainers = document.querySelectorAll('[data-filter]');
            
            filterContainers.forEach(container => {
                const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');
                
                checkboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', this.handleChange.bind(this));
                });
            });
        },

        /**
         * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const checkbox = event.target;
            const name = checkbox.name;
            const value = checkbox.value;
            
            if (checkbox.checked) {
                // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                URLManager.addParamValue(name, value);
            } else {
                // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                URLManager.removeParamValue(name, value);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                
                values.forEach(value => {
                    const checkbox = document.querySelector(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
                    if (checkbox) {
                        checkbox.checked = true;
                        // \u89F8\u767C change \u4E8B\u4EF6\u4EE5\u78BA\u4FDD\u5176\u4ED6\u76F8\u95DC\u908F\u8F2F\u57F7\u884C
                        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                });
            });
        }
    };

    // Select \u7BA1\u7406\u5668
    const SelectManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const selects = document.querySelectorAll('select[data-sort][name]');
            
            selects.forEach(select => {
                select.addEventListener('change', this.handleChange.bind(this));
            });
        },

        /**
         * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const select = event.target;
            const name = select.name;
            const value = select.value;
            
            if (value) {
                URLManager.updateParam(name, value);
            } else {
                URLManager.updateParam(name, null);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                const selects = document.querySelectorAll(\\\`select[data-sort][name="\\\${name}"]\\\`);
                
                selects.forEach(select => {
                    if (select && value) {
                        // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                        let targetIndex = -1;
                        for (let i = 0; i < select.options.length; i++) {
                            if (select.options[i].value === value) {
                                targetIndex = i;
                                break;
                            }
                        }
                        
                        if (targetIndex !== -1) {
                            // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                            select.selectedIndex = targetIndex;
                            // \u89F8\u767C change \u4E8B\u4EF6
                            select.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    }
                });
            });
        }
    };

    // \u4E3B\u521D\u59CB\u5316\u51FD\u6578
    function initialize() {
        // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
        CheckboxManager.init();
        SelectManager.init();
        
        // \u6062\u5FA9\u9801\u9762\u72C0\u614B
        CheckboxManager.restoreState();
        SelectManager.restoreState();
    }

    // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

    // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
    const observer = new MutationObserver(function(mutations) {
        let shouldReinit = false;
        
        mutations.forEach(function(mutation) {
            mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1) { // Element node
                    const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                    const hasSort = node.querySelector && node.querySelector('[data-sort]');
                    
                    if (hasFilter || hasSort) {
                        shouldReinit = true;
                    }
                }
            });
        });
        
        if (shouldReinit) {
            // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
            setTimeout(() => {
                CheckboxManager.init();
                SelectManager.init();
            }, 100);
        }
    });

    // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
    window.FilterSortManager = {
        URLManager,
        CheckboxManager,
        SelectManager,
        initialize
    };

})();
<\/script>`])));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/script.astro", void 0);

export { $$Script as $, $$ArticlesList as a, $$Follower as b, $$Title as c };
