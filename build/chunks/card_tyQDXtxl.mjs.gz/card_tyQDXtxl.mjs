import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, u as unescapeHTML } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Picture } from './banner_FomqbfBt.mjs';
import { $ as $$A, c as $$Link } from './layouts_Dei3z7tc.mjs';
/* empty css                       */

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Calendar = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Calendar;
  const { IDName, className, style, attribute = {}, Tag = "span", width, color } = Astro2.props;
  const cardStyle = {
    ...width ? { "--icon-size": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "calendar-icon"], "style": cardStyle, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1.5 2.09961H16.5C16.9971 2.09961 17.4004 2.50294 17.4004 3V17C17.4004 17.4971 16.9971 17.9004 16.5 17.9004H1.5C1.00294 17.9004 0.599609 17.4971 0.599609 17V3C0.59961 2.50294 1.00294 2.09961 1.5 2.09961Z" stroke="currentColor" stroke-width="1.2"></path>
        <line y1="6.9" x2="18" y2="6.9" stroke="currentColor" stroke-width="1.2"></line>
        <line x1="5.4" y1="3.9" x2="5.4" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
        <line x1="12.9" y1="3.9" x2="12.9" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/calendar.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Date = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Date;
  const { IDName, className, style, attribute = {}, date, fontSize, width, color, mode = "light" } = Astro2.props;
  const cardStyle = {
    ...width ? { "--icon-size": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...fontSize ? { "--icon-font-size": fontSize } : {},
    ...style
  };
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute(["date-card", { "date-card--dark": mode === "dark" }, className], "class:list")}${addAttribute(cardStyle, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Calendar", $$Calendar, {})}
    <span class="date-card-text">
        ${renderSlot($$result, $$slots["default"], renderTemplate`${date}`)}
    </span>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/date.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Card = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Card;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "\u83EF\u78A9\u5546\u7528\u96FB\u8166\u5E02\u4F54\u958B\u5C40\u596A\u51A0\uFF01\u5168\u65B0\u300CAI\u96D9\u6A5F\u300D\u5F37\u5316\u4F01\u696D\u6578\u4F4D\u6230\u529B",
    label = "\u79D1\u6280\u8207\u88FD\u9020",
    breif = "Welcome to Burger Bliss, where we take your cravings to a whole new!\nWelcome to Burger Bliss.",
    date = "2025/11/07",
    logoImage = "/assets/logos/Business-Vertical-Light",
    img = "/assets/images/pages/Article-card-image",
    link = "",
    width = "100%",
    showDate = true,
    showLabel = true,
    showBreif = true,
    showLogo = true,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/Article-card-image",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/Article-card-image",
          // 標準解析度
          "1.5x": "/assets/images/pages/Article-card-image",
          // 1.5倍解析度
          "2x": "/assets/images/pages/Article-card-image"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/Article-card-image",
        densities: {
          "1x": "/assets/images/pages/Article-card-image",
          "1.5x": "/assets/images/pages/Article-card-image",
          "2x": "/assets/images/pages/Article-card-image"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/Article-card-image",
        densities: {
          "1x": "/assets/images/pages/Article-card-image",
          "1.5x": "/assets/images/pages/Article-card-image",
          "2x": "/assets/images/pages/Article-card-image"
        }
      }
    ]
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "A", $$A, { "IDName": IDName, "link": link, "className": [
    className,
    "news-card group"
  ], "style": cardStyle, "attribute": attribute, "title": title }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="news-card-image-container">
        ${renderComponent($$result2, "Picture", $$Picture, { "className": "news-card-image", "img": img, "alt": title, "loading": "lazy", "decoding": "async", "breakpoints": imgBreakpoints, "noWebp": true })}
    </div>
    <div class="news-card-content">
        ${showDate && renderTemplate`${renderComponent($$result2, "Date", $$Date, { "className": "news-card-date" }, { "default": ($$result3) => renderTemplate`${date}` })}`}
        <div class="news-card-head">
            ${title && renderTemplate`<strong class="news-card-title">
                        ${title}
                    </strong>`}
            ${Boolean(showLabel && label) && renderTemplate`<span class="news-card-label">${unescapeHTML(label)}</span>`}
            ${Boolean(showBreif && breif) && renderTemplate`<span class="news-card-breif">${unescapeHTML(breif)}</span>`}
        </div>
        <div class="news-card-footer">
            ${showLogo && renderTemplate`<div class="news-card-logo">
                        ${renderComponent($$result2, "Picture", $$Picture, { "img": logoImage, "alt": title, "type": "svg", "loading": "lazy", "decoding": "async", "noWebp": true })}
                    </div>`}
            ${renderComponent($$result2, "ALink", $$Link, { "link": link, "className": "news-card-link", "title": "\u4E86\u89E3\u66F4\u591A", "size": "16", "showArrow": true, "Tag": "span" })}
        </div>
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/card.astro", void 0);

export { $$Card as $, $$Date as a };
