import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Picture } from './picture_GYxijd3h.mjs';
import { $ as $$CustomSelect } from './customSelect_5p5dc1ur.mjs';
import { d as $$A, c as $$Link } from './layouts_72KHugm1.mjs';
/* empty css                           */

const data = [
  {
    id: "1",
    title: "採購叫貨系統 / 基礎版",
    label: "欣創數位科技有限公司",
    brief: "一站式開店平台，全面強化您的商業運營，增加企業營收，讓企業變得更好，仿造IG的限時動態風格。",
    amount: 1,
    img: "/assets/images/pages/Product-Image"
  },
  {
    id: "2",
    title: "採購叫貨系統 / 高級版",
    label: "欣創數位科技有限公司",
    brief: "一站式開店平台，全面強化您的商業運營，增加企業營收，讓企業變得更好，仿造IG的限時動態風格。",
    amount: 1,
    img: "/assets/images/pages/Product-Image"
  },
  {
    id: "3",
    title: "採購叫貨系統 / 豪華版",
    label: "欣創數位科技有限公司",
    brief: "一站式開店平台，全面強化您的商業運營，增加企業營收，讓企業變得更好，仿造IG的限時動態風格。",
    amount: 1,
    img: "/assets/images/pages/Product-Image"
  }
];

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Card = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Card;
  const { id, className, style, attribute = {}, title, label, brief, amount = 1, img, readonly = false } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(id, "id")}${addAttribute([className, "inquery-card", { "readonly": readonly }], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${!readonly && renderTemplate`${renderComponent($$result, "Picture", $$Picture, { "img": img, "className": "inquery-card-img", "width": 232, "height": 131, "alt": title, "noWebp": true })}`}
    <div class="inquery-card-body">
        <div class="inquery-card-content">
            ${renderComponent($$result, "A", $$A, { "link": `/solution/${id}`, "className": "inquery-card-link", "title": title }, { "default": ($$result2) => renderTemplate`
                <strong class="inquery-card-title">
                    ${title}
                </strong>
            ` })}
            <span class="inquery-card-label">${label}</span>
            <span class="inquery-card-brief">${brief}</span>
        </div>
        ${!readonly && renderTemplate`<div class="inquery-card-controller">
                    ${renderComponent($$result, "Select", $$CustomSelect, { "id": `inquery-amount-${id}`, "className": "inquery-card-select", "value": amount, "data": Array.from({ length: 100 }, (_, i) => ({ value: i + 1, text: i + 1 })), "placeholder": "\u8ACB\u9078\u64C7", "title": `\u6578\u91CF ${amount}`, "attribute": { "data-id": id } })}
                    ${renderComponent($$result, "ALink", $$Link, { "title": "\u79FB\u9664", "className": "inquery-card-remove", "attribute": { "data-id": id } }, { "default": ($$result2) => renderTemplate`
                        移除
                    ` })}
                </div>`}
        ${readonly && renderTemplate`<div class="inquery-card-quantity">x${amount}</div>`}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/inquery/card.astro", void 0);

export { $$Card as $, data as d };
