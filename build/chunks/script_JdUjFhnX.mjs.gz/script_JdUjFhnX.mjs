import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate, r as renderComponent, F as Fragment, e as renderSlot } from './astro/server_Bjgbv9en.mjs';
/* empty css                         */
import { $ as $$Title } from './title_oZPX-wc9.mjs';
import { $ as $$Select } from './select_rR_HL6HG.mjs';
import { $ as $$NotificationIcon } from './notificationIcon_D2ltQgOL.mjs';
import { e as $$Collapse, $ as $$Button, g as $$Offcanvas, c as $$Link } from './layouts_CuL6zXvl.mjs';
import { $ as $$Checkbox } from './checkbox_DKEcsoug.mjs';
import { $ as $$PaginationArrow } from './paginationArrow_CMgZrmJw.mjs';

const $$Astro$a = createAstro("https://www.Asus.com.tw");
const $$Follower = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$Follower;
  const { IDName = "Follower", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "follower"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Go Top" class="follower-button">
        <svg width="25" height="15" viewBox="0 0 25 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.0879 12.4816L12.4813 1.875L1.87469 12.4816" stroke="white" stroke-width="3.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
        <svg width="19" height="11" viewBox="0 0 19 11" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.9316 9.15317L9.15347 1.375L1.37529 9.15317" stroke="white" stroke-width="2.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/follower/follower.astro", void 0);

const $$Astro$9 = createAstro("https://www.Asus.com.tw");
const $$CustomSelect = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$CustomSelect;
  const {
    id,
    data = [],
    className,
    selectClassName,
    required,
    disabled,
    name,
    value,
    placeholder = "\u8ACB\u9078\u64C7",
    title,
    size = "md",
    status,
    validClass,
    validType,
    validLabel,
    customValidText,
    customInvalidText,
    onchange,
    attribute = {},
    selectAttribute = {},
    style = {},
    selectStyle = {},
    custom = true,
    prebuiltStructure = false
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute([{ "custom-select": custom }, className], "class:list")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>
    ${renderComponent($$result, "Select", $$Select, { "id": id, "data": data, "className": [{ "custom-origin-select": custom }, selectClassName], "required": required, "disabled": disabled, "name": name, "value": value, "title": title, "size": size, "status": status, "placeholder": placeholder, "validClass": validClass, "validType": validType, "validLabel": validLabel, "customValidText": customValidText, "customInvalidText": customInvalidText, "onchange": onchange, "attribute": selectAttribute, "style": selectStyle })}
    ${prebuiltStructure && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <div class="select-selected select-selected-placeholder"></div>
            <div class="select-items select-hide"></div>
        ` })}`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/select/customSelect.astro", void 0);

const $$Astro$8 = createAstro("https://www.Asus.com.tw");
const $$SortSelector = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$SortSelector;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  const componentId = IDName || `sort-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "sort-selector"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <label class="sort-selector-label"${addAttribute(componentId, "for")}>排序：</label>
    ${renderComponent($$result, "Select", $$CustomSelect, { "id": componentId, "status": "sort", "className": "sort-selector-select", "size": "sm", "name": "sort", "data": data, "selectAttribute": { "data-sort": "" }, "style": { minWidth: "9.5rem" } })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sortSelector.astro", void 0);

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Sort = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Sort;
  const { IDName, className, style, attribute = {}, total, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "sort"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <span class="sort-result">篩選結果: ${total} 結果</span>
    <div class="sort-selector-container">
        ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": data })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sort.astro", void 0);

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$Notice = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Notice;
  const {
    IDName,
    className,
    style,
    attribute = {},
    text = "\u9078\u64C7\u7BE9\u9078\u689D\u4EF6\u6703\u91CD\u6574\u7D50\u679C\uFF0C\u4E26\u53EF\u80FD\u5F71\u97FF\u5176\u4ED6\u9078\u9805\u7684\u53EF\u7528\u6027\u3002"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "filter-notification"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Icon", $$NotificationIcon, { "size": "16", "style": { "--color": "var(--color-blue-600, #0051A8)" } })}
    <span class="flex-1">${text}</span>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/notice/notice.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Filter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Filter;
  const { IDName, className, style, attribute = {}, title, show, more, data = [] } = Astro2.props;
  const componentId = IDName || `filter-${Math.random().toString(36).substr(2, 9)}`;
  const inputId = `filter-input-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${renderComponent($$result, "Collapse", $$Collapse, { "IDName": componentId, "className": className, "style": style, "attribute": attribute, "title": title, "show": show }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="filter-content">
        ${data?.map((item, index) => renderTemplate`${renderComponent($$result2, "Checkbox", $$Checkbox, { "id": `${inputId}-${index}`, "label": item.label, "name": item.name, "value": item.value, "checked": item.checked, "disabled": item.disabled, "style": {
    ...more && index > 4 ? { display: "none" } : {}
  } })}`)}
        ${more && renderTemplate`<div>
                    ${renderComponent($$result2, "Button", $$Button, { "variant": "blue-outline", "title": "\u66F4\u591A", "size": "sm", "attribute": {
    "data-toggle": "toggle",
    "data-target": "filter-collapse"
  } }, { "default": ($$result3) => renderTemplate`
                        更多
                    ` })}
                </div>`}
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/filter.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Category = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Category;
  const { IDName, className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "category"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Notice", $$Notice, {})}
    <div data-filter>
        ${data?.map((item) => renderTemplate`${renderComponent($$result, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children })}`)}
    </div>
    ${renderComponent($$result, "Button", $$Button, { "variant": "blue", "className": "category-back-button", "size": "lg", "title": "\u8FD4\u56DE\u7BE9\u9078", "block": true, "attribute": { "data-toggle": "back", "data-target": "[data-filter]" }, "style": { visibility: "hidden" } }, { "default": ($$result2) => renderTemplate`
        返回篩選
    ` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/category.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$ArticleOffcanvas = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$ArticleOffcanvas;
  const { IDName = "sectionArticle", className, style, attribute = {}, category } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyOffcanvas", $$Offcanvas, { "IDName": IDName, "postion": "bottom", "hideHeader": true, "className": ["section-article-offcanvas", className], "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<form action="" class="article-offcanvas-form">
        <div class="article-offcanvas-form-header">
            <strong class="article-offcanvas-form-header-title">篩選結果</strong>
            ${renderComponent($$result2, "ALink", $$Link, { "title": "\u6E05\u9664\u5168\u90E8" }, { "default": ($$result3) => renderTemplate`清除全部` })}
        </div>
        <div class="article-offcanvas-form-body scrollbar" data-filter>
            ${category?.map((item, index) => renderTemplate`${renderComponent($$result2, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children, "style": {
    ...index === 0 ? { "--collapse-border-width": "0" } : {}
  } })}`)}
        </div>
        <div class="article-offcanvas-form-footer">
            ${renderComponent($$result2, "Button", $$Button, { "type": "reset", "size": "sm", "variant": "blue-outline", "title": "\u53D6\u6D88", "block": true, "attribute": { "data-bs-dismiss": "offcanvas" } }, { "default": ($$result3) => renderTemplate`取消` })}
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "size": "sm", "variant": "blue", "title": "\u63D0\u4EA4", "block": true }, { "default": ($$result3) => renderTemplate`提交` })}
        </div>
    </form>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articleOffcanvas.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$ShowMore = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ShowMore;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "show-more"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Show More"${addAttribute(["show-more-button"], "class:list")}>
        Show More
        ${renderComponent($$result, "PaginationArrow", $$PaginationArrow, { "size": "12", "direction": "down", "color": "blue-500" })}
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/showMore.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Loading = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Loading;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "section-loading"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="loader"></div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/loading.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$ArticlesList = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ArticlesList;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "",
    total = 0,
    sortDate = [],
    category = [],
    mode = "gray"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "section-articles-list",
    { "section-articles-dark-list": mode === "gray" },
    { "section-articles-light-list": mode === "white" }
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="section-articles-list-inner">
        ${renderComponent($$result, "Title", $$Title, { "title": title })}
        <div class="article-mobile-category">
            <div class="article-mobile-sort-selector">
                ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": sortDate })}
            </div>
            ${renderComponent($$result, "Button", $$Button, { "variant": "blue", "size": "sm", "title": "\u7BE9\u9078", "attribute": {
    "data-bs-toggle": "offcanvas",
    "data-bs-target": `#${IDName}ArticleOffcanvas`,
    "aria-controls": `${IDName}ArticleOffcanvas`
  } }, { "default": ($$result2) => renderTemplate`
                篩選
            ` })}
        </div>
        <div class="article-list-container">
            ${renderComponent($$result, "Sort", $$Sort, { "total": total, "data": sortDate })}
            <div class="article-list-content">
                ${renderComponent($$result, "Category", $$Category, { "className": "article-category", "data": category })}
                <div class="article-list-grid-container">
                    <div class="article-list-grid">
                        ${renderSlot($$result, $$slots["default"])}
                    </div>
                    ${renderComponent($$result, "ShowMore", $$ShowMore, {})}
                    ${renderComponent($$result, "Loading", $$Loading, {})}
                </div>
            </div>
        </div>
    </div>
</div>
${renderComponent($$result, "ArticleOffcanvas", $$ArticleOffcanvas, { "IDName": `${IDName}Article`, "category": category })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articlesList.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Script = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template([`<script>
/**
 * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
 * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
 */
(function() {
    'use strict';

    // URL \u53C3\u6578\u7BA1\u7406\u5DE5\u5177
    const URLManager = {
        /**
         * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
         */
        getParams() {
            const params = new URLSearchParams(window.location.search);
            const result = {};
            for (const [key, value] of params) {
                // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C
                if (value.includes(',')) {
                    result[key] = value.split(',').map(v => v.trim()).filter(v => v);
                } else {
                    result[key] = value;
                }
            }
            return result;
        },

        /**
         * \u66F4\u65B0 URL \u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string|string[]} value - \u53C3\u6578\u503C
         */
        updateParam(name, value) {
            const url = new URL(window.location);
            
            if (Array.isArray(value) && value.length > 0) {
                // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                url.searchParams.set(name, value.join(','));
            } else if (value) {
                // \u55AE\u500B\u503C
                url.searchParams.set(name, value);
            } else {
                // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                url.searchParams.delete(name);
            }
            
            // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
            window.history.replaceState({}, '', url);
        },

        /**
         * \u6DFB\u52A0 URL \u53C3\u6578\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
         */
        addParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            let values = [];
            
            if (currentParam) {
                values = currentParam.includes(',') 
                    ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                    : [currentParam];
            }
            
            if (!values.includes(value)) {
                values.push(value);
                this.updateParam(name, values);
            }
        },

        /**
         * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
         */
        removeParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            
            if (!currentParam) return;
            
            let values = currentParam.includes(',') 
                ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                : [currentParam];
            
            values = values.filter(v => v !== value);
            
            if (values.length > 0) {
                this.updateParam(name, values);
            } else {
                this.updateParam(name, null);
            }
        }
    };

    // Checkbox \u7BA1\u7406\u5668
    const CheckboxManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const filterContainers = document.querySelectorAll('[data-filter]');
            
            filterContainers.forEach(container => {
                const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');
                
                checkboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', this.handleChange.bind(this));
                });
            });
        },

        /**
         * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const checkbox = event.target;
            const name = checkbox.name;
            const value = checkbox.value;
            
            if (checkbox.checked) {
                // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                URLManager.addParamValue(name, value);
            } else {
                // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                URLManager.removeParamValue(name, value);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                
                values.forEach(value => {
                    const checkbox = document.querySelector(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
                    if (checkbox) {
                        checkbox.checked = true;
                        // \u89F8\u767C change \u4E8B\u4EF6\u4EE5\u78BA\u4FDD\u5176\u4ED6\u76F8\u95DC\u908F\u8F2F\u57F7\u884C
                        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                });
            });
        }
    };

    // Select \u7BA1\u7406\u5668
    const SelectManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const selects = document.querySelectorAll('select[data-sort][name]');
            
            selects.forEach(select => {
                select.addEventListener('change', this.handleChange.bind(this));
            });
        },

        /**
         * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const select = event.target;
            const name = select.name;
            const value = select.value;
            
            if (value) {
                URLManager.updateParam(name, value);
            } else {
                URLManager.updateParam(name, null);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                const selects = document.querySelectorAll(\`select[data-sort][name="\${name}"]\`);
                
                selects.forEach(select => {
                    if (select && value) {
                        // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                        let targetIndex = -1;
                        for (let i = 0; i < select.options.length; i++) {
                            if (select.options[i].value === value) {
                                targetIndex = i;
                                break;
                            }
                        }
                        
                        if (targetIndex !== -1) {
                            // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                            select.selectedIndex = targetIndex;
                            // \u89F8\u767C change \u4E8B\u4EF6
                            select.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    }
                });
            });
        }
    };

    // \u4E3B\u521D\u59CB\u5316\u51FD\u6578
    function initialize() {
        // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
        CheckboxManager.init();
        SelectManager.init();
        
        // \u6062\u5FA9\u9801\u9762\u72C0\u614B
        CheckboxManager.restoreState();
        SelectManager.restoreState();
    }

    // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

    // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
    const observer = new MutationObserver(function(mutations) {
        let shouldReinit = false;
        
        mutations.forEach(function(mutation) {
            mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1) { // Element node
                    const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                    const hasSort = node.querySelector && node.querySelector('[data-sort]');
                    
                    if (hasFilter || hasSort) {
                        shouldReinit = true;
                    }
                }
            });
        });
        
        if (shouldReinit) {
            // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
            setTimeout(() => {
                CheckboxManager.init();
                SelectManager.init();
            }, 100);
        }
    });

    // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
    window.FilterSortManager = {
        URLManager,
        CheckboxManager,
        SelectManager,
        initialize
    };

})();
<\/script>`], [`<script>
/**
 * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
 * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
 */
(function() {
    'use strict';

    // URL \u53C3\u6578\u7BA1\u7406\u5DE5\u5177
    const URLManager = {
        /**
         * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
         */
        getParams() {
            const params = new URLSearchParams(window.location.search);
            const result = {};
            for (const [key, value] of params) {
                // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C
                if (value.includes(',')) {
                    result[key] = value.split(',').map(v => v.trim()).filter(v => v);
                } else {
                    result[key] = value;
                }
            }
            return result;
        },

        /**
         * \u66F4\u65B0 URL \u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string|string[]} value - \u53C3\u6578\u503C
         */
        updateParam(name, value) {
            const url = new URL(window.location);
            
            if (Array.isArray(value) && value.length > 0) {
                // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                url.searchParams.set(name, value.join(','));
            } else if (value) {
                // \u55AE\u500B\u503C
                url.searchParams.set(name, value);
            } else {
                // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                url.searchParams.delete(name);
            }
            
            // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
            window.history.replaceState({}, '', url);
        },

        /**
         * \u6DFB\u52A0 URL \u53C3\u6578\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
         */
        addParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            let values = [];
            
            if (currentParam) {
                values = currentParam.includes(',') 
                    ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                    : [currentParam];
            }
            
            if (!values.includes(value)) {
                values.push(value);
                this.updateParam(name, values);
            }
        },

        /**
         * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
         */
        removeParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            
            if (!currentParam) return;
            
            let values = currentParam.includes(',') 
                ? currentParam.split(',').map(v => v.trim()).filter(v => v)
                : [currentParam];
            
            values = values.filter(v => v !== value);
            
            if (values.length > 0) {
                this.updateParam(name, values);
            } else {
                this.updateParam(name, null);
            }
        }
    };

    // Checkbox \u7BA1\u7406\u5668
    const CheckboxManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const filterContainers = document.querySelectorAll('[data-filter]');
            
            filterContainers.forEach(container => {
                const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');
                
                checkboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', this.handleChange.bind(this));
                });
            });
        },

        /**
         * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const checkbox = event.target;
            const name = checkbox.name;
            const value = checkbox.value;
            
            if (checkbox.checked) {
                // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                URLManager.addParamValue(name, value);
            } else {
                // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                URLManager.removeParamValue(name, value);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                
                values.forEach(value => {
                    const checkbox = document.querySelector(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
                    if (checkbox) {
                        checkbox.checked = true;
                        // \u89F8\u767C change \u4E8B\u4EF6\u4EE5\u78BA\u4FDD\u5176\u4ED6\u76F8\u95DC\u908F\u8F2F\u57F7\u884C
                        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                });
            });
        }
    };

    // Select \u7BA1\u7406\u5668
    const SelectManager = {
        /**
         * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const selects = document.querySelectorAll('select[data-sort][name]');
            
            selects.forEach(select => {
                select.addEventListener('change', this.handleChange.bind(this));
            });
        },

        /**
         * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange(event) {
            const select = event.target;
            const name = select.name;
            const value = select.value;
            
            if (value) {
                URLManager.updateParam(name, value);
            } else {
                URLManager.updateParam(name, null);
            }
        },

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
         */
        restoreState() {
            const params = URLManager.getParams();
            
            Object.keys(params).forEach(name => {
                const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                const selects = document.querySelectorAll(\\\`select[data-sort][name="\\\${name}"]\\\`);
                
                selects.forEach(select => {
                    if (select && value) {
                        // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                        let targetIndex = -1;
                        for (let i = 0; i < select.options.length; i++) {
                            if (select.options[i].value === value) {
                                targetIndex = i;
                                break;
                            }
                        }
                        
                        if (targetIndex !== -1) {
                            // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                            select.selectedIndex = targetIndex;
                            // \u89F8\u767C change \u4E8B\u4EF6
                            select.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    }
                });
            });
        }
    };

    // \u4E3B\u521D\u59CB\u5316\u51FD\u6578
    function initialize() {
        // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
        CheckboxManager.init();
        SelectManager.init();
        
        // \u6062\u5FA9\u9801\u9762\u72C0\u614B
        CheckboxManager.restoreState();
        SelectManager.restoreState();
    }

    // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

    // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
    const observer = new MutationObserver(function(mutations) {
        let shouldReinit = false;
        
        mutations.forEach(function(mutation) {
            mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1) { // Element node
                    const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                    const hasSort = node.querySelector && node.querySelector('[data-sort]');
                    
                    if (hasFilter || hasSort) {
                        shouldReinit = true;
                    }
                }
            });
        });
        
        if (shouldReinit) {
            // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
            setTimeout(() => {
                CheckboxManager.init();
                SelectManager.init();
            }, 100);
        }
    });

    // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
    window.FilterSortManager = {
        URLManager,
        CheckboxManager,
        SelectManager,
        initialize
    };

})();
<\/script>`])));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/script.astro", void 0);

export { $$Script as $, $$ArticlesList as a, $$Follower as b };
