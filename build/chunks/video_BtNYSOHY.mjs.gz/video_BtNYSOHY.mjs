import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from './astro/server_Bjgbv9en.mjs';
import { e as $$Modal } from './layouts_PrzpUuZP.mjs';
/* empty css                        */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Video = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Video;
  const { IDName = "Video", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Modal", $$Modal, { "id": IDName, "sizes": "xl", "Modalclass": className, "center": true, "hideFooter": true, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<iframe id="youtube-player" width="560" height="315" src="https://www.youtube.com/embed/3vDjjvBYOLM?si=zo0wzAeuYuy8O7BT&enablejsapi=1" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/modal/video.astro", void 0);

export { $$Video as $ };
