import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate, e as renderSlot } from './astro/server_Bjgbv9en.mjs';
import { f as $$CollapseArrow, g as ext, h as $$Offcanvas, c as $$Link } from './layouts_DpjfgSHX.mjs';
/* empty css                                      */
import { $ as $$Pagination } from './pagination_Bywu0OMJ.mjs';
import { $ as $$CustomSelect } from './customSelect_Cf6hwWwv.mjs';

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Banner = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Banner;
  const { IDName, className, style, attribute = {}, name = "Jon Snow" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<button${addAttribute(IDName, "id")}${addAttribute([
    "acct-mobile-menu",
    className
  ], "class:list")}${addAttribute(style, "style")} data-bs-toggle="offcanvas" data-bs-target="#memberNavOffcanvas" aria-controls="memberNavOffcanvas"${spreadAttributes(attribute)}>
    <div class="acct-mobile-menu-container">
        <div class="acct-mobile-menu-head" slot="title">
            <span class="acct-mobile-menu-body-item">會員</span>
            <span class="acct-mobile-menu-bar"></span>
            <span class="acct-mobile-menu-heading-item">歡迎, ${name}!</span>
        </div>
        ${renderComponent($$result, "CollapseArrow", $$CollapseArrow, { "className": "acct-mobile-menu-arrow" })}
    </div>
</button>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/banner.astro", void 0);

const memberNavItems = [
  {
    id: "overview",
    label: "會員中心",
    icon: "overview",
    href: "/member",
    hasSubmenu: false,
    isExpandable: false
  },
  {
    id: "message-center",
    label: "訊息中心",
    icon: "message",
    href: "/member/message-center",
    hasSubmenu: false,
    isExpandable: false
  },
  {
    id: "account-settings",
    label: "帳戶設定",
    icon: "setting",
    href: "",
    hasSubmenu: true,
    isExpandable: true,
    children: [
      {
        id: "basic-info",
        label: "基本資料",
        href: "/member/basic-info"
      },
      {
        id: "account-management",
        label: "帳號管理",
        href: "/member/account-management"
      },
      {
        id: "update-password",
        label: "變更密碼",
        href: "/member/update-password"
      }
    ]
  },
  {
    id: "my-order-aocc",
    label: "我的諮詢夾",
    icon: "order-aocc",
    href: "/member/order-aocc",
    hasSubmenu: false,
    isExpandable: false
  },
  {
    id: "my-wishlist",
    label: "我的收藏清單",
    icon: "wishlist",
    href: "/member/my-wishlist",
    hasSubmenu: false,
    isExpandable: false
  }
];

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$AcctSideNavTab = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$AcctSideNavTab;
  const iconMap2 = {
    "affiliate-programs": (await import('./affiliateprograms_BBdKNL5P.mjs')).default,
    "bookmark": (await import('./bookmark_BEFMv2va.mjs')).default,
    "company-profile": (await import('./companyprofile_CMuF9Qyl.mjs')).default,
    "contact": (await import('./contact_D3Ifw4zT.mjs')).default,
    "e-receipt": (await import('./ereceipt_CGReG6v-.mjs')).default,
    "events": (await import('./events_CzYMGNpz.mjs')).default,
    "faq": (await import('./faq_B9dbrqXU.mjs')).default,
    "invoice": (await import('./invoice_6IrZTl1E.mjs')).default,
    "message": (await import('./message_HBqHZZto.mjs')).default,
    "my-product": (await import('./myproduct_CUcCewRo.mjs')).default,
    "my-support": (await import('./mysupport_6mjykD9F.mjs')).default,
    "order-aocc": (await import('./order aocc_CTsrjX8w.mjs')).default,
    "overview": (await import('./overview_DgOERLPm.mjs')).default,
    "referral": (await import('./referral_Ep63epZ-.mjs')).default,
    "register": (await import('./register_DX0BsFTC.mjs')).default,
    "setting": (await import('./setting_CC6VsiVC.mjs')).default,
    "store-credit": (await import('./store credit_qYGpK56A.mjs')).default,
    "tax-cert": (await import('./tax cert_xlxZ6uWR.mjs')).default,
    "techinbox": (await import('./techinbox_kE03VJt4.mjs')).default,
    "wishlist": (await import('./wishlist_CmNuXJiA.mjs')).default
  };
  const iconHoverMap = {
    "affiliate-programs-hover": (await import('./affiliateprograms_C0FxPDgQ.mjs')).default,
    "bookmark-hover": (await import('./bookmark_DGIFVvi1.mjs')).default,
    "company-profile-hover": (await import('./company profile_DHMxudg3.mjs')).default,
    "contact-hover": (await import('./contact_jLAlOEtr.mjs')).default,
    "e-receipt-hover": (await import('./ereceipt_BwlmM4_X.mjs')).default,
    "events-hover": (await import('./events_DorYDHX7.mjs')).default,
    "faq-hover": (await import('./faq_ChbnEGBQ.mjs')).default,
    "invoice-hover": (await import('./invoice_BkNqePmp.mjs')).default,
    "message-hover": (await import('./message_CsL8uqTy.mjs')).default,
    "my-product-hover": (await import('./myproduct_gVAGSyrt.mjs')).default,
    "my-support-hover": (await import('./mysupport_BWNTVgy7.mjs')).default,
    "order-aocc-hover": (await import('./order aocc_DAkF7goT.mjs')).default,
    "overview-hover": (await import('./overview_Dhj08Ic3.mjs')).default,
    "referral-hover": (await import('./referral_VNrRb0hT.mjs')).default,
    "register-hover": (await import('./register_lSoU1x1U.mjs')).default,
    "setting-hover": (await import('./setting_CZ5p6-52.mjs')).default,
    "store-credit-hover": (await import('./store credit_Ds7lFba4.mjs')).default,
    "tax-cert-hover": (await import('./tax cert_C5CeipMX.mjs')).default,
    "techinbox-hover": (await import('./techinbox_god_GQ-5.mjs')).default,
    "wishlist-hover": (await import('./wishlist_DM-F8oSW.mjs')).default
  };
  const iconFocusMap = {
    "affiliate-programs-focus": (await import('./affiliateprograms_BcE1KRtb.mjs')).default,
    "bookmark-focus": (await import('./bookmark_CiwyGEeY.mjs')).default,
    "company-profile-focus": (await import('./companyprofile_gWJykGW7.mjs')).default,
    "contact-focus": (await import('./contact_CSClFOIS.mjs')).default,
    "e-receipt-focus": (await import('./ereceipt_Xi--fd5C.mjs')).default,
    "events-focus": (await import('./events_B3-UUSUM.mjs')).default,
    "faq-focus": (await import('./faq_CO0Klomb.mjs')).default,
    "invoice-focus": (await import('./invoice_B-8MK6OD.mjs')).default,
    "message-focus": (await import('./message_-C0Ve9vw.mjs')).default,
    "my-product-focus": (await import('./myproduct_s_tt1nMZ.mjs')).default,
    "my-support-focus": (await import('./mysupport_CsgyUETx.mjs')).default,
    "order-aocc-focus": (await import('./order aocc_DY5zn6fJ.mjs')).default,
    "overview-focus": (await import('./overview_DDE19iR_.mjs')).default,
    "referral-focus": (await import('./referral_TEs7jtFi.mjs')).default,
    "register-focus": (await import('./register_B_7c5nH9.mjs')).default,
    "setting-focus": (await import('./setting_CSg0Pq4Q.mjs')).default,
    "store-credit-focus": (await import('./store credit_De_TDgVg.mjs')).default,
    "tax-cert-focus": (await import('./tax cert_C0ffszsi.mjs')).default,
    "techinbox-focus": (await import('./techinbox_DUYT2GAm.mjs')).default,
    "wishlist-focus": (await import('./wishlist_B2UB56Ix.mjs')).default
  };
  const { IDName, className, style, attribute = {}, Tag = "div", text, icon = "overview", type = "stroke", hasSub, extend } = Astro2.props;
  const IconComponent = iconMap2[icon];
  const IconHoverComponent = iconHoverMap[`${icon}-hover`];
  const IconFocusComponent = iconFocusMap[`${icon}-focus`];
  const link = attribute.href;
  const href = link ? link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#" : void 0;
  const Attr = link ? { ...attribute, href } : attribute;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [
    className,
    "acct-side-nav-tab"
  ], "style": style, ...Attr }, { "default": async ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="acct-side-nav-tab__content">
        <span class="acct-side-nav-tab__icon">
            ${renderComponent($$result2, "IconComponent", IconComponent, { "type": type })}
            ${type === "fill" ? renderTemplate`${renderComponent($$result2, "IconHoverComponent", IconHoverComponent, { "type": type })}` : IconFocusComponent ? renderTemplate`${renderComponent($$result2, "IconFocusComponent", IconFocusComponent, { "type": type })}` : null}
        </span>
        ${renderSlot($$result2, $$slots["default"], renderTemplate`${text}`)}
    </div>
    ${hasSub && renderTemplate`${renderComponent($$result2, "CollapseArrow", $$CollapseArrow, {})}`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/acctSideNavTab.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$AcctSideSubNavTab = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$AcctSideSubNavTab;
  const { IDName, className, style, attribute = {}, Tag = "div", text, extend } = Astro2.props;
  const link = attribute.href;
  const href = link ? link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#" : void 0;
  const Attr = link ? { ...attribute, href } : attribute;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "acct-side-sub-nav-tab"], "style": style, ...Attr }, { "default": ($$result2) => renderTemplate`
    ${renderSlot($$result2, $$slots["default"], renderTemplate`${text}`)}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/acctSideSubNavTab.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$AcctSideNav = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$AcctSideNav;
  const { IDName, className, style, attribute = {}, active = "\u6703\u54E1\u4E2D\u5FC3", type = "side", padding = "width", activeCollapse } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<nav${addAttribute(IDName, "id")}${addAttribute(["acct-side-nav", className], "class:list")}${addAttribute(style, "style")}${addAttribute(type === "indented" ? "true" : void 0, "data-indented")}${addAttribute(type === "side" ? "true" : void 0, "data-side")}${addAttribute(padding === "width" ? "true" : void 0, "data-width")}${spreadAttributes(attribute)}>
    <ul class="acct-side-nav-ul">
        ${memberNavItems.map((item) => renderTemplate`<li>
                    ${renderComponent($$result, "AcctSideNavTab", $$AcctSideNavTab, { "icon": item.icon, "type": "stroke", "Tag": item.children && item.children.length > 0 ? "button" : "a", "hasSub": item.children && item.children.length > 0, "attribute": {
    title: item.label,
    type: item.children && item.children.length > 0 ? "button" : null,
    "data-bs-toggle": item.children && item.children.length > 0 ? "collapse" : null,
    "data-bs-target": item.children && item.children.length > 0 ? `#nav-${item.id}` : null,
    "aria-expanded": item.children && item.children.length > 0 ? item.label === activeCollapse ? "true" : "false" : null,
    "aria-controls": item.children && item.children.length > 0 ? `nav-${item.id}` : null,
    ...item.href ? { href: item.href } : {}
  }, "className": { active: item.label === active } }, { "default": ($$result2) => renderTemplate`${item.label}` })}
                    ${item.children && item.children.length > 0 && renderTemplate`<div${addAttribute(`nav-${item.id}`, "id")}${addAttribute(["collapse", item.label === activeCollapse ? "show" : ""], "class:list")}>
                            ${item.children.map((subItem) => renderTemplate`${renderComponent($$result, "AcctSideNavSubTab", $$AcctSideSubNavTab, { "Tag": "a", "attribute": {
    href: subItem.href,
    title: subItem.label
  }, "className": { active: subItem.label === active } }, { "default": ($$result2) => renderTemplate`${subItem.label}` })}`)}
                        </div>`}
                </li>`)}
    </ul>
</nav>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/acctSideNav.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$NavOffcanvas = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$NavOffcanvas;
  const { IDName = "memberNav", className, style, attribute = {}, activeTab } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyOffcanvas", $$Offcanvas, { "IDName": IDName, "postion": "top", "hideHeader": true, "className": ["member-nav-offcanvas", className], "attribute": attribute, "style": { "--bs-offcanvas-height": "calc(100vh - (var(--header-height) + 3.125rem))", ...style } }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "AcctSideNav", $$AcctSideNav, { "type": "default", "padding": "width", "active": activeTab })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/navOffcanvas.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Body = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Body;
  const { IDName, className, style, attribute = {}, activeTab, activeCollapse } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "member-body"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Banner", $$Banner, {})}
    <div class="member-container">
        ${renderComponent($$result, "AcctSideNav", $$AcctSideNav, { "className": "member-side-nav", "active": activeTab, "activeCollapse": activeCollapse })}
        <div class="member-content">
            ${renderSlot($$result, $$slots["default"])}
        </div>
    </div>
</div>
${renderComponent($$result, "NavOffcanvas", $$NavOffcanvas, { "activeTab": activeTab })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/body.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Sort = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Sort;
  const {
    IDName,
    className,
    style,
    attribute = {},
    type = "bottom",
    start = 1,
    end = 10,
    total = 20,
    active = 1,
    visiblePages = 7,
    showCount = true,
    showPagination = true,
    showSelect = true
  } = Astro2.props;
  const page = total / end;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "member-sort", type], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${showCount && renderTemplate`<span class="member-page-view">
                第 ${start} 至 ${end} 筆，共 ${total} 筆
            </span>`}
    ${showPagination && renderTemplate`${renderComponent($$result, "Pagination", $$Pagination, { "className": "member-page-pagination", "total": page, "active": active, "visiblePages": visiblePages })}`}
    ${showSelect && renderTemplate`<div class="member-page-size">
                <span>每頁</span>
                ${renderComponent($$result, "Select", $$CustomSelect, { "data": Array.from({ length: end }, (_, i) => ({ text: i + 1, value: i + 1 })), "value": start, "attribute": { "aria-label": "\u7B46\u6578" }, "className": "member-page-select", "style": { width: "2.5rem" } })}
                <span>筆</span>
            </div>`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/sort.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Title = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Title;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title,
    infoText,
    showInfoText,
    rightText,
    showRightText,
    showSort,
    link,
    linkText = "\u8FD4\u56DE",
    showLink
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "member-header"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${showLink && renderTemplate`<div class="member-link">
                ${renderComponent($$result, "ALink", $$Link, { "link": link, "title": linkText, "back": true, "showArrow": true })}
            </div>`}
    <div class="member-head">
        <div class="member-head-top">
            ${title && renderTemplate`<h2 class="member-title">${title}</h2>`}
            ${Boolean(showInfoText && infoText) && renderTemplate`<span class="member-info-text">${infoText}</span>`}
            ${showSort && renderTemplate`${renderComponent($$result, "Sort", $$Sort, { "type": "top", "showPagination": false })}`}
        </div>
        ${Boolean(showRightText && rightText) && renderTemplate`<span class="member-right-text">${rightText}</span>`}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/tools/title.astro", void 0);

export { $$Body as $, $$Title as a, $$Sort as b };
