import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$TaxCert = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="4.6" y="2.6" width="14.8" height="18.8" rx="1.6" stroke="var(--color-blue-500, #006ce1)" stroke-width="1.2"></rect>
<path d="M15.056 6L15.8179 7.47293L16.5432 6H17.7264L16.4406 8.18514L17.752 10.4127H16.5212L15.763 8.90645L15.0047 10.4127H13.7996L15.133 8.16696L13.8289 6H15.056Z" fill="var(--color-blue-500, #006ce1)"></path>
<path d="M11.705 6.78798L10.5584 10.4127H9.42657L11.0932 6H11.8002L11.705 6.78798ZM12.6097 10.4127L11.4559 6.78798L11.3497 6H12.0676L13.7489 10.4127H12.6097ZM12.65 8.76704V9.5035H10.2434V8.76704H12.65Z" fill="var(--color-blue-500, #006ce1)"></path>
<path d="M8.66592 6V10.4127H7.59999V6H8.66592ZM9.99193 6V6.73646H6.29962V6H9.99193Z" fill="var(--color-blue-500, #006ce1)"></path>
<path d="M9 14.5996H15" stroke="var(--color-blue-500, #006ce1)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M9 17.5996H15" stroke="var(--color-blue-500, #006ce1)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/focus/tax cert.astro", void 0);

export { $$TaxCert as default };
