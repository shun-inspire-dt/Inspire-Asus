import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
/* empty css                         */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Checkbox = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Checkbox;
  const {
    id,
    className,
    name,
    required,
    disabled,
    readonly,
    label,
    value,
    checked,
    title,
    rounded,
    validClass,
    validType,
    validLabel,
    customValidText,
    customInvalidText,
    setRequired,
    attribute = {},
    aria = {},
    style,
    indeterminate,
    alignment
  } = Astro2.props;
  const validAttribute = {
    "data-valid-class": validClass,
    "data-valid-type": validType ? `${validType}|checkbox` : void 0,
    "data-valid-label": validLabel,
    "data-custom-valid-text": customValidText,
    "data-custom-invalid-text": customInvalidText
  };
  const inputId = id || `checkbox-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`
${maybeRenderHead()}<div${addAttribute(["form-check", { "rounded-check": rounded, "indeterminate-check": indeterminate, "form-check-right": alignment === "right" }, className], "class:list")}${addAttribute(style, "style")}>
    <div class="form-check-input-container">
        
        <input${addAttribute(inputId, "id")} class="form-check-input" type="checkbox"${addAttribute(value, "value")}${addAttribute(name, "name")}${addAttribute(disabled, "disabled")}${addAttribute(required, "required")}${addAttribute(checked, "checked")} autocomplete="off"${spreadAttributes(readonly ? { onclick: "return false;" } : {})}${addAttribute(setRequired, "data-set-required")}${spreadAttributes(attribute)}${spreadAttributes(aria)}${addAttribute(title, "aria-label")}${spreadAttributes(validAttribute)}>
    </div>
    
    <label class="form-check-label"${addAttribute(inputId, "for")}>
        ${renderSlot($$result, $$slots["default"], renderTemplate`${label}`)}
    </label>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/checkboxs/checkbox.astro", void 0);

export { $$Checkbox as $ };
