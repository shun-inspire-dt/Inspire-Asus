import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { b as bannerImages, a as bannerImage } from './banner_BzehUiDa.mjs';
import { $ as $$Picture } from './picture_GYxijd3h.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Banner = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Banner;
  const { IDName, className, style, title, img, mode = "light", attribute = {} } = Astro2.props;
  const imgBreakpoints = bannerImages(img);
  const image = bannerImage(img);
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "section-banner"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Picture", $$Picture, { "img": image, "className": "section-banner-image", "alt": title, "breakpoints": imgBreakpoints, "type": "png", "noWebp": true })}
    <div class="section-banner-head">
        <h2${addAttribute([
    "section-banner-title",
    mode === "dark" && "section-banner-title-dark"
  ], "class:list")}>
            ${title}
        </h2>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/banner/banner.astro", void 0);

export { $$Banner as $ };
