import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$Overview = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_2562_50266)">
<mask id="mask0_2562_50266" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
<path d="M0 0H24V24H0V0Z" fill="white"></path>
</mask>
<g mask="url(#mask0_2562_50266)">
<mask id="mask1_2562_50266" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="2" y="3" width="21" height="18">
<path d="M2 3H22.698V20.622H2V3Z" fill="white"></path>
</mask>
<g mask="url(#mask1_2562_50266)">
<path d="M14.466 20.6224C14.3069 20.6224 14.1543 20.5591 14.0417 20.4466C13.9292 20.3341 13.8664 20.1814 13.8664 20.0223V14.1043C13.8649 13.9987 13.822 13.8977 13.7473 13.8231C13.6726 13.7484 13.5717 13.706 13.466 13.7044H11.031C10.9254 13.706 10.8249 13.7484 10.7502 13.8231C10.6755 13.8977 10.6326 13.9987 10.6311 14.1043V20.0223C10.6311 20.1814 10.5678 20.3341 10.4553 20.4466C10.3428 20.5591 10.1901 20.6224 10.031 20.6224H6.13109C5.56519 20.6221 5.02293 20.397 4.62278 19.9969C4.22264 19.5967 3.99756 19.0542 3.9973 18.4883V11.1883H3.5803L2.98021 11.6673C2.87481 11.7521 2.74338 11.7981 2.60814 11.7974C2.51776 11.7974 2.42878 11.7769 2.34739 11.7376C2.26601 11.6983 2.1946 11.6412 2.13841 11.5704C2.08959 11.5085 2.05336 11.4375 2.03196 11.3616C2.01057 11.2858 2.00412 11.2063 2.01341 11.128C2.0227 11.0497 2.04761 10.9741 2.08616 10.9053C2.12472 10.8366 2.17607 10.7761 2.23802 10.7274L11.8103 3.12726C11.914 3.04491 12.0421 2.99913 12.1745 2.99714C12.3069 2.99515 12.4361 3.03708 12.5422 3.11628L22.467 10.5084C22.5945 10.6034 22.6793 10.7451 22.7024 10.9024C22.7254 11.0597 22.6849 11.2196 22.5901 11.3472C22.4951 11.4747 22.3533 11.5593 22.196 11.5823C22.0387 11.6054 21.8788 11.5651 21.7512 11.4703L21.1203 11.0003L20.5202 11.0074V18.4874C20.5197 19.053 20.2946 19.5954 19.8948 19.9954C19.4949 20.3955 18.9531 20.6206 18.3874 20.6214L14.466 20.6224Z" fill="var(--color-blue-500, var(--color-blue-500, #006ce1))"></path>
</g>
</g>
</g>
<defs>
<clipPath id="clip0_2562_50266">
<rect width="24" height="24" fill="white"></rect>
</clipPath>
</defs>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/hover/overview.astro", void 0);

export { $$Overview as default };
