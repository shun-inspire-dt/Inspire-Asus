import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$TypeIconGoogleSizeSm = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip_google_sm_g)">
<mask id="mask0_2663_37486" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
<path d="M20 0H0V20H20V0Z" fill="white"></path>
</mask>
<g mask="url(#mask0_2663_37486)">
<path d="M19.6 10.2272C19.6 9.518 19.5364 8.83628 19.4182 8.18164H10V12.0498H15.3818C15.15 13.2998 14.4455 14.3589 13.3864 15.068V17.5772H16.6182C18.5091 15.8363 19.6 13.2725 19.6 10.2272Z" fill="#4285F4"></path>
<path d="M9.99957 20.0004C12.6996 20.0004 14.9631 19.1048 16.6177 17.5777L13.3858 15.0686C12.4905 15.6686 11.3449 16.023 9.99957 16.023C7.39493 16.023 5.19047 14.2639 4.40402 11.9004H1.06311V14.4913C2.70866 17.7595 6.09047 20.0004 9.99957 20.0004Z" fill="#34A853"></path>
<path d="M4.40455 11.8997C4.20446 11.2997 4.09091 10.6588 4.09091 9.9997C4.09091 9.34051 4.20446 8.6997 4.40455 8.0997V5.50879H1.06364C0.386364 6.85879 0 8.38606 0 9.9997C0 11.6132 0.386364 13.1405 1.06364 14.4905L4.40455 11.8997Z" fill="#FBBC04"></path>
<path d="M9.99957 3.97727C11.4677 3.97727 12.7858 4.48182 13.8222 5.47273L16.6905 2.60455C14.9587 0.990909 12.6949 0 9.99957 0C6.09047 0 2.70866 2.24091 1.06311 5.50909L4.40402 8.1C5.19047 5.73645 7.39493 3.97727 9.99957 3.97727Z" fill="#E94235"></path>
</g>
</g>
<defs>
<clipPath id="clip_google_sm">
<rect width="20" height="20" fill="white"></rect>
</clipPath>
</defs>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/social/svg-astro/type_icon_google-size_sm.astro", void 0);

export { $$TypeIconGoogleSizeSm as default };
