import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, F as Fragment, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';
/* empty css                         */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Pagination = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Pagination;
  const {
    IDName,
    className,
    style,
    attribute = {},
    active = 1,
    total = 12,
    mode = "Light",
    showStartEllipsis = false,
    showEndEllipsis = false,
    visiblePages = 7,
    noDisabled = false,
    noActive = false,
    hasDataValue = false
  } = Astro2.props;
  function shouldShowPage(page, current, total2, visible) {
    if (total2 <= visible) return true;
    const half = Math.floor(visible / 2);
    let start = Math.max(1, current - half);
    let end = Math.min(total2, start + visible - 1);
    if (end - start + 1 < visible) {
      start = Math.max(1, end - visible + 1);
    }
    return page >= start && page <= end;
  }
  const allPages = Array.from({ length: total }, (_, i) => i + 1);
  return renderTemplate`
${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute(["pagination", `pagination--${mode.toLowerCase()}`, className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)} role="navigation" aria-label="分頁導航">
    
    <a${addAttribute(active > 1 ? `?page=${active - 1}` : void 0, "href")} title="上一頁"${addAttribute([
    "pagination__arrow",
    "pagination__arrow--prev",
    { "pagination__arrow--disabled": active === 1 && !noDisabled }
  ], "class:list")} aria-label="上一頁"${addAttribute(active === 1 && !noDisabled, "aria-disabled")}${addAttribute(active === 1 && !noDisabled ? -1 : 0, "tabindex")}>
        <span class="pagination__arrow-icon pagination__arrow-icon--prev" aria-hidden="true"></span>
    </a>

    
    ${allPages.map((page, index) => {
    const isBeforeLastPage = page === total - 1;
    const isStartEllipsisPosition = index === 1;
    return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${isStartEllipsisPosition && renderTemplate`<span class="pagination__ellipsis" aria-hidden="true"${addAttribute({ ...showStartEllipsis ? {} : { display: "none" } }, "style")}>
                            ...
                        </span>`}<a${addAttribute(`?page=${page}`, "href")}${addAttribute(`\u7B2C ${page} \u9801`, "title")}${addAttribute(["pagination__item", { "pagination__item--active": active === page && !noActive }], "class:list")}${addAttribute(`\u7B2C ${page} \u9801`, "aria-label")}${addAttribute(active === page ? "page" : void 0, "aria-current")}${addAttribute(hasDataValue ? page : void 0, "data-index")}${addAttribute({ ...shouldShowPage(page, active, total, visiblePages) ? {} : { display: "none" } }, "style")}>
                        ${page}
                    </a>
                    ${isBeforeLastPage && renderTemplate`<span class="pagination__ellipsis" aria-hidden="true"${addAttribute({ ...showEndEllipsis ? {} : { display: "none" } }, "style")}>
                            ...
                        </span>`}` })}`;
  })}

    
    <a${addAttribute(active < total ? `?page=${active + 1}` : void 0, "href")} title="下一頁"${addAttribute([
    "pagination__arrow",
    "pagination__arrow--next",
    { "pagination__arrow--disabled": active === total && !noDisabled }
  ], "class:list")} aria-label="下一頁"${addAttribute(active === total && !noDisabled, "aria-disabled")}${addAttribute(active === total && !noDisabled ? -1 : 0, "tabindex")}>
        <span class="pagination__arrow-icon pagination__arrow-icon--next" aria-hidden="true"></span>
    </a>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/pagination/pagination.astro", void 0);

export { $$Pagination as $ };
