import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, u as unescapeHTML } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Picture } from './picture_GYxijd3h.mjs';
import { d as $$A, c as $$Link } from './layouts_CuL6zXvl.mjs';
import { $ as $$Date } from './date_kYIPuAOm.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Card = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Card;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "\u83EF\u78A9\u5546\u7528\u96FB\u8166\u5E02\u4F54\u958B\u5C40\u596A\u51A0\uFF01\u5168\u65B0\u300CAI\u96D9\u6A5F\u300D\u5F37\u5316\u4F01\u696D\u6578\u4F4D\u6230\u529B",
    label = "\u79D1\u6280\u8207\u88FD\u9020",
    breif = "Welcome to Burger Bliss, where we take your cravings to a whole new!\nWelcome to Burger Bliss.",
    date = "2025/11/07",
    logoImage = "/assets/logos/Business-Vertical-Light",
    img = "/assets/images/pages/Article-card-image",
    link = "",
    width = "100%",
    showDate = true,
    showLabel = true,
    showBreif = true,
    showLogo = true,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/Article-card-image",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/Article-card-image",
          // 標準解析度
          "1.5x": "/assets/images/pages/Article-card-image",
          // 1.5倍解析度
          "2x": "/assets/images/pages/Article-card-image"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/Article-card-image",
        densities: {
          "1x": "/assets/images/pages/Article-card-image",
          "1.5x": "/assets/images/pages/Article-card-image",
          "2x": "/assets/images/pages/Article-card-image"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/Article-card-image",
        densities: {
          "1x": "/assets/images/pages/Article-card-image",
          "1.5x": "/assets/images/pages/Article-card-image",
          "2x": "/assets/images/pages/Article-card-image"
        }
      }
    ]
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "A", $$A, { "IDName": IDName, "link": link, "className": [
    className,
    "news-card group"
  ], "style": cardStyle, "attribute": attribute, "title": title }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="news-card-image-container">
        ${renderComponent($$result2, "Picture", $$Picture, { "className": "news-card-image", "img": img, "alt": title, "loading": "lazy", "decoding": "async", "breakpoints": imgBreakpoints, "noWebp": true })}
    </div>
    <div class="news-card-content">
        ${showDate && renderTemplate`${renderComponent($$result2, "Date", $$Date, { "className": "news-card-date" }, { "default": ($$result3) => renderTemplate`${date}` })}`}
        <div class="news-card-head">
            ${title && renderTemplate`<strong class="news-card-title">
                        ${title}
                    </strong>`}
            ${Boolean(showLabel && label) && renderTemplate`<span class="news-card-label">${unescapeHTML(label)}</span>`}
            ${Boolean(showBreif && breif) && renderTemplate`<span class="news-card-breif">${unescapeHTML(breif)}</span>`}
        </div>
        <div class="news-card-footer">
            ${showLogo && renderTemplate`<div class="news-card-logo">
                        ${renderComponent($$result2, "Picture", $$Picture, { "img": logoImage, "alt": title, "type": "svg", "loading": "lazy", "decoding": "async", "noWebp": true })}
                    </div>`}
            ${renderComponent($$result2, "ALink", $$Link, { "link": link, "className": "news-card-link", "title": "\u4E86\u89E3\u66F4\u591A", "size": "16", "showArrow": true, "Tag": "span" })}
        </div>
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/card.astro", void 0);

export { $$Card as $ };
