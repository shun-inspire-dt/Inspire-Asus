import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Invoice = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.2002 2.59961H17.7998C18.6835 2.59961 19.4004 3.31654 19.4004 4.2002V19.7998C19.4004 20.6835 18.6835 21.4004 17.7998 21.4004H6.2002C5.31654 21.4004 4.59961 20.6835 4.59961 19.7998V4.2002C4.59961 3.31654 5.31654 2.59961 6.2002 2.59961Z" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linejoin="round"></path>
<path d="M13.5 6.5C13.5 6.5 11.8575 6.5 11.1528 6.5C9.70591 6.5 9.52813 8.5 11.1528 8.5C11.9646 8.5 11.153 8.5 12.7771 8.5C14.4011 8.5 14.4142 10.5 12.7771 10.5C11.1399 10.5 10.5 10.5 10.5 10.5M12 5.5V6.5M12 10.5V11.5" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M9 14.5996L15 14.5996" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></path>
<path d="M9 17.5996H12" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/invoice.astro", void 0);

export { $$Invoice as default };
