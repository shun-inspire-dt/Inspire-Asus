import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Faq = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="12" cy="12" r="9.4" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></circle>
<line x1="12.1095" y1="15.7816" x2="12.1095" y2="16.3998" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></line>
<path d="M9.78223 9.62032C9.78223 7.74866 10.8428 7 12.055 7C13.2671 7 14.3277 7.74866 14.3277 9.24599C14.3277 10.0753 13.708 10.8462 12.9262 11.3866C12.4296 11.7299 12.055 12.2547 12.055 12.8536V13.3636" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/faq.astro", void 0);

export { $$Faq as default };
