import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, u as unescapeHTML } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Picture } from './picture_GYxijd3h.mjs';
import { d as $$A, c as $$Link } from './layouts_CuL6zXvl.mjs';
import { $ as $$Date } from './date_kYIPuAOm.mjs';

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$CollectionCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$CollectionCard;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "\u83EF\u78A9\u5546\u7528\u5E2B\u96FB\u8166\u5E02\u4F54\u958B\u5C40\u596A\u51A0\uFF01",
    label = "\u79D1\u6280\u8207\u88FD\u9020",
    breif = "\u5E02\u8ABF\u6A5F\u69CBIDC\u6700\u65B0\u5831\u544A\uFF0C\u83EF\u78A9\u5546\u7528\u96FB\u8166\u518D\u6B21\u62FF\u4E0B2025\u5E74!",
    date = "2025/11/07",
    logoImage = "/assets/logos/Business-Vertical-Dark",
    img = "/assets/images/pages/Article-card-image-1",
    link = "",
    width = "100%",
    showDate = true,
    showLabel = true,
    showBreif = true,
    showLogo = true,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/Article-card-image-1",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/Article-card-image-1",
          // 標準解析度
          "1.5x": "/assets/images/pages/Article-card-image-1",
          // 1.5倍解析度
          "2x": "/assets/images/pages/Article-card-image-1"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/Article-card-image-1",
        densities: {
          "1x": "/assets/images/pages/Article-card-image-1",
          "1.5x": "/assets/images/pages/Article-card-image-1",
          "2x": "/assets/images/pages/Article-card-image-1"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/Article-card-image-1",
        densities: {
          "1x": "/assets/images/pages/Article-card-image-1",
          "1.5x": "/assets/images/pages/Article-card-image-1",
          "2x": "/assets/images/pages/Article-card-image-1"
        }
      }
    ]
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "A", $$A, { "IDName": IDName, "link": link, "className": [
    className,
    "collection-card group"
  ], "style": cardStyle, "attribute": attribute, "title": title }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Picture", $$Picture, { "className": "collection-card-image", "img": img, "alt": title, "loading": "lazy", "decoding": "async", "breakpoints": imgBreakpoints, "noWebp": true })}
    ${maybeRenderHead()}<div class="collection-card-body">
        <div class="collection-card-overlay">
        </div>
        <div class="collection-card-content">
            ${showDate && renderTemplate`${renderComponent($$result2, "Date", $$Date, { "className": "collection-card-date", "mode": "dark" }, { "default": ($$result3) => renderTemplate`${date}` })}`}
            <div class="collection-card-head">
                ${title && renderTemplate`<strong class="collection-card-title">
                            ${title}
                        </strong>`}
                ${Boolean(showLabel && label) && renderTemplate`<span class="collection-card-label">${unescapeHTML(label)}</span>`}
                ${Boolean(showBreif && breif) && renderTemplate`<span class="collection-card-breif">${unescapeHTML(breif)}</span>`}
            </div>
            <div class="collection-card-footer">
                ${showLogo && renderTemplate`<div class="collection-card-logo">
                            ${renderComponent($$result2, "Picture", $$Picture, { "img": logoImage, "alt": title, "type": "svg", "loading": "lazy", "decoding": "async", "noWebp": true })}
                        </div>`}
                ${renderComponent($$result2, "ALink", $$Link, { "link": link, "className": "collection-card-link", "title": "\u4E86\u89E3\u66F4\u591A", "size": "16", "showArrow": true, "Tag": "span" })}
            </div>
        </div>
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/collectionCard.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$CollectionHarCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$CollectionHarCard;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "\u83EF\u78A9\u5546\u7528\u5E2B\u96FB\u8166\u5E02\u4F54\u958B\u5C40\u596A\u51A0\uFF01",
    label = "\u79D1\u6280\u8207\u88FD\u9020",
    breif = "\u5E02\u8ABF\u6A5F\u69CBIDC\u6700\u65B0\u5831\u544A\uFF0C\u83EF\u78A9\u5546\u7528\u96FB\u8166\u518D\u6B21\u62FF\u4E0B2025\u5E74!",
    date = "2025/11/07",
    logoImage = "/assets/logos/Business-Vertical-Light",
    img = "/assets/images/pages/Article-card-image-2",
    link = "",
    width = "100%",
    showDate = true,
    showLabel = true,
    showBreif = true,
    showLogo = true,
    showBottomBorder = true,
    last = false,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/Article-card-image-2",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/Article-card-image-2",
          // 標準解析度
          "1.5x": "/assets/images/pages/Article-card-image-2",
          // 1.5倍解析度
          "2x": "/assets/images/pages/Article-card-image-2"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/Article-card-image-2",
        densities: {
          "1x": "/assets/images/pages/Article-card-image-2",
          "1.5x": "/assets/images/pages/Article-card-image-2",
          "2x": "/assets/images/pages/Article-card-image-2"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/Article-card-image-2",
        densities: {
          "1x": "/assets/images/pages/Article-card-image-2",
          "1.5x": "/assets/images/pages/Article-card-image-2",
          "2x": "/assets/images/pages/Article-card-image-2"
        }
      }
    ]
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "A", $$A, { "IDName": IDName, "link": link, "className": [
    className,
    "collection-har-card group",
    { "collection-har-card-bottom-border": showBottomBorder && !last },
    { "collection-har-card-last": last && showBottomBorder }
  ], "style": cardStyle, "attribute": attribute, "title": title }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="collection-har-card-image-container">
        ${renderComponent($$result2, "Picture", $$Picture, { "className": "collection-har-card-image", "img": img, "alt": title, "loading": "lazy", "decoding": "async", "breakpoints": imgBreakpoints, "noWebp": true })}
    </div>
    <div class="collection-har-card-content">
        ${showDate && renderTemplate`${renderComponent($$result2, "Date", $$Date, { "className": "collection-har-card-date" }, { "default": ($$result3) => renderTemplate`${date}` })}`}
        <div class="collection-har-card-head">
            ${title && renderTemplate`<strong class="collection-har-card-title">
                        ${title}
                    </strong>`}
            ${Boolean(showLabel && label) && renderTemplate`<span class="collection-har-card-label">${unescapeHTML(label)}</span>`}
            ${Boolean(showBreif && breif) && renderTemplate`<span class="collection-har-card-breif">${unescapeHTML(breif)}</span>`}
        </div>
        <div class="collection-har-card-footer">
            ${showLogo && renderTemplate`<div class="collection-har-card-logo">
                        ${renderComponent($$result2, "Picture", $$Picture, { "img": logoImage, "alt": title, "type": "svg", "loading": "lazy", "decoding": "async", "noWebp": true })}
                    </div>`}
            ${renderComponent($$result2, "ALink", $$Link, { "link": link, "className": "collection-har-card-link", "title": "\u4E86\u89E3\u66F4\u591A", "size": "16", "showArrow": true, "Tag": "span" })}
        </div>
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/collectionHarCard.astro", void 0);

export { $$CollectionCard as $, $$CollectionHarCard as a };
