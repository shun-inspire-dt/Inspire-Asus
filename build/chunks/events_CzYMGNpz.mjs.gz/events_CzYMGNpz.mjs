import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$Events = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="2.6" y="5.6" width="18.8" height="13.8" rx="1.6" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2"></rect>
<path d="M9 12.5996L11 14.5996L15 10.5996" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M8.5 3.59961V7.4" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></path>
<path d="M15.5 3.59961V7.4" stroke="var(--color-gray-900, var(--color-gray-900, #181818))" stroke-width="1.2" stroke-linecap="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/events.astro", void 0);

export { $$Events as default };
