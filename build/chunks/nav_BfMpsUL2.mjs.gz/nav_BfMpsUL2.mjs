import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { d as $$A } from './layouts_C4hX5So7.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Nav = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Nav;
  const { IDName, className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "section-nav"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${data.map((item) => renderTemplate`${renderComponent($$result, "A", $$A, { "link": item.link, "className": "section-nav-link", "title": item.title, "extend": true }, { "default": ($$result2) => renderTemplate`${item.title}` })}`)}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/nav.astro", void 0);

export { $$Nav as $ };
