import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
/* empty css                             */

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Textarea = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Textarea;
  const {
    id,
    className,
    name,
    title,
    value,
    cols = 2,
    rows = 2,
    maxlength,
    minlength,
    placeholder,
    required,
    disabled,
    readonly,
    validClass = "form",
    validType,
    validLabel,
    validRegex,
    errorFeedback,
    successFeedback,
    FeedbackIcon,
    attribute = {},
    style,
    size,
    noResize
  } = Astro2.props;
  const inputClasses = [
    "control-input",
    // 基礎輸入框類別
    { [`size_${size}`]: size },
    // 尺寸類別
    { noresize: noResize },
    // 是否禁止調整大小
    className
    // 自定義類別
  ].filter(Boolean);
  const validAttribute = {
    "data-valid-class": validClass,
    // 驗證成功時要套用的 CSS 類別
    "data-valid-type": validType,
    // 驗證類型識別
    "data-valid-label": validLabel,
    // 驗證標籤文字
    "data-valid-regex": validRegex,
    // 驗證用正規表達式
    "data-custom-feedback": errorFeedback || successFeedback ? "" : void 0,
    // 是否有自定義回饋訊息
    "data-error-feedback": errorFeedback,
    // 錯誤回饋訊息
    "data-success-feedback": successFeedback,
    // 成功回饋訊息
    "data-feedback-icon": FeedbackIcon ? "" : void 0
    // 是否顯示回饋圖標
  };
  return renderTemplate`${maybeRenderHead()}<textarea${addAttribute(id, "id")}${addAttribute(inputClasses, "class:list")}${addAttribute(name, "name")}${addAttribute(cols, "cols")}${addAttribute(rows, "rows")}${addAttribute(maxlength, "maxlength")}${addAttribute(minlength, "minlength")}${addAttribute(placeholder, "placeholder")}${addAttribute(required, "required")}${addAttribute(disabled, "disabled")}${addAttribute(readonly, "readonly")}${addAttribute(title, "aria-label")}${addAttribute(style, "style")}${spreadAttributes(attribute)}${spreadAttributes(validAttribute)}>    ${value?.trim()}
</textarea>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/textarea.astro", void 0);

export { $$Textarea as $ };
