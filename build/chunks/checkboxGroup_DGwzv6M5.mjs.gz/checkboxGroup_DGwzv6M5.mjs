import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Checkbox } from './checkbox_DqKqFtJg.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$CheckboxGroup = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$CheckboxGroup;
  const { IDName, className, style, attribute = {}, showTop = true, indeterminate = true } = Astro2.props;
  const TopId = IDName || `main-checkbox-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "checkbox-group",
    { "checkbox-group-main": showTop }
  ], "class:list")}${addAttribute(style, "style")} data-checkbox-group${spreadAttributes(attribute)}>
    ${showTop && renderTemplate`${renderComponent($$result, "Checkbox", $$Checkbox, { "id": TopId, "title": "Main Term", "indeterminate": indeterminate, "attribute": { "data-checkbox-main": true } }, { "default": ($$result2) => renderTemplate`
                ${renderSlot($$result2, $$slots["title"])}
            ` })}`}
    <div class="checkbox-group-inner">
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/checkboxGroup.astro", void 0);

export { $$CheckboxGroup as $ };
