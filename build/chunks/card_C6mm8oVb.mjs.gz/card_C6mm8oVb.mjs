import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, F as Fragment, m as maybeRenderHead, b as addAttribute } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Picture } from './picture_GYxijd3h.mjs';
import { d as $$A, c as $$Link } from './layouts_CNnjnwpD.mjs';

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$PlayBack = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$PlayBack;
  const { IDName, className, style, attribute = {}, Tag = "button", size = "48" } = Astro2.props;
  const cardClass = [
    "play-back",
    { "play-back-48": size === "48" },
    { "play-back-32": size === "32" },
    className
  ];
  const cardStyle = (size2) => {
    const data = {
      "48": {
        "--icon-width": "1.2rem",
        "--icon-height": "1.05rem",
        ...style
      },
      "32": {
        "--icon-width": "0.875rem",
        "--icon-height": "0.75rem",
        ...style
      }
    };
    return data[size2];
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "type": Tag === "button" ? "button" : void 0, "class:list": [cardClass], "style": cardStyle(size), "title": "play-back", "aria-label": "play-back", "tabindex": -1, ...attribute }, { "default": ($$result2) => renderTemplate`${size === "48" && renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`
                ${maybeRenderHead()}<svg${addAttribute([
    "play-back-icon",
    { "play-back-icon-48": size === "48" }
  ], "class:list")} width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15.2804 8.00913C15.9522 8.39302 15.9522 9.36172 15.2804 9.74561L1.49594 17.6224C0.829283 18.0034 -0.000195347 17.522 -0.000195313 16.7542L-0.000194625 1.00052C-0.000194591 0.232701 0.829288 -0.248665 1.49594 0.132283L15.2804 8.00913Z" fill="var(--color-white, #fff)"></path>
                </svg>
                <svg${addAttribute([
    "play-back-pause-icon",
    {
      "play-pause-back-icon-48": size === "48"
    }
  ], "class:list")} width="15" height="20" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="0.6" y="0.6" width="1.2" height="18" rx="0.6" fill="var(--color-white, #fff)" stroke="var(--color-white, #fff)" stroke-width="1.2"></rect>
                    <rect x="12.6" y="0.6" width="1.2" height="18" rx="0.6" fill="var(--color-white, #fff)" stroke="var(--color-white, #fff)" stroke-width="1.2"></rect>
                </svg>
            ` })}`}${size === "32" && renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`
                <svg${addAttribute([
    "play-back-icon",
    { "play-back-icon-32": size === "32" }
  ], "class:list")} width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.5192 5.39601C11.1807 5.78188 11.1807 6.73769 10.5192 7.12356L1.50387 12.3825C0.837215 12.7714 3.84081e-07 12.2905 4.17817e-07 11.5187L8.77571e-07 1.0008C9.11307e-07 0.229013 0.837216 -0.251858 1.50387 0.137027L10.5192 5.39601Z" fill="var(--color-white, #fff)"></path>
                </svg>
                <svg${addAttribute([
    "play-back-pause-icon",
    {
      "play-pause-back-icon-32": size === "32"
    }
  ], "class:list")} width="10" height="13" viewBox="0 0 10 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="0.4" y="0.4" width="0.8" height="12" rx="0.4" fill="var(--color-white, #fff)" stroke="var(--color-white, #fff)" stroke-width="0.8"></rect>
                    <rect x="8.4" y="0.4" width="0.8" height="12" rx="0.4" fill="var(--color-white, #fff)" stroke="var(--color-white, #fff)" stroke-width="0.8"></rect>
                </svg>
            ` })}`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/playBack/playBack.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Card = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Card;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "iShops - \u958B\u5E97\u5E73\u53F0\uFF01",
    breif = "\u4E00\u7AD9\u5F0F\u958B\u5E97\u5E73\u53F0\uFF0C\u5168\u9762\u5F37\u5316\u60A8\u7684\u5546\u696D\u904B\u71DF\uFF0C\u589E\u52A0\u4F01\u696D\u71DF\u6536\uFF0C\u8B93\u4F01\u696D\u8B8A\u5F97\u66F4\u597D\uFF0C\u4EFF\u9020IG\u7684\u9650\u6642\u52D5\u614B\u98A8\u683C\u3002",
    logoImage = "/assets/logos/Business-Vertical-Light",
    logoImageType = "svg",
    img = "/assets/images/pages/solutions-bg-1",
    link = "",
    linkText = "\u4E86\u89E3\u66F4\u591A",
    showLinkArrow = true,
    width = "100%",
    showPlayBack = true,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/solutions-bg-1",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/solutions-bg-1",
          // 標準解析度
          "1.5x": "/assets/images/pages/solutions-bg-1",
          // 1.5倍解析度
          "2x": "/assets/images/pages/solutions-bg-1"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/solutions-bg-1",
        densities: {
          "1x": "/assets/images/pages/solutions-bg-1",
          "1.5x": "/assets/images/pages/solutions-bg-1",
          "2x": "/assets/images/pages/solutions-bg-1"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/solutions-bg-1",
        densities: {
          "1x": "/assets/images/pages/solutions-bg-1",
          "1.5x": "/assets/images/pages/solutions-bg-1",
          "2x": "/assets/images/pages/solutions-bg-1"
        }
      }
    ]
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "A", $$A, { "id": IDName, "link": link, "title": title, "className": [
    className,
    "solutions-card group"
  ], "style": cardStyle, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="solutions-card-image-container">
        ${renderComponent($$result2, "Picture", $$Picture, { "img": img, "className": "solutions-card-image", "alt": title, "loading": "lazy", "decoding": "async", "breakpoints": imgBreakpoints, "noWebp": true })}
        ${showPlayBack && renderTemplate`<div class="solutions-card-play-back" data-play-back-overlay>
                    ${renderComponent($$result2, "PlayBack", $$PlayBack, { "size": "48", "attribute": {
    title,
    "data-toggle": "video",
    "data-bs-toggle": "modal",
    "data-bs-target": "#VideoModal",
    "data-auto": "false",
    "data-video-id": "EEwDOMs5Xio"
  } })}
                </div>`}
    </div>
    <div class="solutions-card-content">
        <div class=":uno-solutions-card-head:">
            ${title && renderTemplate`<strong class="solutions-card-title">
                        ${title}
                    </strong>`}
            ${breif && renderTemplate`<span class="solutions-card-breif">
                        ${breif}
                    </span>`}
        </div>
        <div class="solutions-card-footer">
            <div class="solutions-card-logo">
                ${renderComponent($$result2, "Picture", $$Picture, { "img": logoImage, "alt": title, "type": logoImageType, "loading": "lazy", "decoding": "async", "noWebp": true })}
            </div>
            <div class="solutions-card-link">
                ${renderComponent($$result2, "ALink", $$Link, { "link": link, "className": "", "title": linkText, "size": "16", "showArrow": showLinkArrow, "Tag": "span" })}
            </div>
        </div>
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/card.astro", void 0);

export { $$PlayBack as $, $$Card as a };
