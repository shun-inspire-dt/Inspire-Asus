import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, e as renderSlot, u as unescapeHTML, d as renderTemplate, r as renderComponent, F as Fragment, f as renderHead } from './astro/server_Bjgbv9en.mjs';
/* empty css                           */
/* empty css                       */
/* empty css                        */

const data = [
  {
    title: "解決方案",
    links: [
      [
        { link: "/solutions?category=科技與製造", linkText: "科技與製造" },
        { link: "/solutions?category=教育與訓練", linkText: "教育與訓練" },
        { link: "/solutions?category=零售與電商", linkText: "零售與電商" },
        { link: "/solutions?category=建築與工程", linkText: "建築與工程" }
      ],
      [
        { link: "/solutions?category=餐飲與連鎖服務", linkText: "餐飲與連鎖服務" },
        { link: "/solutions?category=旅宿與觀光", linkText: "旅宿與觀光" },
        { link: "/solutions?category=醫療與照護", linkText: "醫療與照護" },
        { link: "/solutions?category=顧問服務", linkText: "顧問服務" }
      ]
    ]
  },
  {
    title: "服務",
    links: [
      [
        { link: "/ivy?category=雲端與基礎設施", linkText: "雲端與基礎設施" },
        { link: "/ivy?category=數據分析與智能應用", linkText: "數據分析與智能應用" },
        { link: "/ivy?category=資安與合規服務", linkText: "資安與合規服務" },
        { link: "/ivy?category=顧問與專案交付", linkText: "顧問與專案交付" }
      ],
      [
        { link: "/ivy?category=企業系統導入與整合", linkText: "企業系統導入與整合" },
        { link: "/ivy?category=IT資源與資產服務", linkText: "IT資源與資產服務" },
        { link: "/ivy?category=應用開發與客製化", linkText: "應用開發與客製化" }
      ]
    ]
  },
  {
    title: "資源",
    links: [
      [
        { link: "/news", linkText: "最新消息" },
        { link: "/success", linkText: "成功案例" }
      ]
    ]
  },
  {
    title: "關於我們",
    links: [
      [
        { link: "/aboutus", linkText: "關於我們" },
        { link: "/contactus", linkText: "聯絡我們" },
        { link: "https://www.asus.com/", linkText: "華碩官網", external: true }
      ]
    ]
  }
];

const ext = "";

const $$Astro$A = createAstro("https://www.Asus.com.tw");
const $$A = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$A, $$props, $$slots);
  Astro2.self = $$A;
  const {
    IDName,
    className,
    link,
    extend,
    target,
    title,
    html,
    variant,
    button,
    round = true,
    disabled,
    attribute = {},
    style,
    block
  } = Astro2.props;
  const href = link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#";
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(IDName, "id")}${addAttribute(className, "class:list")}${addAttribute(href, "href")}${addAttribute(target, "target")}${addAttribute(disabled, "disabled")}${addAttribute(variant, "data-variant")}${addAttribute(title, "title")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>${renderSlot($$result, $$slots["default"], renderTemplate`${title}`)}
${unescapeHTML(html)}</a>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/a.astro", void 0);

const $$Astro$z = createAstro("https://www.Asus.com.tw");
const $$CollapseArrow = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$z, $$props, $$slots);
  Astro2.self = $$CollapseArrow;
  const { IDName, className, style, attribute = {}, Tag = "span" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "collapseArrow"], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.5 0.5L6.00001 6.2L0.5 0.5" stroke="var(--color-gray-900, #181818)" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/arrows/collapseArrow.astro", void 0);

const $$Astro$y = createAstro("https://www.Asus.com.tw");
const $$Collapse = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$y, $$props, $$slots);
  Astro2.self = $$Collapse;
  const { IDName, className, buttonClassName, style, attribute = {}, title, show, data = [] } = Astro2.props;
  const componentId = IDName || `collapse-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute([
    className,
    "Collapse"
  ], "class:list")}${addAttribute({ ...style }, "style")} data-collapse${spreadAttributes(attribute)}>
    <button type="button"${addAttribute([
    "Collapse-button",
    buttonClassName
  ], "class:list")}${addAttribute(title, "title")} data-bs-toggle="collapse"${addAttribute(`#${componentId}`, "data-bs-target")}${addAttribute(show, "aria-expanded")}${addAttribute(componentId, "data-bs-controls")}>
        ${title}
        ${renderComponent($$result, "CollapseArrow", $$CollapseArrow, {})}
    </button>
    <div${addAttribute(componentId, "id")}${addAttribute(["collapse", { show }], "class:list")}>
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/collapse.astro", void 0);

const $$Logo$1 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="106" height="11" viewBox="0 0 106 11" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M17.3784 1.8584H11.1046C9.64999 1.8584 9.00294 2.76946 8.858 3.6391V1.8584H5.37426C4.88768 1.8584 4.65474 2.00334 4.41662 2.34499L3.45898 3.74263H17.3784V1.86358V1.8584Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M0 9.20646H2.50022L5.63196 4.14905L3.39574 3.93164L0 9.20646Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M19.8011 1.8584H17.7461V3.73746H19.8011V1.8584Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M32.8614 4.7981L26.4219 4.41504C26.4219 5.39857 27.0689 6.06116 28.1715 6.14916L32.7578 6.50116C33.1098 6.53222 33.3324 6.62022 33.3324 6.91527C33.3324 7.21033 33.084 7.29833 32.5663 7.29833H26.3184V9.20845H32.6957C34.7094 9.20845 35.5893 8.50445 35.5893 6.89974C35.5893 5.46069 34.7974 4.91716 32.8562 4.7981H32.8614Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M26.3341 4.41344L24.3049 4.29438V6.45297C24.3049 7.13109 23.9685 7.33297 22.7934 7.33297H21.1784C20.2104 7.33297 19.7963 7.05344 19.7963 6.45297V4.08732L17.7412 3.94238V6.63415H17.6946C17.5756 5.85768 17.2857 4.94662 15.329 4.81203L8.88953 4.38756C8.88953 5.37109 9.59352 5.96121 10.6961 6.08026L15.1789 6.53579C15.5309 6.56685 15.7949 6.67038 15.7949 6.96027C15.7949 7.28121 15.5309 7.31227 15.1168 7.31227H8.81188V4.37203L6.75684 4.23744V9.20685H15.1323C17.001 9.20685 17.6015 8.23885 17.6895 7.42615H17.736C17.969 8.70474 19.0871 9.20685 20.9817 9.20685H23.0678C25.2885 9.20685 26.3289 8.52874 26.3289 6.94474V4.41862L26.3341 4.41344Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M35.4493 3.74332V1.86426H28.5387C27.0997 1.86426 26.4526 2.75461 26.3387 3.6139C26.3387 3.62426 26.3387 3.63461 26.3387 3.64496V1.86426H24.3096V3.74332H35.4493Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M97.5928 0L101.066 5.50259L97.5928 11H102.402L103.473 9.30729L105.875 5.50259L103.473 1.69271L102.402 0H97.5928Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M101.062 5.5L103.47 9.30471L105.871 5.5H101.062Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M101.062 5.50129H105.871L103.47 1.69141L101.062 5.50129Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M42.7969 9.15917V1.91211H46.1926C47.0623 1.91211 47.7248 2.08293 48.1804 2.42458C48.6359 2.76623 48.8637 3.22176 48.8637 3.79634C48.8637 4.18458 48.7756 4.5107 48.5945 4.78505C48.4133 5.0594 48.1752 5.26646 47.875 5.41658C47.5747 5.5667 47.2486 5.63917 46.8966 5.63917L47.083 5.26646C47.4919 5.26646 47.8542 5.33893 48.1804 5.48905C48.5065 5.63917 48.7601 5.8514 48.9516 6.13611C49.1432 6.42081 49.2364 6.77281 49.2364 7.19211C49.2364 7.81328 48.9982 8.2947 48.522 8.64152C48.0458 8.98834 47.3366 9.15917 46.3997 9.15917H42.7969ZM44.1427 8.10317H46.3168C46.819 8.10317 47.2072 8.02034 47.4764 7.8547C47.7455 7.68905 47.8801 7.42505 47.8801 7.05752C47.8801 6.68999 47.7455 6.43634 47.4764 6.26552C47.2072 6.0947 46.819 6.01187 46.3168 6.01187H44.0392V4.96623H46.0477C46.5187 4.96623 46.8759 4.8834 47.1295 4.71776C47.3832 4.55211 47.5074 4.30364 47.5074 3.97234C47.5074 3.64105 47.3832 3.38223 47.1295 3.21658C46.8759 3.05093 46.5187 2.96811 46.0477 2.96811H44.1427V8.10317Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M53.6881 9.26758C52.6942 9.26758 51.9178 8.98805 51.3535 8.42899C50.7893 7.86993 50.5098 7.0624 50.5098 6.0064V1.91699H51.8556V5.95464C51.8556 6.70005 52.0161 7.24358 52.337 7.58005C52.658 7.91652 53.1135 8.08734 53.6984 8.08734C54.2834 8.08734 54.7389 7.91652 55.0547 7.58005C55.3704 7.24358 55.5309 6.70005 55.5309 5.95464V1.91699H56.8561V6.0064C56.8561 7.0624 56.5765 7.86993 56.0123 8.42899C55.4481 8.98805 54.6768 9.26758 53.6881 9.26758Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M60.8867 9.26955C60.3225 9.26955 59.7789 9.18672 59.2613 9.02625C58.7436 8.86578 58.3347 8.65355 58.0293 8.3999L58.4952 7.35425C58.7851 7.58202 59.1422 7.77355 59.5719 7.92367C60.0015 8.07378 60.4363 8.15143 60.8867 8.15143C61.2646 8.15143 61.5752 8.11002 61.8081 8.02719C62.041 7.94437 62.217 7.83049 62.3257 7.69072C62.4344 7.55096 62.4914 7.39049 62.4914 7.20931C62.4914 6.98672 62.4137 6.81072 62.2533 6.67614C62.0928 6.54155 61.8909 6.43284 61.6373 6.35519C61.3836 6.27755 61.1041 6.1999 60.7987 6.13261C60.4933 6.06531 60.1827 5.98249 59.8773 5.88931C59.5719 5.79614 59.2923 5.67708 59.0387 5.52696C58.7851 5.37684 58.5832 5.18014 58.4227 4.93166C58.2622 4.68319 58.1846 4.36743 58.1846 3.97919C58.1846 3.59096 58.2881 3.22343 58.5004 2.89731C58.7126 2.57119 59.0335 2.30719 59.4632 2.11049C59.8928 1.91378 60.4415 1.81543 61.1041 1.81543C61.5389 1.81543 61.9686 1.87237 62.3982 1.98108C62.8278 2.08978 63.2006 2.25025 63.5163 2.45731L63.0918 3.50296C62.7657 3.31143 62.4344 3.16649 62.0876 3.07331C61.7408 2.98014 61.4095 2.93355 61.0937 2.93355C60.721 2.93355 60.4208 2.98014 60.1879 3.06814C59.9549 3.15614 59.7893 3.27519 59.6806 3.42014C59.5719 3.56508 59.5201 3.73072 59.5201 3.91708C59.5201 4.13966 59.5978 4.31567 59.753 4.45025C59.9083 4.58484 60.1102 4.68837 60.3639 4.76602C60.6175 4.84367 60.897 4.91614 61.2076 4.98861C61.5182 5.06108 61.8288 5.1439 62.1342 5.2319C62.4396 5.3199 62.7191 5.43896 62.9728 5.5839C63.2264 5.72884 63.4283 5.92555 63.5836 6.17402C63.7389 6.42249 63.8165 6.73825 63.8165 7.11614C63.8165 7.49402 63.713 7.86155 63.5008 8.18766C63.2886 8.51378 62.9676 8.77778 62.5328 8.97449C62.098 9.17119 61.5493 9.26955 60.8867 9.26955Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M65.2478 9.15917V1.91211H66.5937V9.15917H65.2478Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M68.2451 9.15917V1.91211H69.3529L73.8978 7.49234H73.3491V1.91211H74.6846V9.15917H73.5768L69.0319 3.57893H69.5806V9.15917H68.2451Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M76.3232 9.15917V1.91211H81.6136V3.04058H77.6691V8.0307H81.7585V9.15917H76.3232ZM77.5656 6.03258V4.92481H81.1684V6.03258H77.5656Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M85.6045 9.26955C85.0402 9.26955 84.4967 9.18672 83.9791 9.02625C83.4614 8.86578 83.0525 8.65355 82.7471 8.3999L83.213 7.35425C83.5028 7.58202 83.86 7.77355 84.2897 7.92367C84.7193 8.07378 85.1541 8.15143 85.6045 8.15143C85.9823 8.15143 86.2929 8.11002 86.5259 8.02719C86.7588 7.94437 86.9348 7.83049 87.0435 7.69072C87.1522 7.55096 87.2092 7.39049 87.2092 7.20931C87.2092 6.98672 87.1315 6.81072 86.971 6.67614C86.8106 6.54155 86.6087 6.43284 86.355 6.35519C86.1014 6.27755 85.8219 6.1999 85.5165 6.13261C85.2111 6.06531 84.9005 5.98249 84.5951 5.88931C84.2897 5.79614 84.0101 5.67708 83.7565 5.52696C83.5028 5.37684 83.301 5.18014 83.1405 4.93166C82.98 4.68319 82.9024 4.36743 82.9024 3.97919C82.9024 3.59096 83.0059 3.22343 83.2181 2.89731C83.4304 2.57119 83.7513 2.30719 84.1809 2.11049C84.6106 1.91378 85.1593 1.81543 85.8219 1.81543C86.2567 1.81543 86.6863 1.87237 87.116 1.98108C87.5456 2.08978 87.9183 2.25025 88.2341 2.45731L87.8096 3.50296C87.4835 3.31143 87.1522 3.16649 86.8054 3.07331C86.4586 2.98014 86.1273 2.93355 85.8115 2.93355C85.4388 2.93355 85.1386 2.98014 84.9056 3.06814C84.6727 3.15614 84.5071 3.27519 84.3984 3.42014C84.2896 3.56508 84.2379 3.73072 84.2379 3.91708C84.2379 4.13966 84.3155 4.31567 84.4708 4.45025C84.6261 4.58484 84.828 4.68837 85.0816 4.76602C85.3353 4.84367 85.6148 4.91614 85.9254 4.98861C86.236 5.06108 86.5466 5.1439 86.852 5.2319C87.1574 5.3199 87.4369 5.43896 87.6906 5.5839C87.9442 5.72884 88.1461 5.92555 88.3014 6.17402C88.4567 6.42249 88.5343 6.73825 88.5343 7.11614C88.5343 7.49402 88.4308 7.86155 88.2186 8.18766C88.0063 8.51378 87.6854 8.77778 87.2506 8.97449C86.8158 9.17119 86.267 9.26955 85.6045 9.26955Z" fill="var(--color-gray-700, #4d4d4d)"></path>
    <path d="M92.2216 9.26955C91.6574 9.26955 91.1139 9.18672 90.5962 9.02625C90.0786 8.86578 89.6697 8.65355 89.3643 8.3999L89.8301 7.35425C90.12 7.58202 90.4772 7.77355 90.9068 7.92367C91.3365 8.07378 91.7713 8.15143 92.2216 8.15143C92.5995 8.15143 92.9101 8.11002 93.143 8.02719C93.376 7.94437 93.552 7.83049 93.6607 7.69072C93.7694 7.55096 93.8263 7.39049 93.8263 7.20931C93.8263 6.98672 93.7487 6.81072 93.5882 6.67614C93.4278 6.54155 93.2259 6.43284 92.9722 6.35519C92.7186 6.27755 92.4391 6.1999 92.1336 6.13261C91.8282 6.06531 91.5176 5.98249 91.2122 5.88931C90.9068 5.79614 90.6273 5.67708 90.3737 5.52696C90.12 5.37684 89.9181 5.18014 89.7577 4.93166C89.5972 4.68319 89.5195 4.36743 89.5195 3.97919C89.5195 3.59096 89.6231 3.22343 89.8353 2.89731C90.0475 2.57119 90.3685 2.30719 90.7981 2.11049C91.2278 1.91378 91.7765 1.81543 92.4391 1.81543C92.8739 1.81543 93.3035 1.87237 93.7332 1.98108C94.1628 2.08978 94.5355 2.25025 94.8513 2.45731L94.4268 3.50296C94.1007 3.31143 93.7694 3.16649 93.4226 3.07331C93.0758 2.98014 92.7445 2.93355 92.4287 2.93355C92.056 2.93355 91.7558 2.98014 91.5228 3.06814C91.2899 3.15614 91.1242 3.27519 91.0155 3.42014C90.9068 3.56508 90.8551 3.73072 90.8551 3.91708C90.8551 4.13966 90.9327 4.31567 91.088 4.45025C91.2433 4.58484 91.4452 4.68837 91.6988 4.76602C91.9525 4.84367 92.232 4.91614 92.5426 4.98861C92.8532 5.06108 93.1638 5.1439 93.4692 5.2319C93.7746 5.3199 94.0541 5.43896 94.3077 5.5839C94.5614 5.72884 94.7633 5.92555 94.9186 6.17402C95.0739 6.42249 95.1515 6.73825 95.1515 7.11614C95.1515 7.49402 95.048 7.86155 94.8357 8.18766C94.6235 8.51378 94.3026 8.77778 93.8678 8.97449C93.4329 9.17119 92.8842 9.26955 92.2216 9.26955Z" fill="var(--color-gray-700, #4d4d4d)"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/footer/logo.astro", void 0);

const $$Astro$x = createAstro("https://www.Asus.com.tw");
const $$Footer = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$x, $$props, $$slots);
  Astro2.self = $$Footer;
  const { IDName = "footer", className, style, attribute = {}, pages = [], showBorderTop = false } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<footer${addAttribute(IDName, "id")}${addAttribute(["footer", className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="footer-top">
        ${showBorderTop && renderTemplate`<div class="footer-top-border"></div>`}
        <div class="footer-top-body">
            <div class="footer-top-body-top">
                ${renderComponent($$result, "Logo", $$Logo$1, {})}
                <div class="footer-breadcrumb">
                    ${pages.map((page) => renderTemplate`${renderComponent($$result, "A", $$A, { "className": "label-02 !lh-138.5%" }, { "default": ($$result2) => renderTemplate`/ ${page}&nbsp;` })}`)}
                </div>
            </div>
            <div class="footer-links">
                ${data.map((item, i) => renderTemplate`<div class="footer-links-item">
                            <strong class="footer-links-title">${item.title}</strong>
                            <div class="footer-links-body">
                                ${item.links.map((x) => renderTemplate`<div class="footer-links-body-item">
                                        ${x.map((y) => renderTemplate`${renderComponent($$result, "A", $$A, { "className": "footer-links-body-item-link", "link": y.link, "title": y.linkText, "extend": y.external })}`)}
                                    </div>`)}
                            </div>
                        </div>`)}
            </div>
            <div class="footer-mobile">
                ${data.map((item, i) => renderTemplate`${renderComponent($$result, "Collapse", $$Collapse, { "title": item.title, "buttonClassName": "footer-mobile-title !!lh-125", "style": { ...i === 0 ? { "--collapse-border-width": "0" } : {} } }, { "default": ($$result2) => renderTemplate`
                            <div class="footer-mobile-body">
                                ${item.links.map((x) => renderTemplate`<div class="footer-mobile-body-item">
                                        ${x.map((y) => renderTemplate`${renderComponent($$result2, "A", $$A, { "className": "footer-mobile-body-item-link", "link": y.link, "title": y.linkText, "extend": y.external })}`)}
                                    </div>`)}
                            </div>
                        ` })}`)}
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="footer-bottom-body">
            <span class="footer-copyright">© 2025 ASUSTeK Computer Inc. All rights reserved.</span>
            <div class="footer-bottom-body-links">
                ${renderComponent($$result, "A", $$A, { "className": "footer-bottom-body-links-item" }, { "default": ($$result2) => renderTemplate`Cookie 設定` })}
                <div class="footer-bottom-body-links-bar"></div>
                ${renderComponent($$result, "A", $$A, { "className": "footer-bottom-body-links-item" }, { "default": ($$result2) => renderTemplate`隱私權保護政策` })}
                <div class="footer-bottom-body-links-bar"></div>
                ${renderComponent($$result, "A", $$A, { "className": "footer-bottom-body-links-item" }, { "default": ($$result2) => renderTemplate`使用者條款` })}
            </div>
        </div>
    </div>
</footer>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/footer/footer.astro", void 0);

const NavsData = [
  {
    title: "解決方案",
    link: "/solution",
    children: [
      {
        title: "解決方案",
        subTitle: "選擇 ASUS Business，不只是選擇技術，更是選擇可靠的合作夥伴。我們以創新、穩定與安全為核心，助力企業持續成長。",
        linkText: "探索解決方案",
        link: "/solution",
        children: [
          {
            title: "依產業",
            links: [
              [{ linkText: "科技與製造" }, { linkText: "零售與電商" }, { linkText: "餐飲與連鎖服務" }, { linkText: "医療與照護" }, { linkText: "科技照護設備及智慧居家系統" }],
              [{ linkText: "教育與訓練" }, { linkText: "建築與工程" }, { linkText: "旅宿與觀光" }, { linkText: "顧問服務" }, { linkText: "策略規劃與企業流程再造" }]
            ]
          },
          {
            title: "依企業規模",
            links: [
              [{ linkText: "微型 (1-10人)" }, { linkText: "小型 (10-49人)" }, { linkText: "中型 (50-199人)" }, { linkText: "大型 (200-500人)" }],
              [{ linkText: "巨型 (500人以上)" }, { linkText: "全球企業 (超過五百名以上)" }]
            ]
          }
        ]
      }
    ]
  },
  {
    title: "合作夥伴",
    link: "/ivy",
    children: [
      {
        title: "合作夥伴",
        subTitle: "我們與各領域的專業夥伴攜手合作，建立跨產業的生態系，為企業提供更完整、更具價值的解決方案。",
        linkText: "探索合作夥伴",
        link: "/ivy",
        children: [
          {
            title: "依照類型",
            links: [
              [{ linkText: "雲端與基礎設施" }, { linkText: "資安與合規服務" }, { linkText: "企業系統導入整合" }, { linkText: "應用開發與客製化" }],
              [{ linkText: "數據分析與智能應用" }, { linkText: "顧問與專案交付服務" }, { linkText: "IT資源與資產服務" }]
            ]
          },
          {
            title: "依服務地區",
            links: [
              [{ linkText: "北部地區" }, { linkText: "中部地區" }, { linkText: "南部地區" }, { linkText: "東部地區" }],
              [{ linkText: "離島地區" }]
            ]
          }
        ]
      }
    ]
  },
  {
    title: "成功案例",
    link: "/success"
  },
  {
    title: "最新消息",
    link: "/news"
  },
  {
    title: "關於我們",
    link: "/aboutus"
  }
];

const $$Astro$w = createAstro("https://www.Asus.com.tw");
const $$MegaMenu$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$w, $$props, $$slots);
  Astro2.self = $$MegaMenu$1;
  const {
    IDName,
    className,
    style,
    attribute = {},
    data = [],
    position = "left",
    type = "dropdown",
    transition = true
  } = Astro2.props;
  return renderTemplate`<!-- Mega Menu Container - 大型選單容器 -->${maybeRenderHead()}<div${addAttribute(IDName ? `${IDName}mega-menu` : void 0, "id")}${addAttribute(["mega-menu", className], "class:list")}${addAttribute(style, "style")} data-mega-menu${addAttribute(position, "data-mega-menu-position")}${addAttribute(type, "data-mega-menu-type")}${spreadAttributes(transition ? { "data-mega-menu-transition": "" } : {})}${spreadAttributes(attribute)}>
    
    <div class="mega-menu-body">
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/megaMenu/megaMenu.astro", void 0);

const $$Arrow12 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="4" height="7" viewBox="0 0 4 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.146751 0.14169C0.240501 0.0518466 0.349876 0.00497159 0.474876 0.00106534C0.603782 -0.00674716 0.719016 0.0284091 0.820579 0.106534L0.855735 0.14169L3.68581 2.97177C3.73269 3.01864 3.76784 3.07333 3.79128 3.13583C3.81863 3.19442 3.8323 3.25692 3.8323 3.32333C3.8323 3.38974 3.81863 3.45419 3.79128 3.51669C3.76784 3.57919 3.73269 3.63388 3.68581 3.68075L0.855735 6.50497C0.758079 6.60263 0.638938 6.65146 0.498313 6.65146C0.361594 6.65146 0.244407 6.60263 0.146751 6.50497C0.0490945 6.40732 0.000266335 6.29013 0.000266335 6.15341C0.000266335 6.01669 0.0490945 5.8995 0.146751 5.80185L2.62527 3.32333L0.146751 0.850675L0.117454 0.809659C0.0354226 0.712003 -0.00363991 0.600675 0.000266335 0.475675C0.00807884 0.346768 0.056907 0.23544 0.146751 0.14169Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-12.astro", void 0);

const $$Arrow13 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="5" height="8" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.15898 0.153498C0.260542 0.0561671 0.379032 0.00538589 0.514449 0.00115412C0.654097 -0.00730942 0.778934 0.0307765 0.88896 0.115412L0.927046 0.153498L3.99296 3.21942C4.04375 3.2702 4.08183 3.32944 4.10722 3.39715C4.13684 3.46063 4.15166 3.52834 4.15166 3.60028C4.15166 3.67222 4.13684 3.74204 4.10722 3.80975C4.08183 3.87746 4.04375 3.9367 3.99296 3.98748L0.927046 7.04705C0.821252 7.15285 0.692183 7.20574 0.539839 7.20574C0.391727 7.20574 0.264774 7.15285 0.15898 7.04705C0.0531857 6.94126 0.00028853 6.8143 0.00028853 6.66619C0.00028853 6.51808 0.0531857 6.39113 0.15898 6.28533L2.84404 3.60028L0.15898 0.921564L0.127242 0.877131C0.0383745 0.771336 -0.00394324 0.650731 0.00028853 0.515314C0.00875207 0.375666 0.0616492 0.25506 0.15898 0.153498Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-13.astro", void 0);

const $$Arrow14 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="5" height="8" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.171209 0.165305C0.280584 0.0604877 0.408188 0.00580019 0.554022 0.0012429C0.704412 -0.00787169 0.838852 0.0331439 0.957342 0.12429L0.998358 0.165305L4.30012 3.46706C4.3548 3.52175 4.39582 3.58555 4.42316 3.65847C4.45506 3.72683 4.47101 3.79975 4.47101 3.87722C4.47101 3.95469 4.45506 4.02989 4.42316 4.10281C4.39582 4.17572 4.3548 4.23952 4.30012 4.29421L0.998358 7.58913C0.884425 7.70307 0.745428 7.76003 0.581365 7.76003C0.42186 7.76003 0.285141 7.70307 0.171209 7.58913C0.0572769 7.4752 0.000310724 7.33848 0.000310724 7.17898C0.000310724 7.01947 0.0572769 6.88275 0.171209 6.76882L3.06281 3.87722L0.171209 0.992454L0.137029 0.944602C0.0413263 0.83067 -0.00424657 0.700787 0.000310724 0.554954C0.00942531 0.404563 0.0663914 0.27468 0.171209 0.165305Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-14.astro", void 0);

const $$Arrow16 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="9" viewBox="0 0 6 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.195668 0.18892C0.320668 0.0691288 0.466501 0.00662879 0.633168 0.00142045C0.805043 -0.00899621 0.958688 0.0378788 1.09411 0.142045L1.14098 0.18892L4.91442 3.96236C4.97692 4.02486 5.02379 4.09777 5.05504 4.18111C5.0915 4.25923 5.10973 4.34257 5.10973 4.43111C5.10973 4.51965 5.0915 4.60559 5.05504 4.68892C5.02379 4.77225 4.97692 4.84517 4.91442 4.90767L1.14098 8.6733C1.01077 8.8035 0.851918 8.86861 0.664418 8.86861C0.482126 8.86861 0.325876 8.8035 0.195668 8.6733C0.0654593 8.54309 0.000355114 8.38684 0.000355114 8.20455C0.000355114 8.02225 0.0654593 7.866 0.195668 7.7358L3.50036 4.43111L0.195668 1.13423L0.156605 1.07955C0.0472301 0.949337 -0.00485322 0.8009 0.000355114 0.634233C0.0107718 0.462358 0.0758759 0.31392 0.195668 0.18892Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-16.astro", void 0);

const $$Arrow18 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.220126 0.212536C0.360751 0.0777699 0.524814 0.00745739 0.712314 0.00159801C0.905673 -0.0101207 1.07852 0.0426136 1.23087 0.159801L1.2836 0.212536L5.52872 4.45765C5.59903 4.52797 5.65177 4.61 5.68692 4.70375C5.72794 4.79164 5.74845 4.88539 5.74845 4.985C5.74845 5.08461 5.72794 5.18129 5.68692 5.27504C5.65177 5.36879 5.59903 5.45082 5.52872 5.52113L1.2836 9.75746C1.13712 9.90394 0.958407 9.97718 0.74747 9.97718C0.542392 9.97718 0.36661 9.90394 0.220126 9.75746C0.0736417 9.61097 0.000399503 9.43519 0.000399503 9.23011C0.000399503 9.02504 0.0736417 8.84925 0.220126 8.70277L3.9379 4.985L0.220126 1.27601L0.176181 1.21449C0.0531339 1.068 -0.00545987 0.901012 0.000399503 0.713512C0.0121183 0.520153 0.0853604 0.353161 0.220126 0.212536Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-18.astro", void 0);

const $$Arrow20 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.244585 0.236151C0.400835 0.086411 0.583126 0.00828598 0.79146 0.00177557C1.0063 -0.0112453 1.19836 0.0473485 1.36763 0.177557L1.42623 0.236151L6.14302 4.95295C6.22115 5.03107 6.27974 5.12222 6.3188 5.22639C6.36438 5.32404 6.38716 5.42821 6.38716 5.53889C6.38716 5.64956 6.36438 5.75698 6.3188 5.86115C6.27974 5.96532 6.22115 6.05646 6.14302 6.13459L1.42623 10.8416C1.26346 11.0044 1.0649 11.0858 0.830522 11.0858C0.602657 11.0858 0.407345 11.0044 0.244585 10.8416C0.0818241 10.6789 0.000443892 10.4835 0.000443892 10.2557C0.000443892 10.0278 0.0818241 9.8325 0.244585 9.66974L4.37544 5.53889L0.244585 1.41779L0.195756 1.34943C0.0590376 1.18667 -0.00606652 1.00112 0.000443892 0.792791C0.0134647 0.577947 0.0948449 0.392401 0.244585 0.236151Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-20.astro", void 0);

const $$Arrow24 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.293501 0.283381C0.481001 0.103693 0.699751 0.00994318 0.949751 0.00213068C1.20756 -0.0134943 1.43803 0.0568182 1.64116 0.213068L1.71147 0.283381L7.37163 5.94354C7.46538 6.03729 7.53569 6.14666 7.58256 6.27166C7.63725 6.38885 7.6646 6.51385 7.6646 6.64666C7.6646 6.77947 7.63725 6.90838 7.58256 7.03338C7.53569 7.15838 7.46538 7.26776 7.37163 7.36151L1.71147 13.0099C1.51616 13.2053 1.27788 13.3029 0.996626 13.3029C0.723189 13.3029 0.488814 13.2053 0.293501 13.0099C0.0981889 12.8146 0.00053267 12.5803 0.00053267 12.3068C0.00053267 12.0334 0.0981889 11.799 0.293501 11.6037L5.25053 6.64666L0.293501 1.70135L0.234908 1.61932C0.0708452 1.42401 -0.00727983 1.20135 0.00053267 0.951349C0.0161577 0.693537 0.113814 0.470881 0.293501 0.283381Z" fill="currentColor"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/svg/arrow-24.astro", void 0);

const $$Astro$v = createAstro("https://www.Asus.com.tw");
const $$Link = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$v, $$props, $$slots);
  Astro2.self = $$Link;
  const {
    IDName,
    className,
    link,
    extend,
    target,
    title,
    html,
    variant,
    button,
    round,
    disabled,
    attribute = {},
    style,
    block,
    showArrow = false,
    webFontInstalled = false,
    size = "16",
    font = "roboto",
    weight = "regular",
    status = "default",
    Tag = "a"
  } = Astro2.props;
  const href = link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#";
  const linkClasses = [
    "link-with-arrow",
    `size_${size}`,
    `font_${font}`,
    showArrow ? "" : "no-arrow",
    webFontInstalled ? "web-font" : "svg-arrow",
    { btn: button },
    { "btn-block": block, "btn-round": round },
    status && status !== "default" && status,
    disabled && "disabled",
    className
  ].filter(Boolean);
  const arrowComponents = {
    "12": $$Arrow12,
    "13": $$Arrow13,
    "14": $$Arrow14,
    "16": $$Arrow16,
    "18": $$Arrow18,
    "20": $$Arrow20,
    "24": $$Arrow24
  };
  const ArrowComponent = arrowComponents[size] || $$Arrow16;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": linkClasses, "href": href, "target": target, "disabled": disabled, "data-variant": variant, "title": Tag === "a" ? title : void 0, "aria-label": title, ...attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<span${addAttribute(["link-text", `weight_${weight}`], "class:list")}>
        ${html ? renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`${unescapeHTML(html)}` })}` : renderTemplate`${renderSlot($$result2, $$slots["default"], renderTemplate`${title}`)}`}
    </span>
    ${showArrow && (webFontInstalled ? renderTemplate`<span class="link-arrow web-font-arrow"></span>` : renderTemplate`<span class="link-arrow svg-arrow">
                ${renderComponent($$result2, "ArrowComponent", ArrowComponent, {})}
            </span>`)}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/link/link.astro", void 0);

const $$Astro$u = createAstro("https://www.Asus.com.tw");
const $$MegaMenu = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$u, $$props, $$slots);
  Astro2.self = $$MegaMenu;
  const {
    IDName,
    className,
    style,
    attribute = {},
    data = [],
    position = "left",
    type = "dropdown",
    transition = true
  } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyMegaMenu", $$MegaMenu$1, { "IDName": IDName, "className": className, "style": style, "attribute": attribute, "data": data, "position": position, "type": type, "transition": transition }, { "default": ($$result2) => renderTemplate`${data.map((x, i) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`
                ${maybeRenderHead()}<div class="mega-menu-item">
                    <div class="mega-menu-head">
                        <strong class="mega-menu-title">${x.title}</strong>
                        <span class="mega-menu-text">${x.subTitle}</span>
                    </div>
                    ${renderComponent($$result3, "ALink", $$Link, { "link": x.link, "title": x.linkText, "showArrow": true })}
                </div>
                ${x.children && x.children.map((y, j) => renderTemplate`<div class="menu-links">
                            <span class="menu-link-title">
                                ${y.title}
                            </span>
                            <div class="menu-link-list">
                                ${y.links.map((z, k) => renderTemplate`<div class="menu-link-ul">
                                        ${z.map((u, v) => renderTemplate`${renderComponent($$result3, "A", $$A, { "link": u.link, "title": u.linkText })}`)}
                                    </div>`)}
                            </div>
                        </div>`)}` })}`)}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/megaMenu.astro", void 0);

const $$Astro$t = createAstro("https://www.Asus.com.tw");
const $$Nav = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$t, $$props, $$slots);
  Astro2.self = $$Nav;
  const { IDName = "headerNav", className, style, attribute = {}, data = [], type = "dropdown" } = Astro2.props;
  return renderTemplate`<!-- Navigation Container - 導航容器 -->${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <nav>
        ${/**
   * 遍歷導航資料陣列，渲染每個導航項目
   * 如果有子選單，添加 mega menu trigger 屬性
   * */
  data.map((x, i) => renderTemplate`<div class="headerNavItem"${spreadAttributes(x.hasOwnProperty("children") ? { "data-mega-menu-trigger": "", "data-mega-menu-type": type } : {})}>
                    
                    ${renderComponent($$result, "ALink", $$A, { "link": x.link, "className": "headerNavLink" }, { "default": ($$result2) => renderTemplate`
                        <p>${x.title}</p>
                        <span>${x.subTitle}</span>
                    ` })}

                    
                    ${x.hasOwnProperty("children") && renderTemplate`${renderComponent($$result, "MegaMenu", $$MegaMenu, { "position": "center", "type": type, "attribute": {
    /* 第一個選單項目添加特殊標記 */
    "data-first": i === 0 ? "" : void 0
  }, "data": x.children })}`}
                </div>`)}
    </nav>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/nav.astro", void 0);

const $$Astro$s = createAstro("https://www.Asus.com.tw");
const $$TriggerButton = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$s, $$props, $$slots);
  Astro2.self = $$TriggerButton;
  const {
    IDName = "headerOffcanvas",
    className,
    style,
    attribute = {}
  } = Astro2.props;
  return renderTemplate`<!-- Mobile Menu Trigger Button - 手機版選單觸發按鈕 -->${maybeRenderHead()}<button${addAttribute(`${IDName}TriggerButton`, "id")} type="button"${addAttribute(["relative", className], "class:list")} data-bs-toggle="offcanvas" data-bs-target="#headerOffcanvas" aria-controls="headerOffcanvas"${addAttribute(style, "style")} title="header Offcanvas Trigger Button"${spreadAttributes(attribute)}>
    
    <span class="line"></span>
    <span class="line"></span>
</button>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/offcanvas/triggerButton.astro", void 0);

const $$BusinessHorizontalLight = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="205" height="22" viewBox="0 0 205 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M33.5702 3.58984H21.4502C18.6402 3.58984 17.3902 5.34984 17.1102 7.02984V3.58984H10.3802C9.44017 3.58984 8.99018 3.86984 8.53018 4.52984L6.68018 7.22984H33.5702V3.59984V3.58984Z" fill="var(--asus-black, #000000)"></path>
<path d="M0 17.7896H4.83L10.88 8.01961L6.56 7.59961L0 17.7896Z" fill="var(--asus-black, #000000)"></path>
<path d="M38.2498 3.58984H34.2798V7.21984H38.2498V3.58984Z" fill="var(--asus-black, #000000)"></path>
<path d="M63.4798 9.2693L51.0398 8.5293C51.0398 10.4293 52.2898 11.7093 54.4198 11.8793L63.2798 12.5593C63.9598 12.6193 64.3898 12.7893 64.3898 13.3593C64.3898 13.9293 63.9098 14.0993 62.9098 14.0993H50.8398V17.7893H63.1598C67.0498 17.7893 68.7498 16.4293 68.7498 13.3293C68.7498 10.5493 67.2198 9.4993 63.4698 9.2693H63.4798Z" fill="var(--asus-black, #000000)"></path>
<path d="M50.8898 8.52914L46.9698 8.29914V12.4691C46.9698 13.7791 46.3198 14.1691 44.0498 14.1691H40.9298C39.0598 14.1691 38.2598 13.6291 38.2598 12.4691V7.89914L34.2898 7.61914V12.8191H34.1998C33.9698 11.3191 33.4098 9.55914 29.6298 9.29914L17.1898 8.47914C17.1898 10.3791 18.5498 11.5191 20.6798 11.7491L29.3398 12.6291C30.0198 12.6891 30.5298 12.8891 30.5298 13.4491C30.5298 14.0691 30.0198 14.1291 29.2198 14.1291H17.0398V8.44914L13.0698 8.18914V17.7891H29.2498C32.8598 17.7891 34.0198 15.9191 34.1898 14.3491H34.2798C34.7298 16.8191 36.8898 17.7891 40.5498 17.7891H44.5798C48.8698 17.7891 50.8798 16.4791 50.8798 13.4191V8.53914L50.8898 8.52914Z" fill="var(--asus-black, #000000)"></path>
<path d="M68.4902 7.22961V3.59961H55.1402C52.3602 3.59961 51.1102 5.31961 50.8902 6.97961C50.8902 6.99961 50.8902 7.01961 50.8902 7.03961V3.59961H46.9702V7.22961H68.4902Z" fill="var(--asus-black, #000000)"></path>
<path d="M188.53 0L195.24 10.63L188.53 21.25H197.82L199.89 17.98L204.53 10.63L199.89 3.27L197.82 0H188.53Z" fill="var(--asus-blue-light, #0096D2)"></path>
<path d="M195.24 10.6309L199.89 17.9809L204.53 10.6309H195.24Z" fill="var(--asus-blue-dark, #0064d2)"></path>
<path d="M195.24 10.6295H204.53L199.89 3.26953L195.24 10.6295Z" fill="var(--asus-blue, #007dd2)"></path>
<path d="M82.6899 17.6895V3.68945H89.2499C90.9299 3.68945 92.2099 4.01945 93.0899 4.67945C93.9699 5.33945 94.4099 6.21945 94.4099 7.32945C94.4099 8.07945 94.2399 8.70945 93.8899 9.23945C93.5399 9.76945 93.0799 10.1695 92.4999 10.4595C91.9199 10.7495 91.2899 10.8895 90.6099 10.8895L90.9699 10.1695C91.7599 10.1695 92.4599 10.3095 93.0899 10.5995C93.7199 10.8895 94.2099 11.2995 94.5799 11.8495C94.9499 12.3995 95.1299 13.0795 95.1299 13.8895C95.1299 15.0895 94.6699 16.0195 93.7499 16.6895C92.8299 17.3595 91.4599 17.6895 89.6499 17.6895H82.6899ZM85.2899 15.6495H89.4899C90.4599 15.6495 91.2099 15.4895 91.7299 15.1695C92.2499 14.8495 92.5099 14.3395 92.5099 13.6295C92.5099 12.9195 92.2499 12.4295 91.7299 12.0995C91.2099 11.7695 90.4599 11.6095 89.4899 11.6095H85.0899V9.58945H88.9699C89.8799 9.58945 90.5699 9.42945 91.0599 9.10945C91.5499 8.78945 91.7899 8.30945 91.7899 7.66945C91.7899 7.02945 91.5499 6.52945 91.0599 6.20945C90.5699 5.88945 89.8799 5.72945 88.9699 5.72945H85.2899V15.6495Z" fill="var(--asus-black, #000000)"></path>
<path d="M103.73 17.8992C101.81 17.8992 100.31 17.3592 99.2198 16.2792C98.1298 15.1992 97.5898 13.6392 97.5898 11.5992V3.69922H100.19V11.4992C100.19 12.9392 100.5 13.9892 101.12 14.6392C101.74 15.2892 102.62 15.6192 103.75 15.6192C104.88 15.6192 105.76 15.2892 106.37 14.6392C106.98 13.9892 107.29 12.9392 107.29 11.4992V3.69922H109.85V11.5992C109.85 13.6392 109.31 15.1992 108.22 16.2792C107.13 17.3592 105.64 17.8992 103.73 17.8992Z" fill="var(--asus-black, #000000)"></path>
<path d="M117.63 17.9C116.54 17.9 115.49 17.74 114.49 17.43C113.49 17.12 112.7 16.71 112.11 16.22L113.01 14.2C113.57 14.64 114.26 15.01 115.09 15.3C115.92 15.59 116.76 15.74 117.63 15.74C118.36 15.74 118.96 15.66 119.41 15.5C119.86 15.34 120.2 15.12 120.41 14.85C120.62 14.58 120.73 14.27 120.73 13.92C120.73 13.49 120.58 13.15 120.27 12.89C119.96 12.63 119.57 12.42 119.08 12.27C118.59 12.12 118.05 11.97 117.46 11.84C116.87 11.71 116.27 11.55 115.68 11.37C115.09 11.19 114.55 10.96 114.06 10.67C113.57 10.38 113.18 10 112.87 9.52C112.56 9.04 112.41 8.43 112.41 7.68C112.41 6.93 112.61 6.22 113.02 5.59C113.43 4.96 114.05 4.45 114.88 4.07C115.71 3.69 116.77 3.5 118.05 3.5C118.89 3.5 119.72 3.61 120.55 3.82C121.38 4.03 122.1 4.34 122.71 4.74L121.89 6.76C121.26 6.39 120.62 6.11 119.95 5.93C119.28 5.75 118.64 5.66 118.03 5.66C117.31 5.66 116.73 5.75 116.28 5.92C115.83 6.09 115.51 6.32 115.3 6.6C115.09 6.88 114.99 7.2 114.99 7.56C114.99 7.99 115.14 8.33 115.44 8.59C115.74 8.85 116.13 9.05 116.62 9.2C117.11 9.35 117.65 9.49 118.25 9.63C118.85 9.77 119.45 9.93 120.04 10.1C120.63 10.27 121.17 10.5 121.66 10.78C122.15 11.06 122.54 11.44 122.84 11.92C123.14 12.4 123.29 13.01 123.29 13.74C123.29 14.47 123.09 15.18 122.68 15.81C122.27 16.44 121.65 16.95 120.81 17.33C119.97 17.71 118.91 17.9 117.63 17.9Z" fill="var(--asus-black, #000000)"></path>
<path d="M126.07 17.6895V3.68945H128.67V17.6895H126.07Z" fill="var(--asus-black, #000000)"></path>
<path d="M131.85 17.6895V3.68945H133.99L142.77 14.4695H141.71V3.68945H144.29V17.6895H142.15L133.37 6.90945H134.43V17.6895H131.85Z" fill="var(--asus-black, #000000)"></path>
<path d="M147.45 17.6895V3.68945H157.67V5.86945H150.05V15.5095H157.95V17.6895H147.45ZM149.85 11.6495V9.50945H156.81V11.6495H149.85Z" fill="var(--asus-black, #000000)"></path>
<path d="M165.39 17.9C164.3 17.9 163.25 17.74 162.25 17.43C161.25 17.12 160.46 16.71 159.87 16.22L160.77 14.2C161.33 14.64 162.02 15.01 162.85 15.3C163.68 15.59 164.52 15.74 165.39 15.74C166.12 15.74 166.72 15.66 167.17 15.5C167.62 15.34 167.96 15.12 168.17 14.85C168.38 14.58 168.49 14.27 168.49 13.92C168.49 13.49 168.34 13.15 168.03 12.89C167.72 12.63 167.33 12.42 166.84 12.27C166.35 12.12 165.81 11.97 165.22 11.84C164.63 11.71 164.03 11.55 163.44 11.37C162.85 11.19 162.31 10.96 161.82 10.67C161.33 10.38 160.94 10 160.63 9.52C160.32 9.04 160.17 8.43 160.17 7.68C160.17 6.93 160.37 6.22 160.78 5.59C161.19 4.96 161.81 4.45 162.64 4.07C163.47 3.69 164.53 3.5 165.81 3.5C166.65 3.5 167.48 3.61 168.31 3.82C169.14 4.03 169.86 4.34 170.47 4.74L169.65 6.76C169.02 6.39 168.38 6.11 167.71 5.93C167.04 5.75 166.4 5.66 165.79 5.66C165.07 5.66 164.49 5.75 164.04 5.92C163.59 6.09 163.27 6.32 163.06 6.6C162.85 6.88 162.75 7.2 162.75 7.56C162.75 7.99 162.9 8.33 163.2 8.59C163.5 8.85 163.89 9.05 164.38 9.2C164.87 9.35 165.41 9.49 166.01 9.63C166.61 9.77 167.21 9.93 167.8 10.1C168.39 10.27 168.93 10.5 169.42 10.78C169.91 11.06 170.3 11.44 170.6 11.92C170.9 12.4 171.05 13.01 171.05 13.74C171.05 14.47 170.85 15.18 170.44 15.81C170.03 16.44 169.41 16.95 168.57 17.33C167.73 17.71 166.67 17.9 165.39 17.9Z" fill="var(--asus-black, #000000)"></path>
<path d="M178.17 17.9C177.08 17.9 176.03 17.74 175.03 17.43C174.03 17.12 173.24 16.71 172.65 16.22L173.55 14.2C174.11 14.64 174.8 15.01 175.63 15.3C176.46 15.59 177.3 15.74 178.17 15.74C178.9 15.74 179.5 15.66 179.95 15.5C180.4 15.34 180.74 15.12 180.95 14.85C181.16 14.58 181.27 14.27 181.27 13.92C181.27 13.49 181.12 13.15 180.81 12.89C180.5 12.63 180.11 12.42 179.62 12.27C179.13 12.12 178.59 11.97 178 11.84C177.41 11.71 176.81 11.55 176.22 11.37C175.63 11.19 175.09 10.96 174.6 10.67C174.11 10.38 173.72 10 173.41 9.52C173.1 9.04 172.95 8.43 172.95 7.68C172.95 6.93 173.15 6.22 173.56 5.59C173.97 4.96 174.59 4.45 175.42 4.07C176.25 3.69 177.31 3.5 178.59 3.5C179.43 3.5 180.26 3.61 181.09 3.82C181.92 4.03 182.64 4.34 183.25 4.74L182.43 6.76C181.8 6.39 181.16 6.11 180.49 5.93C179.82 5.75 179.18 5.66 178.57 5.66C177.85 5.66 177.27 5.75 176.82 5.92C176.37 6.09 176.05 6.32 175.84 6.6C175.63 6.88 175.53 7.2 175.53 7.56C175.53 7.99 175.68 8.33 175.98 8.59C176.28 8.85 176.67 9.05 177.16 9.2C177.65 9.35 178.19 9.49 178.79 9.63C179.39 9.77 179.99 9.93 180.58 10.1C181.17 10.27 181.71 10.5 182.2 10.78C182.69 11.06 183.08 11.44 183.38 11.92C183.68 12.4 183.83 13.01 183.83 13.74C183.83 14.47 183.63 15.18 183.22 15.81C182.81 16.44 182.19 16.95 181.35 17.33C180.51 17.71 179.45 17.9 178.17 17.9Z" fill="var(--asus-black, #000000)"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/logo/svg-astro/Business-Horizontal-Light.astro", void 0);

const $$BusinessVerticalLight = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="95" height="27" viewBox="0 0 95 27" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M33.5399 0.359375H21.4299C18.6199 0.359375 17.3699 2.11938 17.0899 3.78938V0.359375H10.3699C9.42994 0.359375 8.97994 0.639375 8.52994 1.29937L6.68994 3.98937H33.5499V0.359375H33.5399Z" fill="var(--asus-black, #000000)"></path>
<path d="M0 14.5394H4.83L10.87 4.77938L6.56 4.35938L0 14.5394Z" fill="var(--asus-black, #000000)"></path>
<path d="M38.22 0.359375H34.25V3.98937H38.22V0.359375Z" fill="var(--asus-black, #000000)"></path>
<path d="M63.4301 6.02906L51.0001 5.28906C51.0001 7.18906 52.2501 8.46906 54.3801 8.63906L63.2301 9.31906C63.9101 9.37906 64.3401 9.54906 64.3401 10.1091C64.3401 10.6691 63.8601 10.8491 62.8701 10.8491H50.8101V14.5391H63.1201C67.0101 14.5391 68.7101 13.1791 68.7101 10.0891C68.7101 7.30906 67.1801 6.25906 63.4301 6.02906Z" fill="var(--asus-black, #000000)"></path>
<path d="M50.8398 5.28891L46.9198 5.0589V9.2289C46.9198 10.5389 46.2698 10.9289 43.9998 10.9289H40.8798C39.0098 10.9289 38.2098 10.3889 38.2098 9.2289V4.65891L34.2398 4.37891V9.5689H34.1498C33.9198 8.0689 33.3598 6.3089 29.5798 6.0489L17.1498 5.2289C17.1498 7.1289 18.5098 8.2689 20.6398 8.4889L29.2898 9.36891C29.9698 9.42891 30.4798 9.61891 30.4798 10.1889C30.4798 10.8089 29.9698 10.8689 29.1698 10.8689H16.9998V5.19891L13.0298 4.93891V14.5289H29.1998C32.7998 14.5289 33.9698 12.6589 34.1398 11.0989H34.2298C34.6798 13.5689 36.8398 14.5289 40.4998 14.5289H44.5298C48.8098 14.5289 50.8298 13.2189 50.8298 10.1589V5.27891L50.8398 5.28891Z" fill="var(--asus-black, #000000)"></path>
<path d="M68.4302 3.98937V0.359375H55.1002C52.3202 0.359375 51.0702 2.07937 50.8502 3.73937C50.8502 3.75937 50.8502 3.77937 50.8502 3.79937V0.369374H46.9302V3.99937H68.4302V3.98937Z" fill="var(--asus-black, #000000)"></path>
<path d="M74.1299 0L82.6299 13.45L74.1299 26.91H85.8999L88.5099 22.77L94.3899 13.45L88.5099 4.14L85.8999 0H74.1299Z" fill="var(--asus-blue-light, #0096D2)"></path>
<path d="M82.6299 13.4492L88.5099 22.7692L94.3899 13.4492H82.6299Z" fill="var(--asus-blue-dark, #0064d2)"></path>
<path d="M82.6299 13.4506H94.3899L88.5099 4.14062L82.6299 13.4506Z" fill="var(--asus-blue, #007dd2)"></path>
<path d="M0.469961 26.3707V19.7207H3.58996C4.38996 19.7207 4.99996 19.8807 5.40996 20.1907C5.81996 20.5007 6.03996 20.9207 6.03996 21.4507C6.03996 21.8007 5.95996 22.1107 5.78996 22.3607C5.61996 22.6107 5.40996 22.8007 5.12996 22.9407C4.84996 23.0807 4.55996 23.1407 4.22996 23.1407L4.39996 22.8007C4.76996 22.8007 5.10996 22.8707 5.40996 23.0007C5.70996 23.1407 5.93996 23.3307 6.11996 23.5907C6.28996 23.8507 6.37996 24.1707 6.37996 24.5607C6.37996 25.1307 6.15996 25.5707 5.71996 25.8907C5.27996 26.2107 4.62996 26.3607 3.76996 26.3607H0.459961L0.469961 26.3707ZM1.69996 25.4107H3.69996C4.15996 25.4107 4.51996 25.3307 4.75996 25.1807C5.00996 25.0307 5.12996 24.7807 5.12996 24.4507C5.12996 24.1207 5.00996 23.8807 4.75996 23.7207C4.50996 23.5607 4.15996 23.4907 3.69996 23.4907H1.60996V22.5307H3.44996C3.87996 22.5307 4.20996 22.4507 4.43996 22.3007C4.66996 22.1507 4.78996 21.9207 4.78996 21.6207C4.78996 21.3207 4.66996 21.0807 4.43996 20.9307C4.20996 20.7807 3.87996 20.7007 3.44996 20.7007H1.69996V25.4107Z" fill="var(--asus-black, #000000)"></path>
<path d="M13.2498 26.4705C12.3398 26.4705 11.6198 26.2105 11.1098 25.7005C10.5898 25.1905 10.3398 24.4505 10.3398 23.4805V19.7305H11.5698V23.4405C11.5698 24.1205 11.7198 24.6205 12.0098 24.9305C12.2998 25.2405 12.7198 25.3905 13.2598 25.3905C13.7998 25.3905 14.2098 25.2305 14.4998 24.9305C14.7898 24.6205 14.9398 24.1205 14.9398 23.4405V19.7305H16.1598V23.4805C16.1598 24.4505 15.8998 25.1905 15.3898 25.7005C14.8698 26.2105 14.1598 26.4705 13.2598 26.4705H13.2498Z" fill="var(--asus-black, #000000)"></path>
<path d="M22.6498 26.4704C22.1298 26.4704 21.6298 26.4004 21.1598 26.2504C20.6798 26.1004 20.3098 25.9104 20.0298 25.6704L20.4598 24.7104C20.7298 24.9204 21.0598 25.0904 21.4498 25.2304C21.8398 25.3704 22.2398 25.4404 22.6598 25.4404C23.0098 25.4404 23.2898 25.4004 23.5098 25.3304C23.7298 25.2604 23.8798 25.1504 23.9898 25.0204C24.0898 24.8904 24.1398 24.7404 24.1398 24.5804C24.1398 24.3804 24.0698 24.2104 23.9198 24.0904C23.7698 23.9704 23.5898 23.8704 23.3498 23.8004C23.1198 23.7304 22.8598 23.6604 22.5798 23.6004C22.2998 23.5404 22.0198 23.4604 21.7298 23.3804C21.4498 23.3004 21.1898 23.1804 20.9598 23.0504C20.7298 22.9104 20.5398 22.7304 20.3898 22.5004C20.2398 22.2704 20.1698 21.9804 20.1698 21.6304C20.1698 21.2804 20.2698 20.9404 20.4598 20.6404C20.6498 20.3404 20.9498 20.1004 21.3398 19.9204C21.7398 19.7404 22.2398 19.6504 22.8498 19.6504C23.2498 19.6504 23.6398 19.7004 24.0398 19.8004C24.4398 19.9004 24.7698 20.0504 25.0698 20.2404L24.6798 21.2004C24.3798 21.0204 24.0798 20.8904 23.7598 20.8104C23.4398 20.7304 23.1398 20.6804 22.8498 20.6804C22.5098 20.6804 22.2298 20.7204 22.0198 20.8004C21.8098 20.8804 21.6498 20.9904 21.5498 21.1204C21.4498 21.2504 21.3998 21.4104 21.3998 21.5804C21.3998 21.7804 21.4698 21.9504 21.6098 22.0704C21.7498 22.1904 21.9398 22.2904 22.1698 22.3604C22.3998 22.4304 22.6598 22.5004 22.9398 22.5604C23.2198 22.6204 23.5098 22.7004 23.7898 22.7804C24.0698 22.8604 24.3298 22.9704 24.5598 23.1004C24.7898 23.2304 24.9798 23.4104 25.1198 23.6404C25.2598 23.8704 25.3298 24.1604 25.3298 24.5004C25.3298 24.8404 25.2298 25.1804 25.0398 25.4804C24.8498 25.7804 24.5498 26.0204 24.1498 26.2004C23.7498 26.3804 23.2498 26.4704 22.6398 26.4704H22.6498Z" fill="var(--asus-black, #000000)"></path>
<path d="M29.6401 26.3707V19.7207H30.8701V26.3707H29.6401Z" fill="var(--asus-black, #000000)"></path>
<path d="M35.3701 26.3707V19.7207H36.3901L40.5601 24.8407H40.0601V19.7207H41.2901V26.3707H40.2701L36.1001 21.2507H36.6001V26.3707H35.3701Z" fill="var(--asus-black, #000000)"></path>
<path d="M45.5701 26.3707V19.7207H50.4201V20.7607H46.8001V25.3407H50.5501V26.3807H45.5601L45.5701 26.3707ZM46.7101 23.5107V22.4907H50.0201V23.5107H46.7101Z" fill="var(--asus-black, #000000)"></path>
<path d="M56.89 26.4704C56.37 26.4704 55.87 26.4004 55.4 26.2504C54.92 26.1004 54.55 25.9104 54.27 25.6704L54.7 24.7104C54.97 24.9204 55.3 25.0904 55.69 25.2304C56.08 25.3704 56.48 25.4404 56.9 25.4404C57.25 25.4404 57.53 25.4004 57.75 25.3304C57.97 25.2604 58.12 25.1504 58.23 25.0204C58.33 24.8904 58.38 24.7404 58.38 24.5804C58.38 24.3804 58.31 24.2104 58.16 24.0904C58.01 23.9704 57.83 23.8704 57.59 23.8004C57.36 23.7304 57.1 23.6604 56.82 23.6004C56.54 23.5404 56.26 23.4604 55.97 23.3804C55.69 23.3004 55.43 23.1804 55.2 23.0504C54.97 22.9104 54.78 22.7304 54.63 22.5004C54.48 22.2704 54.41 21.9804 54.41 21.6304C54.41 21.2804 54.51 20.9404 54.7 20.6404C54.89 20.3404 55.19 20.1004 55.58 19.9204C55.98 19.7404 56.48 19.6504 57.09 19.6504C57.49 19.6504 57.88 19.7004 58.28 19.8004C58.68 19.9004 59.01 20.0504 59.31 20.2404L58.92 21.2004C58.62 21.0204 58.32 20.8904 58 20.8104C57.68 20.7304 57.38 20.6804 57.09 20.6804C56.75 20.6804 56.47 20.7204 56.26 20.8004C56.05 20.8804 55.89 20.9904 55.79 21.1204C55.69 21.2504 55.64 21.4104 55.64 21.5804C55.64 21.7804 55.71 21.9504 55.85 22.0704C55.99 22.1904 56.18 22.2904 56.41 22.3604C56.64 22.4304 56.9 22.5004 57.18 22.5604C57.46 22.6204 57.75 22.7004 58.03 22.7804C58.31 22.8604 58.57 22.9704 58.8 23.1004C59.03 23.2304 59.22 23.4104 59.36 23.6404C59.5 23.8704 59.57 24.1604 59.57 24.5004C59.57 24.8404 59.47 25.1804 59.28 25.4804C59.09 25.7804 58.79 26.0204 58.39 26.2004C57.99 26.3804 57.49 26.4704 56.88 26.4704H56.89Z" fill="var(--asus-black, #000000)"></path>
<path d="M65.5599 26.4704C65.0399 26.4704 64.5399 26.4004 64.0699 26.2504C63.5899 26.1004 63.2199 25.9104 62.9399 25.6704L63.3699 24.7104C63.6399 24.9204 63.9699 25.0904 64.3599 25.2304C64.7499 25.3704 65.1499 25.4404 65.5699 25.4404C65.9199 25.4404 66.1999 25.4004 66.4199 25.3304C66.6399 25.2604 66.7899 25.1504 66.8999 25.0204C66.9999 24.8904 67.0499 24.7404 67.0499 24.5804C67.0499 24.3804 66.9799 24.2104 66.8299 24.0904C66.6799 23.9704 66.4999 23.8704 66.2599 23.8004C66.0299 23.7304 65.7699 23.6604 65.4899 23.6004C65.2099 23.5404 64.9299 23.4604 64.6399 23.3804C64.3599 23.3004 64.0999 23.1804 63.8699 23.0504C63.6399 22.9104 63.4499 22.7304 63.2999 22.5004C63.1499 22.2704 63.0799 21.9804 63.0799 21.6304C63.0799 21.2804 63.1799 20.9404 63.3699 20.6404C63.5599 20.3404 63.8599 20.1004 64.2499 19.9204C64.6499 19.7404 65.1499 19.6504 65.7599 19.6504C66.1599 19.6504 66.5499 19.7004 66.9499 19.8004C67.3499 19.9004 67.6799 20.0504 67.9799 20.2404L67.5899 21.2004C67.2899 21.0204 66.9899 20.8904 66.6699 20.8104C66.3499 20.7304 66.0499 20.6804 65.7599 20.6804C65.4199 20.6804 65.1399 20.7204 64.9299 20.8004C64.7199 20.8804 64.5599 20.9904 64.4599 21.1204C64.3599 21.2504 64.3099 21.4104 64.3099 21.5804C64.3099 21.7804 64.3799 21.9504 64.5199 22.0704C64.6599 22.1904 64.8499 22.2904 65.0799 22.3604C65.3099 22.4304 65.5699 22.5004 65.8499 22.5604C66.1299 22.6204 66.4199 22.7004 66.6999 22.7804C66.9799 22.8604 67.2399 22.9704 67.4699 23.1004C67.6999 23.2304 67.8899 23.4104 68.0299 23.6404C68.1699 23.8704 68.2399 24.1604 68.2399 24.5004C68.2399 24.8404 68.1399 25.1804 67.9499 25.4804C67.7599 25.7804 67.4599 26.0204 67.0599 26.2004C66.6599 26.3804 66.1599 26.4704 65.5499 26.4704H65.5599Z" fill="var(--asus-black, #000000)"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/logo/svg-astro/Business-Vertical-Light.astro", void 0);

const $$Astro$r = createAstro("https://www.Asus.com.tw");
const $$Logo = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$r, $$props, $$slots);
  Astro2.self = $$Logo;
  const { IDName = "headerLogo", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "A", $$A, { "IDName": IDName, "className": className, "style": style, ...attribute, "link": "/", "title": "Asus" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "ImageDesktop", $$BusinessHorizontalLight, {})}
    ${renderComponent($$result2, "ImageMobile", $$BusinessVerticalLight, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/logo.astro", void 0);

const $$Astro$q = createAstro("https://www.Asus.com.tw");
const $$HeaderTop = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$q, $$props, $$slots);
  Astro2.self = $$HeaderTop;
  const { IDName = "headerTop", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderSlot($$result, $$slots["default"])}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/headerTop.astro", void 0);

const $$Astro$p = createAstro("https://www.Asus.com.tw");
const $$HeaderBottom = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$p, $$props, $$slots);
  Astro2.self = $$HeaderBottom;
  const { IDName = "headerBottom", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderSlot($$result, $$slots["default"])}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/headerBottom.astro", void 0);

const $$Astro$o = createAstro("https://www.Asus.com.tw");
const $$Offcanvas$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$o, $$props, $$slots);
  Astro2.self = $$Offcanvas$1;
  const {
    IDName,
    className,
    title,
    headerClassName,
    hideHeader,
    titleClassName,
    hideTitle,
    closeClassName,
    hideClose,
    bodyClassName,
    postion = "start",
    scrollable,
    backdrop = void 0,
    attribute = {},
    style,
    sizes = "default"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName ? `${IDName}Offcanvas` : void 0, "id")}${addAttribute([
    {
      offcanvas: sizes === "default",
      "offcanvas-xxl": sizes === "xxl",
      "offcanvas-xl": sizes === "xl",
      "offcanvas-lg": sizes === "lg",
      "offcanvas-md": sizes === "md",
      "offcanvas-sm": sizes === "sm"
    },
    {
      "offcanvas-start": postion === "start",
      "offcanvas-end": postion === "end",
      "offcanvas-top": postion === "top",
      "offcanvas-bottom": postion === "bottom"
    },
    className
  ], "class:list")} tabindex="-1"${addAttribute(IDName ? `${IDName}OffcanvasLabel` : void 0, "aria-labelledby")}${spreadAttributes(scrollable ? { "data-bs-scroll": "true" } : {})}${spreadAttributes(backdrop ? { "data-bs-backdrop": backdrop } : {})}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${!hideHeader && renderTemplate`<div${addAttribute(["offcanvas-header", headerClassName], "class:list")}>
                ${renderSlot($$result, $$slots["header"], renderTemplate`
                    ${!hideTitle && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
                            ${renderSlot($$result2, $$slots["title-left"])}
                            ${renderSlot($$result2, $$slots["title"], renderTemplate`
                                <strong${addAttribute(IDName ? `${IDName}OffcanvasLabel` : void 0, "id")}${addAttribute(["offcanvas-title", titleClassName], "class:list")}>
                                    ${title}
                                </strong>
                            `)}
                            ${renderSlot($$result2, $$slots["title-right"])}
                        ` })}`}
                    ${!hideClose && renderTemplate`<button type="button"${addAttribute(["offcanvas-close-button", closeClassName], "class:list")} data-bs-dismiss="offcanvas" aria-label="Close"></button>`}
                `)}
            </div>`}
    <div${addAttribute(["offcanvas-body", bodyClassName], "class:list")}>
        ${renderSlot($$result, $$slots["default"])}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/offcanvas/offcanvas.astro", void 0);

const $$Astro$n = createAstro("https://www.Asus.com.tw");
const $$Offcanvas = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$n, $$props, $$slots);
  Astro2.self = $$Offcanvas;
  const { IDName = "header", className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`

${renderComponent($$result, "MyOffcanvas", $$Offcanvas$1, { "IDName": IDName, "postion": "end", "hideHeader": true, "className": className, "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`${data.map((x) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate`${Boolean(x.children && x.children.length > 0) ? renderTemplate`${renderComponent($$result3, "Collapse", $$Collapse, { "title": x.title }, { "default": ($$result4) => renderTemplate`
                        ${maybeRenderHead()}<div class="header-offcanvas-link-container">
                            <div class="header-offcanvas-link-content">
                                ${x.children?.flatMap((y) => y.children).map((y) => renderTemplate`<div class="menu-links">
                                            <span class="menu-link-title">
                                                ${y?.title}
                                            </span>
                                            <div class="menu-link-list">
                                                ${y?.links.map((z) => renderTemplate`<div class="menu-link-ul">
                                                        ${z?.map((u) => renderTemplate`${renderComponent($$result4, "A", $$A, { "link": u.link, "title": u.linkText })}`)}
                                                    </div>`)}
                                            </div>
                                        </div>`)}
                            </div>
                        </div>
                    ` })}` : renderTemplate`${renderComponent($$result3, "A", $$A, { "link": x.link, "className": "header-offcanvas-link !!lh-125", "title": x.title })}`}` })}`)}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/offcanvas/offcanvas.astro", void 0);

const $$Astro$m = createAstro("https://www.Asus.com.tw");
const $$Input = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$m, $$props, $$slots);
  Astro2.self = $$Input;
  const {
    id,
    // 輸入框 ID
    className,
    // 自定義 CSS 類別
    type = "text",
    // 輸入框類型，預設為文字輸入
    name,
    // 表單欄位名稱
    value,
    // 輸入框值
    placeholder,
    // 佔位符文字
    inputmode = "text",
    // 輸入模式，預設為文字
    maxLength,
    // 最大字元長度
    minLength,
    // 最小字元長度
    max,
    // 最大數值
    min,
    // 最小數值
    required,
    // 是否必填
    disabled,
    // 是否禁用
    readonly,
    // 是否唯讀
    autocomplete,
    // 自動完成
    title,
    // 標題（用於無障礙）
    transparent,
    // 是否透明樣式
    size = "md",
    // 尺寸，預設為 md
    status,
    // 輸入框狀態，預設為 value
    focus = false,
    // 是否顯示焦點邊框，預設為 false
    validClass,
    // 驗證 CSS 類別
    validType,
    // 驗證類型
    validLabel,
    // 驗證標籤
    validRegex,
    // 驗證正規表達式
    errorFeedback,
    // 錯誤回饋訊息
    successFeedback,
    // 成功回饋訊息
    FeedbackIcon,
    // 是否顯示回饋圖標
    attribute = {},
    // 其他 HTML 屬性，預設為空物件
    aria = {},
    // ARIA 屬性，預設為空物件
    style = {}
    // 自定義樣式
  } = Astro2.props;
  const inputClasses = [
    "control-input",
    // 基礎輸入框類別
    { [`size_${size}`]: size },
    // 尺寸類別
    { [`status_${status}`]: status },
    // 狀態類別
    { "input-transparent": transparent },
    // 透明樣式
    { "has-focus": focus },
    // 焦點狀態
    className
    // 自定義類別
  ].filter(Boolean);
  const validAttribute = {
    "data-valid-class": validClass,
    // 驗證成功時要套用的 CSS 類別
    "data-valid-type": validType,
    // 驗證類型識別
    "data-valid-label": validLabel,
    // 驗證標籤文字
    "data-valid-regex": validRegex,
    // 驗證用正規表達式
    "data-custom-feedback": errorFeedback || successFeedback ? "" : void 0,
    // 是否有自定義回饋訊息
    "data-error-feedback": errorFeedback,
    // 錯誤回饋訊息
    "data-success-feedback": successFeedback,
    // 成功回饋訊息
    "data-feedback-icon": FeedbackIcon ? "" : void 0
    // 是否顯示回饋圖標
  };
  return renderTemplate`${maybeRenderHead()}<input${addAttribute(id, "id")}${addAttribute(inputClasses, "class:list")}${addAttribute(value, "value")}${addAttribute(type, "type")}${addAttribute(name, "name")}${addAttribute(max, "max")}${addAttribute(min, "min")}${addAttribute(maxLength, "maxlength")}${addAttribute(minLength, "minlength")}${addAttribute(placeholder, "placeholder")}${addAttribute(inputmode, "inputmode")}${addAttribute(required, "required")}${addAttribute(disabled, "disabled")}${addAttribute(readonly, "readonly")}${addAttribute(autocomplete, "autocomplete")}${addAttribute(title, "aria-label")}${spreadAttributes(attribute)}${spreadAttributes(aria)}${spreadAttributes(validAttribute)}${addAttribute(style, "style")}>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/input/input.astro", void 0);

const $$Astro$l = createAstro("https://www.Asus.com.tw");
const $$HideShowIcon = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$l, $$props, $$slots);
  Astro2.self = $$HideShowIcon;
  const {
    Tag = "span",
    state = "show",
    class: className = "",
    attribute = {},
    aria = {}
  } = Astro2.props;
  const getVariantClass = () => {
    const baseClass = "hide-show-icon";
    const stateClass = `hide-show-icon--${state}`;
    return `${baseClass} ${stateClass}`.trim();
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "class": `${getVariantClass()} ${className}`, "data-state": state, ...attribute, ...aria }, { "default": ($$result2) => renderTemplate`${state === "show" ? renderTemplate`<!-- Show State SVG -->
        ${maybeRenderHead()}<svg width="22" height="15" viewBox="0 0 22 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4.70778 14.1459C4.58699 14.0423 4.51228 13.895 4.50009 13.7363C4.4879 13.5776 4.53923 13.4205 4.64278 13.2997L15.8423 0.209533C15.9458 0.0886944 16.0931 0.0139587 16.2518 0.00176508C16.4104 -0.0104285 16.5674 0.0409188 16.6882 0.144512C16.8087 0.248088 16.8832 0.395244 16.8954 0.553703C16.9076 0.712163 16.8565 0.868988 16.7532 0.98978L5.55374 14.0799C5.49772 14.1462 5.42785 14.1993 5.34907 14.2356C5.27028 14.2719 5.1845 14.2905 5.09776 14.29C4.95476 14.29 4.81646 14.2389 4.70778 14.1459ZM7.58864 13.2377C7.515 13.2094 7.44765 13.1669 7.39044 13.1126C7.33324 13.0583 7.2873 12.9932 7.25526 12.9211C7.22321 12.849 7.2057 12.7713 7.20371 12.6924C7.20172 12.6135 7.2153 12.535 7.24366 12.4614C7.272 12.3877 7.31459 12.3203 7.36901 12.2631C7.42342 12.2059 7.48858 12.16 7.56076 12.1281C7.63293 12.0961 7.71071 12.0787 7.78962 12.0768C7.86853 12.075 7.94703 12.0887 8.02063 12.1173C9.62327 12.7693 11.3839 12.9285 13.0774 12.5744C14.4673 12.2493 15.768 11.6204 16.8862 10.7329C18.0667 9.80876 19.0948 8.70498 19.9331 7.46183C18.7401 5.94631 17.2835 4.6586 15.6333 3.66063C15.5648 3.6215 15.5048 3.56927 15.4565 3.50691C15.4083 3.44456 15.3728 3.3733 15.3521 3.29722C15.3314 3.22114 15.3259 3.14172 15.3358 3.0635C15.3458 2.98528 15.3711 2.9098 15.4103 2.84137C15.4494 2.77291 15.5016 2.71283 15.5639 2.66456C15.6263 2.6163 15.6975 2.58079 15.7736 2.56008C15.8496 2.53936 15.929 2.53384 16.0072 2.54383C16.0854 2.55382 16.1608 2.57912 16.2292 2.6183C18.1333 3.76975 19.8017 5.27211 21.146 7.0457L21.4 7.3668L21.195 7.71991C20.249 9.24293 19.0391 10.585 17.6222 11.6832C15.8402 13.1268 13.6243 13.9284 11.3315 13.9589C10.0501 13.9512 8.78118 13.7067 7.58864 13.2377ZM5.00277 11.9462C3.27807 10.8295 1.70998 9.48755 0.339984 7.95599L0 7.58687L0.299986 7.18674C1.36389 5.86509 2.60446 4.6961 3.98681 3.71264C5.22537 2.80823 6.60305 2.11188 8.06562 1.65099C9.73113 1.13108 11.5034 1.05488 13.2074 1.42992C13.2844 1.44718 13.3572 1.47946 13.4217 1.52492C13.4862 1.57037 13.5411 1.62811 13.5833 1.69483C13.6255 1.76154 13.6541 1.83592 13.6675 1.91371C13.6809 1.9915 13.6788 2.07116 13.6614 2.14815C13.6441 2.22517 13.6118 2.29803 13.5664 2.36256C13.521 2.42709 13.4632 2.48202 13.3966 2.52421C13.3299 2.56639 13.2555 2.595 13.1777 2.6084C13.1 2.6218 13.0204 2.61972 12.9434 2.60229C11.4415 2.27261 9.87959 2.34158 8.41261 2.80235C7.07542 3.22521 5.81599 3.86309 4.68378 4.69095C3.54203 5.51252 2.49944 6.46385 1.57693 7.52585C2.78328 8.8243 4.14712 9.96684 5.63674 10.9269C5.70351 10.9688 5.7614 11.0234 5.80708 11.0876C5.85277 11.1518 5.88536 11.2244 5.90301 11.3012C5.92065 11.378 5.92299 11.4576 5.9099 11.5353C5.89682 11.613 5.86855 11.6874 5.82673 11.7542C5.77257 11.8405 5.69733 11.9116 5.60811 11.9608C5.51889 12.0099 5.41862 12.0356 5.31675 12.0353C5.20486 12.0358 5.09506 12.0049 4.99977 11.9462H5.00277ZM9.39056 11.3671C9.31665 11.3395 9.2489 11.2976 9.19119 11.2438C9.13348 11.19 9.08695 11.1253 9.05426 11.0535C9.02156 10.9816 9.00335 10.9041 9.00066 10.8252C8.99797 10.7463 9.01085 10.6677 9.03858 10.5938C9.06615 10.5199 9.10804 10.4521 9.16183 10.3944C9.21562 10.3367 9.28026 10.2901 9.35206 10.2574C9.42386 10.2247 9.5014 10.2065 9.58024 10.2038C9.65908 10.2011 9.73768 10.214 9.81154 10.2417C10.1664 10.3751 10.5424 10.4429 10.9215 10.4418C11.7366 10.4511 12.5222 10.1368 13.1061 9.56773C13.69 8.99865 14.0245 8.22121 14.0363 7.40581C14.0359 6.87461 13.8936 6.35317 13.6244 5.89533C13.5842 5.82749 13.5579 5.7524 13.5467 5.67435C13.5356 5.59631 13.54 5.51684 13.5596 5.44048C13.5792 5.36412 13.6136 5.29238 13.6609 5.22934C13.7083 5.1663 13.7675 5.1132 13.8354 5.07307C13.9032 5.03297 13.9783 5.00665 14.0564 4.9956C14.1345 4.98456 14.2139 4.98901 14.2903 5.00871C14.3666 5.0284 14.4383 5.06295 14.5013 5.11038C14.5643 5.15782 14.6173 5.2172 14.6573 5.28514C15.0357 5.92815 15.2352 6.66068 15.2353 7.40681C15.2234 8.54057 14.7625 9.62332 13.9536 10.4175C13.1446 11.2117 12.0539 11.6525 10.9205 11.6432C10.3981 11.6433 9.87995 11.5498 9.39056 11.3671ZM6.84668 8.79625C6.68902 8.34965 6.60854 7.87945 6.60869 7.40581C6.62057 6.27206 7.08152 5.18931 7.89043 4.39511C8.69933 3.60092 9.79012 3.16014 10.9235 3.16947C11.2149 3.16923 11.5057 3.19805 11.7914 3.2555C11.9472 3.2871 12.084 3.3792 12.1719 3.5116C12.2598 3.644 12.2917 3.80588 12.2604 3.96172C12.2448 4.03906 12.2141 4.11256 12.17 4.17801C12.126 4.24346 12.0694 4.29957 12.0037 4.34315C11.9379 4.38672 11.8642 4.4169 11.7868 4.43195C11.7094 4.44701 11.6297 4.44664 11.5525 4.43087C11.3457 4.38963 11.1353 4.36885 10.9245 4.36885C10.1093 4.35976 9.32367 4.6743 8.73983 5.24354C8.15598 5.81279 7.82149 6.59032 7.80964 7.40581C7.80936 7.74312 7.86651 8.07801 7.97863 8.39613C8.03149 8.54603 8.02275 8.71079 7.95432 8.85425C7.8859 8.99771 7.76338 9.10816 7.61364 9.16137C7.54964 9.18513 7.48192 9.19733 7.41365 9.19738C7.28912 9.19751 7.16763 9.15886 7.06603 9.08681C6.96444 9.01475 6.88778 8.91386 6.84668 8.79625Z" fill="currentColor"></path>
        </svg>` : renderTemplate`<!-- Hide State SVG -->
        <svg width="22" height="13" viewBox="0 0 22 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0.339952 6.6724L0 6.30349L0.304957 5.90358C1.18408 4.80961 2.18809 3.82215 3.29653 2.96129C5.43743 1.14873 8.1242 0.106092 10.9274 0C14.4679 0 17.8025 1.93953 20.84 5.76662L21.1 6.09454L20.884 6.45045C20.1595 7.57003 19.2882 8.5875 18.2934 9.47573C16.3391 11.3617 13.7495 12.4477 11.0344 12.52C7.50693 12.52 3.91044 10.5525 0.339952 6.6724ZM4.06142 3.88707C3.1618 4.59224 2.33089 5.3809 1.57978 6.2425C4.79232 9.6117 7.97087 11.3203 11.0354 11.3203C13.4443 11.2588 15.741 10.2897 17.4655 8.60694C18.2748 7.87928 19.0003 7.06341 19.6282 6.17452C16.9076 2.87531 13.982 1.20071 10.9294 1.20071C8.40797 1.32139 5.99553 2.26499 4.06142 3.88707ZM6.51207 6.12453C6.52369 5.00617 6.97841 3.93805 7.77652 3.15445C8.57463 2.37085 9.65097 1.93574 10.7695 1.94453C11.8881 1.93574 12.9645 2.37082 13.7628 3.15439C14.561 3.93796 15.016 5.00607 15.0279 6.12453C15.016 7.2429 14.561 8.31091 13.7627 9.09432C12.9644 9.87773 11.888 10.3126 10.7695 10.3035C9.65114 10.3123 8.57495 9.87735 7.77687 9.09397C6.97879 8.31058 6.52395 7.24273 6.51207 6.12453ZM7.7119 6.12453C7.7235 6.92463 8.05184 7.6875 8.62496 8.24595C9.19809 8.80441 9.96926 9.1129 10.7695 9.10382C11.57 9.11343 12.3417 8.80518 12.9153 8.24667C13.4888 7.68815 13.8174 6.92498 13.829 6.12453C13.8177 5.32391 13.4892 4.56048 12.9156 4.00175C12.342 3.44303 11.5702 3.13463 10.7695 3.14425C9.96909 3.13517 9.19777 3.4438 8.62462 4.00247C8.05146 4.56114 7.72323 5.32426 7.7119 6.12453Z" fill="currentColor"></path>
        </svg>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/hidden/HideShowIcon.astro", void 0);

const $$Astro$k = createAstro("https://www.Asus.com.tw");
const $$Cross = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$k, $$props, $$slots);
  Astro2.self = $$Cross;
  const { IDName, className, style, attribute = {}, size, color, mode = "light", Tag = "span", aria = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": [className, "cross-icon", `mode-${mode}`], "style": {
    ...style,
    "--icon-size": size ? `${size}px` : void 0,
    "--icon-color": color ? color.charAt(0) === "#" ? color : `var(--color-${color})` : void 0
  }, ...attribute, ...aria }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="cross-svg">
        <path d="M12.6 0.599609L0.599976 12.5996M0.599976 0.599609L12.6 12.5996" stroke="var(--icon-color)" stroke-width="1" stroke-linecap="round"></path>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/header-menu/cross.astro", void 0);

const $$Astro$j = createAstro("https://www.Asus.com.tw");
const $$Search$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$j, $$props, $$slots);
  Astro2.self = $$Search$1;
  const {
    IDName,
    className,
    style,
    attribute = {},
    mode = "light",
    state = "normal",
    width,
    color,
    Tag = "span",
    aria = {}
  } = Astro2.props;
  const searchPath = "M10.5364 10.5359L13.6001 13.5996M12.0217 6.30986C12.0217 9.46453 9.46501 12.0212 6.31035 12.0212C3.15785 12.0212 0.600098 9.46453 0.600098 6.30986C0.600098 3.15736 3.15676 0.599609 6.31035 0.599609C9.46501 0.599609 12.0217 3.15628 12.0217 6.30986Z";
  const svgClass = ["search-icon", { [`mode-${mode}`]: mode }, { [`state-${state}`]: state }, className];
  const iconStyle = {
    ...width ? { "--icon-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "class:list": svgClass, ...attribute, ...aria, "style": iconStyle }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" class="search-svg">
        <path${addAttribute(searchPath, "d")} fill="none" stroke="var(--icon-color)" stroke-width="1.2" stroke-linecap="round"></path>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/search/search.astro", void 0);

const $$Astro$i = createAstro("https://www.Asus.com.tw");
const $$InputWrapper = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$i, $$props, $$slots);
  Astro2.self = $$InputWrapper;
  const {
    id,
    // 輸入框 ID
    className,
    // 自定義 CSS 類別
    attribute = {},
    // 其他 HTML 屬性，預設為空物件
    style = {},
    // 自定義 CSS 樣式，預設為空物件
    pwdShowIcon,
    // 是否顯示密碼顯示圖標，預設為 false
    pwdHideIcon,
    // 是否顯示密碼隱藏圖標，預設為 false
    closeIcon,
    // 是否顯示清除圖標，預設為 false
    searchIcon,
    // 是否顯示搜尋圖標，預設為 false
    /** Input 屬性 */
    inputId,
    // Input ID
    inputClassName,
    // Input CSS 類別
    name,
    // 表單欄位名稱
    value,
    // 輸入框值
    type = "text",
    // 輸入框類型
    maxLength,
    // 最大字元長度
    minLength,
    // 最小字元長度
    placeholder = "\u8ACB\u8F38\u5165\u5BC6\u78BC",
    // 佔位符文字，預設為密碼提示
    inputmode = "text",
    // 輸入模式，預設為文字
    required,
    // 是否必填
    disabled,
    // 是否禁用
    readonly,
    // 是否唯讀
    autocomplete = "current-password",
    // 自動完成，預設為當前密碼
    title,
    // 標題（用於無障礙）
    transparent,
    // 是否透明樣式
    size,
    // 輸入框尺寸，預設為 xl
    status,
    // 輸入框狀態，預設為 value
    focus,
    // 是否顯示焦點邊框，預設為 false
    validClass,
    // 驗證 CSS 類別
    validType,
    // 驗證類型
    validLabel,
    // 驗證標籤
    validRegex,
    // 驗證正規表達式
    errorFeedback,
    // 錯誤回饋訊息
    successFeedback,
    // 成功回饋訊息
    FeedbackIcon,
    // 是否顯示回饋圖標
    aria = {},
    // ARIA 屬性，預設為空物件
    inputAttribute = {},
    // Input 屬性，預設為空物件
    inputStyle = {}
    // Input 樣式，預設為空物件
  } = Astro2.props;
  const componentId = id || `input-wrapper-${Math.random().toString(36).substr(2, 9)}`;
  const inputID = inputId || `input-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`
${maybeRenderHead()}<div${addAttribute(id || componentId, "id")}${addAttribute(["input-wrapper", className], "class:list")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>
    ${renderComponent($$result, "Input", $$Input, { "id": inputID, "className": {
    inputClassName,
    ...{
      "has-search-icon": searchIcon,
      "has-pwd-show-icon": pwdShowIcon,
      "has-pwd-hide-icon": pwdHideIcon,
      "has-cross-icon": closeIcon
    }
  }, "type": type, "name": name, "value": value, "maxLength": maxLength, "minLength": minLength, "placeholder": placeholder, "inputmode": inputmode, "required": required, "disabled": disabled, "readonly": readonly, "autocomplete": autocomplete, "title": title, "transparent": transparent, "size": size, "status": status, "focus": focus, "validClass": validClass, "validType": validType, "validLabel": validLabel, "validRegex": validRegex, "errorFeedback": errorFeedback, "successFeedback": successFeedback, "FeedbackIcon": FeedbackIcon, "aria": aria, "attribute": inputAttribute, "style": inputStyle })}
    ${(pwdShowIcon || pwdHideIcon || closeIcon || searchIcon) && renderTemplate`<div class="input-icons">
                ${pwdShowIcon && renderTemplate`${renderComponent($$result, "HideShowIcon", $$HideShowIcon, { "state": "show", "Tag": "button", "attribute": { type: "button", "data-pwd-expand": "true" }, "aria": { "aria-label": "\u986F\u793A\u5BC6\u78BC" } })}`}
                ${pwdHideIcon && renderTemplate`${renderComponent($$result, "HideShowIcon", $$HideShowIcon, { "state": "hide", "Tag": "button", "attribute": { type: "button", "data-pwd-expand": "false" }, "aria": { "aria-label": "\u96B1\u85CF\u5BC6\u78BC" } })}`}
                ${closeIcon && renderTemplate`${renderComponent($$result, "CrossIcon", $$Cross, { "Tag": "button", "attribute": { type: "button" }, "aria": { "aria-label": "\u6E05\u9664\u8F38\u5165" } })}`}
                ${searchIcon && renderTemplate`${renderComponent($$result, "SearchIcon", $$Search$1, { "Tag": "button", "attribute": { type: "submit" }, "aria": { "aria-label": "\u641C\u5C0B" } })}`}
            </div>`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/input/inputWrapper.astro", void 0);

const $$Astro$h = createAstro("https://www.Asus.com.tw");
const $$Search = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$h, $$props, $$slots);
  Astro2.self = $$Search;
  const { IDName = "headerSearch", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`

${renderComponent($$result, "MyOffcanvas", $$Offcanvas$1, { "IDName": IDName, "postion": "top", "hideHeader": true, "className": className, "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<form class="header-search-from">
        <div class="header-search-from-body">
            ${renderComponent($$result2, "InputWrapper", $$InputWrapper, { "size": "lg", "name": "products", "placeholder": "\u641C\u5C0B ASUS.com/business", "searchIcon": true })}
            ${renderComponent($$result2, "Link", $$Link, { "title": "\u95DC\u9589", "className": "header-search-from-body-close", "attribute": { "data-bs-dismiss": "offcanvas", "aria-label": "Close" } }, { "default": ($$result3) => renderTemplate`關閉` })}
        </div>
    </form>
` })}

`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/offcanvas/search.astro", void 0);

const $$Astro$g = createAstro("https://www.Asus.com.tw");
const icons = {};
const $$Icons = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$g, $$props, $$slots);
  Astro2.self = $$Icons;
  const {
    IDName,
    className,
    style,
    attribute = {},
    icon,
    width,
    height,
    fill,
    strokeWidth = 0,
    strokeColor,
    custom
  } = Astro2.props;
  const MyIcon = icons[icon];
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${MyIcon && renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "fa-Icons", icon, { customStyle: custom }], "class:list")}${addAttribute({
    ...style,
    ...!isNaN(width) ? { "--width": `${width / 16}rem` } : {},
    ...!isNaN(height) ? { "--height": `${height / 16}rem` } : {},
    ...fill ? { "--fill": fill.charAt(0) === "#" ? fill : `var(--color-${fill})` } : {},
    ...!isNaN(strokeWidth) ? { "--strokeWidth": `${strokeWidth / 16}rem` } : {},
    ...strokeColor ? { "--stroke": strokeColor.charAt(0) === "#" ? strokeColor : `var(--color-${strokeColor})` } : {}
  }, "style")}${spreadAttributes(attribute)}>
                
            </div>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/icons.astro", void 0);

const $$Astro$f = createAstro("https://www.Asus.com.tw");
const $$Button = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$f, $$props, $$slots);
  Astro2.self = $$Button;
  const {
    IDName,
    type = "button",
    Tag = "button",
    size,
    title,
    className,
    variant,
    disabled,
    block,
    button = true,
    round = true,
    rounded = false,
    role,
    link,
    extend,
    target,
    noFocus,
    attribute = {},
    style,
    icon,
    iconPosition = "right",
    iconWidth,
    iconHeight,
    iconFill,
    iconStrokeColor,
    iconStrokeWidth = 0,
    CustomIconColor = true,
    IconAttribute = {},
    IconStyle
  } = Astro2.props;
  const href = link !== "#" && link ? !extend ? `${Astro2.url.origin}${link}${ext}` : link : "#";
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "type": Tag === "button" ? type : void 0, "class:list": [
    {
      btn: button,
      "btn-xs": size === "xs",
      "btn-sm": size === "sm",
      "btn-md": size === "md",
      "btn-lg": size === "lg",
      "btn-xl": size === "xl",
      "btn-block": block,
      "btn-round": round,
      "btn-rounded": rounded,
      "no-focus": noFocus
    },
    className
  ], "title": title, "disabled": disabled, "data-variant": variant, ...attribute, "style": style, "href": Tag === "a" ? href : void 0, "target": Tag === "a" ? target : void 0, "role": Tag !== "button" ? role : void 0 }, { "default": ($$result2) => renderTemplate`
    ${renderSlot($$result2, $$slots["icon-left"], renderTemplate`
        ${Boolean(icon && iconPosition === "left") && renderTemplate`${renderComponent($$result2, "Icons", $$Icons, { "icon": icon, "width": iconWidth, "height": iconHeight, "fill": iconFill, "strokeColor": iconStrokeColor, "strokeWidth": iconStrokeWidth, "custom": CustomIconColor, "attribute": IconAttribute, "style": IconStyle })}`}
    `)}
    ${renderSlot($$result2, $$slots["default"])}
    ${renderSlot($$result2, $$slots["icon-right"], renderTemplate`
        ${Boolean(icon && iconPosition === "right") && renderTemplate`${renderComponent($$result2, "Icons", $$Icons, { "icon": icon, "width": iconWidth, "height": iconHeight, "fill": iconFill, "stroke-color": iconStrokeColor, "stroke-width": iconStrokeWidth, "custom": CustomIconColor, "attribute": IconAttribute, "style": IconStyle })}`}
    `)}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/button/button.astro", void 0);

const $$Astro$e = createAstro("https://www.Asus.com.tw");
const $$Quantity = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$e, $$props, $$slots);
  Astro2.self = $$Quantity;
  const { quantity = "2", class: className = "" } = Astro2.props;
  const displayQuantity = String(quantity);
  return renderTemplate`${maybeRenderHead()}<span${addAttribute(`quantity-label ${className}`, "class")}>
    ${displayQuantity}
</span>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/quantity/quantity.astro", void 0);

const $$Astro$d = createAstro("https://www.Asus.com.tw");
const $$HeaderInquery = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$d, $$props, $$slots);
  Astro2.self = $$HeaderInquery;
  const {
    haveItems = "false",
    status = "normal",
    colorMode = "light",
    state = "normal",
    mode = "light",
    quantity = "2",
    className = "",
    Tag = "span",
    attribute = {},
    aria = {},
    style = {}
  } = Astro2.props;
  const getVariantClass = () => {
    const baseClass = "header-inquery";
    const itemsClass = `header-inquery--${haveItems.toLowerCase()}`;
    const statusClass = `header-inquery--${status.toLowerCase()}`;
    const colorClass = `header-inquery--${colorMode.toLowerCase()}`;
    const stateClass = `header-inquery--${state}`;
    const modeClass = `header-inquery--${mode.toLowerCase()}`;
    return `${baseClass} ${itemsClass} ${statusClass} ${colorClass} ${stateClass} ${modeClass}`;
  };
  const hasQuantityLabel = haveItems === "true" || haveItems === "header" && colorMode === "true";
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "class": `${getVariantClass()} ${className}`, ...attribute, ...aria, "style": style }, { "default": ($$result2) => renderTemplate`
    
    ${maybeRenderHead()}<svg width="12" height="15" viewBox="0 0 12 15" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0.887134 4.04628H4.76471V0.886767M3.75941 8.06747L5.19555 9.50361L8.06784 6.63133M0.599976 4.11815L4.83659 0.599609H10.0788C10.7133 0.599609 11.2277 1.114 11.2277 1.74852V12.9507C11.2277 13.5852 10.7133 14.0996 10.0788 14.0996H1.74889C1.11436 14.0996 0.599976 13.5852 0.599976 12.9507V4.11815Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>

    
    ${hasQuantityLabel && renderTemplate`${renderComponent($$result2, "QuantityLabel", $$Quantity, { "quantity": quantity })}`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/header-inquery/HeaderInquery.astro", void 0);

const $$Astro$c = createAstro("https://www.Asus.com.tw");
const $$HeaderMember = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$c, $$props, $$slots);
  Astro2.self = $$HeaderMember;
  const {
    logIn = "False",
    status = "normal",
    colorMode = "light",
    className = "",
    color,
    width,
    Tag = "span",
    attribute = {},
    aria = {},
    style = {}
  } = Astro2.props;
  const isActive = logIn === "True";
  const getVariantClass = () => {
    const baseClass = "header-member";
    const loginClass = logIn === "True" ? "header-member--active" : "header-member--inactive";
    const statusClass = status === "hover" ? "header-member--hover" : "header-member--normal";
    const colorClass = colorMode === "Dark" ? "header-member--dark" : "header-member--light";
    return [baseClass, loginClass, statusClass, colorClass, className];
  };
  const iconStyle = {
    ...width ? { "--icon-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...color ? { "--icon-color": color.charAt(0) === "#" ? color : `var(--color-${color})` } : {},
    ...style
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "class:list": getVariantClass(), ...attribute, ...aria, "style": iconStyle }, { "default": ($$result2) => renderTemplate`${isActive ? renderTemplate`<!-- Active member icon with green dot -->
    ${maybeRenderHead()}<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="6.59998" cy="3.97461" r="3.375" stroke="currentColor" stroke-width="1.2"></circle>
      <path d="M6.59961 6.75C7.92886 6.75 9.16538 7.14527 10.2012 7.82129C9.81087 8.02254 9.45475 8.28095 9.14648 8.58789C8.38782 8.18115 7.52073 7.94922 6.59961 7.94922C3.82027 7.94942 1.53187 10.0502 1.2334 12.75H8.05469C8.17566 13.1813 8.36157 13.5851 8.60352 13.9492H0.599609C0.268418 13.949 0 13.6808 0 13.3496C0.000211066 9.70484 2.95484 6.75021 6.59961 6.75Z" fill="currentColor"></path>
      <circle cx="11.9827" cy="11.5996" r="3" class="header-member__dot"></circle>
    </svg>` : renderTemplate`<!-- Inactive member icon -->
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="6.59998" cy="3.97461" r="3.375" stroke="currentColor" stroke-width="1.2"></circle>
      <path d="M6.59961 6.75C10.2446 6.75 13.199 9.70471 13.1992 13.3496C13.1992 13.681 12.931 13.9492 12.5996 13.9492H0.599609C0.268418 13.949 0 13.6808 0 13.3496C0.000211066 9.70484 2.95484 6.75021 6.59961 6.75ZM6.59961 7.94922C3.82027 7.94942 1.53187 10.0502 1.2334 12.75H11.9658C11.6673 10.0501 9.3791 7.94922 6.59961 7.94922Z" fill="currentColor"></path>
    </svg>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/header-member/HeaderMember.astro", void 0);

const $$Astro$b = createAstro("https://www.Asus.com.tw");
const $$Header = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$b, $$props, $$slots);
  Astro2.self = $$Header;
  const { IDName = "header", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`<!-- Header -->${maybeRenderHead()}<header${addAttribute(IDName, "id")}${addAttribute(["header", className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div id="header-body">
        ${renderComponent($$result, "Left", $$HeaderTop, {}, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Logo", $$Logo, {})}
            ${renderComponent($$result2, "Navs", $$Nav, { "type": "megaMenu", "data": NavsData })}
        ` })}
        ${renderComponent($$result, "Right", $$HeaderBottom, {}, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Button", $$Button, { "variant": "blue-outline", "size": "sm", "title": "\u6210\u70BAISV\u5925\u4F34", "rounded": true, "className": "header-control-button" }, { "default": ($$result3) => renderTemplate`成為ISV夥伴` })}
            ${renderComponent($$result2, "IconSearch", $$Search$1, { "Tag": "button", "attribute": {
    type: "button",
    title: "search",
    "data-bs-toggle": "offcanvas",
    "data-bs-target": "#headerSearchOffcanvas",
    "data-bs-expended": "false",
    "aria-controls": "headerSearchOffcanvas"
  }, "className": "header-control" })}
            ${renderComponent($$result2, "IconHeaderInquery", $$HeaderInquery, { "haveItems": "header", "colorMode": "true", "Tag": "button", "attribute": { type: "button", title: "inquery" }, "className": "header-control" })}
            <div class="header-control-member">
                ${renderComponent($$result2, "IconHeaderMember", $$HeaderMember, { "logIn": "True", "Tag": "button", "attribute": {
    type: "button",
    title: "member",
    "data-bs-toggle": "dropdown",
    "aria-expanded": "false",
    "data-bs-offset": "0,4"
  }, "className": "header-control" })}
                <ul class="header-dropdown dropdown-menu">
                    <div class="menu-links">
                        <span class="menu-link-title"> 用戶選單 </span>
                        <div class="menu-link-list">
                            <div class="menu-link-ul">
                                ${["\u57FA\u672C\u8CC7\u6599", "\u8A0A\u606F\u4E2D\u5FC3(10)", "\u6211\u7684\u8AEE\u8A62\u593E(10)", "\u6211\u7684\u6536\u85CF\u6E05\u55AE(10)", "\u767B\u51FA"].map((z) => renderTemplate`${renderComponent($$result2, "A", $$A, { "link": "#", "title": z })}`)}
                            </div>
                        </div>
                    </div>
                </ul>
            </div>
            ${renderComponent($$result2, "TriggerButton", $$TriggerButton, {})}
        ` })}
    </div>
</header>
${renderComponent($$result, "Offcanvas", $$Offcanvas, { "data": NavsData })}
${renderComponent($$result, "SearchOffcanvas", $$Search, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/header/header.astro", void 0);

const $$CssVariable = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`<style type="text/css">
</style>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/css-variable.astro", void 0);

const $$Astro$a = createAstro("https://www.Asus.com.tw");
const $$Meta = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$Meta;
  const { title, description, keywords, themeColor, colorScheme } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${title && renderTemplate`<title>${title}</title>`}${description && renderTemplate`<meta name="description"${addAttribute(description, "content")}>`}${keywords && renderTemplate`<meta name="keywords"${addAttribute(keywords.join(", "), "content")}>`}${colorScheme && renderTemplate`<meta name="color-scheme"${addAttribute(colorScheme, "content")}>`}${themeColor && renderTemplate`<meta name="theme-color"${addAttribute(themeColor, "content")}>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Meta.astro", void 0);

const $$Astro$9 = createAstro("https://www.Asus.com.tw");
const $$Facebook = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$Facebook;
  const { url, type, title, description, image } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${url && renderTemplate`<meta property="og:url"${addAttribute(url, "content")}>`}${type && renderTemplate`<meta property="og:type"${addAttribute(type, "content")}>`}${title && renderTemplate`<meta property="og:title"${addAttribute(title, "content")}>`}${description && renderTemplate`<meta property="og:description"${addAttribute(description, "content")}>`}${image && renderTemplate`<meta property="og:image"${addAttribute(image, "content")}>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Facebook.astro", void 0);

const $$Astro$8 = createAstro("https://www.Asus.com.tw");
const $$Twitter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$Twitter;
  const { card, site, title, description, image } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${card && renderTemplate`<meta name="twitter:card"${addAttribute(card, "content")}>`}${site && renderTemplate`<meta name="twitter:site"${addAttribute(site, "content")}>`}${title && renderTemplate`<meta name="twitter:title"${addAttribute(title, "content")}>`}${description && renderTemplate`<meta name="twitter:description"${addAttribute(description, "content")}>`}${image && renderTemplate`<meta name="twitter:image"${addAttribute(image, "content")}>`}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Twitter.astro", void 0);

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Google = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Google;
  const { description, author = "", copyright = "", applicationName = "", verification = "" } = Astro2.props;
  return renderTemplate`${description && renderTemplate`<meta name="description"${addAttribute(description, "content")}>`}
${author && renderTemplate`<meta name="author"${addAttribute(author, "content")}>`}
${copyright && renderTemplate`<meta name="copyright"${addAttribute(copyright, "content")}>`}
${applicationName && renderTemplate`<meta name="application-name"${addAttribute(applicationName, "content")}>`}
${verification && renderTemplate`<meta name="google-site-verification"${addAttribute(verification, "content")}>`}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/social/Google.astro", void 0);

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$Icon = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Icon;
  const { favicon = [], appleTouchIcon = [] } = Astro2.props;
  return renderTemplate`
${favicon.map((x) => renderTemplate`<link${addAttribute(x.rel, "rel")}${addAttribute(x.href, "href")}${addAttribute(x.type, "type")}${addAttribute(x.sizes, "sizes")}>`)}

${appleTouchIcon.map((x) => renderTemplate`<link${addAttribute(x?.rel ?? "apple-touch-icon", "rel")}${addAttribute(x.sizes, "sizes")}${addAttribute(x.href, "href")}>`)}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/icon/icon.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Robots = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Robots;
  const { content } = Astro2.props;
  return renderTemplate`${content && renderTemplate`<meta name="robots"${addAttribute(content, "content")}>`}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/robots/robots.astro", void 0);

function JsonLd(item, space) {
  return JSON.stringify(item, safeJsonLdReplacer, space);
}
const ESCAPE_ENTITIES = Object.freeze({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&apos;"
});
const ESCAPE_REGEX = new RegExp(
  `[${Object.keys(ESCAPE_ENTITIES).join("")}]`,
  "g"
);
const ESCAPE_REPLACER = (t) => ESCAPE_ENTITIES[t];
const safeJsonLdReplacer = /* @__PURE__ */ (() => {
  return (_, value) => {
    switch (typeof value) {
      case "object":
        if (value === null) {
          return void 0;
        }
        return value;
      // JSON.stringify will recursively call replacer.
      case "number":
      case "boolean":
      case "bigint":
        return value;
      // These values are not risky.
      case "string":
        return value.replace(ESCAPE_REGEX, ESCAPE_REPLACER);
      default: {
        return void 0;
      }
    }
  };
})();

var __freeze$1 = Object.freeze;
var __defProp$1 = Object.defineProperty;
var __template$1 = (cooked, raw) => __freeze$1(__defProp$1(cooked, "raw", { value: __freeze$1(cooked.slice()) }));
var _a$1;
const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Schema$1 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Schema$1;
  const { item, space } = Astro2.props;
  return renderTemplate(_a$1 || (_a$1 = __template$1(['<script type="application/ld+json">', "<\/script>"])), unescapeHTML(JsonLd(item, space)));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/node_modules/.pnpm/astro-seo-schema@5.1.0_astro@4.16.19_@types+node@20.14.2_less@4.2.0_lightningcss@1.25.1_a4db162a8c3d07006d0bab4a650ffa08/node_modules/astro-seo-schema/dist/Schema.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$Schema = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Schema;
  const { schemas = [] } = Astro2.props;
  return renderTemplate`${schemas.map((item) => renderTemplate`${renderComponent($$result, "SeoSchema", $$Schema$1, { "item": item })}`)}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/schema/schema.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Font = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Font;
  const { google, custom, icon } = Astro2.props;
  const defaultFontsPath = `${Astro2.url.origin}/assets/fonts`;
  return renderTemplate`${google && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link rel="preload" as="style"${addAttribute(google, "href")} onload="this.onload = null; this.rel = 'stylesheet'">
            ${maybeRenderHead()}<noscript>
                <link${addAttribute(google, "href")} rel="stylesheet" type="text/css">
            </noscript>
        ` })}`}
${icon && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <link rel="preload" as="style"${addAttribute(icon, "href")}${addAttribute(`this.onload = null; this.rel = 'stylesheet'`, "onload")}>
            <noscript>
                <link rel="stylesheet"${addAttribute(icon, "href")}>
            </noscript>
        ` })}`}
${custom && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${custom?.fonts?.map((x) => renderTemplate`<link rel="preload"${addAttribute(`${custom?.fontsPath ?? defaultFontsPath}/${x}`, "href")} as="font"${addAttribute(`font/${custom?.type}`, "type")} crossorigin>`)}` })}`}
${custom && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
            <link rel="preload" as="style"${addAttribute(custom.css, "href")}${addAttribute(`this.onload = null; this.rel = 'stylesheet'`, "onload")}>
            <noscript>
                <link rel="stylesheet"${addAttribute(custom.css, "href")}>
            </noscript>
        ` })}`}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/font/font.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Seo = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Seo;
  const {
    title,
    description,
    keywords,
    themeColor,
    colorScheme,
    facebook,
    twitter,
    google,
    robots,
    schemas,
    font,
    favicon,
    appleTouchIcon
  } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Meta", $$Meta, { "title": title, "description": description, "keywords": keywords, "themeColor": themeColor, "colorScheme": colorScheme })}

    ${renderComponent($$result2, "Icon", $$Icon, { "favicon": favicon, "appleTouchIcon": appleTouchIcon })}

    ${renderComponent($$result2, "Facebook", $$Facebook, { "title": title, "description": description, "image": facebook?.image, "url": facebook?.url, "type": facebook?.type })}
    ${renderComponent($$result2, "Twitter", $$Twitter, { "title": title, "description": description, "image": twitter?.image, "site": twitter?.site, "card": twitter?.card })}
    ${renderComponent($$result2, "Google", $$Google, { "description": description, "author": google?.author, "copyright": google?.copyright, "applicationName": google?.applicationName, "verification": google?.verification })}

    ${renderComponent($$result2, "Robots", $$Robots, { "content": robots?.content })}
    ${renderComponent($$result2, "Schema", $$Schema, { "schemas": schemas })}

    

    ${renderComponent($$result2, "Font", $$Font, { "google": font?.google, "custom": font?.custom, "icon": font?.icon })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/meta/seo.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Script = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["<script><\/script>"])));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/script/script.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Layouts = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Layouts;
  const site = Astro2.url.origin;
  const OGImage = `${site}/assets/meta/Open-Graph-Image.jpg`;
  const favicon = [
    {
      rel: "shortcut icon",
      sizes: "16x16",
      type: "image/ico",
      href: `${site}/assets/meta/favicon.ico`
    },
    {
      rel: "icon",
      sizes: "16x16",
      type: "image/ico",
      href: `${site}/assets/meta/favicon.ico`
    },
    {
      rel: "icon",
      sizes: "192x192",
      type: "image/png",
      href: `${site}/assets/meta/android-icon-192x192.png`
    },
    {
      rel: "icon",
      sizes: "32x32",
      type: "image/png",
      href: `${site}/assets/meta/favicon-32x32.png`
    },
    {
      rel: "icon",
      sizes: "96x96",
      type: "image/png",
      href: `${site}/assets/meta/favicon-96x96.png`
    },
    {
      rel: "icon",
      sizes: "16x16",
      type: "image/png",
      href: `${site}/assets/meta/favicon-16x16.png`
    },
    {
      rel: "bookmark",
      sizes: "32x32",
      type: "image/png",
      href: `${site}/assets/meta/favicon-32x32.png`
    }
  ];
  const appleTouchIcon = [
    {
      type: "image/png",
      sizes: "57x57",
      href: `${site}/assets/meta/apple-icon-57x57.png`
    },
    {
      type: "image/png",
      sizes: "60x60",
      href: `${site}/assets/meta/apple-icon-60x60.png`
    },
    {
      type: "image/png",
      sizes: "72x72",
      href: `${site}/assets/meta/apple-icon-72x72.png`
    },
    {
      type: "image/png",
      sizes: "76x76",
      href: `${site}/assets/meta/apple-icon-76x76.png`
    },
    {
      type: "image/png",
      sizes: "114x114",
      href: `${site}/assets/meta/apple-icon-114x114.png`
    },
    {
      type: "image/png",
      sizes: "120x120",
      href: `${site}/assets/meta/apple-icon-120x120.png`
    },
    {
      type: "image/png",
      sizes: "144x144",
      href: `${site}/assets/meta/apple-icon-144x144.png`
    },
    {
      type: "image/png",
      sizes: "152x152",
      href: `${site}/assets/meta/apple-icon-152x152.png`
    },
    {
      type: "image/png",
      sizes: "167x167",
      href: `${site}/assets/meta/apple-icon-167x167.png`
    },
    {
      type: "image/png",
      sizes: "180x180",
      href: `${site}/assets/meta/apple-icon-180x180.png`
    }
  ];
  const customFont = {
    css: `${Astro2.url.origin}/assets/fonts/fonts.css`,
    fonts: [
      "TTNormsProNormal_normal_normal.woff2",
      "TTNormsProNormal_normal_normal.woff",
      "TTNormsProMedium_normal_normal.woff2",
      "TTNormsProMedium_normal_normal.woff"
    ],
    type: "woff2"
  };
  const { IDName, className, bodyClassName, footerShowBorderTop = false, minMarginHeader = false } = Astro2.props;
  return renderTemplate`<html lang="zh-TW">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        ${renderComponent($$result, "Seo", $$Seo, { "title": "Asus", "description": "Asus", "keywords": "Asus".split(","), "favicon": favicon, "appleTouchIcon": appleTouchIcon, "themeColor": "#", "colorScheme": "light", "facebook": {
    image: OGImage,
    url: site,
    type: "website"
  }, "twitter": {
    image: OGImage,
    site,
    card: "summary"
  }, "google": {
    author: "Asus",
    copyright: "Asus",
    applicationName: "Asus"
  }, "robots": {
    content: "all"
  }, "font": {
    custom: customFont
  }, "schemas": [
    {
      "@context": "https://schema.org",
      "@type": "WorkersUnion",
      url: `${site}`,
      logo: `${site}/assets/logos/logo-text.png`,
      address: {
        "@type": "PostalAddress",
        streetAddress: "",
        addressLocality: "",
        addressRegion: "",
        postalCode: "",
        addressCountry: "Taiwan"
      },
      contactPoint: {
        "@type": "ContactPoint",
        telephone: "",
        contactType: ""
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      url: `${site}`,
      name: "",
      alternateName: ""
    }
  ] })}
        ${renderComponent($$result, "CssVariable", $$CssVariable, {})}
        ${renderSlot($$result, $$slots["link"])}
    ${renderHead()}</head>
    <body${addAttribute(bodyClassName, "class:list")}>
        <!-- <Toast /> -->
        ${renderComponent($$result, "Header", $$Header, {})}
        <main${addAttribute(IDName, "id")}${addAttribute([className, { "margin-top": minMarginHeader }], "class:list")}${addAttribute(IDName, "data-name")}>
            ${renderSlot($$result, $$slots["default"])}
        </main>
        ${renderComponent($$result, "Footer", $$Footer, { "showBorderTop": footerShowBorderTop })}
        ${renderComponent($$result, "Script", $$Script, {})}
        ${renderSlot($$result, $$slots["script"])}
    </body></html>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/layouts/layouts.astro", void 0);

export { $$A as $, $$Button as a, $$Layouts as b, $$Link as c, $$Collapse as d, $$Offcanvas$1 as e };
