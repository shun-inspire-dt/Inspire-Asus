import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';
import { $ as $$Picture } from './picture_GYxijd3h.mjs';

const bannerImage = (text) => `/assets/images/pages/${text}-sm`;
const bannerImages = (text) => [
  {
    width: 1280,
    // 桌面版斷點 (1280px+)
    img: `/assets/images/pages/${text}-lg`,
    // 向後相容的預設圖片
    densities: {
      "1x": `/assets/images/pages/${text}-lg`,
      // 標準解析度
      "1.5x": `/assets/images/pages/${text}-lg`,
      // 1.5倍解析度
      "2x": `/assets/images/pages/${text}-lg`
      // 2倍解析度（高解析度螢幕）
    }
  },
  {
    width: 768,
    // 平板版斷點 (768px-1279px)
    img: `/assets/images/pages/${text}-md`,
    densities: {
      "1x": `/assets/images/pages/${text}-md`,
      "1.5x": `/assets/images/pages/${text}-md`,
      "2x": `/assets/images/pages/${text}-md`
    }
  },
  {
    width: 0,
    // 手機版斷點 (767px 以下)
    img: `/assets/images/pages/${text}-sm`,
    densities: {
      "1x": `/assets/images/pages/${text}-sm`,
      "1.5x": `/assets/images/pages/${text}-sm`,
      "2x": `/assets/images/pages/${text}-sm`
    }
  }
];

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Banner = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Banner;
  const { IDName, className, style, title, img, mode = "light", attribute = {} } = Astro2.props;
  const imgBreakpoints = bannerImages(img);
  const image = bannerImage(img);
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "section-banner"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Picture", $$Picture, { "img": image, "className": "section-banner-image", "alt": title, "breakpoints": imgBreakpoints, "type": "png", "noWebp": true })}
    <div class="section-banner-head">
        <h2${addAttribute([
    "section-banner-title",
    mode === "dark" && "section-banner-title-dark"
  ], "class:list")}>
            ${title}
        </h2>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/banner/banner.astro", void 0);

export { $$Banner as $ };
