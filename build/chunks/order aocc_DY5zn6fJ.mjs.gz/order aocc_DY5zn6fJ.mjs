import { a as createComponent, m as maybeRenderHead, d as renderTemplate } from './astro/server_Bjgbv9en.mjs';

const $$OrderAocc = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.5001 2.59961L4.6001 7.49961V19.8C4.6001 20.6837 5.31644 21.4 6.2001 21.4H17.8005C18.6841 21.4 19.4005 20.6837 19.4005 19.8V4.19961C19.4005 3.31595 18.6841 2.59961 17.8005 2.59961H10.5001Z" stroke="var(--color-blue-500, #006ce1)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M5 7.4H10.4V3" stroke="var(--color-blue-500, #006ce1)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M9 13L11 15L15 11" stroke="var(--color-blue-500, #006ce1)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/member/svg-astro/focus/order aocc.astro", void 0);

export { $$OrderAocc as default };
