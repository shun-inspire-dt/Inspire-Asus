import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate, r as renderComponent, f as renderSlot, e as defineScriptVars } from './astro/server_v5wg8FJS.mjs';
/* empty css                         */
import { $ as $$Title } from './title_C418meuI.mjs';
import { $ as $$CustomSelect } from './customSelect_C2FrwOlA.mjs';
import { $ as $$NotificationIcon } from './notificationIcon_D_PqDPap.mjs';
import { c as $$Link, j as $$Collapse, $ as $$Button, h as $$Offcanvas } from './layouts_CAx5rqF_.mjs';
import { $ as $$Badge, a as $$PaginationArrow } from './paginationArrow_BG81CqcK.mjs';
import { $ as $$Checkbox } from './checkbox_CezxJCXT.mjs';

const $$Astro$b = createAstro("https://www.Asus.com.tw");
const $$Follower = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$b, $$props, $$slots);
  Astro2.self = $$Follower;
  const { IDName = "Follower", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "follower"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Go Top" class="follower-button">
        <svg width="25" height="15" viewBox="0 0 25 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.0879 12.4816L12.4813 1.875L1.87469 12.4816" stroke="white" stroke-width="3.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
        <svg width="19" height="11" viewBox="0 0 19 11" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.9316 9.15317L9.15347 1.375L1.37529 9.15317" stroke="white" stroke-width="2.75" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/follower/follower.astro", void 0);

const $$Astro$a = createAstro("https://www.Asus.com.tw");
const $$SortSelector = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$SortSelector;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  const componentId = IDName || `sort-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "sort-selector"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <label class="sort-selector-label"${addAttribute(componentId, "for")}>排序：</label>
    ${renderComponent($$result, "Select", $$CustomSelect, { "id": componentId, "status": "sort", "className": "sort-selector-select", "size": "sm", "name": "sort", "data": data, "value": data && data?.[0] ? data[0].value : void 0, "selectAttribute": { "data-sort": "" }, "style": { minWidth: "9.5rem" } })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sortSelector.astro", void 0);

const $$Astro$9 = createAstro("https://www.Asus.com.tw");
const $$Sort = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$Sort;
  const { IDName, className, style, attribute = {}, total, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "sort"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <span class="sort-result">篩選結果: ${total} 結果</span>
    <div class="sort-selector-container">
        ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": data })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/sort/sort.astro", void 0);

const $$Astro$8 = createAstro("https://www.Asus.com.tw");
const $$Notice = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$Notice;
  const {
    IDName,
    className,
    style,
    attribute = {},
    text = "\u9078\u64C7\u7BE9\u9078\u689D\u4EF6\u6703\u91CD\u6574\u7D50\u679C\uFF0C\u4E26\u53EF\u80FD\u5F71\u97FF\u5176\u4ED6\u9078\u9805\u7684\u53EF\u7528\u6027\u3002"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "filter-notification"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Icon", $$NotificationIcon, { "size": "16", "style": { "--color": "var(--color-blue-600, #0051A8)" } })}
    <span class="flex-1">${text}</span>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/notice/notice.astro", void 0);

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Badges = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Badges;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute({ display: "none", ...style }, "style")}${spreadAttributes(attribute)} data-filter-badges>
    <div class="category-badges">
        <div class="category-badges-header">
            排序與篩選
            ${renderComponent($$result, "ALink", $$Link, { "title": "\u6E05\u9664\u5168\u90E8", "attribute": { "data-category-clear": "" } }, { "default": ($$result2) => renderTemplate`清除全部` })}
        </div>
        <template>
            ${renderComponent($$result, "Badge", $$Badge, { "Tag": "span", "status": "filter", "showCross": true }, { "default": ($$result2) => renderTemplate`<span></span>` })}
        </template>
        <div class="category-badges-list" data-filter-badges-list></div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/badges.astro", void 0);

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$Filter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Filter;
  const { IDName, className, style, attribute = {}, title, show, more, data = [] } = Astro2.props;
  const componentId = IDName || `filter-${Math.random().toString(36).substr(2, 9)}`;
  const inputId = `filter-input-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${renderComponent($$result, "Collapse", $$Collapse, { "IDName": componentId, "className": className, "style": style, "attribute": attribute, "title": title, "show": show }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="filter-content">
        ${data?.map((item, index) => renderTemplate`${renderComponent($$result2, "Checkbox", $$Checkbox, { "id": `${inputId}-${index}`, "label": `${item.label}${item.count ? `(${item.count})` : ""}`, "name": item.name, "value": item.value, "checked": item.checked, "disabled": item.disabled, "style": {
    ...more && index > 4 ? { display: "none" } : {}
  }, "attribute": {
    "data-count": item.count,
    "data-title": item.label
  } })}`)}
        ${more && renderTemplate`<div>
                    ${renderComponent($$result2, "Button", $$Button, { "variant": "blue-outline", "title": "\u66F4\u591A", "size": "sm", "attribute": {
    "data-toggle": "toggle",
    "data-target": "filter-collapse"
  } }, { "default": ($$result3) => renderTemplate`
                        更多
                    ` })}
                </div>`}
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/filter.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Category = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Category;
  const { IDName, className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "category"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Notice", $$Notice, {})}
    ${renderComponent($$result, "Badges", $$Badges, {})}
    <div data-filter>
        ${data?.map((item) => renderTemplate`${renderComponent($$result, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children })}`)}
    </div>
    ${renderComponent($$result, "Button", $$Button, { "className": "category-back-button", "title": "\u8FD4\u56DE\u7BE9\u9078", "button": false, "attribute": { "data-toggle": "back", "data-target": "#SolutionList" }, "style": { visibility: "hidden" } }, { "default": ($$result2) => renderTemplate`
        <span>返回篩選</span>
    ` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/collapse/category.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$ArticleOffcanvas = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$ArticleOffcanvas;
  const { IDName = "sectionArticle", className, style, attribute = {}, category } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyOffcanvas", $$Offcanvas, { "IDName": IDName, "postion": "bottom", "hideHeader": true, "className": ["section-article-offcanvas", className], "attribute": attribute, "style": style }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<form action="" class="article-offcanvas-form">
        <div class="article-offcanvas-form-header">
            <div class="article-offcanvas-form-header-top">
                <strong class="article-offcanvas-form-header-title">篩選結果</strong>
                ${renderComponent($$result2, "ALink", $$Link, { "title": "\u6E05\u9664\u5168\u90E8", "attribute": { "data-category-clear": "" } }, { "default": ($$result3) => renderTemplate`清除全部` })}
            </div>
            <div data-filter-badges>
                <template>
                    ${renderComponent($$result2, "Badge", $$Badge, { "Tag": "span", "status": "filter", "showCross": true }, { "default": ($$result3) => renderTemplate`<span></span>` })}
                </template>
                <div class="category-badges-list" data-filter-badges-list></div>
            </div>
        </div>
        <div class="article-offcanvas-form-body scrollbar" data-filter>
            ${category?.map((item, index) => renderTemplate`${renderComponent($$result2, "Filter", $$Filter, { "title": item.title, "show": item.show, "more": item.more, "data": item.children, "style": {
    ...index === 0 ? { "--collapse-border-width": "0" } : {}
  } })}`)}
        </div>
        <div class="article-offcanvas-form-footer">
            ${renderComponent($$result2, "Button", $$Button, { "type": "reset", "size": "sm", "variant": "blue-outline", "title": "\u53D6\u6D88", "block": true, "attribute": { "data-bs-dismiss": "offcanvas" } }, { "default": ($$result3) => renderTemplate`取消` })}
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "size": "sm", "variant": "blue", "title": "\u63D0\u4EA4", "block": true, "attribute": { "data-title": "\u63D0\u4EA4", "data-category-button": "" } }, { "default": ($$result3) => renderTemplate`
                提交
            ` })}
        </div>
    </form>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articleOffcanvas.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$ShowMore = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$ShowMore;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "show-more"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <button type="button" title="Show More"${addAttribute([
    "show-more-button"
  ], "class:list")} data-toggle="show-more" data-target="#article-list-grid">
        Show More
        ${renderComponent($$result, "PaginationArrow", $$PaginationArrow, { "size": "12", "direction": "down", "color": "blue-500" })}
    </button>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/showMore.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Loading = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Loading;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "section-loading"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="loader"></div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/loading.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$ArticlesList = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ArticlesList;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "",
    total = 0,
    sortDate = [],
    category = [],
    mode = "gray"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "section-articles-list",
    { "section-articles-dark-list": mode === "gray" },
    { "section-articles-light-list": mode === "white" }
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="section-articles-list-inner">
        ${renderComponent($$result, "Title", $$Title, { "title": title })}
        <div class="article-mobile-category">
            <div class="article-mobile-sort-selector">
                ${renderComponent($$result, "SortSelector", $$SortSelector, { "data": sortDate })}
            </div>
            ${renderComponent($$result, "Button", $$Button, { "variant": "blue", "size": "sm", "title": "\u7BE9\u9078", "attribute": {
    "data-bs-toggle": "offcanvas",
    "data-bs-target": `#${IDName}ArticleOffcanvas`,
    "aria-controls": `${IDName}ArticleOffcanvas`,
    "data-title": "\u7BE9\u9078",
    "data-category-button": ""
  } }, { "default": ($$result2) => renderTemplate`
                篩選
            ` })}
        </div>
        <div class="article-list-container">
            ${renderComponent($$result, "Sort", $$Sort, { "total": total, "data": sortDate })}
            <div class="article-list-content">
                ${renderComponent($$result, "Category", $$Category, { "className": "article-category", "data": category })}
                <div class="article-list-grid-container">
                    <div id="article-list-grid" class="article-list-grid">
                        ${renderSlot($$result, $$slots["default"])}
                    </div>
                    ${renderComponent($$result, "ShowMore", $$ShowMore, {})}
                    <template id="article-loading-template">
                        ${renderComponent($$result, "Loading", $$Loading, { "style": { "grid-column": "span 2 / span 2" } })}
                    </template>
                </div>
            </div>
        </div>
    </div>
</div>
${renderComponent($$result, "ArticleOffcanvas", $$ArticleOffcanvas, { "IDName": `${IDName}Article`, "category": category })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/article/articlesList.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://www.Asus.com.tw");
const $$SciptInline = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$SciptInline;
  const { data } = Astro2.props;
  return renderTemplate(_a || (_a = __template(["<script>(function(){", `
    window.NewsData = data;
})();<\/script>
<script>
    /**
     * News \u5361\u7247\u6A21\u677F\u53C3\u6578
     * @typedef {Object} NewsCardParams
     * @property {string} link - \u5361\u7247\u9023\u7D50
     * @property {string} date - \u65E5\u671F\u6587\u5B57
     * @property {string} title - \u6A19\u984C
     * @property {string} label - \u6A19\u7C64/\u5206\u985E
     * @property {string} breif - \u7C21\u4ECB
     * @property {string[]} images - \u5716\u7247\u7531\u5C0F\u5716\u653E\u5230\u5927\u5716\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 image \u53EF\u64C7\u4E00\u500B
     * @property {string} image - \u53EA\u60F3\u653E\u55AE\u4E00\u5716\u7247\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 images \u53EF\u64C7\u4E00\u500B
     * @property {string} logo - Logo \u5716\u7247\u8DEF\u5F91\uFF08\u542B\u526F\u6A94\u540D\uFF09
     */

    /**
     * \u6A21\u64EC API \u5C64
     */
    class API {
        /**
         * \u53D6\u5F97\u66F4\u591A News \u8CC7\u6599
         * @returns {Promise<NewsItem[]>} News \u8CC7\u6599\u9663\u5217
         * @description \u5BEB\u4F60\u6B63\u5F0F\u7684 API \u4F86\u6E90\uFF0C\u56DE\u50B3\u9663\u5217\u662F NewsItem[]\uFF0C\u5305\u542B\u4EE5\u4E0B Key/value
         * @param {string} link - \u5361\u7247\u9023\u7D50
         * @param {string} date - \u65E5\u671F\u6587\u5B57
         * @param {string} title - \u6A19\u984C
         * @param {string} label - \u6A19\u7C64/\u5206\u985E
         * @param {string} breif - \u7C21\u4ECB
         * @param {string[]} images - \u5716\u7247\u7531\u5C0F\u5716\u653E\u5230\u5927\u5716\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 image \u53EF\u64C7\u4E00\u500B
         * @param {string} image - \u53EA\u60F3\u653E\u55AE\u4E00\u5716\u7247\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 images \u53EF\u64C7\u4E00\u500B
         * @param {string} logo - Logo \u5716\u7247\u8DEF\u5F91\uFF08\u542B\u526F\u6A94\u540D\uFF09
         */
        addNewsApi = (searchParams = '') => {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve(window.NewsData);
                }, 2000);
            });
        };
    }

    /**
     * News \u5217\u8868\u4E92\u52D5\u63A7\u5236\u5668
     * @description
     * - \u9EDE\u64CA\u300C\u986F\u793A\u66F4\u591A\u300D\u6309\u9215\u5F8C\u8F09\u5165\u8CC7\u6599\u4E26\u63D2\u5165\u5361\u7247
     * - \u540C\u6B65 URL query string \u7684 page\uFF08\u4EE3\u8868\u76EE\u524D\u5DF2\u986F\u793A\u5361\u7247\u6578\u91CF\uFF09
     */
    class Article extends API {
        /**
         * \u300C\u986F\u793A\u66F4\u591A\u300D\u6309\u9215
         * @type {HTMLButtonElement | null}
         */
        triggerBtn = document.querySelector('button[data-toggle="show-more"]');

        /**
         * \u5361\u7247\u5217\u8868\u5BB9\u5668
         * @type {HTMLElement | null}
         */
        listGrid =
            document.querySelector(this.triggerBtn?.getAttribute('data-target')) || document.querySelector('#article-list-grid');

        /**
         * \u5217\u8868\u5BB9\u5668\u7684\u5916\u5C64\uFF08\u7528\u65BC\u63D2\u5165 loading template \u8207\u63A7\u5236\u986F\u793A\uFF09
         * @type {HTMLElement}
         */
        listGridContainer = this.listGrid?.parentNode;

        /**
         * \u65E5\u66C6 icon SVG \u6A21\u677F
         * @type {string}
         */
        calendarIconTemp = \`
        <svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.5 2.09961H16.5C16.9971 2.09961 17.4004 2.50294 17.4004 3V17C17.4004 17.4971 16.9971 17.9004 16.5 17.9004H1.5C1.00294 17.9004 0.599609 17.4971 0.599609 17V3C0.59961 2.50294 1.00294 2.09961 1.5 2.09961Z" stroke="currentColor" stroke-width="1.2"></path>
            <line y1="6.9" x2="18" y2="6.9" stroke="currentColor" stroke-width="1.2"></line>
            <line x1="5.4" y1="3.9" x2="5.4" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
            <line x1="12.9" y1="3.9" x2="12.9" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
        </svg>\`;

        /**
         * \u7BAD\u982D icon SVG \u6A21\u677F
         * @type {string}
         */
        arrowIconTemp = \`
        <svg width="6" height="9" viewBox="0 0 6 9" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0.195668 0.18892C0.320668 0.0691288 0.466501 0.00662879 0.633168 0.00142045C0.805043 -0.00899621 0.958688 0.0378788 1.09411 0.142045L1.14098 0.18892L4.91442 3.96236C4.97692 4.02486 5.02379 4.09777 5.05504 4.18111C5.0915 4.25923 5.10973 4.34257 5.10973 4.43111C5.10973 4.51965 5.0915 4.60559 5.05504 4.68892C5.02379 4.77225 4.97692 4.84517 4.91442 4.90767L1.14098 8.6733C1.01077 8.8035 0.851918 8.86861 0.664418 8.86861C0.482126 8.86861 0.325876 8.8035 0.195668 8.6733C0.0654593 8.54309 0.000355114 8.38684 0.000355114 8.20455C0.000355114 8.02225 0.0654593 7.866 0.195668 7.7358L3.50036 4.43111L0.195668 1.13423L0.156605 1.07955C0.0472301 0.949337 -0.00485322 0.8009 0.000355114 0.634233C0.0107718 0.462358 0.0758759 0.31392 0.195668 0.18892Z" fill="currentColor"></path>
        </svg>\`;

        /**
         * Loading template HTML
         * @type {string | undefined}
         */
        loadingTemp = document.querySelector('template[id="article-loading-template"]')?.innerHTML?.trim();

        /**
         * \u521D\u59CB\u5316\u4E26\u7D81\u5B9A\u4E8B\u4EF6
         */
        constructor() {
            super();
        }

        /**
         * \u521D\u59CB\u5316
         */
        init = () => {
            this.bindEvent();
            this.syncPageQuery();
        };

        /**
         * \u540C\u6B65 URL query string \u7684 page
         * @description
         * page \u53C3\u6578\u4EE3\u8868\u76EE\u524D\u5DF2\u6E32\u67D3\u5728\u9801\u9762\u4E0A\u7684\u5361\u7247\u6578\u91CF\u3002
         * @returns {void}
         */
        syncPageQuery = () => {
            const count = this.listGrid?.querySelectorAll?.('.news-card')?.length ?? 0;
            const url = new URL(window.location.href);
            url.searchParams.set('page', String(count));
            window.history.replaceState(window.history.state, '', url.toString());
        };

        /**
         * \u7522\u751F News \u5361\u7247 HTML \u5B57\u4E32
         * @param {NewsCardParams} params - \u5361\u7247\u6E32\u67D3\u6240\u9700\u53C3\u6578
         * @param {string} link - \u5361\u7247\u9023\u7D50
         * @param {string} date - \u65E5\u671F\u6587\u5B57
         * @param {string} title - \u6A19\u984C
         * @param {string} label - \u6A19\u7C64/\u5206\u985E
         * @param {string} breif - \u7C21\u4ECB
         * @param {string[]} images - \u5716\u7247\u7531\u5C0F\u5716\u653E\u5230\u5927\u5716\uFF0C\u8207 image \u53EF\u64C7\u4E00\u500B
         * @param {string} image - \u53EA\u60F3\u653E\u55AE\u4E00\u5716\u7247\uFF0C\u8207 images \u53EF\u64C7\u4E00\u500B
         * @param {string} logo - Logo \u5716\u7247\u8DEF\u5F91\uFF08\u542B\u526F\u6A94\u540D\uFF09
         * @returns {string} card HTML
         */
        cardTemp = ({ link, date, title, label, breif, images, image, logo }) => {
            const image_sm = images?.[0] || image;
            const image_md = images?.[1] || images?.[0] || image;
            const image_lg = images?.[2] || images?.[1] || images?.[0] || image;
            return \`
            <a class="news-card group" href="\${link}" title="\${title}" style="--card-width:100%">
                <div class="news-card-image-container">
                    <picture>
                        <source srcset="\${image_sm} 1x, \${image_md} 1.5x, \${image_lg} 2x" media="(min-width:1280px)" type="image/png">
                        <source srcset="\${image_sm} 1x, \${image_md} 1.5x, \${image_lg} 2x" media="(min-width:731px)" type="image/png">
                        <source srcset="\${image_sm} 1x, \${image_md} 1.5x, \${image_lg} 2x" media="(min-width:0px)" type="image/png">
                        <img class="news-card-image" src="\${image_sm}" alt="\${title}" title="\${title}" loading="lazy" decoding="async">
                    </picture>
                </div>
                <div class="news-card-content">
                    \${
                        date
                            ? \`<div class="date-card news-card-date">
                                    <span class="calendar-icon">
                                        \${this.calendarIconTemp}
                                    </span>
                                    <span class="date-card-text">\${date}</span>
                                </div>\`
                            : ''
                    }
                    \${
                        Boolean(title || label || breif)
                            ? \`<div class="news-card-head">
                                    \${title ? \`<strong class="news-card-title">\${title}</strong>\` : ''}
                                    \${label ? \`<span class="news-card-label">\${label}</span>\` : ''}
                                    \${breif ? \`<span class="news-card-breif">\${breif}</span>\` : ''}
                                </div>\`
                            : ''
                    }
                    <div class="news-card-footer">
                        \${
                            logo
                                ? \`<div class="news-card-logo">
                                        <picture>
                                            <img src="\${logo}" alt="\${title}" title="\${title}" loading="lazy" decoding="async">
                                        </picture>
                                    </div>\`
                                : ''
                        }
                        <span href="\${link}" aria-label="\u4E86\u89E3\u66F4\u591A" class="link-with-arrow size_16 font_roboto svg-arrow news-card-link">
                            <span class="link-text weight_regular">\u4E86\u89E3\u66F4\u591A</span>
                            <span class="link-arrow svg-arrow">
                                \${this.arrowIconTemp}
                            </span>
                        </span>
                    </div>
                </div>
            </a>\`;
        };

        /**
         * \u7D81\u5B9A\u300C\u986F\u793A\u66F4\u591A\u300D\u6309\u9215\u4E8B\u4EF6
         * @returns {void}
         */
        bindEvent = () => {
            this.triggerBtn.addEventListener('click', () => this.handleClick());
        };

        /**
         * \u6309\u9215\u9EDE\u64CA\u4E8B\u4EF6
         * @param {string} searchParams - \u641C\u5C0B\u53C3\u6578
         * @param {boolean} update - \u662F\u5426\u6E05\u7A7A\u5F8C\u91CD\u5EFA
         * @returns {Promise<void>}
         */
        handleClick = async (searchParams = '', update = false) => {
            try {
                if (update && this.listGrid) this.listGrid.innerHTML = '';
                this.beginLoading();
                const data = await this.addNewsApi(searchParams);
                this.add(data);
            } catch (error) {
                this.endLoading();
            }
        };

        /**
         * \u65B0\u589E\u5361\u7247\u5230\u5217\u8868
         * @param {NewsItem[]} data - \u6B32\u63D2\u5165\u7684\u8CC7\u6599
         * @param {boolean} update - \u662F\u5426\u6E05\u7A7A\u5F8C\u91CD\u5EFA
         * @returns {Promise<void>}
         */
        add = async (data = []) => {
            data.forEach((item) => {
                const data = {
                    title: item.title,
                    label: item.label,
                    date: item.date,
                    breif: item.breif,
                    image: item.img + '.png',
                    link: item.link,
                    logo: item.logoImage ? item.logoImage + '.' + item.logoImageType : undefined
                };
                if (this.listGrid) {
                    this.listGrid.insertAdjacentHTML('beforeend', this.cardTemp(data));
                }
            });
            this.syncPageQuery();
            this.endLoading();
        };

        /**
         * \u9032\u5165 loading \u72C0\u614B
         * @description
         * - \u7981\u7528\u6309\u9215
         * - \u96B1\u85CF\u6309\u9215\u7236\u5C64
         * - \u5728\u5BB9\u5668\u63D2\u5165 loading template
         * @returns {void}
         */
        beginLoading = () => {
            console.log('Begin Loading');
            if (this.triggerBtn) {
                this.triggerBtn.disabled = true;
                this.triggerBtn.parentNode.style.display = 'none';
            }
            if (this.listGridContainer) {
                const hasLoading = this.listGridContainer.querySelector('.section-loading');
                if (hasLoading) return;
                if (!this.loadingTemp) return;
                this.listGridContainer.insertAdjacentHTML('beforeend', this.loadingTemp);
            }
        };

        /**
         * \u7D50\u675F loading \u72C0\u614B
         * @param {boolean=} isLast - \u662F\u5426\u70BA\u6700\u5F8C\u4E00\u9801\uFF08\u70BA true \u6642\u4E0D\u518D\u986F\u793A\u6309\u9215\uFF09
         * @returns {void}
         */
        endLoading = (isLast) => {
            if (this.triggerBtn) {
                if (!isLast) {
                    this.triggerBtn.disabled = false;
                    this.triggerBtn.parentNode.style.display = 'flex';
                }
            }
            if (this.listGridContainer) {
                const loadingEl = this.listGridContainer.querySelector('.section-loading');
                if (!loadingEl) return;
                loadingEl.remove();
            }
        };
    }

    // \u7B49\u5F85 DOM \u52A0\u8F09\u5B8C\u6210\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new Article().init());
    } else {
        new Article().init();
    }
<\/script>`], ["<script>(function(){", `
    window.NewsData = data;
})();<\/script>
<script>
    /**
     * News \u5361\u7247\u6A21\u677F\u53C3\u6578
     * @typedef {Object} NewsCardParams
     * @property {string} link - \u5361\u7247\u9023\u7D50
     * @property {string} date - \u65E5\u671F\u6587\u5B57
     * @property {string} title - \u6A19\u984C
     * @property {string} label - \u6A19\u7C64/\u5206\u985E
     * @property {string} breif - \u7C21\u4ECB
     * @property {string[]} images - \u5716\u7247\u7531\u5C0F\u5716\u653E\u5230\u5927\u5716\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 image \u53EF\u64C7\u4E00\u500B
     * @property {string} image - \u53EA\u60F3\u653E\u55AE\u4E00\u5716\u7247\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 images \u53EF\u64C7\u4E00\u500B
     * @property {string} logo - Logo \u5716\u7247\u8DEF\u5F91\uFF08\u542B\u526F\u6A94\u540D\uFF09
     */

    /**
     * \u6A21\u64EC API \u5C64
     */
    class API {
        /**
         * \u53D6\u5F97\u66F4\u591A News \u8CC7\u6599
         * @returns {Promise<NewsItem[]>} News \u8CC7\u6599\u9663\u5217
         * @description \u5BEB\u4F60\u6B63\u5F0F\u7684 API \u4F86\u6E90\uFF0C\u56DE\u50B3\u9663\u5217\u662F NewsItem[]\uFF0C\u5305\u542B\u4EE5\u4E0B Key/value
         * @param {string} link - \u5361\u7247\u9023\u7D50
         * @param {string} date - \u65E5\u671F\u6587\u5B57
         * @param {string} title - \u6A19\u984C
         * @param {string} label - \u6A19\u7C64/\u5206\u985E
         * @param {string} breif - \u7C21\u4ECB
         * @param {string[]} images - \u5716\u7247\u7531\u5C0F\u5716\u653E\u5230\u5927\u5716\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 image \u53EF\u64C7\u4E00\u500B
         * @param {string} image - \u53EA\u60F3\u653E\u55AE\u4E00\u5716\u7247\uFF08\u542B\u526F\u6A94\u540D\uFF09\uFF0C\u8207 images \u53EF\u64C7\u4E00\u500B
         * @param {string} logo - Logo \u5716\u7247\u8DEF\u5F91\uFF08\u542B\u526F\u6A94\u540D\uFF09
         */
        addNewsApi = (searchParams = '') => {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve(window.NewsData);
                }, 2000);
            });
        };
    }

    /**
     * News \u5217\u8868\u4E92\u52D5\u63A7\u5236\u5668
     * @description
     * - \u9EDE\u64CA\u300C\u986F\u793A\u66F4\u591A\u300D\u6309\u9215\u5F8C\u8F09\u5165\u8CC7\u6599\u4E26\u63D2\u5165\u5361\u7247
     * - \u540C\u6B65 URL query string \u7684 page\uFF08\u4EE3\u8868\u76EE\u524D\u5DF2\u986F\u793A\u5361\u7247\u6578\u91CF\uFF09
     */
    class Article extends API {
        /**
         * \u300C\u986F\u793A\u66F4\u591A\u300D\u6309\u9215
         * @type {HTMLButtonElement | null}
         */
        triggerBtn = document.querySelector('button[data-toggle="show-more"]');

        /**
         * \u5361\u7247\u5217\u8868\u5BB9\u5668
         * @type {HTMLElement | null}
         */
        listGrid =
            document.querySelector(this.triggerBtn?.getAttribute('data-target')) || document.querySelector('#article-list-grid');

        /**
         * \u5217\u8868\u5BB9\u5668\u7684\u5916\u5C64\uFF08\u7528\u65BC\u63D2\u5165 loading template \u8207\u63A7\u5236\u986F\u793A\uFF09
         * @type {HTMLElement}
         */
        listGridContainer = this.listGrid?.parentNode;

        /**
         * \u65E5\u66C6 icon SVG \u6A21\u677F
         * @type {string}
         */
        calendarIconTemp = \\\`
        <svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.5 2.09961H16.5C16.9971 2.09961 17.4004 2.50294 17.4004 3V17C17.4004 17.4971 16.9971 17.9004 16.5 17.9004H1.5C1.00294 17.9004 0.599609 17.4971 0.599609 17V3C0.59961 2.50294 1.00294 2.09961 1.5 2.09961Z" stroke="currentColor" stroke-width="1.2"></path>
            <line y1="6.9" x2="18" y2="6.9" stroke="currentColor" stroke-width="1.2"></line>
            <line x1="5.4" y1="3.9" x2="5.4" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
            <line x1="12.9" y1="3.9" x2="12.9" y2="0.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></line>
        </svg>\\\`;

        /**
         * \u7BAD\u982D icon SVG \u6A21\u677F
         * @type {string}
         */
        arrowIconTemp = \\\`
        <svg width="6" height="9" viewBox="0 0 6 9" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0.195668 0.18892C0.320668 0.0691288 0.466501 0.00662879 0.633168 0.00142045C0.805043 -0.00899621 0.958688 0.0378788 1.09411 0.142045L1.14098 0.18892L4.91442 3.96236C4.97692 4.02486 5.02379 4.09777 5.05504 4.18111C5.0915 4.25923 5.10973 4.34257 5.10973 4.43111C5.10973 4.51965 5.0915 4.60559 5.05504 4.68892C5.02379 4.77225 4.97692 4.84517 4.91442 4.90767L1.14098 8.6733C1.01077 8.8035 0.851918 8.86861 0.664418 8.86861C0.482126 8.86861 0.325876 8.8035 0.195668 8.6733C0.0654593 8.54309 0.000355114 8.38684 0.000355114 8.20455C0.000355114 8.02225 0.0654593 7.866 0.195668 7.7358L3.50036 4.43111L0.195668 1.13423L0.156605 1.07955C0.0472301 0.949337 -0.00485322 0.8009 0.000355114 0.634233C0.0107718 0.462358 0.0758759 0.31392 0.195668 0.18892Z" fill="currentColor"></path>
        </svg>\\\`;

        /**
         * Loading template HTML
         * @type {string | undefined}
         */
        loadingTemp = document.querySelector('template[id="article-loading-template"]')?.innerHTML?.trim();

        /**
         * \u521D\u59CB\u5316\u4E26\u7D81\u5B9A\u4E8B\u4EF6
         */
        constructor() {
            super();
        }

        /**
         * \u521D\u59CB\u5316
         */
        init = () => {
            this.bindEvent();
            this.syncPageQuery();
        };

        /**
         * \u540C\u6B65 URL query string \u7684 page
         * @description
         * page \u53C3\u6578\u4EE3\u8868\u76EE\u524D\u5DF2\u6E32\u67D3\u5728\u9801\u9762\u4E0A\u7684\u5361\u7247\u6578\u91CF\u3002
         * @returns {void}
         */
        syncPageQuery = () => {
            const count = this.listGrid?.querySelectorAll?.('.news-card')?.length ?? 0;
            const url = new URL(window.location.href);
            url.searchParams.set('page', String(count));
            window.history.replaceState(window.history.state, '', url.toString());
        };

        /**
         * \u7522\u751F News \u5361\u7247 HTML \u5B57\u4E32
         * @param {NewsCardParams} params - \u5361\u7247\u6E32\u67D3\u6240\u9700\u53C3\u6578
         * @param {string} link - \u5361\u7247\u9023\u7D50
         * @param {string} date - \u65E5\u671F\u6587\u5B57
         * @param {string} title - \u6A19\u984C
         * @param {string} label - \u6A19\u7C64/\u5206\u985E
         * @param {string} breif - \u7C21\u4ECB
         * @param {string[]} images - \u5716\u7247\u7531\u5C0F\u5716\u653E\u5230\u5927\u5716\uFF0C\u8207 image \u53EF\u64C7\u4E00\u500B
         * @param {string} image - \u53EA\u60F3\u653E\u55AE\u4E00\u5716\u7247\uFF0C\u8207 images \u53EF\u64C7\u4E00\u500B
         * @param {string} logo - Logo \u5716\u7247\u8DEF\u5F91\uFF08\u542B\u526F\u6A94\u540D\uFF09
         * @returns {string} card HTML
         */
        cardTemp = ({ link, date, title, label, breif, images, image, logo }) => {
            const image_sm = images?.[0] || image;
            const image_md = images?.[1] || images?.[0] || image;
            const image_lg = images?.[2] || images?.[1] || images?.[0] || image;
            return \\\`
            <a class="news-card group" href="\\\${link}" title="\\\${title}" style="--card-width:100%">
                <div class="news-card-image-container">
                    <picture>
                        <source srcset="\\\${image_sm} 1x, \\\${image_md} 1.5x, \\\${image_lg} 2x" media="(min-width:1280px)" type="image/png">
                        <source srcset="\\\${image_sm} 1x, \\\${image_md} 1.5x, \\\${image_lg} 2x" media="(min-width:731px)" type="image/png">
                        <source srcset="\\\${image_sm} 1x, \\\${image_md} 1.5x, \\\${image_lg} 2x" media="(min-width:0px)" type="image/png">
                        <img class="news-card-image" src="\\\${image_sm}" alt="\\\${title}" title="\\\${title}" loading="lazy" decoding="async">
                    </picture>
                </div>
                <div class="news-card-content">
                    \\\${
                        date
                            ? \\\`<div class="date-card news-card-date">
                                    <span class="calendar-icon">
                                        \\\${this.calendarIconTemp}
                                    </span>
                                    <span class="date-card-text">\\\${date}</span>
                                </div>\\\`
                            : ''
                    }
                    \\\${
                        Boolean(title || label || breif)
                            ? \\\`<div class="news-card-head">
                                    \\\${title ? \\\`<strong class="news-card-title">\\\${title}</strong>\\\` : ''}
                                    \\\${label ? \\\`<span class="news-card-label">\\\${label}</span>\\\` : ''}
                                    \\\${breif ? \\\`<span class="news-card-breif">\\\${breif}</span>\\\` : ''}
                                </div>\\\`
                            : ''
                    }
                    <div class="news-card-footer">
                        \\\${
                            logo
                                ? \\\`<div class="news-card-logo">
                                        <picture>
                                            <img src="\\\${logo}" alt="\\\${title}" title="\\\${title}" loading="lazy" decoding="async">
                                        </picture>
                                    </div>\\\`
                                : ''
                        }
                        <span href="\\\${link}" aria-label="\u4E86\u89E3\u66F4\u591A" class="link-with-arrow size_16 font_roboto svg-arrow news-card-link">
                            <span class="link-text weight_regular">\u4E86\u89E3\u66F4\u591A</span>
                            <span class="link-arrow svg-arrow">
                                \\\${this.arrowIconTemp}
                            </span>
                        </span>
                    </div>
                </div>
            </a>\\\`;
        };

        /**
         * \u7D81\u5B9A\u300C\u986F\u793A\u66F4\u591A\u300D\u6309\u9215\u4E8B\u4EF6
         * @returns {void}
         */
        bindEvent = () => {
            this.triggerBtn.addEventListener('click', () => this.handleClick());
        };

        /**
         * \u6309\u9215\u9EDE\u64CA\u4E8B\u4EF6
         * @param {string} searchParams - \u641C\u5C0B\u53C3\u6578
         * @param {boolean} update - \u662F\u5426\u6E05\u7A7A\u5F8C\u91CD\u5EFA
         * @returns {Promise<void>}
         */
        handleClick = async (searchParams = '', update = false) => {
            try {
                if (update && this.listGrid) this.listGrid.innerHTML = '';
                this.beginLoading();
                const data = await this.addNewsApi(searchParams);
                this.add(data);
            } catch (error) {
                this.endLoading();
            }
        };

        /**
         * \u65B0\u589E\u5361\u7247\u5230\u5217\u8868
         * @param {NewsItem[]} data - \u6B32\u63D2\u5165\u7684\u8CC7\u6599
         * @param {boolean} update - \u662F\u5426\u6E05\u7A7A\u5F8C\u91CD\u5EFA
         * @returns {Promise<void>}
         */
        add = async (data = []) => {
            data.forEach((item) => {
                const data = {
                    title: item.title,
                    label: item.label,
                    date: item.date,
                    breif: item.breif,
                    image: item.img + '.png',
                    link: item.link,
                    logo: item.logoImage ? item.logoImage + '.' + item.logoImageType : undefined
                };
                if (this.listGrid) {
                    this.listGrid.insertAdjacentHTML('beforeend', this.cardTemp(data));
                }
            });
            this.syncPageQuery();
            this.endLoading();
        };

        /**
         * \u9032\u5165 loading \u72C0\u614B
         * @description
         * - \u7981\u7528\u6309\u9215
         * - \u96B1\u85CF\u6309\u9215\u7236\u5C64
         * - \u5728\u5BB9\u5668\u63D2\u5165 loading template
         * @returns {void}
         */
        beginLoading = () => {
            console.log('Begin Loading');
            if (this.triggerBtn) {
                this.triggerBtn.disabled = true;
                this.triggerBtn.parentNode.style.display = 'none';
            }
            if (this.listGridContainer) {
                const hasLoading = this.listGridContainer.querySelector('.section-loading');
                if (hasLoading) return;
                if (!this.loadingTemp) return;
                this.listGridContainer.insertAdjacentHTML('beforeend', this.loadingTemp);
            }
        };

        /**
         * \u7D50\u675F loading \u72C0\u614B
         * @param {boolean=} isLast - \u662F\u5426\u70BA\u6700\u5F8C\u4E00\u9801\uFF08\u70BA true \u6642\u4E0D\u518D\u986F\u793A\u6309\u9215\uFF09
         * @returns {void}
         */
        endLoading = (isLast) => {
            if (this.triggerBtn) {
                if (!isLast) {
                    this.triggerBtn.disabled = false;
                    this.triggerBtn.parentNode.style.display = 'flex';
                }
            }
            if (this.listGridContainer) {
                const loadingEl = this.listGridContainer.querySelector('.section-loading');
                if (!loadingEl) return;
                loadingEl.remove();
            }
        };
    }

    // \u7B49\u5F85 DOM \u52A0\u8F09\u5B8C\u6210\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new Article().init());
    } else {
        new Article().init();
    }
<\/script>`])), defineScriptVars({ data }));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/scipt-inline.astro", void 0);

export { $$Follower as $, $$SciptInline as a, $$ArticlesList as b };
