import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, f as renderSlot, d as renderTemplate } from './astro/server_v5wg8FJS.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Divider = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Divider;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute(["auth-divider", className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <span class="auth-divider-line"></span>
    <span class="flex-none text-gray-900 body-02">
        ${renderSlot($$result, $$slots["default"])}
    </span>
    <span class="auth-divider-line"></span>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/auth/divider.astro", void 0);

export { $$Divider as $ };
