/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { f as field, d as data } from '../../chunks/data_Zo7AKlqP.mjs';
import { c as $$Link, a as $$Layouts } from '../../chunks/layouts_DEVhm48G.mjs';
import { $ as $$Body, a as $$Title, b as $$Sort } from '../../chunks/title_Cr1nKE0I.mjs';
import { $ as $$Tables } from '../../chunks/tables_BG2Y_4Oy.mjs';
/* empty css                                         */
export { renderers } from '../../renderers.mjs';

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$MobileTd = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MobileTd;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "order-aocc-card"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <strong class="order-aocc-card-title">${data[2].text}</strong>
    <ul class="order-aocc-card-list">
        <li class="order-aocc-card-li">
            <span class="order-aocc-list-title">詢問單號</span>
            <span>${data[0].text}</span>
        </li>
        <li class="order-aocc-card-li">
            <span class="order-aocc-list-title">詢問日期</span>
            <span>${data[1].text}</span>
        </li>
        <li class="order-aocc-card-li">
            <span class="order-aocc-list-title">數量</span>
            <span>${data[3].text}</span>
        </li>
        <li class="order-aocc-card-li">
            <span class="order-aocc-list-title">狀態</span>
            <span>${data[4].text}</span>
        </li>
        <li class="order-aocc-card-li-center">
            ${renderComponent($$result, "ALink", $$Link, { "link": `/member/order-aocc/${data[0].text}`, "size": "14", "title": "\u67E5\u770B\u660E\u7D30" }, { "default": ($$result2) => renderTemplate`查看明細` })}
        </li>
    </ul>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/order-aocc/MobileTd.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Content = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Content;
  const { IDName = "OrderAocc", className, style, attribute = {}, data = [], field = [] } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tables", $$Tables, { "IDName": IDName, "data": data, "field": field, "className": [className, ":uno-order-aocc-tables:"], "mobileTable": "md", "MobileComponent": $$MobileTd, "style": style, ...attribute })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/order-aocc/content.astro", void 0);

const $$OrderAocc = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberOrder-aocc", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u6211\u7684\u8AEE\u8A62\u593E" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u6211\u7684\u8AEE\u8A62\u593E", "showSort": true })}
        ${renderComponent($$result3, "Table", $$Content, { "data": data, "field": field })}
        ${renderComponent($$result3, "Sort", $$Sort, { "type": "bottom" })}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc.astro";
const $$url = "/member/order-aocc.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$OrderAocc,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
