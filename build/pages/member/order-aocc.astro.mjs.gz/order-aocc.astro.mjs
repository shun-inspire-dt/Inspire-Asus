/* empty css                                      */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../../chunks/layouts_DkrHgxBi.mjs';
import '../../chunks/order-aocc.454a5b5d_l0sNRNKZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$OrderAocc = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberOrder-aocc", "minMarginHeader": true, "isMemberFooter": true })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc.astro";
const $$url = "/member/order-aocc.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$OrderAocc,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
