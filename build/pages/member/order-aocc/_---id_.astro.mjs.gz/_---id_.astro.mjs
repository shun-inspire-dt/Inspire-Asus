/* empty css                                         */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate, r as renderComponent } from '../../../chunks/astro/server_v5wg8FJS.mjs';
import { d as data } from '../../../chunks/data_fMNA7_yL.mjs';
import { $ as $$Card, d as data$1 } from '../../../chunks/card_DPKfhZrm.mjs';
import { a as $$Layouts } from '../../../chunks/layouts_2rr1OTfM.mjs';
import { $ as $$Body, a as $$Title } from '../../../chunks/title_DYmC-7ff.mjs';
/* empty css                                      */
export { renderers } from '../../../renderers.mjs';

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Progress = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Progress;
  const { IDName, className, style, attribute = {}, progress = [] } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "progress"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <!-- 手機版 -->
    <div class="progress-mobile">
        <div class="progress-mobile__steps">
            ${progress.map((item) => {
    return renderTemplate`<span${addAttribute(["progress-mobile__step", { active: item.active }], "class:list")}>${item.id}</span>`;
  })}
        </div>
        <div class="progress-mobile__bar"${addAttribute({
    "--progress-width": progress.slice(1).filter((i) => i.active).length * 100 / progress.slice(1).length + "%"
  }, "style")}>
        </div>
        <div class="progress-mobile__content">
            ${progress.map((item, index) => {
    return renderTemplate`<span${addAttribute([
      "progress-mobile__info",
      {
        active: progress.filter((i) => i.active).findLastIndex((i) => i.active) === index
      }
    ], "class:list")}>
                            ${item.title && renderTemplate`<span class="progress-mobile__title">${item.title}</span>`}
                            ${item.date && renderTemplate`<span class="progress-mobile__date">${item.date}</span>`}
                            ${item.text && renderTemplate`<span class="progress-mobile__text">${item.text}</span>`}
                        </span>`;
  })}
        </div>
    </div>
    <!-- 電腦版 -->
    <div class="progress-desktop">
        ${progress.map((item, index) => renderTemplate`<div${addAttribute(["progress-desktop__item", { active: item.active }], "class:list")}>
                    <div${addAttribute(["progress-desktop__bar", { first: index === 0 }, { last: index === progress.length - 1 }], "class:list")}></div>
                    <div class="progress-desktop__content">
                        <span${addAttribute(["progress-desktop__step"], "class:list")}>${item.id}</span>
                        <span class="progress-desktop__info">
                            ${item.title && renderTemplate`<span class="progress-desktop__title">${item.title}</span>`}
                            ${item.date && renderTemplate`<span${addAttribute(["progress-desktop__date"], "class:list")}>${item.date}</span>`}
                            ${item.text && renderTemplate`<span${addAttribute(["progress-desktop__text"], "class:list")}>${item.text}</span>`}
                        </span>
                    </div>
                </div>`)}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/progress/progress.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Content = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Content;
  const { IDName, className, style, attribute = {}, date = "", data = [] } = Astro2.props;
  const progress = [
    { id: 1, title: "\u8AEE\u8A62\u6210\u7ACB", date, active: true },
    { id: 2, title: "\u8AEE\u8A62\u6210\u7ACB", date, active: false },
    { id: 3, title: "\u8AEE\u8A62\u6210\u7ACB", date, active: false }
  ];
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "order-aocc-detail"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Progress", $$Progress, { "progress": progress })}
    <div class="order-aocc-detail-content">
        <div class="order-aocc-detail-comment">
            <strong class="order-aocc-detail-comment-title">諮詢備註</strong>
            <p class="order-aocc-detail-comment-text">訂單備註訂單備註訂單備註訂單備註訂單備註訂單備註訂單備註</p>
        </div>
        <div class="order-aocc-detail-product">
            <div class="order-aocc-detail-product-head">
                <strong class="order-aocc-detail-product-title">產品清單</strong>
                <p class="order-aocc-detail-product-text">共 <b>2</b> 項產品</p>
            </div>
            <div class="order-aocc-detail-product-list">
                ${data.map((x) => renderTemplate`${renderComponent($$result, "Card", $$Card, { "id": x.id, "title": x.title, "label": x.label, "brief": x.brief, "amount": x.amount, "img": x.img, "readonly": true })}`)}
            </div>
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/order-aocc/[id]/content.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
async function getStaticPaths() {
  return data.flatMap((x) => x.items.map((y) => y.text).filter((_, index) => index === 0)).map((id) => ({ params: { id } }));
}
const prerender = true;
const $$ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const targetData = data.map((x) => x.items.map((y) => y.text));
  const { id } = Astro2.params;
  const [_, date = "", text = "", quantity = "", status = ""] = targetData.filter((x) => x.includes(id?.toString())).flatMap((x) => x) || [];
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberOrder-aoccDetail", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u6211\u7684\u8AEE\u8A62\u593E" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u8AEE\u8A62\u7DE8\u865F: " + id, "link": "/member/order-aocc", "linkText": "\u8FD4\u56DE\u6211\u7684\u8AEE\u8A62\u593E\u5217\u8868", "rightText": `\u65E5\u671F: ${date}`, "showRightText": true, "showLink": true })}
        ${renderComponent($$result3, "Content", $$Content, { "date": date, "data": data$1 })}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc/[...id].astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc/[...id].astro";
const $$url = "/member/order-aocc/[...id].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$,
    file: $$file,
    getStaticPaths,
    prerender,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
