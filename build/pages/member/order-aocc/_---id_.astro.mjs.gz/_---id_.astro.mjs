/* empty css                                         */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from '../../../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../../../chunks/layouts_DkrHgxBi.mjs';
import '../../../chunks/_id_.0974ced3_l0sNRNKZ.mjs';
export { renderers } from '../../../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
async function getStaticPaths() {
  return Array.from({ length: 10 }).map((_, index) => ({ params: { id: index } }));
}
const prerender = true;
const $$ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const { id } = Astro2.params;
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberOrder-aoccDetail", "minMarginHeader": true, "isMemberFooter": true })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc/[...id].astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/order-aocc/[...id].astro";
const $$url = "/member/order-aocc/[...id].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$,
    file: $$file,
    getStaticPaths,
    prerender,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
