/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, a as $$Layouts } from '../../chunks/layouts_k9LlQnqK.mjs';
import { $ as $$Body, a as $$Title } from '../../chunks/title_RaiNZ8Eo.mjs';
import { $ as $$ComfirmCode } from '../../chunks/comfirm-code_BGaLU3e_.mjs';
import { $ as $$InputGroup } from '../../chunks/inputGroup_BwDyYgK3.mjs';
import { $ as $$PasswordInput } from '../../chunks/passwordInput_BHGsGiTO.mjs';
import '../../chunks/update-password.b0055741_l0sNRNKZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "UpdatePasswordForm", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<form${addAttribute(IDName, "id")}${addAttribute([className, "update-password-form needs-validation"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)} action="/member/order-aocc" novalidate>
    <div class="section-half-form-grid-item">
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u820A\u5BC6\u78BC", "infoText": "\u8ACB\u8F38\u5165\u60A8\u7684\u820A\u5BC6\u78BC", "errorText": "\u5BC6\u78BC\u9700\u5305\u62EC8\u81F325\u4F4D\u5927\u5C0F\u5BEB\u5B57\u6BCD\u3001\u6578\u5B57\u53CA\u7B26\u865F\uFF0C\u4E14\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\u3002", "block": true, "error": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "PasswordInput", $$PasswordInput, { "inputId": "old-password", "required": true })}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u65B0\u5BC6\u78BC", "infoText": "\u5BC6\u78BC\u9700\u5305\u62EC8\u81F325\u4F4D\u5927\u5C0F\u5BEB\u5B57\u6BCD\u3001\u6578\u5B57\u53CA\u7B26\u865F\uFF0C\u4E14\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\u3002", "errorText": "\u5BC6\u78BC\u9700\u5305\u62EC8\u81F325\u4F4D\u5927\u5C0F\u5BEB\u5B57\u6BCD\u3001\u6578\u5B57\u53CA\u7B26\u865F\uFF0C\u4E14\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\u3002", "block": true, "error": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "PasswordInput", $$PasswordInput, { "inputId": "password", "required": true })}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u518D\u6B21\u8F38\u5165\u60A8\u7684\u65B0\u5BC6\u78BC", "infoText": "\u8ACB\u60A8\u518D\u6B21\u8F38\u5165\u60A8\u7684\u65B0\u5BC6\u78BC", "errorText": "\u8207\u65B0\u5BC6\u78BC\u4E0D\u7B26\u5408", "block": true, "error": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "PasswordInput", $$PasswordInput, { "inputId": "confirm-password", "required": true, "inputAttribute": {
    "data-valid": "confirm",
    "data-target": "#password"
  } })}
        ` })}
    </div>
    <div class="section-form-grid-item">
        <div class="form-button-container">
            ${renderComponent($$result, "Button", $$Button, { "type": "submit", "className": "basic-info-form-button", "size": "lg", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result2) => renderTemplate`
                確認修改
            ` })}
        </div>
    </div>
</form>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/update-password/form.astro", void 0);

const $$UpdatePassword = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberUpdate-password", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u8B8A\u66F4\u5BC6\u78BC", "activeCollapse": "\u5E33\u6236\u8A2D\u5B9A" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u8B8A\u66F4\u5BC6\u78BC", "showSort": true })}
        ${renderComponent($$result3, "Form", $$Form, {})}
    ` })}
` })}
${renderComponent($$result, "ComfirmCode", $$ComfirmCode, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/update-password.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/update-password.astro";
const $$url = "/member/update-password.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$UpdatePassword,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
