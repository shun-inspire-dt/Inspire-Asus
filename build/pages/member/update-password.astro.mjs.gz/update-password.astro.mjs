/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, a as $$Layouts } from '../../chunks/layouts_fHJQayoE.mjs';
import { $ as $$Body, a as $$Title } from '../../chunks/title_4GCBRRg8.mjs';
import { $ as $$ComfirmCode } from '../../chunks/comfirm-code_D5wNpxJ4.mjs';
import { $ as $$ScriptNext } from '../../chunks/script-next.copy_6IMlkj12.mjs';
import { $ as $$InputGroup } from '../../chunks/inputGroup_BwDyYgK3.mjs';
import { $ as $$PasswordInput } from '../../chunks/passwordInput_BEawJj2N.mjs';
import '../../chunks/update-password.b0055741_l0sNRNKZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "UpdatePasswordForm", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<form${addAttribute(IDName, "id")}${addAttribute([className, "update-password-form needs-validation"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)} action="" novalidate data-needs-loading="true">
    <div class="section-half-form-grid-item">
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u820A\u5BC6\u78BC", "infoText": "\u8ACB\u8F38\u5165\u60A8\u7684\u820A\u5BC6\u78BC", "errorText": "", "block": true, "error": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "PasswordInput", $$PasswordInput, { "inputId": "old-password", "required": true, "inputAttribute": {
    "data-valid": "async",
    "data-target": "checkPWD"
  } })}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u65B0\u5BC6\u78BC", "infoText": "\u5BC6\u78BC\u9700\u5305\u62EC8\u81F325\u4F4D\u5927\u5C0F\u5BEB\u5B57\u6BCD\u3001\u6578\u5B57\u53CA\u7B26\u865F\uFF0C\u4E14\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\u3002", "errorText": "", "block": true, "error": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "PasswordInput", $$PasswordInput, { "inputId": "password", "inputAttribute": { pattern: `(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[^A-Za-z0-9])[!-~]{8,25}` }, "required": true })}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u518D\u6B21\u8F38\u5165\u60A8\u7684\u65B0\u5BC6\u78BC", "infoText": "\u8ACB\u60A8\u518D\u6B21\u8F38\u5165\u60A8\u7684\u65B0\u5BC6\u78BC", "errorText": "", "block": true, "error": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "PasswordInput", $$PasswordInput, { "inputId": "confirm-password", "required": true, "inputAttribute": {
    "data-valid": "confirm",
    "data-target": "#password",
    "data-valid-feedback": "\u8207\u65B0\u5BC6\u78BC\u4E0D\u7B26\u5408"
  } })}
        ` })}
    </div>
    <div class="section-form-grid-item">
        <div class="form-button-container">
            ${renderComponent($$result, "Button", $$Button, { "type": "submit", "className": "basic-info-form-button", "size": "lg", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result2) => renderTemplate`
                確認修改
            ` })}
        </div>
    </div>
</form>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/update-password/form.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$ScriptInline = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["<script>\n    // \u5168\u5C40 Toast \u5BE6\u4F8B\n    const toastEl = document.getElementById('toastModal');\n    const header = () =>\n        new Headers({\n            'Content-Type': 'application/json',\n            token: '123'\n        });\n    // \u521D\u59CB\u5316\u6240\u6709\u9700\u8981\u9A57\u8B49\u7684\u8868\u55AE\n    const checkPWD = async (password) => {\n        const raw = JSON.stringify({\n            password\n        });\n\n        const requestOptions = {\n            method: 'POST',\n            headers: header(),\n            body: raw\n        };\n\n        return await fetch('https://shun-fast-api.zeabur.app/api/form/check-password', requestOptions)\n            .then((response) => response.json())\n            .then((result) => result)\n            .catch((error) => {\n                console.error('Password check error:', error.message);\n                return { success: false, message: '\u9A57\u8B49\u5931\u6557' };\n            });\n    };\n\n    const form = document.getElementById('UpdatePasswordForm');\n    const validation = new FormValidator(form, {\n        asyncValidators: {\n            checkPWD: async (input) => {\n                const result = await checkPWD(input.value);\n                return result.success ? true : { feedback: '\u820A\u5BC6\u78BC\u8F38\u5165\u932F\u8AA4' };\n            }\n        },\n        async onValidSubmit({ controls }) {\n            try {\n                const { 'confirm-password': RpasswordEl, password: passwordEl } = controls || {};\n\n                const raw = JSON.stringify({\n                    password: RpasswordEl.value\n                });\n\n                const requestOptions = {\n                    method: 'POST',\n                    headers: header(),\n                    body: raw\n                };\n\n                await fetch('https://shun-fast-api.zeabur.app/api/form/strict-update-password', requestOptions)\n                    .then((response) => response.json())\n                    .then((result) => {\n                        if (result.success) {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: { title: '\u6210\u529F', text: result.message }\n                                })\n                            );\n                        } else {\n                            RpasswordEl.value = '';\n                            passwordEl.value = '';\n                            validation.triggerValidation(passwordEl, true, result.message || '\u820A\u5BC6\u78BC\u8F38\u5165\u932F\u8AA4');\n                            validation.triggerValidation(RpasswordEl, true, '\u65B0\u5BC6\u78BC\u8207\u78BA\u8A8D\u5BC6\u78BC\u4E0D\u4E00\u81F4');\n                        }\n                    })\n                    .catch((error) => {\n                        console.error('Password check error:', error.message);\n                        toastEl.dispatchEvent(\n                            new CustomEvent('fire', {\n                                detail: { title: '\u932F\u8AA4', text: '\u5BC6\u78BC\u9A57\u8B49\u904E\u7A0B\u4E2D\u767C\u751F\u932F\u8AA4' }\n                            })\n                        );\n                    });\n            } catch (error) {\n                console.error('Toast dispatch error:', error);\n            }\n        }\n    });\n<\/script>"])));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/update-password/script-inline.astro", void 0);

const $$UpdatePassword = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberUpdate-password", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u8B8A\u66F4\u5BC6\u78BC", "activeCollapse": "\u5E33\u6236\u8A2D\u5B9A" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u8B8A\u66F4\u5BC6\u78BC", "showSort": true })}
        ${renderComponent($$result3, "Form", $$Form, {})}
    ` })}
` })}
${renderComponent($$result, "ComfirmCode", $$ComfirmCode, {})}
${renderComponent($$result, "ScriptNext", $$ScriptNext, {})}
${renderComponent($$result, "ScriptInline", $$ScriptInline, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/update-password.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/update-password.astro";
const $$url = "/member/update-password.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$UpdatePassword,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
