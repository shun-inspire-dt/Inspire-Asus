/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate, r as renderComponent } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../../chunks/layouts_Ls1-M9Mi.mjs';
import { $ as $$Body, a as $$Title, b as $$Sort } from '../../chunks/title_D7bmQK4c.mjs';
import { $ as $$Tables } from '../../chunks/tables_B9j6SiM7.mjs';
/* empty css                                             */
export { renderers } from '../../renderers.mjs';

const data = [
  ["未讀", "2025/09/15", "審核已通過", "您上架的解決方案 iShops 已審核通過"],
  ["已讀", "2025/09/14", "補件通知", "您上架的解決方案 iShops 需要補件"],
  ["已讀", "2025/09/13", "審核中", "您的解決方案 iShops 正在審核中"],
  ["已讀", "2025/09/12", "審核未通過", "您上架的解決方案 iShops 未審核通過，請檢查您的資料"],
  ["已讀", "2025/09/11", "已回覆", "審核團隊已回覆您的問題"],
  ["已讀", "2025/09/10", "需進一步審核", "您的解決方案 iShops 需要更詳細的資料進行審核"],
  ["已讀", "2025/09/09", "提交成功", "您的解決方案 iShops 已成功提交"],
  ["已讀", "2025/09/08", "修改建議", "我們建議對您的解決方案 iShops 進行一些修改"],
  ["已讀", "2025/09/07", "等待客戶確認", "您的解決方案 iShops 正在等待客戶的確認"],
  ["已讀", "2025/09/06", "已上架", "您的解決方案 iShops 已成功上架到平台"]
].flatMap((x) => ({
  items: x.flatMap((y) => ({ text: y, attribute: { style: { "color": y === "未讀" ? "var(--color-red-300, #B42D18)" : "" } } }))
}));
const emptyData = [
  ["目前沒有任何通知訊息"]
].flatMap((x) => ({
  items: x.flatMap((y) => ({ text: y, colspan: 4, attribute: { "data-empty": true } }))
}));
const width = {
  狀態: "4.5rem",
  時間: "7.375rem",
  標題: "8rem",
  內容: "auto"
};
const field = ["狀態", "時間", "標題", "內容"].map((x) => ({
  text: x,
  attribute: { style: { "min-width": width[x] } }
}));

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$MobileTd = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MobileTd;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "message-center-card"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="message-center-card-head">
        <strong class="message-center-card-head-title">${data?.[2]?.text}</strong>
        <span class="message-center-card-head-text">${data?.[0]?.text}</span>
    </div>
    <div class="message-center-card-body">
        <p class="message-center-card-body-text">${data?.[1]?.text}</p>
        <p class="message-center-card-body-date">${data?.[3]?.text}</p>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/message-center/MobileTd.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Table = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Table;
  const {
    IDName = "MessageCenter",
    className,
    style,
    attribute = {},
    data = [],
    field = [],
    mobileTable = "md",
    empty = false
  } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Tables", $$Tables, { "IDName": IDName, "data": data, "field": field, "className": ["group", { "empty-tables": empty }, className], "mobileTable": mobileTable, "MobileComponent": $$MobileTd, "style": style, "attribute": { "data-empty": empty ? true : void 0, ...attribute } })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/message-center/table.astro", void 0);

const $$MessageCenter = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberMessage-center", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u8A0A\u606F\u4E2D\u5FC3" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u8A0A\u606F\u4E2D\u5FC3", "showSort": true })}
        ${renderComponent($$result3, "Table", $$Table, { "data": data, "field": field })}
        ${renderComponent($$result3, "Table", $$Table, { "data": emptyData, "field": field, "empty": true })}
        ${renderComponent($$result3, "Sort", $$Sort, { "type": "bottom" })}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/message-center.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/message-center.astro";
const $$url = "/member/message-center.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$MessageCenter,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
