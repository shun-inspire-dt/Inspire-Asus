/* empty css                                      */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../../chunks/layouts_DkrHgxBi.mjs';
import '../../chunks/basic-info.8866ddee_l0sNRNKZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$BasicInfo = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberBasic-info", "minMarginHeader": true, "isMemberFooter": true })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/basic-info.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/basic-info.astro";
const $$url = "/member/basic-info.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$BasicInfo,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
