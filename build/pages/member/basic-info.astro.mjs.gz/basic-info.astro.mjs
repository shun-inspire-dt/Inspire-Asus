/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, b as $$Input, a as $$Layouts } from '../../chunks/layouts_Bzy3aiqY.mjs';
import { $ as $$Body, a as $$Title } from '../../chunks/title_CkpihzED.mjs';
import { $ as $$InputGroup } from '../../chunks/inputGroup_B5i-ZHGC.mjs';
import { $ as $$Select } from '../../chunks/select_DOhfc9yu.mjs';
import '../../chunks/basic-info.8866ddee_l0sNRNKZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<form${addAttribute(IDName, "id")}${addAttribute([
    className,
    "basic-info-form needs-validation"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)} novalidate>
    <div class="section-form-grid-item">
        <strong class="section-form-grid-title">基本資料</strong>
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u59D3\u540D", "errorText": "\u8ACB\u8F38\u5165\u60A8\u7684\u59D3\u540D", "error": true, "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u624B\u6A5F\u865F\u78BC", "errorText": "\u8ACB\u8F38\u5165\u60A8\u7684\u624B\u6A5F\u865F\u78BC", "error": true, "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Input", $$Input, { "type": "tel", "inputmode": "tel", "maxLength": 10 })}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u96FB\u5B50\u4FE1\u7BB1", "errorText": "\u8ACB\u8F38\u5165\u60A8\u7684\u96FB\u5B50\u90F5\u4EF6", "error": true, "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Input", $$Input, { "type": "email", "inputmode": "email" })}
        ` })}
    </div>
    <div class="section-form-grid-item">
        <strong class="section-form-grid-title">公司資料</strong>
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u540D\u7A31", "errorText": "\u8ACB\u8F38\u5165\u516C\u53F8\u7684\u540D\u7A31", "error": true, "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u7D71\u7DE8", "errorText": "\u8ACB\u8F38\u5165\u516C\u53F8\u7684\u7D71\u7DE8", "error": true, "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Input", $$Input, { "type": "text", "inputmode": "numeric", "minLength": 8, "maxLength": 8 })}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u90E8\u9580", "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Select", $$Select, { "data": [
    { text: "IT\u90E8\u9580", value: "IT\u90E8\u9580" },
    { text: "\u8CA1\u52D9\u90E8\u9580", value: "\u8CA1\u52D9\u90E8\u9580" }
  ], "value": "IT\u90E8\u9580" })}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u8077\u7A31", "errorText": "\u8ACB\u8F38\u5165\u5728\u516C\u53F8\u7684\u8077\u7A31", "error": true, "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result, "InputGroup", $$InputGroup, { "label": "\u7522\u696D\u985E\u5225", "block": true }, { "default": ($$result2) => renderTemplate`
            ${renderComponent($$result2, "Select", $$Select, { "data": [
    { text: "\u96F2\u7AEF\u8207\u57FA\u790E\u8A2D\u65BD", value: "\u96F2\u7AEF\u8207\u57FA\u790E\u8A2D\u65BD" },
    { text: "\u4F01\u696D\u61C9\u7528", value: "\u4F01\u696D\u61C9\u7528" },
    { text: "\u8CC7\u6599\u4E2D\u5FC3", value: "\u8CC7\u6599\u4E2D\u5FC3" },
    { text: "\u5132\u5B58", value: "\u5132\u5B58" },
    { text: "\u5B89\u5168", value: "\u5B89\u5168" },
    { text: "\u5132\u5B58", value: "\u5132\u5B58" }
  ], "value": "IT\u90E8\u9580" })}
        ` })}
        <div class="form-button-container">
            ${renderComponent($$result, "Button", $$Button, { "type": "submit", "className": "basic-info-form-button", "size": "lg", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result2) => renderTemplate`
                確認修改
            ` })}
        </div>
    </div>
</form>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/basic-info/form.astro", void 0);

const $$BasicInfo = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberBasic-info", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u57FA\u672C\u8CC7\u6599", "activeCollapse": "\u5E33\u6236\u8A2D\u5B9A" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u500B\u4EBA\u57FA\u672C\u8CC7\u6599", "showSort": true })}
        ${renderComponent($$result3, "Form", $$Form, {})}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/basic-info.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/basic-info.astro";
const $$url = "/member/basic-info.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$BasicInfo,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
