/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../../chunks/layouts_72KHugm1.mjs';
import { $ as $$Body, a as $$Title, b as $$Sort } from '../../chunks/title_D6UReHMS.mjs';
import { a as $$Card } from '../../chunks/card_9uyYff7Z.mjs';
import '../../chunks/my-wishlist.dda7cb26_l0sNRNKZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$List = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$List;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "my-wishlist-grid"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result, "Card", $$Card, { "linkText": "\u79FB\u9664\u6536\u85CF", "showLinkArrow": false, "showPlayBack": index % 2 === 0 })}`)}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/my-wishlist/list.astro", void 0);

const $$MyWishlist = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberMy-wishlist", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u6211\u7684\u6536\u85CF\u6E05\u55AE" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u6536\u85CF\u6E05\u55AE", "showSort": true })}
        ${renderComponent($$result3, "List", $$List, {})}
        ${renderComponent($$result3, "Sort", $$Sort, { "type": "bottom" })}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/my-wishlist.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/my-wishlist.astro";
const $$url = "/member/my-wishlist.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$MyWishlist,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
