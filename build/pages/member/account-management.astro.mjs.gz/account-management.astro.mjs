/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, a as $$Layouts } from '../../chunks/layouts_Cd0HYti7.mjs';
import { $ as $$Body, a as $$Title } from '../../chunks/title_BF3VFlb6.mjs';
import { $ as $$SocialIcon } from '../../chunks/SocialIcon_6ODmP4Ig.mjs';
import '../../chunks/account-management.fe992dc0_l0sNRNKZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "account-management"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <ul class="account-management-acct">
        <li class="account-management-acct-title">您的 Email</li>
        <li class="account-management-acct-content">
            <span class="account-management-acct-email">
                <span class="account-management-acct-email-text">
                    marketing@inspire-dt.com
                </span>
                <span class="account-management-acct-email-btn">
                    ${renderComponent($$result, "Button", $$Button, { "type": "button", "variant": "blue-outline", "size": "sm", "title": "\u8B8A\u66F4\u4FE1\u7BB1" }, { "default": ($$result2) => renderTemplate`變更信箱` })}
                </span>
            </span>
        </li>
    </ul>
    <ul class="account-management-social">
        <li class="account-management-social-title">社群帳號</li>
        <li class="account-management-social-list">
            <span class="account-management-social-item">
                <span class="account-management-social-item-content">
                    <span class="account-management-social-item-text">
                        ${renderComponent($$result, "SocialIcon", $$SocialIcon, { "type": "icon_google", "size": "sm" })}
                        已與 Google 帳號做連結
                    </span>
                    <span class="account-management-social-item-link">
                        ${renderComponent($$result, "Button", $$Button, { "Tag": "a", "variant": "blue-outline", "size": "sm", "title": "\u89E3\u9664\u9023\u7D50" }, { "default": ($$result2) => renderTemplate`解除連結` })}
                    </span>
                </span>
            </span>
            <span class="account-management-social-item">
                <span class="account-management-social-item-content">
                    <span class="account-management-social-item-text">
                        ${renderComponent($$result, "SocialIcon", $$SocialIcon, { "type": "icon_microsoft", "size": "sm" })}
                        尚未與 Microsoft 帳號做連結
                    </span>
                    <span class="account-management-social-item-link">
                        ${renderComponent($$result, "Button", $$Button, { "Tag": "a", "variant": "blue-outline", "size": "sm", "title": "\u7ACB\u5373\u9023\u7D50" }, { "default": ($$result2) => renderTemplate`立即連結` })}
                    </span>
                </span>
            </span>
        </li>
    </ul>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/account-management/form.astro", void 0);

const $$AccountManagement = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberAccount-management", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u5E33\u865F\u7BA1\u7406", "activeCollapse": "\u5E33\u6236\u8A2D\u5B9A" }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u5E33\u865F\u7BA1\u7406", "showSort": true })}
        ${renderComponent($$result3, "Form", $$Form, {})}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/account-management.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/account-management.astro";
const $$url = "/member/account-management.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$AccountManagement,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
