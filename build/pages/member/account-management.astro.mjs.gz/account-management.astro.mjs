/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, e as $$Modal, b as $$Input, a as $$Layouts } from '../../chunks/layouts_D8she11O.mjs';
import { $ as $$Body, a as $$Title } from '../../chunks/title_CUuDcLa_.mjs';
import { $ as $$SocialIcon } from '../../chunks/SocialIcon_6ODmP4Ig.mjs';
import '../../chunks/account-management.fe992dc0_l0sNRNKZ.mjs';
import { $ as $$InputGroup } from '../../chunks/inputGroup_c-Ph_iRB.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "account-management"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <ul class="account-management-acct">
        <li class="account-management-acct-title">您的 Email</li>
        <li class="account-management-acct-content">
            <span class="account-management-acct-email">
                <span class="account-management-acct-email-text">
                    marketing@inspire-dt.com
                </span>
                <span class="account-management-acct-email-btn">
                    ${renderComponent($$result, "Button", $$Button, { "type": "button", "variant": "blue-outline", "size": "sm", "title": "\u8B8A\u66F4\u4FE1\u7BB1", "attribute": { "data-bs-toggle": "modal", "data-bs-target": "#UpdateEmailSendCodeModal" } }, { "default": ($$result2) => renderTemplate`
                        變更信箱
                    ` })}
                </span>
            </span>
        </li>
    </ul>
    <ul class="account-management-social">
        <li class="account-management-social-title">社群帳號</li>
        <li class="account-management-social-list">
            <span class="account-management-social-item">
                <span class="account-management-social-item-content">
                    <span class="account-management-social-item-text">
                        ${renderComponent($$result, "SocialIcon", $$SocialIcon, { "type": "icon_google", "size": "sm" })}
                        已與 Google 帳號做連結
                    </span>
                    <span class="account-management-social-item-link">
                        ${renderComponent($$result, "Button", $$Button, { "Tag": "a", "variant": "blue-outline", "size": "sm", "title": "\u89E3\u9664\u9023\u7D50" }, { "default": ($$result2) => renderTemplate`解除連結` })}
                    </span>
                </span>
            </span>
            <span class="account-management-social-item">
                <span class="account-management-social-item-content">
                    <span class="account-management-social-item-text">
                        ${renderComponent($$result, "SocialIcon", $$SocialIcon, { "type": "icon_microsoft", "size": "sm" })}
                        尚未與 Microsoft 帳號做連結
                    </span>
                    <span class="account-management-social-item-link">
                        ${renderComponent($$result, "Button", $$Button, { "Tag": "a", "variant": "blue-outline", "size": "sm", "title": "\u7ACB\u5373\u9023\u7D50" }, { "default": ($$result2) => renderTemplate`立即連結` })}
                    </span>
                </span>
            </span>
        </li>
    </ul>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/member/account-management/form.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$ComfirmUpdateEmail = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ComfirmUpdateEmail;
  const { IDName = "ComfirmUpdateEmail", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Modal", $$Modal, { "id": IDName, "title": "\u8F38\u5165\u9A57\u8B49\u78BC", "Modalclass": className, "cancelVariant": "blue-outline", "cancelTitle": "\u53D6\u6D88", "okVariant": "blue", "okTitle": "\u78BA\u8A8D\u9A57\u8B49", "okAttribute": { "type": "submit" }, "sizes": "xl", "center": true, "ContentTag": "form", "contentAttribute": { action: "", id: `${IDName}Form`, "data-step": "next", "data-target": "#ResetEmailModal" }, "hideColse": true, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    請至原本的信箱收取驗證碼，驗證成功後才能變更信箱
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u8ACB\u8F38\u5165\u9A57\u8B49\u78BC", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "required": true })}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/modal/comfirm-update-email.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$UpdateEmailSendCode = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$UpdateEmailSendCode;
  const { IDName = "UpdateEmailSendCode", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Modal", $$Modal, { "id": IDName, "title": "\u8B8A\u66F4\u4FE1\u7BB1", "Modalclass": className, "cancelVariant": "blue-outline", "cancelTitle": "\u53D6\u6D88", "okVariant": "blue", "okTitle": "\u78BA\u8A8D\u5BC4\u51FA", "okAttribute": { type: "submit" }, "sizes": "xl", "center": true, "ContentTag": "form", "contentAttribute": { action: "", id: `${IDName}Form` }, "hideColse": true, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    請至原本的信箱收取驗證碼，驗證成功後才能變更信箱
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/modal/update-email-send-code.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$ResetEmail = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ResetEmail;
  const { IDName = "ResetEmail", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Modal", $$Modal, { "id": IDName, "title": "\u8B8A\u66F4\u4FE1\u7BB1", "Modalclass": className, "cancelVariant": "blue-outline", "cancelTitle": "\u53D6\u6D88", "okVariant": "blue", "okTitle": "\u78BA\u8A8D\u5BC4\u51FA", "okAttribute": { "type": "submit" }, "sizes": "xl", "center": true, "ContentTag": "form", "contentAttribute": { action: "", id: `${IDName}Form` }, "hideColse": true, "attribute": attribute }, { "default": ($$result2) => renderTemplate`
    請至原本的信箱收取驗證碼，驗證成功後才能變更信箱
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u8ACB\u8F38\u5165\u96FB\u5B50\u90F5\u4EF6", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "type": "email", "inputmode": "email", "required": true })}
    ` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/modal/reset-email.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$AccountManagement = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["", "\n", "\n", "\n", "\n\n<script>\n    /**\n     * \u5E33\u865F\u7BA1\u7406 - \u4FE1\u7BB1\u8B8A\u66F4\u6D41\u7A0B\u7BA1\u7406\u985E\u5225\n     * @description \u7BA1\u7406\u4FE1\u7BB1\u8B8A\u66F4\u7684\u591A\u6B65\u9A5F\u6D41\u7A0B\uFF0C\u5305\u542B\u9A57\u8B49\u78BC\u767C\u9001\u3001\u78BA\u8A8D\u548C\u91CD\u8A2D\n     * @author ASUS Team\n     * @version 1.0.0\n     */\n    class EmailUpdateManager {\n        /**\n         * \u5EFA\u69CB\u51FD\u5F0F\n         * @description \u521D\u59CB\u5316\u6240\u6709 Modal \u548C Form \u5143\u7D20\uFF0C\u4E26\u7D81\u5B9A\u4E8B\u4EF6\u76E3\u807D\u5668\n         */\n        constructor() {\n            this.initElements();\n            this.bindEvents();\n        }\n\n        /**\n         * \u521D\u59CB\u5316 DOM \u5143\u7D20\n         * @description \u53D6\u5F97\u6240\u6709\u76F8\u95DC\u7684 Modal \u548C Form \u5143\u7D20\n         */\n        initElements() {\n            // Modal \u5143\u7D20\n            this.modals = {\n                confirm: document.querySelector('#ComfirmUpdateEmailModal'),\n                update: document.querySelector('#UpdateEmailSendCodeModal'),\n                reset: document.querySelector('#ResetEmailModal'),\n                toast: document.querySelector('#toastModal')\n            };\n\n            // Form \u5143\u7D20\n            this.forms = {\n                confirm: document.querySelector('#ComfirmUpdateEmailForm'),\n                update: document.querySelector('#UpdateEmailSendCodeForm'),\n                reset: document.querySelector('#ResetEmailForm')\n            };\n        }\n\n        /**\n         * \u7D81\u5B9A\u6240\u6709\u4E8B\u4EF6\u76E3\u807D\u5668\n         * @description \u70BA\u5404\u500B Form \u548C Modal \u7D81\u5B9A\u76F8\u61C9\u7684\u4E8B\u4EF6\u8655\u7406\u5668\n         */\n        bindEvents() {\n            // \u767C\u9001\u9A57\u8B49\u78BC\u8868\u55AE\u63D0\u4EA4\n            this.forms.update?.addEventListener('submit', async (e) => await this.handleUpdateSubmit(e));\n            \n            // \u78BA\u8A8D\u9A57\u8B49\u78BC\u8868\u55AE\u63D0\u4EA4\n            this.forms.confirm?.addEventListener('submit', async (e) => await this.handleConfirmSubmit(e));\n            \n            // \u91CD\u8A2D\u4FE1\u7BB1\u8868\u55AE\u63D0\u4EA4\n            this.forms.reset?.addEventListener('submit', async (e) => await this.handleResetSubmit(e));\n            \n            // Modal \u95DC\u9589\u4E8B\u4EF6\n            this.modals.confirm?.addEventListener('hidden.bs.modal', () => this.handleConfirmHidden());\n            this.modals.reset?.addEventListener('hidden.bs.modal', () => this.handleResetHidden());\n        }\n\n        /**\n         * \u8655\u7406\u767C\u9001\u9A57\u8B49\u78BC\u8868\u55AE\u63D0\u4EA4\n         * @param {Event} e - \u8868\u55AE\u63D0\u4EA4\u4E8B\u4EF6\n         * @description \u96B1\u85CF\u767C\u9001\u9A57\u8B49\u78BC Modal\uFF0C\u986F\u793A\u78BA\u8A8D\u9A57\u8B49\u78BC Modal\n         */\n        async handleUpdateSubmit(e) {\n            e.preventDefault();\n            this.hideModal('update');\n            this.showModal('confirm');\n        }\n\n        /**\n         * \u8655\u7406\u78BA\u8A8D\u9A57\u8B49\u78BC\u8868\u55AE\u63D0\u4EA4\n         * @param {Event} e - \u8868\u55AE\u63D0\u4EA4\u4E8B\u4EF6\n         * @description \u6839\u64DA\u6B65\u9A5F\u6C7A\u5B9A\u4E0B\u4E00\u500B\u52D5\u4F5C\uFF08\u986F\u793A\u91CD\u8A2D Modal \u6216\u5B8C\u6210\u6D41\u7A0B\uFF09\n         */\n        async handleConfirmSubmit(e) {\n            e.preventDefault();\n            const { step, target = '' } = this.forms.confirm?.dataset || {};\n            \n            if (step === 'next') {\n                this.handleNextStep(target);\n            } else if (step === 'finish') {\n                this.handleFinishStep();\n            }\n        }\n\n        /**\n         * \u8655\u7406\u91CD\u8A2D\u4FE1\u7BB1\u8868\u55AE\u63D0\u4EA4\n         * @param {Event} e - \u8868\u55AE\u63D0\u4EA4\u4E8B\u4EF6\n         * @description \u96B1\u85CF\u91CD\u8A2D Modal\uFF0C\u8A2D\u5B9A\u5B8C\u6210\u6B65\u9A5F\u4E26\u986F\u793A\u78BA\u8A8D Modal\n         */\n        async handleResetSubmit(e) {\n            e.preventDefault();\n            this.hideModal('reset');\n            this.forms.confirm?.setAttribute('data-step', 'finish');\n            this.showModal('confirm');\n        }\n\n        /**\n         * \u8655\u7406\u4E0B\u4E00\u6B65\u9A5F\n         * @param {string} target - \u76EE\u6A19 Modal \u9078\u64C7\u5668\n         * @description \u96B1\u85CF\u78BA\u8A8D Modal\uFF0C\u986F\u793A\u76EE\u6A19 Modal\n         */\n        handleNextStep(target) {\n            const targetModal = document.querySelector(target);\n            if (targetModal) {\n                this.hideModal('confirm');\n                targetModal.dispatchEvent(new Event('show'));\n            }\n        }\n\n        /**\n         * \u8655\u7406\u5B8C\u6210\u6B65\u9A5F\n         * @description \u986F\u793A\u6210\u529F Toast \u8A0A\u606F\n         */\n        handleFinishStep() {\n            this.modals.toast?.dispatchEvent(\n                new CustomEvent('fire', {\n                    detail: {\n                        icon: 'success',\n                        title: '\u4FE1\u7BB1\u5DF2\u6210\u529F\u8B8A\u66F4',\n                        text: '\u60A8\u7684\u806F\u7D61\u4FE1\u7BB1\u5DF2\u6210\u529F\u8B8A\u66F4',\n                        link: {\n                            primaryText: '\u95DC\u9589',\n                            primaryVariant: 'blue',\n                            cancel: () => {\n                                this.modals.toast?.dispatchEvent(new CustomEvent('hide'));\n                            }\n                        }\n                    }\n                })\n            );\n        }\n\n        /**\n         * \u8655\u7406\u78BA\u8A8D Modal \u95DC\u9589\u4E8B\u4EF6\n         * @description \u91CD\u8A2D\u78BA\u8A8D\u8868\u55AE\n         */\n        handleConfirmHidden() {\n            this.forms.confirm?.reset();\n        }\n\n        /**\n         * \u8655\u7406\u91CD\u8A2D Modal \u95DC\u9589\u4E8B\u4EF6\n         * @description \u91CD\u8A2D\u91CD\u8A2D\u8868\u55AE\n         */\n        handleResetHidden() {\n            this.forms.reset?.reset();\n        }\n\n        /**\n         * \u986F\u793A\u6307\u5B9A\u7684 Modal\n         * @param {string} modalName - Modal \u540D\u7A31\n         * @description \u89F8\u767C\u6307\u5B9A Modal \u7684\u986F\u793A\u4E8B\u4EF6\n         */\n        showModal(modalName) {\n            this.modals[modalName]?.dispatchEvent(new Event('show'));\n        }\n\n        /**\n         * \u96B1\u85CF\u6307\u5B9A\u7684 Modal\n         * @param {string} modalName - Modal \u540D\u7A31\n         * @description \u89F8\u767C\u6307\u5B9A Modal \u7684\u96B1\u85CF\u4E8B\u4EF6\n         */\n        hideModal(modalName) {\n            this.modals[modalName]?.dispatchEvent(new Event('hide'));\n        }\n    }\n\n    // \u521D\u59CB\u5316\u4FE1\u7BB1\u8B8A\u66F4\u7BA1\u7406\u5668\n    document.addEventListener('DOMContentLoaded', () => {\n        new EmailUpdateManager();\n    });\n<\/script>"])), renderComponent($$result, "Layouts", $$Layouts, { "IDName": "MemberAccount-management", "minMarginHeader": true, "isMemberFooter": true }, { "default": async ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Body", $$Body, { "activeTab": "\u5E33\u865F\u7BA1\u7406", "activeCollapse": "\u5E33\u6236\u8A2D\u5B9A" }, { "default": async ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Title", $$Title, { "title": "\u5E33\u865F\u7BA1\u7406", "showSort": true })}
        ${renderComponent($$result3, "Form", $$Form, {})}
    ` })}
` }), renderComponent($$result, "ComfirmUpdateEmail", $$ComfirmUpdateEmail, {}), renderComponent($$result, "UpdateEmailSendCode", $$UpdateEmailSendCode, {}), renderComponent($$result, "ResetEmail", $$ResetEmail, {}));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/account-management.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/account-management.astro";
const $$url = "/member/account-management.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$AccountManagement,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
