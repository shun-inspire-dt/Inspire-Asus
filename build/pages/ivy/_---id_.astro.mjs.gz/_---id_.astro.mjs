/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderTemplate, r as renderComponent, F as Fragment } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { d as $$A, a as $$Layouts } from '../../chunks/layouts_72KHugm1.mjs';
import { $ as $$Relative$1, a as $$Relative$2 } from '../../chunks/relative_BkRDZZAV.mjs';
import { $ as $$Nav } from '../../chunks/nav_D3LayA7j.mjs';
import { $ as $$Video } from '../../chunks/video_B8dAuQfo.mjs';
import { $ as $$Title } from '../../chunks/title_oZPX-wc9.mjs';
import { $ as $$Swiper, a as $$NavigatiorArrow } from '../../chunks/navigatiorArrow_C2-jrvGz.mjs';
import { $ as $$PlayBack, a as $$Card$1 } from '../../chunks/card_9uyYff7Z.mjs';
import '../../chunks/_id_.40fd0b3a_l0sNRNKZ.mjs';
import { C as Content } from '../../chunks/content_LlPOr_hm.mjs';
import { $ as $$Article$1 } from '../../chunks/article_DmKQRT5H.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Card = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Card;
  const { IDName, className, style, attribute = {}, type = "img", img, alt, text, title } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "ivy-card"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${img && renderTemplate`<img${addAttribute([
    "ivy-card-img",
    { "ivy-card-img-video": type === "video" }
  ], "class:list")}${addAttribute(img, "src")}${addAttribute(alt, "alt")}${addAttribute(alt, "title")} loading="lazy" decoding="async">`}
    ${type === "video" && renderTemplate`<div class="ivy-card-video">
                ${renderComponent($$result, "PlayBack", $$PlayBack, { "size": "48", "attribute": {
    title,
    "data-toggle": "video",
    "data-bs-toggle": "modal",
    "data-bs-target": "#VideoModal",
    "data-auto": "false",
    "data-video-id": "B-HEpSM-J5c"
  } })}
            </div>`}
    ${Boolean(type === "img" && text) && renderTemplate`<div class="ivy-card-text">
                ${text}
            </div>`}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/ivy/[id]/card.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Info = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Info;
  const { IDName = "IvyInformation", className, style, attribute = {} } = Astro2.props;
  const data = [
    {
      img: "/assets/images/pages/ivy-demo-1.png",
      alt: "ivy-demo-1",
      text: "Discover the advantages of Complete Hierarchies over Salesforce account hierarchies.",
      type: "video"
    },
    {
      img: "/assets/images/pages/ivy-demo-1.png",
      alt: "ivy-demo-1",
      text: "Discover the advantages of Complete Hierarchies over Salesforce account hierarchies.",
      type: "img"
    },
    {
      img: "/assets/images/pages/ivy-demo-1.png",
      alt: "ivy-demo-1",
      text: "Discover the advantages of Complete Hierarchies over Salesforce account hierarchies.",
      type: "img"
    },
    {
      img: "/assets/images/pages/ivy-demo-1.png",
      alt: "ivy-demo-1",
      text: "Discover the advantages of Complete Hierarchies over Salesforce account hierarchies.",
      type: "img"
    }
  ];
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "ivy-section-info"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Title", $$Title, { "title": "\u6B23\u5275\u6578\u4F4D\u79D1\u6280\u6709\u9650\u516C\u53F8" })}
    ${renderComponent($$result, "Swiper", $$Swiper, { "IDName": IDName, "className": "ivy-swiper-container", "swiperClassName": "ivy-swiper" }, { "default": ($$result2) => renderTemplate`${data.map((item, index) => renderTemplate`<div class="swiper-slide :uno-ivy-swiper-slide: !w-18.5rem md:!w-500px">
                    ${renderComponent($$result2, "Card", $$Card, { "img": item.img, "alt": item.alt, "text": item.text, "type": item.type })}
                </div>`)}
    `, "outside": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outside" }, { "default": ($$result3) => renderTemplate`
            <div class="ivy-section-next-button" data-swiper-button-next>
                ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "right" })}
            </div>
            <div class="ivy-section-prev-button" data-swiper-button-prev>
                ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "left" })}
            </div>
        ` })}` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/ivy/[id]/info.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$Follower = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Follower;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "ivy-follower"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "A", $$A, { "link": "", "className": "ivy-follower-button", "title": "\u7ACB\u5373\u8AEE\u8A62" }, { "default": ($$result2) => renderTemplate`
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M17 7H7C5.89543 7 5 7.89543 5 9V25C5 26.1046 5.89543 27 7 27H22C23.1046 27 24 26.1046 24 25V16.7561" stroke="var(--color-white, #fff)" stroke-width="1.5" stroke-linecap="round"></path>
            <path d="M12.0661 16.8265L23.5661 5.32653C23.5661 5.32653 25.0661 4.32653 26.5661 5.82653C28.0661 7.32653 27.0661 8.82653 27.0661 8.82653L15.5661 20.3265C15.5661 20.3265 10.5657 22.3265 10.0661 21.8265C9.5664 21.3265 12.0661 16.8265 12.0661 16.8265Z" stroke="var(--color-white, #fff)" stroke-width="1.5"></path>
        </svg>
        <span class="ivy-follower-button-text">
            <span>立</span>
            <span>即</span>
            <span>諮</span>
            <span>詢</span>
        </span>
    ` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/ivy/[id]/follower.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Article = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Article;
  const { IDName = "IvyArticle", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyArticle", $$Article$1, { "buttonText": "\u56DE\u5408\u4F5C\u5925\u4F34\u7E3D\u89BD", "buttonLink": "/ivy", "html": Content, "IDName": IDName, "className": ["ivy-article", className], "style": style, "attribute": attribute })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/ivy/[id]/article.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Relative = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Relative;
  const { IDName = "IvyRelative", className, style, attribute = {}, title = "\u76F8\u95DC\u65B9\u6848" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyRelative", $$Relative$1, { "title": title, "className": ["ivy-section-relative", className], "IDName": IDName, "style": style, "attribute": attribute, "count": 12 }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Card", $$Card$1, { "link": "/ivy/0", "showPlayBack": false })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/ivy/[id]/relative.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
async function getStaticPaths() {
  return Array.from({ length: 10 }).map((_, index) => ({ params: { id: index } }));
}
const prerender = true;
const $$ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const { id } = Astro2.params;
  const navId = `scroll-spy-IvyDetail`;
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "IvyDetail", "minMarginHeader": true, "footerPages": ["\u5408\u4F5C\u5925\u4F34"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Nav", $$Nav, { "IDName": navId, "data": [
    { title: "\u516C\u53F8\u4ECB\u7D39", link: "#IvyInformation", offset: "#scroll-spy-IvyDetail" },
    { title: "\u89E3\u6C7A\u65B9\u6848", link: "#IvyArticle", offset: "#scroll-spy-IvyDetail" },
    { title: "\u6700\u65B0\u6D88\u606F", link: "#IvyRelativeSwiperContainer", offset: "#scroll-spy-IvyDetail" }
  ] })}
    ${maybeRenderHead()}<div>
        ${renderComponent($$result2, "Info", $$Info, {})}
        ${renderComponent($$result2, "Article", $$Article, {})}
        ${renderComponent($$result2, "Relative", $$Relative, {})}
    </div>
` })}
${renderComponent($$result, "Follower", $$Follower, {})}
${renderComponent($$result, "Script", $$Relative$2, {})}
${renderComponent($$result, "Video", $$Video, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy/[...id].astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy/[...id].astro";
const $$url = "/ivy/[...id].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$,
    file: $$file,
    getStaticPaths,
    prerender,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
