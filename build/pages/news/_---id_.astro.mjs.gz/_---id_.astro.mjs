/* empty css                                      */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../../chunks/layouts_DpjfgSHX.mjs';
import { $ as $$Relative$1, a as $$Relative$2 } from '../../chunks/relative_ClCr-Y18.mjs';
import { $ as $$Article$1 } from '../../chunks/article_2peHogii.mjs';
import '../../chunks/_id_.1470729a_l0sNRNKZ.mjs';
import { $ as $$Card } from '../../chunks/card_s_R1mYA5.mjs';
export { renderers } from '../../renderers.mjs';

const Content = "<img src=\"https://dlcdnwebimgs.asus.com/files/media/202507/da91d98d-45d1-435a-bb31-049c323c85e7/thumb.png\">\n<br>\n<p>\n    市調機構IDC最新報告公布<a href=\"#footnote-1\"><sup>1</sup></a>，華碩<a\n        href=\"https://www.asus.com/tw/displays-desktops/tower-pcs/all-series/filter?Category=For-Work\"\n        target=\"_blank\">商用電腦</a>再次拿下2025年第一季台灣市佔冠軍，中小企業領域表現尤其亮眼！<a\n        href=\"https://www.asus.com/tw/displays-desktops/tower-pcs/all-series/filter?Category=For-Work\"\n        target=\"_blank\">商用桌機</a>以46%超高市佔率遙遙領先，遠超第二名的20%；\n    <a href=\"https://www.asus.com/tw/deals/for-work-onsale/\"\n        target=\"_blank\">商用筆電</a>則以27.5%的市佔率穩居首位，展現華碩商用強大的品牌號召力與市場信賴度。\n</p>\n<p>隨著Windows 10將於2025年10月14日終止支援，華碩為協助企業用戶輕鬆應對AI轉型浪潮，推出全新AI商用筆電ASUS ExpertBook B5 (B5405CCA)，以及華碩首款AI商用桌機ASUS\n    ExpertCenter D900 Mini Tower (D900MF)。兩款新機皆內建Windows\n    Copilot功能，透過專屬Copilot鍵享即時AI商務支援，提升數位競爭力與生產力超有感；並搭載華碩獨家商用軟體「AI\n    ExpertMeet」，提供即時會議紀錄、摘要翻譯、音訊降噪等功能，資料可於本地端運算，資安防護滴水不漏。</p>\n<br>\n<h2>ASUS ExpertBook B5 (B5405CCA) 商用筆電：AI助力．智領未來</h2>\n<p>ASUS ExpertBook B5換新裝！搭載Intel Core Ultra處理器及Intel\n    Arc顯示晶片，以AI技術大幅提升工作效率！機身僅1.36kg起，具雙SO-DIMM插槽，最高支援64GB記憶體，方便客製化與擴充維護，滿足各式企業需求。符合MIL-STD\n    810H軍規測試，結構堅固，是數位游牧、混合辦公的理想之選。</p>\n<p>\n    資安防護亦全面升級，包括：雙BIOS ROM、Opal 2.0 SED SSD、符合NIST SP 800-155標準的安全BIOS、內建入侵機殼感測器、 Windows 11 Secured-core PC\n    技術、指紋感應器、紅外線攝影機臉部辨識登入、TPM 2.0晶片及實體網路攝影機防窺閘等，提供企業多層次的資安保障。<b>建議售價：NT$40,900起</b>，詳細規格：<a\n        href=\"https://www.asus.com/tw/laptops/for-work/expertbook/asus-expertbook-b5-b5405/\" target=\"_blank\">ASUS\n        ExpertBook B5 (B5405CCA)</a></p>\n<br>\n<h2>ASUS ExpertCenter D900 Mini Tower (D900MF) 商用桌機：AI 加持．商務智勝</h2>\n<p>華碩首款專為企業打造的AI商用桌機，最高搭載Intel Core Ultra 9處理器且最高支援NVIDIA GeForce RTX 4060顯示卡，含4個DDR5 U-DIMM插槽，最高支援128GB\n    DDR5記憶體與6TB儲存空間，效能優異。15.9升機身內建完整連接埠，空間運用便利，且設計易於拆卸擴充，方便IT維護升級。</p>\n<p>ASUS ExpertCenter D900 Mini Tower (D900MF)亦支援Intel vPro，提供企業級安全性，更符合美國軍規MIL-STD\n    810H標準及嚴格的華碩內部測試，並採用世界第一的華碩主機板及全固態電容設計，確保耐用性及穩定性。預計7月上市。<b>建議售價：NT$45,000起</b>，詳細規格：<a\n        href=\"https://www.asus.com/tw/displays-desktops/tower-pcs/expertcenter/asus-expertcenter-d9-mini-tower-d900mf/\"\n        target=\"_blank\">ASUS ExpertCenter D900 Mini Tower (D900MF)</a></p>";

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Article = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Article;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyArticle", $$Article$1, { "title": "ASUS ExpertBook B5 \u5546\u7528\u7B46\u96FB\u3001ASUS ExpertCenter D900 Mini Tower \u5546\u7528\u684C\u6A5F\u63A5\u529B\u4E0A\u5E02", "date": "2025/11/12", "breadcrumb": [{ name: "IDC\u5E02\u5834\u5831\u544A" }, { name: "\u5546\u7528\u96FB\u8166" }, { name: "\u5E02\u5360\u7387" }, { name: "\u5546\u696D\u5831\u544A" }], "buttonText": "\u56DE\u6700\u65B0\u6D88\u606F\u7E3D\u89BD\u9801", "buttonLink": "/news", "html": Content, "IDName": IDName, "className": ["my-news-article", className], "style": style, "attribute": attribute })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/[id]/article.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Relative = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Relative;
  const { IDName = "NewsRelative", className, style, attribute = {}, title = "\u76F8\u95DC\u6D88\u606F" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyRelative", $$Relative$1, { "title": title, "className": ["news-section-relative", className], "IDName": IDName, "style": style, "attribute": attribute, "count": 12 }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Card", $$Card, { "link": "/news/0", "showLogo": false, "showBreif": false })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/[id]/relative.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
async function getStaticPaths() {
  return Array.from({ length: 10 }).map((_, index) => ({ params: { id: index } }));
}
const prerender = true;
const $$ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const { id } = Astro2.params;
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "NewsDetail", "minMarginHeader": true, "footerPages": ["\u6700\u65B0\u6D88\u606F"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Article", $$Article, {})}
    ${renderComponent($$result2, "Relative", $$Relative, {})}
` })}
${renderComponent($$result, "Script", $$Relative$2, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/news/[...id].astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/news/[...id].astro";
const $$url = "/news/[...id].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$,
    file: $$file,
    getStaticPaths,
    prerender,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
