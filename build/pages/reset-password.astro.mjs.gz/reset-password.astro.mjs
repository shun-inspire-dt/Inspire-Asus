/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, a as $$Layouts } from '../chunks/layouts_D8she11O.mjs';
import { $ as $$Form$1 } from '../chunks/form_PYguvSQ8.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_c-Ph_iRB.mjs';
import { $ as $$PasswordInput } from '../chunks/passwordInput_Ci5NCRWH.mjs';
import '../chunks/reset-password.3da46ccd_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "id": IDName, "title": "\u91CD\u8A2D\u5BC6\u78BC", "class:list": [className], "style": style, ...attribute, "action": "/reset-password" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u65B0\u5BC6\u78BC", "infoText": "\u5BC6\u78BC\u9700\u5305\u62EC8\u81F325\u4F4D\u5927\u5C0F\u5BEB\u5B57\u6BCD\u3001\u6578\u5B57\u53CA\u7B26\u865F\uFF0C\u4E14\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\u3002", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "PasswordInput", $$PasswordInput, {})}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u518D\u6B21\u8F38\u5165\u60A8\u7684\u65B0\u5BC6\u78BC", "infoText": "\u8ACB\u518D\u6B21\u8F38\u5165\u5BC6\u78BC", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "PasswordInput", $$PasswordInput, {})}
    ` })}
    ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "variant": "blue", "title": "\u78BA\u8A8D\u8B8A\u66F4", "block": true }, { "default": ($$result3) => renderTemplate`確認變更` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/reset-password/form.astro", void 0);

const $$ResetPassword = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Reset-password", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/reset-password.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/reset-password.astro";
const $$url = "/reset-password.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$ResetPassword,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
