/* empty css                                   */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate, F as Fragment } from '../chunks/astro/server_v5wg8FJS.mjs';
import { a as $$Layouts } from '../chunks/layouts_2rr1OTfM.mjs';
import { $ as $$Banner } from '../chunks/banner_D4dx3PBM.mjs';
import { $ as $$Follower, a as $$SciptInline, b as $$ArticlesList } from '../chunks/scipt-inline_NrO92H3b.mjs';
import { $ as $$Title } from '../chunks/title_C418meuI.mjs';
import { $ as $$Swiper, a as $$NavigatiorArrow } from '../chunks/navigatiorArrow_DyOPDvK4.mjs';
import { $ as $$CollectionCard, a as $$CollectionHarCard } from '../chunks/collectionHarCard_DtkmzgaF.mjs';
/* empty css                                 */
import { $ as $$Card } from '../chunks/card_Ca7Yrdu1.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業", value: "tech-manufacturing", name: "industry", checked: false, count: 1 },
  { label: "零售與電商產業", value: "retail-ecommerce", name: "industry", checked: false, count: 5 },
  { label: "餐飲與連鎖服務產業", value: "food-service", name: "industry", checked: false, count: 2 },
  { label: "醫療與照護產業", value: "healthcare", name: "industry", checked: false, count: 2 },
  { label: "教育與訓練產業", value: "education", name: "industry", checked: false, count: 1 },
  { label: "建築與工程產業", value: "construction", name: "industry", checked: false, count: 1 },
  { label: "旅宿與觀光產業", value: "hospitality", name: "industry", checked: false, count: 1 },
  { label: "顧問服務產業", value: "consulting", name: "industry", checked: false, count: 1 }
];
const child2 = [
  { label: "AWS", value: "aws", name: "theme", checked: false, count: 1 },
  { label: "GCP", value: "gcp", name: "theme", checked: false, count: 1 },
  { label: "雲端運算", value: "cloud-computing", name: "theme", checked: false, count: 1 },
  { label: "AI發展", value: "ai-development", name: "theme", checked: false, count: 1 }
];
const data$1 = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  },
  {
    title: "主題類別",
    show: true,
    children: child2
  }
];

const data = [
  {
    title: "iShops - 開店平台！",
    date: "2025-12-24",
    breif: "一站式開店平台，全面強化您的商業運營，增加企業營收，讓企業變得更好。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/0",
    linkText: "了解更多"
  },
  {
    title: "CloudSync - 雲端同步系統雲端同步系統雲端同步系統雲端同步系統雲端同步系統",
    date: "2025-12-24",
    breif: "智能雲端數據同步解決方案，提供即時備份與多裝置協作功能。支援跨平台檔案同步、版本控制、團隊共享空間，並具備先進的資料加密技術，確保您的重要文件隨時隨地都能安全存取。適合遠距工作團隊和需要高度協作的企業使用。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/1",
    linkText: "了解更多"
  },
  {
    title: "SecureGuard - 企業資安防護",
    date: "2025-12-24",
    breif: "全方位企業資訊安全防護系統，包含防火牆、入侵檢測、惡意軟體防護等多層次安全機制，確保您的數位資產安全無虞。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/2",
    linkText: "了解更多"
  },
  {
    title: "DataFlow - 數據分析平台",
    date: "2025-12-24",
    breif: "強大的商業智能分析工具，將複雜數據轉化為可視化報表，協助企業做出精準決策。整合多種數據源，提供即時儀表板、預測分析、趨勢洞察等功能，支援自定義報表和自動化警報系統，讓管理層能快速掌握業務狀況並制定有效策略。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/3",
    linkText: "了解更多"
  },
  {
    title: "TeamConnect - 協作管理工具",
    date: "2025-12-24",
    breif: "整合專案管理、團隊溝通、文件共享的一體化協作平台。提供任務分配、進度追蹤、時程管理、資源配置等完整功能，支援即時通訊、視訊會議、檔案協作編輯，並具備強大的權限管理系統，讓團隊協作更加順暢高效。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/4",
    linkText: "了解更多"
  },
  {
    title: "AutoFlow - 工作流程自動化",
    date: "2025-12-24",
    breif: "透過智能自動化技術，簡化繁複的業務流程，提升工作效率，減少人為錯誤，讓團隊專注於更有價值的創新工作。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/5",
    linkText: "了解更多"
  },
  {
    title: "MobileFirst - 行動應用開發",
    date: "2025-12-24",
    breif: "專業的跨平台行動應用開發服務，支援 iOS 和 Android 雙平台。採用最新的開發框架和技術，提供原生效能體驗，包含 UI/UX 設計、功能開發、測試部署、上架協助等完整服務，並提供後續維護和更新支援，助您快速搶占行動市場。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/6",
    linkText: "了解更多"
  },
  {
    title: "SmartInventory - 智慧庫存管理",
    date: "2025-12-24",
    breif: "運用 AI 技術預測需求，優化庫存配置，降低成本並提高供應鏈效率。智能分析歷史銷售數據、季節性趨勢、市場變化等因素，自動調整採購建議和安全庫存水位，減少缺貨風險和過剩庫存，並提供供應商管理和成本分析功能。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/7",
    linkText: "了解更多"
  },
  {
    title: "CustomerCare - 客戶關係管理",
    date: "2025-12-24",
    breif: "完整的 CRM 解決方案，從潛在客戶開發到售後服務，全程追蹤客戶互動歷程，建立長期穩固的客戶關係，提升客戶滿意度與忠誠度。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/8",
    linkText: "了解更多"
  },
  {
    title: "EcoTech - 綠色科技解決方案",
    date: "2025-12-24",
    breif: "環保永續的科技解決方案，協助企業實現碳中和目標。提供碳足跡追蹤、能源效率優化、綠色供應鏈管理、永續報告生成等功能，結合 IoT 感測器和 AI 分析技術，幫助企業建立環保營運模式，符合 ESG 標準並提升品牌形象。",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/9",
    linkText: "了解更多"
  }
];

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Articles = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Articles;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "article-collection"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Title", $$Title, { "title": "\u7CBE\u9078\u6D88\u606F" })}
    <div class="article-collection-inner">
        <div class="article-collection-top">
            ${renderComponent($$result, "CollectionCard", $$CollectionCard, { "showLogo": false })}
        </div>
        <div class="article-collection-bottom">
            ${renderComponent($$result, "Swiper", $$Swiper, { "IDName": "newsCollection", "swiperClassName": "news-collection-swiper" }, { "default": ($$result2) => renderTemplate`
                
                ${Array.from({ length: 3 }).map((_, index) => renderTemplate`<div class="swiper-slide" style="width: auto;">
                            ${renderComponent($$result2, "CollectionHarCard", $$CollectionHarCard, { "showLogo": false, "last": index === 2 })}
                        </div>`)}`, "outside": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outside" }, { "default": ($$result3) => renderTemplate`
                    <div class="article-collection-next-button" data-swiper-button-next>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "right" })}
                    </div>
                    <div class="article-collection-prev-button" data-swiper-button-prev>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "left" })}
                    </div>
                ` })}` })}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/articles.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Script = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template([`<script>
    /**
     * \u9632\u6296\uFF08debounce\uFF09\u5DE5\u5177
     * @description
     * \u5728\u9023\u7E8C\u89F8\u767C\u671F\u9593\u5167\u53EA\u6703\u4FDD\u7559\u6700\u5F8C\u4E00\u6B21\u547C\u53EB\uFF0C\u4E26\u5728\u5EF6\u9072\u6642\u9593\u5230\u9054\u5F8C\u624D\u57F7\u884C\u3002
     * \u9069\u5408\u7528\u65BC\u7BE9\u9078\u689D\u4EF6\uFF08checkbox/select\uFF09\u5FEB\u901F\u8B8A\u66F4\u6642\uFF0C\u907F\u514D\u91CD\u8907\u66F4\u65B0\u6587\u7AE0\u5217\u8868\u3002
     * @template {(...args: any[]) => any} T
     * @param {T} func - \u9700\u8981\u88AB\u9632\u6296\u8655\u7406\u7684\u51FD\u5F0F
     * @param {number} delay - \u5EF6\u9072\u6642\u9593\uFF08\u6BEB\u79D2\uFF09
     * @returns {(...args: Parameters<T>) => void} \u9632\u6296\u5F8C\u7684\u51FD\u5F0F
     */
    const debounce = (func, delay) => {
        let timer = null;
        return function (...args) {
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(
                function () {
                    func.apply(this, args);
                }.bind(this),
                delay
            );
        };
    };

    /**
     * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
     * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
     */
    class UrlManager {
        constructor() {
            this.article = new Article();
            this.debouncedUpdateArticleList = debounce((search) => {
                const add = this.article.handleClick.bind(this.article);
                add(search, true);
            }, 1000);
        }

        /**
         * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
         */
        getParams() {
            const params = new URLSearchParams(window.location.search);
            const result = {};

            // \u8655\u7406\u5169\u7A2E\u683C\u5F0F\uFF1A
            // 1. industry=food-service&industry=healthcare (\u591A\u500B\u540C\u540D\u53C3\u6578)
            // 2. industry=food-service,healthcare (\u9017\u865F\u5206\u9694)

            for (const [key, value] of params) {
                if (result[key]) {
                    // \u5DF2\u7D93\u5B58\u5728\u8A72 key\uFF0C\u8868\u793A\u662F\u683C\u5F0F1\uFF08\u591A\u500B\u540C\u540D\u53C3\u6578\uFF09
                    if (Array.isArray(result[key])) {
                        result[key].push(value);
                    } else {
                        result[key] = [result[key], value];
                    }
                } else {
                    // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C\uFF08\u683C\u5F0F2\uFF09
                    if (value.includes(',')) {
                        result[key] = value
                            .split(',')
                            .map((v) => v.trim())
                            .filter((v) => v);
                    } else {
                        result[key] = value;
                    }
                }
            }
            return result;
        }

        /**
         * \u66F4\u65B0 URL \u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string|string[]|null} value - \u53C3\u6578\u503C
         */
        updateParam(name, value) {
            const url = new URL(window.location);

            if (Array.isArray(value) && value.length > 0) {
                // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                url.searchParams.set(name, value.join(','));
            } else if (value) {
                // \u55AE\u500B\u503C
                url.searchParams.set(name, value);
            } else {
                // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                url.searchParams.delete(name);
            }

            // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
            window.history.replaceState({}, '', url);
            // \u63A1 CSR \u66F4\u65B0\u6587\u7AE0\u5217\u8868\uFF08\u907F\u514D\u9023\u7E8C\u64CD\u4F5C\u5C0E\u81F4\u91CD\u8907\u66F4\u65B0\uFF09
            this.debouncedUpdateArticleList(url.search);
        }

        /**
         * \u6DFB\u52A0 URL \u53C3\u6578\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
         */
        addParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            let values = [];

            if (currentParam) {
                values = currentParam.includes(',')
                    ? currentParam
                          .split(',')
                          .map((v) => v.trim())
                          .filter((v) => v)
                    : [currentParam];
            }

            if (!values.includes(value)) {
                values.push(value);
                this.updateParam(name, values);
            }
        }

        /**
         * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
         */
        removeParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);

            if (!currentParam) return;

            let values = currentParam.includes(',')
                ? currentParam
                      .split(',')
                      .map((v) => v.trim())
                      .filter((v) => v)
                : [currentParam];

            values = values.filter((v) => v !== value);

            if (values.length > 0) {
                this.updateParam(name, values);
            } else {
                this.updateParam(name, null);
            }
        }
    }

    class CheckboxManager {
        constructor({ urlManager, badgeManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.badgeManager = badgeManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u540C\u6B65\u540C\u4E00\u7D44\uFF08\u540C name + value\uFF09checkbox \u7684\u52FE\u9078\u72C0\u614B
         * @param {string} name - checkbox name
         * @param {string} value - checkbox value
         * @param {boolean} checked - \u76EE\u6A19\u52FE\u9078\u72C0\u614B
         * @param {HTMLInputElement} source - \u4E8B\u4EF6\u4F86\u6E90 checkbox
         */
        syncSameCheckboxes(name, value, checked, source) {
            const checkboxes = document.querySelectorAll(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
            checkboxes.forEach((cb) => {
                if (cb === source) return;
                cb.checked = checked;
            });
        }

        /**
         * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const filterContainers = document.querySelectorAll('[data-filter]');

            filterContainers.forEach((container) => {
                const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');

                checkboxes.forEach((checkbox) => {
                    checkbox.addEventListener('change', this.handleChange);
                });
            });
        }

        /**
         * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange = (event) => {
            const checkbox = event.target;
            const name = checkbox.name;
            const value = checkbox.value;

            // \u540C\u6B65\u684C\u6A5F/\u624B\u6A5F\u5169\u5957\u76F8\u540C\u689D\u4EF6\u7684 checkbox
            this.syncSameCheckboxes(name, value, checkbox.checked, checkbox);

            if (checkbox.checked) {
                // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                this.urlManager.addParamValue(name, value);
            } else {
                // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                this.urlManager.removeParamValue(name, value);
            }

            // \u66F4\u65B0\u7BE9\u9078 badges
            this.badgeManager.updateFilterBadges();
        };

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
         */
        restoreState() {
            const params = this.urlManager.getParams();

            Object.keys(params).forEach((name) => {
                if (this.isIgnoredParam(name)) return;
                const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                values.forEach((value) => {
                    const checkboxs = document.querySelectorAll(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
                    checkboxs.forEach((checkbox) => {
                        if (checkbox) {
                            checkbox.checked = true;
                        }
                    });
                });
            });
        }
    }

    class SelectManager {
        constructor({ urlManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u540C\u6B65\u540C\u4E00\u7D44\uFF08\u540C name\uFF09\u7684 select \u9078\u64C7\u72C0\u614B
         * @param {string} name - select name
         * @param {string} value - \u76EE\u6A19 value
         * @param {HTMLSelectElement} source - \u4E8B\u4EF6\u4F86\u6E90 select
         */
        syncSameSelects(name, value, source) {
            const selects = document.querySelectorAll(\`select[data-sort][name="\${name}"]\`);
            selects.forEach((s) => {
                if (s === source) return;
                s.value = value;
                s.dispatchEvent(new CustomEvent('custom-select:update'));
            });
        }

        /**
         * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const selects = document.querySelectorAll('select[data-sort][name]');

            selects.forEach((select) => {
                select.addEventListener('change', this.handleChange);
            });
        }

        /**
         * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange = (event) => {
            const select = event.target;
            const name = select.name;
            const value = select.value;

            // \u540C\u6B65\u684C\u6A5F/\u624B\u6A5F\u5169\u5957\u76F8\u540C name \u7684 select
            this.syncSameSelects(name, value, select);

            if (value) {
                this.urlManager.updateParam(name, value);
            } else {
                this.urlManager.updateParam(name, null);
            }
        };

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
         */
        restoreState() {
            const params = this.urlManager.getParams();

            Object.keys(params).forEach((name) => {
                if (this.isIgnoredParam(name)) return;
                const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                const selects = document.querySelectorAll(\`select[data-sort][name="\${name}"]\`);
                selects.forEach((select) => {
                    if (select && value) {
                        // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                        let targetIndex = -1;
                        for (let i = 0; i < select.options.length; i++) {
                            if (select.options[i].value === value) {
                                targetIndex = i;
                                break;
                            }
                        }

                        if (targetIndex !== -1) {
                            // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                            select.selectedIndex = targetIndex;
                            // \u89F8\u767C change \u4E8B\u4EF6
                            select.dispatchEvent(new Event('custom-select:update', { bubbles: true }));
                        }
                    }
                });
            });
        }
    }

    class FilterCountManager {
        constructor({ urlManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u8A08\u7B97\u7576\u524D\u7BE9\u9078\u6578\u91CF\uFF08\u4E0D\u5305\u542B sort\uFF09
         */
        getFilterCount() {
            const params = this.urlManager.getParams();
            let count = 0;

            // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
            Object.keys(params).forEach((name) => {
                if (this.isIgnoredParam(name)) return;
                // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578\uFF08\u901A\u904E\u6AA2\u67E5\u662F\u5426\u6709\u5C0D\u61C9\u7684 select[data-sort] \u5143\u7D20\uFF09
                const isSort = document.querySelector(\`select[data-sort][name="\${name}"]\`);

                if (!isSort) {
                    // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u8A08\u7B97\u6578\u91CF
                    const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                    count += values.filter((v) => v && v.trim()).length;
                }
            });

            return count;
        }

        /**
         * \u66F4\u65B0\u6240\u6709 data-category-button \u6309\u9215\u7684\u6587\u5B57
         */
        updateButtonTexts = () => {
            const buttons = document.querySelectorAll('[data-category-button]');
            const count = this.getFilterCount();

            buttons.forEach((button) => {
                const originalTitle = button.getAttribute('data-title');
                if (originalTitle) {
                    if (count > 0) {
                        button.textContent = \`\${originalTitle}(\${count})\`;
                    } else {
                        button.textContent = originalTitle;
                    }
                }
            });
        };

        /**
         * \u521D\u59CB\u5316\u7BE9\u9078\u6578\u91CF\u986F\u793A
         */
        init() {
            // \u521D\u59CB\u66F4\u65B0
            this.updateButtonTexts();

            // \u76E3\u807D URL \u8B8A\u5316
            const originalReplaceState = window.history.replaceState;
            window.history.replaceState = (...args) => {
                originalReplaceState.apply(window.history, args);
                // URL \u66F4\u65B0\u5F8C\u91CD\u65B0\u8A08\u7B97\u6578\u91CF
                setTimeout(() => this.updateButtonTexts(), 0);
            };
        }
    }

    class FilterBadgeManager {
        constructor({ urlManager, countManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.countManager = countManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u7372\u53D6\u7BE9\u9078\u53C3\u6578\u7684\u986F\u793A\u6587\u5B57
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u53C3\u6578\u503C
         */
        getFilterDisplayText(name, value) {
            // \u5617\u8A66\u5F9E\u5C0D\u61C9\u7684 checkbox \u7684 data-title \u5C6C\u6027\u7372\u53D6\u986F\u793A\u6587\u5B57
            const checkbox = document.querySelector(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
            if (checkbox) {
                // \u512A\u5148\u4F7F\u7528 data-title \u5C6C\u6027
                const dataTitle = checkbox.getAttribute('data-title');
                if (dataTitle) {
                    return dataTitle.trim();
                }
            }

            // \u5982\u679C\u627E\u4E0D\u5230\u5C0D\u61C9\u7684 checkbox \u6216 data-title\uFF0C\u8FD4\u56DE\u539F\u59CB\u503C
            return value;
        }

        /**
         * \u66F4\u65B0\u6240\u6709\u7BE9\u9078 badges
         */
        updateFilterBadges() {
            const badgeContainers = document.querySelectorAll('[data-filter-badges]');
            const params = this.urlManager.getParams();

            badgeContainers.forEach((container) => {
                const badgesList = container.querySelector('[data-filter-badges-list]');
                const template = container.querySelector('template');

                if (!badgesList || !template) return;

                // \u6E05\u7A7A\u73FE\u6709\u7684 badges
                badgesList.innerHTML = '';

                let hasFilters = false;

                // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
                Object.keys(params).forEach((name) => {
                    if (this.isIgnoredParam(name)) return;
                    // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578
                    const isSort = document.querySelector(\`select[data-sort][name="\${name}"]\`);

                    if (!isSort) {
                        // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u5275\u5EFA badge
                        const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                        values.forEach((value) => {
                            if (value && value.trim()) {
                                hasFilters = true;

                                // \u8907\u88FD\u6A21\u677F\u5167\u5BB9
                                const badgeClone = template.content.cloneNode(true);
                                const badge = badgeClone.querySelector('.badge');
                                const textSpan = badge?.querySelector('span:not(.badge-close)');

                                if (badge && textSpan) {
                                    // \u8A2D\u7F6E data \u5C6C\u6027
                                    badge.setAttribute('data-key', name);
                                    badge.setAttribute('data-value', value);

                                    // \u8A2D\u7F6E\u986F\u793A\u6587\u5B57
                                    const displayText = this.getFilterDisplayText(name, value);
                                    textSpan.textContent = displayText;

                                    // \u6DFB\u52A0\u9EDE\u64CA\u4E8B\u4EF6\u4F86\u522A\u9664\u7BE9\u9078
                                    badge.addEventListener('click', (e) => {
                                        e.preventDefault();
                                        this.removeFilter(name, value);
                                    });

                                    // \u6DFB\u52A0\u5230\u5217\u8868
                                    badgesList.appendChild(badgeClone);
                                }
                            }
                        });
                    }
                });

                // \u986F\u793A\u6216\u96B1\u85CF\u6574\u500B badge \u5BB9\u5668
                if (hasFilters) {
                    container.style.display = '';
                } else {
                    container.style.display = 'none';
                }
            });
        }

        /**
         * \u79FB\u9664\u7279\u5B9A\u7684\u7BE9\u9078\u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u53C3\u6578\u503C
         */
        removeFilter(name, value) {
            // \u79FB\u9664 URL \u53C3\u6578
            this.urlManager.removeParamValue(name, value);

            // \u66F4\u65B0\u5C0D\u61C9\u7684 checkbox \u72C0\u614B
            const checkboxes = document.querySelectorAll(\`input[type="checkbox"][name="\${name}"][value="\${value}"]\`);
            checkboxes.forEach((checkbox) => {
                checkbox.checked = false;
                // \u89F8\u767C change \u4E8B\u4EF6
                // checkbox.dispatchEvent(new Event('change', { bubbles: true }));
            });

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            this.countManager.updateButtonTexts();

            // \u66F4\u65B0 badges \u986F\u793A
            this.updateFilterBadges();
        }

        /**
         * \u521D\u59CB\u5316\u7BE9\u9078 badge \u529F\u80FD
         */
        init() {
            // \u521D\u59CB\u66F4\u65B0
            this.updateFilterBadges();
        }
    }

    class ClearFilterManager {
        constructor({ urlManager, badgeManager, countManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.badgeManager = badgeManager;
            this.countManager = countManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u6E05\u9664\u6240\u6709\u7BE9\u9078\u53C3\u6578\uFF0C\u4F46\u4FDD\u7559\u6392\u5E8F\u53C3\u6578
         */
        clearAllFilters() {
            const url = new URL(window.location);

            // \u6E05\u9664\u6240\u6709\u53C3\u6578
            url.searchParams.forEach((value, key) => {
                if (this.isIgnoredParam(key)) return;
                const isSort = document.querySelector(\`select[data-sort][name="\${key}"]\`);
                if (isSort) return;
                url.searchParams.delete(key);
            });

            // \u66F4\u65B0 URL
            window.history.replaceState({}, '', url);
            // \u63A1 CSR \u66F4\u65B0\u6587\u7AE0\u5217\u8868\uFF08\u907F\u514D\u9023\u7E8C\u64CD\u4F5C\u5C0E\u81F4\u91CD\u8907\u66F4\u65B0\uFF09
            this.urlManager.debouncedUpdateArticleList(url.search);

            // \u91CD\u7F6E\u6240\u6709 checkbox \u72C0\u614B
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name]');
            checkboxes.forEach((checkbox) => {
                checkbox.checked = false;
            });

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            this.countManager.updateButtonTexts();

            // \u66F4\u65B0\u7BE9\u9078 badges
            this.badgeManager.updateFilterBadges();
        }

        /**
         * \u521D\u59CB\u5316\u6E05\u9664\u6309\u9215\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const clearButtons = document.querySelectorAll('[data-category-clear]');

            clearButtons.forEach((button) => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.clearAllFilters();
                });
            });
        }
    }

    class FilterSortApp {
        constructor() {
            this.isIgnoredParam = (name) => {
                return ['page', 'current_page', 'page_limit'].includes(name);
            };

            this.urlManager = new UrlManager();
            this.countManager = new FilterCountManager({
                urlManager: this.urlManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.badgeManager = new FilterBadgeManager({
                urlManager: this.urlManager,
                countManager: this.countManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.checkboxManager = new CheckboxManager({
                urlManager: this.urlManager,
                badgeManager: this.badgeManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.selectManager = new SelectManager({
                urlManager: this.urlManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.clearFilterManager = new ClearFilterManager({
                urlManager: this.urlManager,
                badgeManager: this.badgeManager,
                countManager: this.countManager,
                isIgnoredParam: this.isIgnoredParam
            });

            this.observer = null;

            this.initialize();
        }

        initialize() {
            // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
            this.checkboxManager.init();
            this.selectManager.init();
            this.countManager.init();
            this.clearFilterManager.init();
            this.badgeManager.init();

            // \u6062\u5FA9\u9801\u9762\u72C0\u614B
            this.checkboxManager.restoreState();
            this.selectManager.restoreState();

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            this.countManager.updateButtonTexts();

            // \u66F4\u65B0\u7BE9\u9078 badges
            this.badgeManager.updateFilterBadges();

            // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
            this.setupMutationObserver();

            // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
            window.FilterSortManager = {
                URLManager: this.urlManager,
                CheckboxManager: this.checkboxManager,
                SelectManager: this.selectManager,
                FilterCountManager: this.countManager,
                ClearFilterManager: this.clearFilterManager,
                FilterBadgeManager: this.badgeManager,
                initialize: this.initialize.bind(this)
            };
        }

        setupMutationObserver() {
            if (this.observer) return;

            this.observer = new MutationObserver((mutations) => {
                let shouldReinit = false;

                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1) {
                            // Element node
                            const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                            const hasSort = node.querySelector && node.querySelector('[data-sort]');

                            if (hasFilter || hasSort) {
                                shouldReinit = true;
                            }
                        }
                    });
                });

                if (shouldReinit) {
                    // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
                    setTimeout(() => {
                        this.checkboxManager.init();
                        this.selectManager.init();
                        this.clearFilterManager.init();
                        this.badgeManager.init();
                        this.countManager.updateButtonTexts();
                        this.badgeManager.updateFilterBadges();
                    }, 100);
                }
            });

            // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
            this.observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }
    }

    const start = () => {
        new FilterSortApp();
    };

    // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
<\/script>`], [`<script>
    /**
     * \u9632\u6296\uFF08debounce\uFF09\u5DE5\u5177
     * @description
     * \u5728\u9023\u7E8C\u89F8\u767C\u671F\u9593\u5167\u53EA\u6703\u4FDD\u7559\u6700\u5F8C\u4E00\u6B21\u547C\u53EB\uFF0C\u4E26\u5728\u5EF6\u9072\u6642\u9593\u5230\u9054\u5F8C\u624D\u57F7\u884C\u3002
     * \u9069\u5408\u7528\u65BC\u7BE9\u9078\u689D\u4EF6\uFF08checkbox/select\uFF09\u5FEB\u901F\u8B8A\u66F4\u6642\uFF0C\u907F\u514D\u91CD\u8907\u66F4\u65B0\u6587\u7AE0\u5217\u8868\u3002
     * @template {(...args: any[]) => any} T
     * @param {T} func - \u9700\u8981\u88AB\u9632\u6296\u8655\u7406\u7684\u51FD\u5F0F
     * @param {number} delay - \u5EF6\u9072\u6642\u9593\uFF08\u6BEB\u79D2\uFF09
     * @returns {(...args: Parameters<T>) => void} \u9632\u6296\u5F8C\u7684\u51FD\u5F0F
     */
    const debounce = (func, delay) => {
        let timer = null;
        return function (...args) {
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(
                function () {
                    func.apply(this, args);
                }.bind(this),
                delay
            );
        };
    };

    /**
     * URL Query String \u540C\u6B65\u7BA1\u7406\u5668
     * \u8655\u7406 data-filter \u7684 checkboxes \u548C data-sort \u7684 select \u8207 URL \u7684\u540C\u6B65
     */
    class UrlManager {
        constructor() {
            this.article = new Article();
            this.debouncedUpdateArticleList = debounce((search) => {
                const add = this.article.handleClick.bind(this.article);
                add(search, true);
            }, 1000);
        }

        /**
         * \u7372\u53D6\u7576\u524D URL \u7684\u6240\u6709\u67E5\u8A62\u53C3\u6578
         */
        getParams() {
            const params = new URLSearchParams(window.location.search);
            const result = {};

            // \u8655\u7406\u5169\u7A2E\u683C\u5F0F\uFF1A
            // 1. industry=food-service&industry=healthcare (\u591A\u500B\u540C\u540D\u53C3\u6578)
            // 2. industry=food-service,healthcare (\u9017\u865F\u5206\u9694)

            for (const [key, value] of params) {
                if (result[key]) {
                    // \u5DF2\u7D93\u5B58\u5728\u8A72 key\uFF0C\u8868\u793A\u662F\u683C\u5F0F1\uFF08\u591A\u500B\u540C\u540D\u53C3\u6578\uFF09
                    if (Array.isArray(result[key])) {
                        result[key].push(value);
                    } else {
                        result[key] = [result[key], value];
                    }
                } else {
                    // \u6AA2\u67E5\u662F\u5426\u70BA\u9017\u865F\u5206\u9694\u7684\u591A\u503C\uFF08\u683C\u5F0F2\uFF09
                    if (value.includes(',')) {
                        result[key] = value
                            .split(',')
                            .map((v) => v.trim())
                            .filter((v) => v);
                    } else {
                        result[key] = value;
                    }
                }
            }
            return result;
        }

        /**
         * \u66F4\u65B0 URL \u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string|string[]|null} value - \u53C3\u6578\u503C
         */
        updateParam(name, value) {
            const url = new URL(window.location);

            if (Array.isArray(value) && value.length > 0) {
                // \u591A\u500B\u503C\u7528\u9017\u865F\u5206\u9694
                url.searchParams.set(name, value.join(','));
            } else if (value) {
                // \u55AE\u500B\u503C
                url.searchParams.set(name, value);
            } else {
                // \u7A7A\u503C\u5247\u522A\u9664\u53C3\u6578
                url.searchParams.delete(name);
            }

            // \u66F4\u65B0 URL \u4F46\u4E0D\u91CD\u8F09\u9801\u9762
            window.history.replaceState({}, '', url);
            // \u63A1 CSR \u66F4\u65B0\u6587\u7AE0\u5217\u8868\uFF08\u907F\u514D\u9023\u7E8C\u64CD\u4F5C\u5C0E\u81F4\u91CD\u8907\u66F4\u65B0\uFF09
            this.debouncedUpdateArticleList(url.search);
        }

        /**
         * \u6DFB\u52A0 URL \u53C3\u6578\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u6DFB\u52A0\u7684\u503C
         */
        addParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);
            let values = [];

            if (currentParam) {
                values = currentParam.includes(',')
                    ? currentParam
                          .split(',')
                          .map((v) => v.trim())
                          .filter((v) => v)
                    : [currentParam];
            }

            if (!values.includes(value)) {
                values.push(value);
                this.updateParam(name, values);
            }
        }

        /**
         * \u79FB\u9664 URL \u53C3\u6578\u4E2D\u7684\u7279\u5B9A\u503C
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u8981\u79FB\u9664\u7684\u503C
         */
        removeParamValue(name, value) {
            const currentParam = new URLSearchParams(window.location.search).get(name);

            if (!currentParam) return;

            let values = currentParam.includes(',')
                ? currentParam
                      .split(',')
                      .map((v) => v.trim())
                      .filter((v) => v)
                : [currentParam];

            values = values.filter((v) => v !== value);

            if (values.length > 0) {
                this.updateParam(name, values);
            } else {
                this.updateParam(name, null);
            }
        }
    }

    class CheckboxManager {
        constructor({ urlManager, badgeManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.badgeManager = badgeManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u540C\u6B65\u540C\u4E00\u7D44\uFF08\u540C name + value\uFF09checkbox \u7684\u52FE\u9078\u72C0\u614B
         * @param {string} name - checkbox name
         * @param {string} value - checkbox value
         * @param {boolean} checked - \u76EE\u6A19\u52FE\u9078\u72C0\u614B
         * @param {HTMLInputElement} source - \u4E8B\u4EF6\u4F86\u6E90 checkbox
         */
        syncSameCheckboxes(name, value, checked, source) {
            const checkboxes = document.querySelectorAll(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
            checkboxes.forEach((cb) => {
                if (cb === source) return;
                cb.checked = checked;
            });
        }

        /**
         * \u521D\u59CB\u5316\u6240\u6709 checkbox \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const filterContainers = document.querySelectorAll('[data-filter]');

            filterContainers.forEach((container) => {
                const checkboxes = container.querySelectorAll('input[type="checkbox"][name]');

                checkboxes.forEach((checkbox) => {
                    checkbox.addEventListener('change', this.handleChange);
                });
            });
        }

        /**
         * \u8655\u7406 checkbox \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange = (event) => {
            const checkbox = event.target;
            const name = checkbox.name;
            const value = checkbox.value;

            // \u540C\u6B65\u684C\u6A5F/\u624B\u6A5F\u5169\u5957\u76F8\u540C\u689D\u4EF6\u7684 checkbox
            this.syncSameCheckboxes(name, value, checkbox.checked, checkbox);

            if (checkbox.checked) {
                // \u6DFB\u52A0\u5230 URL \u53C3\u6578
                this.urlManager.addParamValue(name, value);
            } else {
                // \u5F9E URL \u53C3\u6578\u4E2D\u79FB\u9664
                this.urlManager.removeParamValue(name, value);
            }

            // \u66F4\u65B0\u7BE9\u9078 badges
            this.badgeManager.updateFilterBadges();
        };

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 checkbox \u72C0\u614B
         */
        restoreState() {
            const params = this.urlManager.getParams();

            Object.keys(params).forEach((name) => {
                if (this.isIgnoredParam(name)) return;
                const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                values.forEach((value) => {
                    const checkboxs = document.querySelectorAll(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
                    checkboxs.forEach((checkbox) => {
                        if (checkbox) {
                            checkbox.checked = true;
                        }
                    });
                });
            });
        }
    }

    class SelectManager {
        constructor({ urlManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u540C\u6B65\u540C\u4E00\u7D44\uFF08\u540C name\uFF09\u7684 select \u9078\u64C7\u72C0\u614B
         * @param {string} name - select name
         * @param {string} value - \u76EE\u6A19 value
         * @param {HTMLSelectElement} source - \u4E8B\u4EF6\u4F86\u6E90 select
         */
        syncSameSelects(name, value, source) {
            const selects = document.querySelectorAll(\\\`select[data-sort][name="\\\${name}"]\\\`);
            selects.forEach((s) => {
                if (s === source) return;
                s.value = value;
                s.dispatchEvent(new CustomEvent('custom-select:update'));
            });
        }

        /**
         * \u521D\u59CB\u5316\u6240\u6709 select \u7684\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const selects = document.querySelectorAll('select[data-sort][name]');

            selects.forEach((select) => {
                select.addEventListener('change', this.handleChange);
            });
        }

        /**
         * \u8655\u7406 select \u8B8A\u66F4\u4E8B\u4EF6
         * @param {Event} event - \u8B8A\u66F4\u4E8B\u4EF6
         */
        handleChange = (event) => {
            const select = event.target;
            const name = select.name;
            const value = select.value;

            // \u540C\u6B65\u684C\u6A5F/\u624B\u6A5F\u5169\u5957\u76F8\u540C name \u7684 select
            this.syncSameSelects(name, value, select);

            if (value) {
                this.urlManager.updateParam(name, value);
            } else {
                this.urlManager.updateParam(name, null);
            }
        };

        /**
         * \u6839\u64DA URL \u53C3\u6578\u6062\u5FA9 select \u72C0\u614B
         */
        restoreState() {
            const params = this.urlManager.getParams();

            Object.keys(params).forEach((name) => {
                if (this.isIgnoredParam(name)) return;
                const value = Array.isArray(params[name]) ? params[name][0] : params[name];
                const selects = document.querySelectorAll(\\\`select[data-sort][name="\\\${name}"]\\\`);
                selects.forEach((select) => {
                    if (select && value) {
                        // \u627E\u5230\u5C0D\u61C9\u7684\u9078\u9805\u7D22\u5F15
                        let targetIndex = -1;
                        for (let i = 0; i < select.options.length; i++) {
                            if (select.options[i].value === value) {
                                targetIndex = i;
                                break;
                            }
                        }

                        if (targetIndex !== -1) {
                            // \u4F7F\u7528 selectedIndex \u8A2D\u7F6E\u9078\u4E2D\u9805
                            select.selectedIndex = targetIndex;
                            // \u89F8\u767C change \u4E8B\u4EF6
                            select.dispatchEvent(new Event('custom-select:update', { bubbles: true }));
                        }
                    }
                });
            });
        }
    }

    class FilterCountManager {
        constructor({ urlManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u8A08\u7B97\u7576\u524D\u7BE9\u9078\u6578\u91CF\uFF08\u4E0D\u5305\u542B sort\uFF09
         */
        getFilterCount() {
            const params = this.urlManager.getParams();
            let count = 0;

            // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
            Object.keys(params).forEach((name) => {
                if (this.isIgnoredParam(name)) return;
                // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578\uFF08\u901A\u904E\u6AA2\u67E5\u662F\u5426\u6709\u5C0D\u61C9\u7684 select[data-sort] \u5143\u7D20\uFF09
                const isSort = document.querySelector(\\\`select[data-sort][name="\\\${name}"]\\\`);

                if (!isSort) {
                    // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u8A08\u7B97\u6578\u91CF
                    const values = Array.isArray(params[name]) ? params[name] : [params[name]];
                    count += values.filter((v) => v && v.trim()).length;
                }
            });

            return count;
        }

        /**
         * \u66F4\u65B0\u6240\u6709 data-category-button \u6309\u9215\u7684\u6587\u5B57
         */
        updateButtonTexts = () => {
            const buttons = document.querySelectorAll('[data-category-button]');
            const count = this.getFilterCount();

            buttons.forEach((button) => {
                const originalTitle = button.getAttribute('data-title');
                if (originalTitle) {
                    if (count > 0) {
                        button.textContent = \\\`\\\${originalTitle}(\\\${count})\\\`;
                    } else {
                        button.textContent = originalTitle;
                    }
                }
            });
        };

        /**
         * \u521D\u59CB\u5316\u7BE9\u9078\u6578\u91CF\u986F\u793A
         */
        init() {
            // \u521D\u59CB\u66F4\u65B0
            this.updateButtonTexts();

            // \u76E3\u807D URL \u8B8A\u5316
            const originalReplaceState = window.history.replaceState;
            window.history.replaceState = (...args) => {
                originalReplaceState.apply(window.history, args);
                // URL \u66F4\u65B0\u5F8C\u91CD\u65B0\u8A08\u7B97\u6578\u91CF
                setTimeout(() => this.updateButtonTexts(), 0);
            };
        }
    }

    class FilterBadgeManager {
        constructor({ urlManager, countManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.countManager = countManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u7372\u53D6\u7BE9\u9078\u53C3\u6578\u7684\u986F\u793A\u6587\u5B57
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u53C3\u6578\u503C
         */
        getFilterDisplayText(name, value) {
            // \u5617\u8A66\u5F9E\u5C0D\u61C9\u7684 checkbox \u7684 data-title \u5C6C\u6027\u7372\u53D6\u986F\u793A\u6587\u5B57
            const checkbox = document.querySelector(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
            if (checkbox) {
                // \u512A\u5148\u4F7F\u7528 data-title \u5C6C\u6027
                const dataTitle = checkbox.getAttribute('data-title');
                if (dataTitle) {
                    return dataTitle.trim();
                }
            }

            // \u5982\u679C\u627E\u4E0D\u5230\u5C0D\u61C9\u7684 checkbox \u6216 data-title\uFF0C\u8FD4\u56DE\u539F\u59CB\u503C
            return value;
        }

        /**
         * \u66F4\u65B0\u6240\u6709\u7BE9\u9078 badges
         */
        updateFilterBadges() {
            const badgeContainers = document.querySelectorAll('[data-filter-badges]');
            const params = this.urlManager.getParams();

            badgeContainers.forEach((container) => {
                const badgesList = container.querySelector('[data-filter-badges-list]');
                const template = container.querySelector('template');

                if (!badgesList || !template) return;

                // \u6E05\u7A7A\u73FE\u6709\u7684 badges
                badgesList.innerHTML = '';

                let hasFilters = false;

                // \u904D\u6B77\u6240\u6709\u53C3\u6578\uFF0C\u6392\u9664 sort \u76F8\u95DC\u7684\u53C3\u6578
                Object.keys(params).forEach((name) => {
                    if (this.isIgnoredParam(name)) return;
                    // \u6AA2\u67E5\u662F\u5426\u70BA sort \u53C3\u6578
                    const isSort = document.querySelector(\\\`select[data-sort][name="\\\${name}"]\\\`);

                    if (!isSort) {
                        // \u4E0D\u662F sort \u53C3\u6578\uFF0C\u5275\u5EFA badge
                        const values = Array.isArray(params[name]) ? params[name] : [params[name]];

                        values.forEach((value) => {
                            if (value && value.trim()) {
                                hasFilters = true;

                                // \u8907\u88FD\u6A21\u677F\u5167\u5BB9
                                const badgeClone = template.content.cloneNode(true);
                                const badge = badgeClone.querySelector('.badge');
                                const textSpan = badge?.querySelector('span:not(.badge-close)');

                                if (badge && textSpan) {
                                    // \u8A2D\u7F6E data \u5C6C\u6027
                                    badge.setAttribute('data-key', name);
                                    badge.setAttribute('data-value', value);

                                    // \u8A2D\u7F6E\u986F\u793A\u6587\u5B57
                                    const displayText = this.getFilterDisplayText(name, value);
                                    textSpan.textContent = displayText;

                                    // \u6DFB\u52A0\u9EDE\u64CA\u4E8B\u4EF6\u4F86\u522A\u9664\u7BE9\u9078
                                    badge.addEventListener('click', (e) => {
                                        e.preventDefault();
                                        this.removeFilter(name, value);
                                    });

                                    // \u6DFB\u52A0\u5230\u5217\u8868
                                    badgesList.appendChild(badgeClone);
                                }
                            }
                        });
                    }
                });

                // \u986F\u793A\u6216\u96B1\u85CF\u6574\u500B badge \u5BB9\u5668
                if (hasFilters) {
                    container.style.display = '';
                } else {
                    container.style.display = 'none';
                }
            });
        }

        /**
         * \u79FB\u9664\u7279\u5B9A\u7684\u7BE9\u9078\u53C3\u6578
         * @param {string} name - \u53C3\u6578\u540D\u7A31
         * @param {string} value - \u53C3\u6578\u503C
         */
        removeFilter(name, value) {
            // \u79FB\u9664 URL \u53C3\u6578
            this.urlManager.removeParamValue(name, value);

            // \u66F4\u65B0\u5C0D\u61C9\u7684 checkbox \u72C0\u614B
            const checkboxes = document.querySelectorAll(\\\`input[type="checkbox"][name="\\\${name}"][value="\\\${value}"]\\\`);
            checkboxes.forEach((checkbox) => {
                checkbox.checked = false;
                // \u89F8\u767C change \u4E8B\u4EF6
                // checkbox.dispatchEvent(new Event('change', { bubbles: true }));
            });

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            this.countManager.updateButtonTexts();

            // \u66F4\u65B0 badges \u986F\u793A
            this.updateFilterBadges();
        }

        /**
         * \u521D\u59CB\u5316\u7BE9\u9078 badge \u529F\u80FD
         */
        init() {
            // \u521D\u59CB\u66F4\u65B0
            this.updateFilterBadges();
        }
    }

    class ClearFilterManager {
        constructor({ urlManager, badgeManager, countManager, isIgnoredParam }) {
            this.urlManager = urlManager;
            this.badgeManager = badgeManager;
            this.countManager = countManager;
            this.isIgnoredParam = isIgnoredParam;
        }

        /**
         * \u6E05\u9664\u6240\u6709\u7BE9\u9078\u53C3\u6578\uFF0C\u4F46\u4FDD\u7559\u6392\u5E8F\u53C3\u6578
         */
        clearAllFilters() {
            const url = new URL(window.location);

            // \u6E05\u9664\u6240\u6709\u53C3\u6578
            url.searchParams.forEach((value, key) => {
                if (this.isIgnoredParam(key)) return;
                const isSort = document.querySelector(\\\`select[data-sort][name="\\\${key}"]\\\`);
                if (isSort) return;
                url.searchParams.delete(key);
            });

            // \u66F4\u65B0 URL
            window.history.replaceState({}, '', url);
            // \u63A1 CSR \u66F4\u65B0\u6587\u7AE0\u5217\u8868\uFF08\u907F\u514D\u9023\u7E8C\u64CD\u4F5C\u5C0E\u81F4\u91CD\u8907\u66F4\u65B0\uFF09
            this.urlManager.debouncedUpdateArticleList(url.search);

            // \u91CD\u7F6E\u6240\u6709 checkbox \u72C0\u614B
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name]');
            checkboxes.forEach((checkbox) => {
                checkbox.checked = false;
            });

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            this.countManager.updateButtonTexts();

            // \u66F4\u65B0\u7BE9\u9078 badges
            this.badgeManager.updateFilterBadges();
        }

        /**
         * \u521D\u59CB\u5316\u6E05\u9664\u6309\u9215\u4E8B\u4EF6\u76E3\u807D
         */
        init() {
            const clearButtons = document.querySelectorAll('[data-category-clear]');

            clearButtons.forEach((button) => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.clearAllFilters();
                });
            });
        }
    }

    class FilterSortApp {
        constructor() {
            this.isIgnoredParam = (name) => {
                return ['page', 'current_page', 'page_limit'].includes(name);
            };

            this.urlManager = new UrlManager();
            this.countManager = new FilterCountManager({
                urlManager: this.urlManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.badgeManager = new FilterBadgeManager({
                urlManager: this.urlManager,
                countManager: this.countManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.checkboxManager = new CheckboxManager({
                urlManager: this.urlManager,
                badgeManager: this.badgeManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.selectManager = new SelectManager({
                urlManager: this.urlManager,
                isIgnoredParam: this.isIgnoredParam
            });
            this.clearFilterManager = new ClearFilterManager({
                urlManager: this.urlManager,
                badgeManager: this.badgeManager,
                countManager: this.countManager,
                isIgnoredParam: this.isIgnoredParam
            });

            this.observer = null;

            this.initialize();
        }

        initialize() {
            // \u521D\u59CB\u5316\u4E8B\u4EF6\u76E3\u807D\u5668
            this.checkboxManager.init();
            this.selectManager.init();
            this.countManager.init();
            this.clearFilterManager.init();
            this.badgeManager.init();

            // \u6062\u5FA9\u9801\u9762\u72C0\u614B
            this.checkboxManager.restoreState();
            this.selectManager.restoreState();

            // \u66F4\u65B0\u7BE9\u9078\u6578\u91CF\u986F\u793A
            this.countManager.updateButtonTexts();

            // \u66F4\u65B0\u7BE9\u9078 badges
            this.badgeManager.updateFilterBadges();

            // \u76E3\u807D\u52D5\u614B\u5167\u5BB9\u8B8A\u5316\uFF08\u5982\u679C\u6709 AJAX \u8F09\u5165\u7684\u5167\u5BB9\uFF09
            this.setupMutationObserver();

            // \u66B4\u9732\u5230\u5168\u57DF\u4F9B\u5176\u4ED6\u8173\u672C\u4F7F\u7528\uFF08\u53EF\u9078\uFF09
            window.FilterSortManager = {
                URLManager: this.urlManager,
                CheckboxManager: this.checkboxManager,
                SelectManager: this.selectManager,
                FilterCountManager: this.countManager,
                ClearFilterManager: this.clearFilterManager,
                FilterBadgeManager: this.badgeManager,
                initialize: this.initialize.bind(this)
            };
        }

        setupMutationObserver() {
            if (this.observer) return;

            this.observer = new MutationObserver((mutations) => {
                let shouldReinit = false;

                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1) {
                            // Element node
                            const hasFilter = node.querySelector && node.querySelector('[data-filter]');
                            const hasSort = node.querySelector && node.querySelector('[data-sort]');

                            if (hasFilter || hasSort) {
                                shouldReinit = true;
                            }
                        }
                    });
                });

                if (shouldReinit) {
                    // \u91CD\u65B0\u521D\u59CB\u5316\u65B0\u6DFB\u52A0\u7684\u5143\u7D20
                    setTimeout(() => {
                        this.checkboxManager.init();
                        this.selectManager.init();
                        this.clearFilterManager.init();
                        this.badgeManager.init();
                        this.countManager.updateButtonTexts();
                        this.badgeManager.updateFilterBadges();
                    }, 100);
                }
            });

            // \u958B\u59CB\u89C0\u5BDF DOM \u8B8A\u5316
            this.observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }
    }

    const start = () => {
        new FilterSortApp();
    };

    // \u7B49\u5F85 DOM \u5B8C\u5168\u8F09\u5165\u5F8C\u521D\u59CB\u5316
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
<\/script>`])));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/script.copy.astro", void 0);

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "News", "footerShowBorderTop": true, "footerPages": ["\u6700\u65B0\u6D88\u606F"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "news-banner", "title": "\u6700\u65B0\u6D88\u606F" })}
    ${renderComponent($$result2, "Articles", $$Articles, {})}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "NewsList", "title": "\u6700\u65B0\u6D88\u606F", "total": 10, "sortDate": [
    { text: "\u63A8\u85A6\u6587\u7AE0", value: "0" },
    { text: "\u6700\u65B0\u6D88\u606F", value: "1" }
  ], "category": data$1 }, { "default": ($$result3) => renderTemplate`${data.map((x) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "title": x.title, "date": x.date, "breif": x.breif, "label": x.label, "img": x.img, "link": x.link, "linkText": x.linkText, "showLogo": false })}`)}` })}
` })}
${renderComponent($$result, "Follower", $$Follower, {})}
${renderComponent($$result, "ScriptInline", $$SciptInline, { "data": data })}
${renderComponent($$result, "Script", $$Script, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/news/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/news/index.astro";
const $$url = "/news.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
