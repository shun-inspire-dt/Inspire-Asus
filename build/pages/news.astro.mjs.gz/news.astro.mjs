/* empty css                                   */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate, F as Fragment } from '../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../chunks/layouts_CNnjnwpD.mjs';
import { $ as $$Banner } from '../chunks/banner_H9CF1t-5.mjs';
import { $ as $$Follower, a as $$Script, b as $$ArticlesList } from '../chunks/script_DM_NK_DO.mjs';
import { $ as $$Title } from '../chunks/title_oZPX-wc9.mjs';
import { $ as $$Swiper, a as $$NavigatiorArrow } from '../chunks/navigatiorArrow_C2-jrvGz.mjs';
import { $ as $$CollectionCard, a as $$CollectionHarCard } from '../chunks/collectionHarCard_CGkyj9X0.mjs';
/* empty css                                 */
import { $ as $$Card } from '../chunks/card_C630H2uv.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業", value: "tech-manufacturing", name: "industry", checked: false, count: 1 },
  { label: "零售與電商產業", value: "retail-ecommerce", name: "industry", checked: false, count: 5 },
  { label: "餐飲與連鎖服務產業", value: "food-service", name: "industry", checked: false, count: 2 },
  { label: "醫療與照護產業", value: "healthcare", name: "industry", checked: false, count: 2 },
  { label: "教育與訓練產業", value: "education", name: "industry", checked: false, count: 1 },
  { label: "建築與工程產業", value: "construction", name: "industry", checked: false, count: 1 },
  { label: "旅宿與觀光產業", value: "hospitality", name: "industry", checked: false, count: 1 },
  { label: "顧問服務產業", value: "consulting", name: "industry", checked: false, count: 1 }
];
const child2 = [
  { label: "AWS", value: "aws", name: "theme", checked: false, count: 1 },
  { label: "GCP", value: "gcp", name: "theme", checked: false, count: 1 },
  { label: "雲端運算", value: "cloud-computing", name: "theme", checked: false, count: 1 },
  { label: "AI發展", value: "ai-development", name: "theme", checked: false, count: 1 }
];
const data = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  },
  {
    title: "主題類別",
    show: true,
    children: child2
  }
];

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Articles = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Articles;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "article-collection"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Title", $$Title, { "title": "\u7CBE\u9078\u6D88\u606F" })}
    <div class="article-collection-inner">
        <div class="article-collection-top">
            ${renderComponent($$result, "CollectionCard", $$CollectionCard, { "showLogo": false })}
        </div>
        <div class="article-collection-bottom">
            ${renderComponent($$result, "Swiper", $$Swiper, { "IDName": "newsCollection", "swiperClassName": "news-collection-swiper" }, { "default": ($$result2) => renderTemplate`
                
                ${Array.from({ length: 3 }).map((_, index) => renderTemplate`<div class="swiper-slide" style="width: auto;">
                            ${renderComponent($$result2, "CollectionHarCard", $$CollectionHarCard, { "showLogo": false, "last": index === 2 })}
                        </div>`)}`, "outside": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outside" }, { "default": ($$result3) => renderTemplate`
                    <div class="article-collection-next-button" data-swiper-button-next>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "right" })}
                    </div>
                    <div class="article-collection-prev-button" data-swiper-button-prev>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "left" })}
                    </div>
                ` })}` })}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/news/articles.astro", void 0);

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "News", "footerShowBorderTop": true, "footerPages": ["\u6700\u65B0\u6D88\u606F"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "news-banner", "title": "\u6700\u65B0\u6D88\u606F" })}
    ${renderComponent($$result2, "Articles", $$Articles, {})}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "NewsList", "title": "\u6700\u65B0\u6D88\u606F", "total": 10, "sortDate": [
    { text: "\u63A8\u85A6\u6587\u7AE0", value: "0" },
    { text: "\u6700\u65B0\u6D88\u606F", value: "1" }
  ], "category": data }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "link": `/news/${index}`, "showLogo": false })}`)}` })}
` })}
${renderComponent($$result, "Follower", $$Follower, {})}
${renderComponent($$result, "Script", $$Script, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/news/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/news/index.astro";
const $$url = "/news.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
