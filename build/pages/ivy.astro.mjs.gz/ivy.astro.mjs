/* empty css                                   */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_Bjgbv9en.mjs';
import { b as $$Layouts } from '../chunks/layouts_DPDjnNBK.mjs';
import { a as $$Banner } from '../chunks/banner_FomqbfBt.mjs';
import { $ as $$ArticlesList, a as $$Follower } from '../chunks/articlesList_B0EmJKFN.mjs';
import { $ as $$Card } from '../chunks/card_DdptNh4N.mjs';
import '../chunks/ivy.7897cccb_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業(1)", value: "科技與製造產業", checked: false },
  { label: "零售與電商產業(5)", value: "零售與電商產業", checked: false },
  { label: "餐飲與連鎖服務產業(2)", value: "餐飲與連鎖服務產業", checked: false },
  { label: "醫療與照護產業(2)", value: "醫療與照護產業", checked: false },
  { label: "教育與訓練產業(1)", value: "教育與訓練產業", checked: false },
  { label: "建築與工程產業(1)", value: "建築與工程產業", checked: false },
  { label: "旅宿與觀光產業(1)", value: "旅宿與觀光產業", checked: false },
  { label: "顧問服務產業(1)", value: "顧問服務產業", checked: false }
];
const child2 = [
  { label: "北部地區(1)", value: "北部地區", checked: false },
  { label: "中部地區(1)", value: "中部地區", checked: false },
  { label: "南部地區(1)", value: "南部地區", checked: false },
  { label: "東部地區(10)", value: "東部地區", checked: false },
  { label: "離島地區(100)", value: "離島地區", checked: false }
];
const data = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  },
  {
    title: "服務地區",
    show: true,
    children: child2
  }
];

const $$Ivy = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Ivy" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "ivy-banner", "title": "\u5408\u4F5C\u5925\u4F34" })}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "IvyList", "title": "\u5408\u4F5C\u5925\u4F34", "total": 10, "sortDate": [
    { text: "\u65B0\u4E0A\u5E02", value: "0" },
    { text: "\u5408\u4F5C\u5925\u4F34", value: "1" }
  ], "category": data, "mode": "white" }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "showLogo": false, "showLabel": false })}`)}` })}
    ${renderComponent($$result2, "Follower", $$Follower, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy.astro";
const $$url = "/ivy.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Ivy,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
