/* empty css                                   */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_v5wg8FJS.mjs';
import { a as $$Layouts } from '../chunks/layouts_CD-64Xzn.mjs';
import { $ as $$Banner } from '../chunks/banner_D4dx3PBM.mjs';
import { $ as $$Follower, a as $$SciptInline, b as $$ArticlesList } from '../chunks/scipt-inline_B0tRIb0y.mjs';
import { $ as $$Card } from '../chunks/card_DMScW66i.mjs';
import { $ as $$Script } from '../chunks/script_CiBXlnxE.mjs';
import '../chunks/index.537c41b6_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業", value: "tech-manufacturing", name: "industry", checked: false, count: 1 },
  { label: "零售與電商產業", value: "retail-ecommerce", name: "industry", checked: false, count: 5 },
  { label: "餐飲與連鎖服務產業", value: "food-service", name: "industry", checked: false, count: 2 },
  { label: "醫療與照護產業", value: "healthcare", name: "industry", checked: false, count: 2 },
  { label: "教育與訓練產業", value: "education", name: "industry", checked: false, count: 1 },
  { label: "建築與工程產業", value: "construction", name: "industry", checked: false, count: 1 },
  { label: "旅宿與觀光產業", value: "hospitality", name: "industry", checked: false, count: 1 },
  { label: "顧問服務產業", value: "consulting", name: "industry", checked: false, count: 1 }
];
const child2 = [
  { label: "北部地區", value: "north", name: "region", checked: false, count: 1 },
  { label: "中部地區", value: "central", name: "region", checked: false, count: 1 },
  { label: "南部地區", value: "south", name: "region", checked: false, count: 1 },
  { label: "東部地區", value: "east", name: "region", checked: false, count: 10 },
  { label: "離島地區", value: "islands", name: "region", checked: false, count: 100 }
];
const data$1 = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  },
  {
    title: "服務地區",
    show: true,
    children: child2
  }
];

const data = [
  {
    title: "iShops - 開店平台！",
    date: "2025-12-24",
    breif: "一站式開店平台，全面強化您的商業運營，增加企業營收，讓企業變得更好。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/0",
    linkText: "了解更多"
  },
  {
    title: "CloudSync - 雲端同步系統",
    date: "2025-12-24",
    breif: "智能雲端數據同步解決方案，提供即時備份與多裝置協作功能。支援跨平台檔案同步、版本控制、團隊共享空間，並具備先進的資料加密技術，確保您的重要文件隨時隨地都能安全存取。適合遠距工作團隊和需要高度協作的企業使用。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/1",
    linkText: "了解更多"
  },
  {
    title: "SecureGuard - 企業資安防護",
    date: "2025-12-24",
    breif: "全方位企業資訊安全防護系統，包含防火牆、入侵檢測、惡意軟體防護等多層次安全機制，確保您的數位資產安全無虞。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/2",
    linkText: "了解更多"
  },
  {
    title: "DataFlow - 數據分析平台",
    date: "2025-12-24",
    breif: "強大的商業智能分析工具，將複雜數據轉化為可視化報表，協助企業做出精準決策。整合多種數據源，提供即時儀表板、預測分析、趨勢洞察等功能，支援自定義報表和自動化警報系統，讓管理層能快速掌握業務狀況並制定有效策略。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/3",
    linkText: "了解更多"
  },
  {
    title: "TeamConnect - 協作管理工具",
    date: "2025-12-24",
    breif: "整合專案管理、團隊溝通、文件共享的一體化協作平台。提供任務分配、進度追蹤、時程管理、資源配置等完整功能，支援即時通訊、視訊會議、檔案協作編輯，並具備強大的權限管理系統，讓團隊協作更加順暢高效。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/4",
    linkText: "了解更多"
  },
  {
    title: "AutoFlow - 工作流程自動化",
    date: "2025-12-24",
    breif: "透過智能自動化技術，簡化繁複的業務流程，提升工作效率，減少人為錯誤，讓團隊專注於更有價值的創新工作。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/5",
    linkText: "了解更多"
  },
  {
    title: "MobileFirst - 行動應用開發",
    date: "2025-12-24",
    breif: "專業的跨平台行動應用開發服務，支援 iOS 和 Android 雙平台。採用最新的開發框架和技術，提供原生效能體驗，包含 UI/UX 設計、功能開發、測試部署、上架協助等完整服務，並提供後續維護和更新支援，助您快速搶占行動市場。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/6",
    linkText: "了解更多"
  },
  {
    title: "SmartInventory - 智慧庫存管理",
    date: "2025-12-24",
    breif: "運用 AI 技術預測需求，優化庫存配置，降低成本並提高供應鏈效率。智能分析歷史銷售數據、季節性趨勢、市場變化等因素，自動調整採購建議和安全庫存水位，減少缺貨風險和過剩庫存，並提供供應商管理和成本分析功能。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/7",
    linkText: "了解更多"
  },
  {
    title: "CustomerCare - 客戶關係管理",
    date: "2025-12-24",
    breif: "完整的 CRM 解決方案，從潛在客戶開發到售後服務，全程追蹤客戶互動歷程，建立長期穩固的客戶關係，提升客戶滿意度與忠誠度。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/8",
    linkText: "了解更多"
  },
  {
    title: "EcoTech - 綠色科技解決方案",
    date: "2025-12-24",
    breif: "環保永續的科技解決方案，協助企業實現碳中和目標。提供碳足跡追蹤、能源效率優化、綠色供應鏈管理、永續報告生成等功能，結合 IoT 感測器和 AI 分析技術，幫助企業建立環保營運模式，符合 ESG 標準並提升品牌形象。",
    img: "/assets/images/pages/Article-card-image",
    link: "/ivy/9",
    linkText: "了解更多"
  }
];

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Ivy", "footerPages": ["\u5408\u4F5C\u5925\u4F34"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "ivy-banner", "title": "\u5408\u4F5C\u5925\u4F34" })}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "IvyList", "title": "\u5408\u4F5C\u5925\u4F34", "total": 10, "sortDate": [
    { text: "\u65B0\u4E0A\u5E02", value: "0" },
    { text: "\u5408\u4F5C\u5925\u4F34", value: "1" }
  ], "category": data$1, "mode": "white" }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "link": `/ivy/${index}`, "showLogo": false, "showLabel": false })}`)}` })}
` })}
${renderComponent($$result, "Follower", $$Follower, {})}    
${renderComponent($$result, "ScriptInline", $$SciptInline, { "data": data })}
${renderComponent($$result, "Script", $$Script, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy/index.astro";
const $$url = "/ivy.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
