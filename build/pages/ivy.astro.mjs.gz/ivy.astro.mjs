/* empty css                                   */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../chunks/layouts_Bzy3aiqY.mjs';
import { $ as $$Banner } from '../chunks/banner_H9CF1t-5.mjs';
import { $ as $$Follower, a as $$Script, b as $$ArticlesList } from '../chunks/script_DPeN18Hi.mjs';
import { $ as $$Card } from '../chunks/card_DpXd-TDX.mjs';
import '../chunks/index.537c41b6_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業", value: "tech-manufacturing", name: "industry", checked: false, count: 1 },
  { label: "零售與電商產業", value: "retail-ecommerce", name: "industry", checked: false, count: 5 },
  { label: "餐飲與連鎖服務產業", value: "food-service", name: "industry", checked: false, count: 2 },
  { label: "醫療與照護產業", value: "healthcare", name: "industry", checked: false, count: 2 },
  { label: "教育與訓練產業", value: "education", name: "industry", checked: false, count: 1 },
  { label: "建築與工程產業", value: "construction", name: "industry", checked: false, count: 1 },
  { label: "旅宿與觀光產業", value: "hospitality", name: "industry", checked: false, count: 1 },
  { label: "顧問服務產業", value: "consulting", name: "industry", checked: false, count: 1 }
];
const child2 = [
  { label: "北部地區", value: "north", name: "region", checked: false, count: 1 },
  { label: "中部地區", value: "central", name: "region", checked: false, count: 1 },
  { label: "南部地區", value: "south", name: "region", checked: false, count: 1 },
  { label: "東部地區", value: "east", name: "region", checked: false, count: 10 },
  { label: "離島地區", value: "islands", name: "region", checked: false, count: 100 }
];
const data = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  },
  {
    title: "服務地區",
    show: true,
    children: child2
  }
];

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Ivy", "footerPages": ["\u5408\u4F5C\u5925\u4F34"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "ivy-banner", "title": "\u5408\u4F5C\u5925\u4F34" })}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "IvyList", "title": "\u5408\u4F5C\u5925\u4F34", "total": 10, "sortDate": [
    { text: "\u65B0\u4E0A\u5E02", value: "0" },
    { text: "\u5408\u4F5C\u5925\u4F34", value: "1" }
  ], "category": data, "mode": "white" }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "link": `/ivy/${index}`, "showLogo": false, "showLabel": false })}`)}` })}
` })}
${renderComponent($$result, "Follower", $$Follower, {})}    
${renderComponent($$result, "Script", $$Script, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/ivy/index.astro";
const $$url = "/ivy.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
