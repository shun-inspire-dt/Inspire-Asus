/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, F as Fragment, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, u as unescapeHTML } from '../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, c as $$Link, a as $$Layouts } from '../chunks/layouts_DpjfgSHX.mjs';
import { $ as $$Relative, a as $$Relative$1 } from '../chunks/relative_CwABVtZI.mjs';
import { b as bannerImages, a as bannerImage } from '../chunks/banner_BzehUiDa.mjs';
import { $ as $$Swiper } from '../chunks/navigatiorArrow_DKC9erjs.mjs';
import { $ as $$Picture } from '../chunks/picture_GYxijd3h.mjs';
/* empty css                                 */
import { a as $$Card } from '../chunks/card_CNxYSv_q.mjs';
import { $ as $$Card$1 } from '../chunks/card_s_R1mYA5.mjs';
export { renderers } from '../renderers.mjs';

const data = [
  {
    image: {
      sm: `<svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20.8491 0C32.1432 0 41.3325 9.18919 41.3325 20.4834C41.3325 21.5597 41.2554 22.5849 41.0962 23.6182C41.0384 23.9929 40.7153 24.2616 40.3472 24.2617C40.3087 24.2617 40.2701 24.2579 40.231 24.252C39.8168 24.1882 39.5325 23.8009 39.5962 23.3867C39.705 22.678 39.759 21.9658 39.7866 21.2412H30.688C30.6759 21.8172 30.6661 22.3976 30.6343 22.9541C30.6098 23.3719 30.2469 23.6895 29.8335 23.668C29.4158 23.6442 29.0963 23.2856 29.1206 22.8672C29.1509 22.3389 29.1586 21.7877 29.1704 21.2412H12.5298C12.5883 24.4653 13.0142 27.5804 13.7788 30.3447H22.7456C23.1649 30.3447 23.5043 30.6843 23.5044 31.1035C23.5044 31.5228 23.1649 31.8623 22.7456 31.8623H14.2417C15.8212 36.5548 18.2979 39.448 20.8491 39.4482C21.8477 39.4482 22.7978 39.3771 23.7534 39.2305C24.169 39.1719 24.5557 39.4501 24.6187 39.8643C24.6824 40.2783 24.3989 40.6657 23.9849 40.7295C22.9514 40.8888 21.9256 40.9658 20.8491 40.9658C13.8914 40.9657 7.49774 37.4826 3.69775 31.6514C3.6008 31.5653 3.53297 31.456 3.48975 31.334C1.4501 28.0906 0.366786 24.3449 0.366699 20.4834C0.366699 14.2523 3.15733 8.43487 8.02295 4.52246C8.34818 4.25872 8.82807 4.31098 9.09033 4.6377C9.35249 4.96441 9.30006 5.44187 8.97412 5.7041C7.72552 6.70789 6.64198 7.85834 5.70264 9.10352H12.6069C13.57 6.06191 14.9186 3.62663 16.5161 2.03809C15.6476 2.24226 14.7882 2.48883 13.9497 2.81641C13.5557 2.96677 13.119 2.77601 12.9663 2.38574C12.8137 1.99532 13.0073 1.55496 13.397 1.40234C15.7793 0.471971 18.2868 4.21467e-05 20.8491 0ZM5.729 31.8623C8.43214 35.4594 12.2481 37.9413 16.5542 38.9375C14.9786 37.3806 13.6267 34.9735 12.644 31.8623H5.729ZM1.91064 21.2412C2.03899 24.4758 2.98229 27.5986 4.6665 30.3447H12.2144C11.4822 27.5526 11.0687 24.4484 11.0122 21.2412H1.91064ZM4.65771 10.6211C2.99474 13.3419 2.05573 16.4617 1.92627 19.7246H11.0054C11.0612 16.4159 11.4671 13.3235 12.1675 10.6211H4.65771ZM13.7749 10.6211C13.0345 13.3112 12.5829 16.4217 12.522 19.7246H29.1772C29.1163 16.4218 28.6647 13.3111 27.9243 10.6211H13.7749ZM29.5317 10.6211C30.2321 13.3235 30.638 16.4159 30.6938 19.7246H39.7769C39.6442 16.398 38.6553 13.2951 37.0181 10.6211H29.5317ZM20.8491 1.51758C18.1882 1.51784 15.7778 4.5359 14.2378 9.10352H27.4614C25.9214 4.53565 23.5102 1.51758 20.8491 1.51758ZM25.1802 2.03516C26.7788 3.62371 28.1286 6.06014 29.0923 9.10352H35.9858C33.3572 5.61589 29.5644 3.06484 25.1802 2.03516Z" fill="#006CE1"/>
<path d="M20.8491 0C32.1432 0 41.3325 9.18919 41.3325 20.4834C41.3325 21.5597 41.2554 22.5849 41.0962 23.6182C41.0384 23.9929 40.7153 24.2616 40.3472 24.2617C40.3087 24.2617 40.2701 24.2579 40.231 24.252C39.8168 24.1882 39.5325 23.8009 39.5962 23.3867C39.705 22.678 39.759 21.9658 39.7866 21.2412H30.688C30.6759 21.8172 30.6661 22.3976 30.6343 22.9541C30.6098 23.3719 30.2469 23.6895 29.8335 23.668C29.4158 23.6442 29.0963 23.2856 29.1206 22.8672C29.1509 22.3389 29.1586 21.7877 29.1704 21.2412H12.5298C12.5883 24.4653 13.0142 27.5804 13.7788 30.3447H22.7456C23.1649 30.3447 23.5043 30.6843 23.5044 31.1035C23.5044 31.5228 23.1649 31.8623 22.7456 31.8623H14.2417C15.8212 36.5548 18.2979 39.448 20.8491 39.4482C21.8477 39.4482 22.7978 39.3771 23.7534 39.2305C24.169 39.1719 24.5557 39.4501 24.6187 39.8643C24.6824 40.2783 24.3989 40.6657 23.9849 40.7295C22.9514 40.8888 21.9256 40.9658 20.8491 40.9658C13.8914 40.9657 7.49774 37.4826 3.69775 31.6514C3.6008 31.5653 3.53297 31.456 3.48975 31.334C1.4501 28.0906 0.366786 24.3449 0.366699 20.4834C0.366699 14.2523 3.15733 8.43487 8.02295 4.52246C8.34818 4.25872 8.82807 4.31098 9.09033 4.6377C9.35249 4.96441 9.30006 5.44187 8.97412 5.7041C7.72552 6.70789 6.64198 7.85834 5.70264 9.10352H12.6069C13.57 6.06191 14.9186 3.62663 16.5161 2.03809C15.6476 2.24226 14.7882 2.48883 13.9497 2.81641C13.5557 2.96677 13.119 2.77601 12.9663 2.38574C12.8137 1.99532 13.0073 1.55496 13.397 1.40234C15.7793 0.471971 18.2868 4.21467e-05 20.8491 0ZM5.729 31.8623C8.43214 35.4594 12.2481 37.9413 16.5542 38.9375C14.9786 37.3806 13.6267 34.9735 12.644 31.8623H5.729ZM1.91064 21.2412C2.03899 24.4758 2.98229 27.5986 4.6665 30.3447H12.2144C11.4822 27.5526 11.0687 24.4484 11.0122 21.2412H1.91064ZM4.65771 10.6211C2.99474 13.3419 2.05573 16.4617 1.92627 19.7246H11.0054C11.0612 16.4159 11.4671 13.3235 12.1675 10.6211H4.65771ZM13.7749 10.6211C13.0345 13.3112 12.5829 16.4217 12.522 19.7246H29.1772C29.1163 16.4218 28.6647 13.3111 27.9243 10.6211H13.7749ZM29.5317 10.6211C30.2321 13.3235 30.638 16.4159 30.6938 19.7246H39.7769C39.6442 16.398 38.6553 13.2951 37.0181 10.6211H29.5317ZM20.8491 1.51758C18.1882 1.51784 15.7778 4.5359 14.2378 9.10352H27.4614C25.9214 4.53565 23.5102 1.51758 20.8491 1.51758ZM25.1802 2.03516C26.7788 3.62371 28.1286 6.06014 29.0923 9.10352H35.9858C33.3572 5.61589 29.5644 3.06484 25.1802 2.03516Z" stroke="#006CE1"/>
<path d="M11.3124 4.08909C11.6752 3.87961 11.7996 3.41566 11.5901 3.05274C11.3805 2.68991 10.9166 2.56563 10.5538 2.7751C10.1909 2.98458 10.0666 3.44853 10.2761 3.81136C10.4856 4.17429 10.9495 4.29856 11.3124 4.08909Z" fill="#006CE1"/>
<path d="M39.2754 39.6426L43.6335 44.0007" stroke="#007A99" stroke-width="1.5" stroke-linecap="round"/>
<path d="M33.2827 25.6835C37.6822 25.6835 41.2493 29.2498 41.2495 33.6493C41.2495 38.0489 37.6823 41.6161 33.2827 41.6161C28.8833 41.6159 25.3169 38.0488 25.3169 33.6493C25.3171 29.25 28.8834 25.6837 33.2827 25.6835Z" stroke="#007A99" stroke-width="1.5"/>
</svg>
`,
      lg: `<svg width="61" height="62" viewBox="0 0 61 62" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M28.4307 0.149658C43.9144 0.149658 56.5115 12.747 56.5117 28.2307C56.5117 29.706 56.4069 31.1124 56.1885 32.5295C56.0981 33.1149 55.5934 33.5334 55.0186 33.5334C54.9584 33.5334 54.8984 33.5289 54.8379 33.5198H54.8369C54.1902 33.4202 53.7472 32.8147 53.8467 32.1682C53.9861 31.2597 54.0575 30.346 54.0967 29.4153H41.9941C41.979 30.1517 41.9647 30.8948 41.9238 31.6096C41.888 32.2225 41.3875 32.695 40.7939 32.7239H40.6738C40.0213 32.6869 39.5214 32.1265 39.5596 31.4729C39.5978 30.805 39.6104 30.1108 39.625 29.4153H17.2393C17.3285 33.704 17.8962 37.8445 18.9043 41.5295H31.0176C31.6721 41.5297 32.2021 42.0596 32.2021 42.7141C32.202 43.3685 31.672 43.8985 31.0176 43.8987H19.6309C20.6937 46.9943 22.0422 49.4917 23.542 51.2219C25.0747 52.9901 26.7511 53.9435 28.4307 53.9436C29.785 53.9436 31.0727 53.8455 32.3682 53.6467H32.3701C33.0153 53.5559 33.6209 53.9884 33.7197 54.637C33.8192 55.2834 33.3761 55.8889 32.7295 55.9885C31.3124 56.2069 29.9059 56.3118 28.4307 56.3118C18.8971 56.3116 10.1362 51.5418 4.92578 43.5559C4.78587 43.426 4.68764 43.2674 4.62402 43.095C1.83263 38.6511 0.349609 33.5198 0.349609 28.2307C0.34972 19.6883 4.17633 11.7132 10.8467 6.34985L10.9443 6.27856C11.447 5.94973 12.1289 6.05244 12.5127 6.53052C12.9218 7.04043 12.8409 7.78601 12.332 8.19556C10.721 9.49071 9.31317 10.9675 8.08203 12.5637H17.082C18.3236 8.68185 20.0289 5.51784 22.0518 3.34985C21.0444 3.6023 20.0489 3.89951 19.0762 4.27954L19.0752 4.28052C18.462 4.51443 17.7796 4.21792 17.541 3.60767C17.3028 2.99811 17.6048 2.31085 18.2129 2.07251H18.2139C21.48 0.796996 24.9179 0.149704 28.4307 0.149658ZM8.11719 43.8987C11.6635 48.5064 16.5703 51.7279 22.1055 53.1272C20.1085 50.9984 18.3982 47.8655 17.1328 43.8987H8.11719ZM2.76465 29.4153C2.96117 33.7176 4.21994 37.8682 6.44922 41.5295H16.4629C15.5026 37.8012 14.9568 33.6759 14.8711 29.4153H2.76465ZM40.4629 14.9329C41.3814 18.5455 41.9176 22.6557 42.002 27.0461H54.082C53.8792 22.6246 52.5617 18.4997 50.3936 14.9329H40.4629ZM18.8984 14.9329C17.9215 18.5211 17.3224 22.6557 17.2295 27.0461H39.6328C39.5399 22.6556 38.9398 18.5212 37.9629 14.9329H18.8984ZM6.43555 14.9329C4.23508 18.5603 2.98289 22.7071 2.78516 27.0461H14.8604C14.9447 22.6557 15.4809 18.5455 16.3994 14.9329H6.43555ZM34.8057 3.34595C36.8302 5.51412 38.5378 8.67913 39.7803 12.5637H48.7666C45.3132 8.09162 40.435 4.78939 34.8057 3.34595ZM28.4307 2.5188C26.6771 2.51894 24.9862 3.51377 23.4639 5.30298C21.9748 7.0531 20.662 9.54947 19.626 12.5637H37.2363C36.2003 9.54951 34.8875 7.0531 33.3984 5.30298C31.876 3.51365 30.1844 2.5188 28.4307 2.5188Z" fill="#006CE1" stroke="#006CE1" stroke-width="0.3"/>
<path d="M15.4262 5.87635C15.9209 5.59071 16.0905 4.95805 15.8049 4.46316C15.5191 3.96839 14.8864 3.79893 14.3917 4.08457C13.8969 4.37021 13.7273 5.00288 14.0131 5.49764C14.2987 5.99253 14.9314 6.162 15.4262 5.87635Z" fill="#006CE1" stroke="#006CE1" stroke-width="0.5"/>
<path d="M53.5571 54.3572L59.5 60.3" stroke="#007A99" stroke-width="2.5" stroke-linecap="round"/>
<path d="M45.3857 35.55C51.2597 35.5501 56.0215 40.3119 56.0215 46.1858C56.0215 52.0597 51.2596 56.8215 45.3857 56.8215C39.5118 56.8215 34.75 52.0597 34.75 46.1858C34.75 40.3119 39.5118 35.55 45.3857 35.55Z" stroke="#007A99" stroke-width="2.5"/>
</svg>
`
    },
    title: "探索適合的解決方案",
    description: "發掘最適合您企業的數位轉型工具與方法，從營運管理到行銷應用，快速找到能真正解決問題的方案。"
  },
  {
    image: {
      sm: `<svg width="44" height="45" viewBox="0 0 44 45" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M21.8087 32.9342C25.2468 32.9342 28.0339 30.1473 28.0339 26.7095C28.0339 23.2717 25.2468 20.4849 21.8087 20.4849C18.3706 20.4849 15.5835 23.2717 15.5835 26.7095C15.5835 30.1473 18.3706 32.9342 21.8087 32.9342Z" stroke="#007A99" stroke-width="1.5"/>
<path d="M21.8087 32.9341C15.696 32.9341 10.7417 37.888 10.7417 44.0001H32.8758C32.8758 37.888 27.9214 32.9341 21.8087 32.9341Z" stroke="#007A99" stroke-width="1.5" stroke-linejoin="round"/>
<path d="M35.191 35.9492C37.6919 35.9492 39.7193 33.922 39.7193 31.4213C39.7193 28.9205 37.6919 26.8933 35.191 26.8933C32.69 26.8933 30.6626 28.9205 30.6626 31.4213C30.6626 33.922 32.69 35.9492 35.191 35.9492Z" stroke="#006CE1" stroke-width="1.5"/>
<path d="M35.1908 43.9997H43.2412C43.2412 39.5535 39.6373 35.95 35.1908 35.95C34.242 35.95 33.3316 36.114 32.4863 36.4153" stroke="#006CE1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8.80904 35.9492C6.3081 35.9492 4.28068 33.922 4.28068 31.4213C4.28068 28.9205 6.3081 26.8933 8.80904 26.8933C11.31 26.8933 13.3374 28.9205 13.3374 31.4213C13.3374 33.922 11.31 35.9492 8.80904 35.9492Z" stroke="#006CE1" stroke-width="1.5"/>
<path d="M8.80875 43.9997H0.758331C0.758331 39.5535 4.36223 35.95 8.80875 35.95C9.75753 35.95 10.668 36.114 11.5132 36.4153" stroke="#006CE1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M38.2008 22.755C38.1437 22.755 38.0796 22.755 38.0225 22.7337C37.6375 22.6341 37.4094 22.2502 37.5092 21.8662C37.8514 20.5364 38.0225 19.164 38.0225 17.7774C38.0225 8.76083 30.6647 1.42242 21.6243 1.42242C12.5839 1.42242 5.22603 8.76083 5.22603 17.7774C5.22603 19.164 5.39715 20.5364 5.73937 21.8662C5.83918 22.2502 5.61104 22.6341 5.22603 22.7337C4.84816 22.8332 4.45603 22.6057 4.35621 22.2217C3.98547 20.7782 3.79297 19.2849 3.79297 17.7774C3.8001 7.97153 11.7925 0.000244141 21.6243 0.000244141C31.4561 0.000244141 39.4485 7.97153 39.4485 17.7774C39.4485 19.2778 39.2631 20.7782 38.8852 22.2217C38.7997 22.5417 38.5145 22.755 38.1936 22.755H38.2008Z" fill="#006CE1"/>
<path d="M30.6938 22.0439C30.6938 22.0439 30.6367 22.0439 30.6153 22.0439C30.2232 22.0013 29.9451 21.6457 29.9879 21.2546C30.1163 20.1169 30.1875 18.9507 30.1875 17.7774C30.1875 8.76083 26.3518 1.42242 21.6319 1.42242C16.9121 1.42242 13.0763 8.76083 13.0763 17.7774C13.0763 18.9436 13.1405 20.1169 13.276 21.2546C13.3187 21.6457 13.0407 21.9942 12.6486 22.0439C12.2636 22.0937 11.9071 21.8093 11.8572 21.4182C11.7217 20.2307 11.6504 19.0076 11.6504 17.7845C11.6433 7.80798 16.028 0.000244141 21.6248 0.000244141C27.2216 0.000244141 31.6064 7.80798 31.6064 17.7774C31.6064 19.0005 31.5351 20.2236 31.3996 21.4111C31.3568 21.7737 31.0502 22.0439 30.6938 22.0439Z" fill="#006CE1"/>
<path d="M4.51318 17.0642H38.7356V18.4871H4.51318V17.0642Z" fill="#006CE1"/>
<path d="M21.6247 10.6678C16.5627 10.6678 11.6646 9.89271 7.83594 8.49187L8.32789 7.15503C12.0068 8.49898 16.7266 9.24562 21.6319 9.24562C26.5371 9.24562 31.2569 8.50609 34.9358 7.15503L35.4278 8.49187C31.592 9.89271 26.6939 10.6678 21.639 10.6678H21.6247Z" fill="#006CE1"/>
<path d="M20.9116 0.713623H22.3373V17.7797H20.9116V0.713623Z" fill="#006CE1"/>
</svg>
`,
      lg: `<svg width="61" height="62" viewBox="0 0 61 62" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M29.955 45.1606C34.6433 45.1606 38.444 41.3602 38.444 36.6722C38.444 31.9842 34.6433 28.1838 29.955 28.1838C25.2667 28.1838 21.4661 31.9842 21.4661 36.6722C21.4661 41.3602 25.2667 45.1606 29.955 45.1606Z" stroke="#007A99" stroke-width="2.5"/>
<path d="M29.955 45.1606C21.6195 45.1606 14.8636 51.9161 14.8636 60.2511H45.0464C45.0464 51.9161 38.2905 45.1606 29.955 45.1606Z" stroke="#007A99" stroke-width="2.5" stroke-linejoin="round"/>
<path d="M48.2035 49.2709C51.6139 49.2709 54.3786 46.5064 54.3786 43.0963C54.3786 39.6861 51.6139 36.9216 48.2035 36.9216C44.7932 36.9216 42.0285 39.6861 42.0285 43.0963C42.0285 46.5064 44.7932 49.2709 48.2035 49.2709Z" stroke="#006CE1" stroke-width="2.5"/>
<path d="M48.2032 60.2501H59.181C59.181 54.1871 54.2666 49.2729 48.2032 49.2729C46.9094 49.2729 45.6679 49.4967 44.5153 49.9076" stroke="#006CE1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12.228 49.2709C8.81761 49.2709 6.05295 46.5064 6.05295 43.0963C6.05295 39.6861 8.81761 36.9216 12.228 36.9216C15.6384 36.9216 18.403 39.6861 18.403 43.0963C18.403 46.5064 15.6384 49.2709 12.228 49.2709Z" stroke="#006CE1" stroke-width="2.5"/>
<path d="M12.2278 60.2501H1.25001C1.25001 54.1871 6.16442 49.2729 12.2278 49.2729C13.5216 49.2729 14.7631 49.4967 15.9157 49.9076" stroke="#006CE1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M52.3078 31.2801C52.23 31.2801 52.1425 31.2801 52.0647 31.251C51.5397 31.1152 51.2286 30.5916 51.3647 30.0679C51.8314 28.2546 52.0647 26.3831 52.0647 24.4922C52.0647 12.1966 42.0313 2.18938 29.7035 2.18938C17.3756 2.18938 7.34224 12.1966 7.34224 24.4922C7.34224 26.3831 7.57557 28.2546 8.04224 30.0679C8.17835 30.5916 7.86724 31.1152 7.34224 31.251C6.82696 31.3867 6.29223 31.0764 6.15612 30.5528C5.65056 28.5843 5.38806 26.548 5.38806 24.4922C5.39778 11.1202 16.2965 0.25 29.7035 0.25C43.1105 0.25 54.0092 11.1202 54.0092 24.4922C54.0092 26.5383 53.7564 28.5843 53.2411 30.5528C53.1244 30.9891 52.7355 31.2801 52.298 31.2801H52.3078Z" fill="#006CE1" stroke="#006CE1" stroke-width="0.5"/>
<path d="M42.0707 30.3104C42.0707 30.3104 41.9929 30.3104 41.9637 30.3104C41.429 30.2522 41.0499 29.7673 41.1082 29.234C41.2832 27.6825 41.3804 26.0922 41.3804 24.4922C41.3804 12.1966 36.1498 2.18938 29.7137 2.18938C23.2775 2.18938 18.0469 12.1966 18.0469 24.4922C18.0469 26.0825 18.1344 27.6825 18.3192 29.234C18.3775 29.7673 17.9983 30.2425 17.4636 30.3104C16.9386 30.3782 16.4525 29.9904 16.3844 29.457C16.1997 27.8377 16.1025 26.1698 16.1025 24.5019C16.0928 10.8972 22.072 0.25 29.704 0.25C37.3359 0.25 43.3151 10.8972 43.3151 24.4922C43.3151 26.1601 43.2179 27.828 43.0332 29.4473C42.9749 29.9419 42.5568 30.3104 42.0707 30.3104Z" fill="#006CE1" stroke="#006CE1" stroke-width="0.5"/>
<path d="M6.37018 23.5198H53.0371V25.4601H6.37018V23.5198Z" fill="#006CE1" stroke="#006CE1" stroke-width="0.5"/>
<path d="M29.7039 14.7971C22.8011 14.7971 16.1219 13.7401 10.901 11.8299L11.5718 10.0068C16.5885 11.8395 23.0247 12.8577 29.7136 12.8577C36.4025 12.8577 42.8387 11.8492 47.8554 10.0068L48.5262 11.8299C43.2956 13.7401 36.6164 14.7971 29.7233 14.7971H29.7039Z" fill="#006CE1" stroke="#006CE1" stroke-width="0.5"/>
<path d="M28.7312 1.22241H30.6754V24.495H28.7312V1.22241Z" fill="#006CE1" stroke="#006CE1" stroke-width="0.5"/>
</svg>
`
    },
    title: "找尋專業的服務夥伴",
    description: "透過平台串聯各領域的專業夥伴，不必單打獨鬥，建立合作網絡，共同推動產業創新與成長。"
  },
  {
    image: {
      sm: `<svg width="44" height="46" viewBox="0 0 44 46" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M21.8983 33.6739H27.7004C29.1569 33.6739 30.3377 32.4931 30.3377 31.0366M13.9863 40.5309H26.0275C29.5841 40.5309 32.9468 38.9096 35.1616 36.1268L40.5272 29.3855C41.3239 28.3844 41.2104 26.9376 40.2673 26.073C39.4032 25.281 38.0975 25.2167 37.1598 25.92L30.3377 31.0366M30.3377 31.0366C30.3377 29.58 29.1569 28.3993 27.7003 28.3993H20.8231C18.9447 28.3993 17.1083 28.9553 15.5453 29.9972L13.9863 31.0366" stroke="#007A99" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M11.0249 27.344H13.1348V42.6404H11.0249" stroke="#006CE1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M2.05811 25.2336H10.4975V44.7498H2.05811" stroke="#006CE1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M23.9395 9.85889L26.0252 14.085L30.689 14.7626L27.3143 18.0522L28.1109 22.6971L23.9395 20.504L19.7682 22.6971L20.5648 18.0522L17.1901 14.7626L21.8539 14.085L23.9395 9.85889Z" stroke="#007A99" stroke-width="1.5" stroke-linejoin="round"/>
<path d="M23.9399 4.29834L23.9399 0.749955" stroke="#007A99" stroke-width="1.5" stroke-linecap="round"/>
<path d="M33.5454 5.71802L31.0363 8.2271" stroke="#007A99" stroke-width="1.5" stroke-linecap="round"/>
<path d="M13.8862 5.71802L16.3953 8.2271" stroke="#007A99" stroke-width="1.5" stroke-linecap="round"/>
<path d="M34.585 14.5886L38.1333 14.5886" stroke="#007A99" stroke-width="1.5" stroke-linecap="round"/>
<path d="M9.74609 14.5886L13.2945 14.5886" stroke="#007A99" stroke-width="1.5" stroke-linecap="round"/>
</svg>
`,
      lg: `<svg width="60" height="63" viewBox="0 0 60 63" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M29.2567 45.6415H37.4324C39.4848 45.6415 41.1486 43.9777 41.1486 41.9253M18.1081 55.3036H35.2922C40.1667 55.3036 44.7753 53.0815 47.8109 49.2676L55.5065 39.5987C56.6292 38.1882 56.4693 36.1494 55.1403 34.9312C53.9228 33.8151 52.083 33.7245 50.7617 34.7155L41.1486 41.9253M41.1486 41.9253C41.1486 39.8729 39.4848 38.209 37.4324 38.209H27.7417C25.0948 38.209 22.5072 38.9925 20.3049 40.4607L18.1081 41.9253" stroke="#007A99" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.1351 36.7222H18.108V58.2762H15.1351" stroke="#006CE1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M2.5 33.7502H14.3919V61.2502H2.5" stroke="#006CE1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M33.3333 12.0833L36.2722 18.0382L42.8439 18.9931L38.0886 23.6283L39.2112 30.1734L33.3333 27.0832L27.4555 30.1734L28.578 23.6283L23.8227 18.9931L30.3944 18.0382L33.3333 12.0833Z" stroke="#007A99" stroke-width="2.5" stroke-linejoin="round"/>
<path d="M33.3333 6.25L33.3333 1.25" stroke="#007A99" stroke-width="2.5" stroke-linecap="round"/>
<path d="M46.8685 6.25L43.3329 9.78553" stroke="#007A99" stroke-width="2.5" stroke-linecap="round"/>
<path d="M19.1666 6.25L22.7022 9.78553" stroke="#007A99" stroke-width="2.5" stroke-linecap="round"/>
<path d="M48.3333 18.75L53.3333 18.75" stroke="#007A99" stroke-width="2.5" stroke-linecap="round"/>
<path d="M13.3333 18.75L18.3333 18.75" stroke="#007A99" stroke-width="2.5" stroke-linecap="round"/>
</svg>
`
    },
    title: "創造數位轉型的成果",
    description: "藉由平台，您不僅能導入工具，更能開拓新市場、創造全新的商業模式，實現企業持續成長與價值突破。"
  }
];

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Banner = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Banner;
  const { IDName = "IndexBanner", className, style, attribute = {} } = Astro2.props;
  const imgBreakpoints = bannerImages("index-banner");
  const image = bannerImage("index-banner");
  return renderTemplate`${renderComponent($$result, "Swiper", $$Swiper, { "IDName": IDName, "className": ["index-banner", className], "swiperClassName": "has-indicator", "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    
    ${Array.from({ length: 5 }).map(() => renderTemplate`${maybeRenderHead()}<div class="swiper-slide index-banner-slide">
                ${renderComponent($$result2, "Picture", $$Picture, { "img": image, "breakpoints": imgBreakpoints, "className": "index-banner-image", "width": 1440, "height": 777, "alt": "ASUS MarketPlace", "noWebp": true })}
                <div class="index-banner-article">
                    <h1 class="index-banner-title">
                        ASUS MarketPlace
                    </h1>
                    <strong class="index-banner-text">
                        數位轉型不必再分散與複雜，透過
                        商用數位轉型整合解決方案平台，企業即可一次到位完成管理、行銷與營運升級，快速抓住未來商機。
                    </strong>
                    <div class="index-banner-link">
                        ${renderComponent($$result2, "Button", $$Button, { "Tag": "a", "variant": "blue", "size": "sm", "link": "/solution", "title": "ASUS MarketPlace" }, { "default": ($$result3) => renderTemplate`
                            查看更多
                        ` })}
                    </div>
                </div>
            </div>`)}`, "outside": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outside" }, { "default": ($$result3) => renderTemplate`
        <div class="swiper-pagination-container">
            <div class="swiper-pagination"></div>
            <button type="button" class="swiper-button-play" title="Play">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 8L6 11.4641L6 4.5359L12 8Z" fill="var(--color-gray-900, #818181)"></path>
                </svg>
            </button>
            <button type="button" class="swiper-button-pause" style="display: none;" title="Pause">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="9" y="4.66602" width="1.66667" height="6.66667" rx="0.833333" fill="var(--color-gray-900, #818181)"></rect>
                    <rect x="5.3335" y="4.66602" width="1.66667" height="6.66667" rx="0.833333" fill="var(--color-gray-900, #818181)"></rect>
                </svg>
            </button>
        </div>
    ` })}` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/index/banner.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Aboutus = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Aboutus;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "index-aboutus-section"
  ], "class:list")}${addAttribute({ "--bg-image": 'url("/assets/images/pages/feature-BG-2.png")', ...style }, "style")}${spreadAttributes(attribute)}>
    <div class="index-aboutus-section-container">
        <h2 class="index-solutions-title">
            Why ASUS Business?
        </h2>
        <div class="index-aboutus-content">
            ${data?.map((item, index) => renderTemplate`<div class="index-aboutus-card">
                        <span class="index-aboutus-card-icon-sm">${unescapeHTML(item.image?.sm)}</span>
                        <span class="index-aboutus-card-icon-lg">${unescapeHTML(item.image?.lg)}</span>
                        <div class="index-aboutus-card-head">
                            <h3 class="index-aboutus-card-title">${item.title}</h3>
                            <p class="index-aboutus-card-description">${item.description}</p>
                        </div>
                    </div>`)}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/index/aboutus.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$Solutions = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Solutions;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "index-solutions-section"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="index-solutions-section-container">
        <h2 class="index-solutions-section-title">解決方案</h2>
        <div class="index-solutions-section-cards">
            ${Array.from({ length: 6 }).map((_, index) => renderTemplate`${renderComponent($$result, "Card", $$Card, { "link": `/solutions/${index}`, "showPlayBack": (index + 1) % 2 === 0 })}`)}
        </div>
        ${renderComponent($$result, "ALink", $$Link, { "link": "/solution", "title": "\u67E5\u770B\u66F4\u591A", "showArrow": true }, { "default": ($$result2) => renderTemplate`查看更多` })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/index/solutions.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Success = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Success;
  const { IDName = "SuccessRelative", className, style, attribute = {}, title = "\u6210\u529F\u6848\u4F8B" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyRelative", $$Relative, { "title": title, "className": ["news-section-relative", className], "IDName": IDName, "style": style, "attribute": attribute, "count": 12 }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Card", $$Card$1, { "link": "/news/0", "showLogo": false, "showLabel": false, "showDate": false })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/index/success.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Ivy = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Ivy;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "index-ivy-section"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="index-ivy-head">
        <h2 class="index-ivy-title">成為華碩合作夥伴</h2>
        <p class="index-ivy-subTitle">
            您的專業，是滋養數位沃土的泉源，一同共創、共享繁茂永續且多贏的產業智慧生態。
        </p>
    </div>
    <div class="index-ivy-brands">
        ${Array.from({ length: 40 }).map((_, index) => renderTemplate`<img width="140" height="48" class="index-ivy-brand-item"${addAttribute(`/assets/images/pages/brands/Logo-${index < 9 ? `0${index + 1}` : index + 1}.png`, "src")} alt="Logo" loading="lazy" decoding="async">`)}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/index/ivy.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$News = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$News;
  const { IDName = "NewsRelative", className, style, attribute = {}, title = "\u6700\u65B0\u6D88\u606F" } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyRelative", $$Relative, { "title": title, "className": ["news-section-relative", className], "IDName": IDName, "style": style, "attribute": attribute, "count": 12 }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Card", $$Card$1, { "link": "/news/0", "showLogo": false, "showLabel": false })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/index/news.astro", void 0);

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Index" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, {})}
    ${renderComponent($$result2, "Aboutus", $$Aboutus, { "data": data })}
    ${renderComponent($$result2, "Solutions", $$Solutions, {})}
    ${renderComponent($$result2, "Success", $$Success, {})}
    ${renderComponent($$result2, "Ivy", $$Ivy, {})}
    ${renderComponent($$result2, "News", $$News, {})}
` })}
${renderComponent($$result, "Script", $$Relative$1, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
