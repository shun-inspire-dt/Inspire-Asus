/* empty css                                   */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$A, a as $$Button, b as $$Layouts } from '../chunks/layouts_DUiMKDyJ.mjs';
import { $ as $$Banner } from '../chunks/banner_jdnpgIj0.mjs';
import { $ as $$Picture } from '../chunks/picture_GYxijd3h.mjs';
import '../chunks/aboutus.c05b071b_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const bannerImage = (text) => `/assets/images/pages/${text}`;
const bannerImages = (text) => [
  {
    width: 1280,
    // 桌面版斷點 (1280px+)
    img: `/assets/images/pages/${text}`,
    // 向後相容的預設圖片
    densities: {
      "1x": `/assets/images/pages/${text}`,
      // 標準解析度
      "1.5x": `/assets/images/pages/${text}`,
      // 1.5倍解析度
      "2x": `/assets/images/pages/${text}`
      // 2倍解析度（高解析度螢幕）
    }
  },
  {
    width: 768,
    // 平板版斷點 (768px-1279px)
    img: `/assets/images/pages/${text}`,
    densities: {
      "1x": `/assets/images/pages/${text}`,
      "1.5x": `/assets/images/pages/${text}`,
      "2x": `/assets/images/pages/${text}`
    }
  },
  {
    width: 0,
    // 手機版斷點 (767px 以下)
    img: `/assets/images/pages/${text}`,
    densities: {
      "1x": `/assets/images/pages/${text}`,
      "1.5x": `/assets/images/pages/${text}`,
      "2x": `/assets/images/pages/${text}`
    }
  }
];
const data$1 = [
  {
    title: "使命",
    text: "在全球化與數位化的浪潮下，企業正面臨前所未有的挑戰。供應鏈重組、跨國競爭加劇、科技快速演進，加上後疫情時代的工作型態轉變，都迫使企業必須更快適應市場的不確定性。對多數中小企業而言，技術資源與專業有限，使數位轉型成為一條艱鉅卻不得不走的道路。",
    img: bannerImage("aboutus-BG-01"),
    imgBreakpoints: bannerImages("aboutus-BG-01")
  },
  {
    title: "願景",
    text: "因此，華碩以「平台、生態圈、服務導向」為核心精神，整合多元的數位解決方案與專業服務團隊， 搭配不同採購模式、創造多元選擇，進而降低門檻，協助企業快速導入所需工具。 並透過聚合效應與生態圈夥伴合作，推動中小企業在數位轉型中穩健前行。",
    img: bannerImage("aboutus-BG-02"),
    imgBreakpoints: bannerImages("aboutus-BG-02")
  },
  {
    title: "核心價值",
    text: "我們的核心價值，建立在三大目標之上：一站式平台，以安全穩定的架構支撐多元解決方案； 生態圈合作，串聯軟體供應商、硬體夥伴與系統整合商，共同打造共好環境；服務導向， 以客戶需求為核心，提供彈性、持續優化的數位體驗和服務。這三大支柱，構成我們推動企業數位轉型的重要基石。",
    img: bannerImage("aboutus-BG-03"),
    imgBreakpoints: bannerImages("aboutus-BG-03")
  }
];

const data = [
  {
    title: "嚴選多元方案",
    text: "集合雲端、AI、行銷、營運等數位工具，讓企業在同一平台快速找到最合適的解決方案。",
    img: bannerImage("aboutus-BG-02-01"),
    imgBreakpoints: bannerImages("aboutus-BG-02-01")
  },
  {
    title: "嚴選多元方案",
    text: "集合雲端、AI、行銷、營運等數位工具，讓企業在同一平台快速找到最合適的解決方案。",
    img: bannerImage("aboutus-BG-02-02"),
    imgBreakpoints: bannerImages("aboutus-BG-02-02")
  },
  {
    title: "嚴選多元方案",
    text: "集合雲端、AI、行銷、營運等數位工具，讓企業在同一平台快速找到最合適的解決方案。",
    img: bannerImage("aboutus-BG-02-03"),
    imgBreakpoints: bannerImages("aboutus-BG-02-03")
  },
  {
    title: "嚴選多元方案",
    text: "集合雲端、AI、行銷、營運等數位工具，讓企業在同一平台快速找到最合適的解決方案。",
    img: bannerImage("aboutus-BG-02-04"),
    imgBreakpoints: bannerImages("aboutus-BG-02-04")
  },
  {
    title: "嚴選多元方案",
    text: "集合雲端、AI、行銷、營運等數位工具，讓企業在同一平台快速找到最合適的解決方案。",
    img: bannerImage("aboutus-BG-02-05"),
    imgBreakpoints: bannerImages("aboutus-BG-02-05")
  },
  {
    title: "嚴選多元方案",
    text: "集合雲端、AI、行銷、營運等數位工具，讓企業在同一平台快速找到最合適的解決方案。",
    img: bannerImage("aboutus-BG-02-06"),
    imgBreakpoints: bannerImages("aboutus-BG-02-06")
  }
];

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Nav = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Nav;
  const { IDName, className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "section-nav"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${data.map((item) => renderTemplate`${renderComponent($$result, "A", $$A, { "link": item.link, "className": "section-nav-link", "title": item.title, "extend": true }, { "default": ($$result2) => renderTemplate`${item.title}` })}`)}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/section/nav.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Card = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Card;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "\u4F7F\u547D",
    text = "\u5728\u5168\u7403\u5316\u8207\u6578\u4F4D\u5316\u7684\u6D6A\u6F6E\u4E0B\uFF0C\u4F01\u696D\u6B63\u9762\u81E8\u524D\u6240\u672A\u6709\u7684\u6311\u6230\u3002\u4F9B\u61C9\u93C8\u91CD\u7D44\u3001\u8DE8\u570B\u7AF6\u722D\u52A0\u5287\u3001\u79D1\u6280\u5FEB\u901F\u6F14\u9032\uFF0C\u52A0\u4E0A\u5F8C\u75AB\u60C5\u6642\u4EE3\u7684\u5DE5\u4F5C\u578B\u614B\u8F49\u8B8A\uFF0C\u90FD\u8FEB\u4F7F\u4F01\u696D\u5FC5\u9808\u66F4\u5FEB\u9069\u61C9\u5E02\u5834\u7684\u4E0D\u78BA\u5B9A\u6027\u3002\u5C0D\u591A\u6578\u4E2D\u5C0F\u4F01\u696D\u800C\u8A00\uFF0C\u6280\u8853\u8CC7\u6E90\u8207\u5C08\u696D\u6709\u9650\uFF0C\u4F7F\u6578\u4F4D\u8F49\u578B\u6210\u70BA\u4E00\u689D\u8271\u9245\u537B\u4E0D\u5F97\u4E0D\u8D70\u7684\u9053\u8DEF\u3002",
    img,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/aboutus-BG-1",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/aboutus-BG-1",
          // 標準解析度
          "1.5x": "/assets/images/pages/aboutus-BG-1",
          // 1.5倍解析度
          "2x": "/assets/images/pages/aboutus-BG-1"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/aboutus-BG-1",
        densities: {
          "1x": "/assets/images/pages/aboutus-BG-1",
          "1.5x": "/assets/images/pages/aboutus-BG-1",
          "2x": "/assets/images/pages/aboutus-BG-1"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/aboutus-BG-1",
        densities: {
          "1x": "/assets/images/pages/aboutus-BG-1",
          "1.5x": "/assets/images/pages/aboutus-BG-1",
          "2x": "/assets/images/pages/aboutus-BG-1"
        }
      }
    ],
    width,
    direction = "row"
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...direction ? { "--card-direction": direction } : {},
    ...style
  };
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "aboutus-card group"
  ], "class:list")}${addAttribute(cardStyle, "style")}${spreadAttributes(attribute)}>
    <div class="aboutus-card-image-container">
        ${renderComponent($$result, "Picture", $$Picture, { "img": img, "className": "aboutus-card-image", "breakpoints": imgBreakpoints, "alt": title, "loading": "lazy", "decoding": "async", "noWebp": true })}
    </div>
    <div class="aboutus-card-content">
        <strong class="aboutus-card-title">${title}</strong>
        <p class="aboutus-card-text">${text}</p>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/aboutus/card.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$Section01 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Section01;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "aboutus-section-01"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="aboutus-section-01-body">
        <div class="aboutus-section-head">
            <h1 class="aboutus-section-title">
                跨產業合作生態
            </h1>
            <p class="aboutus-section-01-brief">
                華碩共好生態圈平台的成立，不只是提供產品與技術，更是希望透過各類專家團隊的協同合作，提供企業創新、穩定與安全的數位轉型解決方案或服務，陪伴企業共同成長。
            </p>
        </div>
        <div class="aboutus-section-01-grid">
            ${data?.map((item, index) => renderTemplate`${renderComponent($$result, "Card", $$Card, { "title": item.title, "text": item.text, "img": item.img, "imgBreakpoints": item.imgBreakpoints, "direction": index % 2 === 0 ? "row" : "row-reverse" })}`)}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/aboutus/section01.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Card2 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Card2;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "\u56B4\u9078\u591A\u5143\u65B9\u6848",
    text = "\u96C6\u5408\u96F2\u7AEF\u3001AI\u3001\u884C\u92B7\u3001\u71DF\u904B\u7B49\u6578\u4F4D\u5DE5\u5177\uFF0C\u8B93\u4F01\u696D\u5728\u540C\u4E00\u5E73\u53F0\u5FEB\u901F\u627E\u5230\u6700\u5408\u9069\u7684\u89E3\u6C7A\u65B9\u6848\u3002",
    img,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/aboutus-BG-2",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/aboutus-BG-2",
          // 標準解析度
          "1.5x": "/assets/images/pages/aboutus-BG-2",
          // 1.5倍解析度
          "2x": "/assets/images/pages/aboutus-BG-2"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/aboutus-BG-2",
        densities: {
          "1x": "/assets/images/pages/aboutus-BG-2",
          "1.5x": "/assets/images/pages/aboutus-BG-2",
          "2x": "/assets/images/pages/aboutus-BG-2"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/aboutus-BG-2",
        densities: {
          "1x": "/assets/images/pages/aboutus-BG-2",
          "1.5x": "/assets/images/pages/aboutus-BG-2",
          "2x": "/assets/images/pages/aboutus-BG-2"
        }
      }
    ],
    width
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...style
  };
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "aboutus-card-2"
  ], "class:list")}${addAttribute(cardStyle, "style")}${spreadAttributes(attribute)}>
    <div class="aboutus-card-2-image-container">
        ${renderComponent($$result, "Picture", $$Picture, { "img": img, "className": "aboutus-card-2-image", "breakpoints": imgBreakpoints, "alt": title, "loading": "lazy", "decoding": "async", "noWebp": true })}
    </div>
    <div class="aboutus-card-2-container group">
        <div class="aboutus-card-2-content">
            <strong class="aboutus-card-2-title">${title}</strong>
            <p class="aboutus-card-2-text">${text}</p>
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/aboutus/card2.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Section02 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Section02;
  const { IDName, className, style, attribute = {}, data } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "aboutus-section-02"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="aboutus-section-02-body">
        <h2 class="aboutus-section-title">
            競爭優勢
        </h2>
        <div class="aboutus-section-02-grid">
            ${data?.map((item) => renderTemplate`${renderComponent($$result, "Card2", $$Card2, { "title": item.title, "text": item.text, "img": item.img, "imgBreakpoints": item.imgBreakpoints })}`)}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/aboutus/section02.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Section03 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Section03;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "aboutus-section-03"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
<div class="aboutus-section-03-body">
        <div class="aboutus-section-03-head">
            <h3 class="aboutus-section-03-title">ASUS MarketPlace</h3>
            <p class="aboutus-section-03-brief">加入 ASUS MarketPlace，連結資源、拓展市場，創造企業新價值。</p>
        </div>
        ${renderComponent($$result, "Button", $$Button, { "Tag": "a", "variant": "blue", "link": "/ivy", "title": "\u6210\u70BA ISV \u5925\u4F34", "block": true }, { "default": ($$result2) => renderTemplate`成為 ISV 夥伴` })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/aboutus/section03.astro", void 0);

const $$Aboutus = createComponent(($$result, $$props, $$slots) => {
  const navId = `scroll-spy-${Math.random().toString(36).substr(2, 9)}`;
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Aboutus" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "aboutus-banner", "title": "\u95DC\u65BC\u6211\u5011" })}
    ${renderComponent($$result2, "Nav", $$Nav, { "IDName": navId, "data": [
    { title: "\u8DE8\u7522\u696D\u5408\u4F5C\u751F\u614B", link: "#section01" },
    { title: "\u7AF6\u722D\u512A\u52E2", link: "#section02" }
  ] })}
    ${maybeRenderHead()}<div data-bs-spy="scroll" data-bs-root-margin="0px 0px 0px"${addAttribute(`#${navId}`, "data-bs-target")} data-bs-smooth-scroll="true">
        ${renderComponent($$result2, "Section01", $$Section01, { "IDName": "section01", "data": data$1 })}
        ${renderComponent($$result2, "Section02", $$Section02, { "IDName": "section02", "data": data })}
        ${renderComponent($$result2, "Section03", $$Section03, { "IDName": "section03" })}
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/aboutus.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/aboutus.astro";
const $$url = "/aboutus.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Aboutus,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
