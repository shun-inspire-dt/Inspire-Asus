/* empty css                                   */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../chunks/layouts_CplpB5U3.mjs';
import '../chunks/index.33662b54_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Member", "minMarginHeader": true, "isMemberFooter": true })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/member/index.astro";
const $$url = "/member.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
