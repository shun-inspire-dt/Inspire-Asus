/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Bjgbv9en.mjs';
import { b as $$Input, $ as $$Button, a as $$Layouts } from '../chunks/layouts_KEEHHm9S.mjs';
import { $ as $$Form$1 } from '../chunks/form_PYguvSQ8.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_Dmit_mIv.mjs';
import '../chunks/forget-password.ee11f018_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "id": IDName, "title": "\u5FD8\u8A18\u5BC6\u78BC?", "class:list": [className], "style": style, ...attribute, "action": "/reset-password" }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<p class="forget-password-info-text">
        請輸入您當初註冊時所填寫的 E-mail 帳號或手機號碼。
    </p>
    <img width="120" height="120" src="/assets/images/pages/dropped-image.png" alt="忘記密碼" loading="lazy">
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u5E33\u865F", "infoText": "\u96FB\u5B50\u90F5\u4EF6\u5730\u5740\u662F\u60A8\u7684\u5E33\u6236", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "type": "email", "inputmode": "email" })}
    ` })}
    <hr class="forget-password-divider">
    <p class="forget-password-warning-text">
        若是使用社群帳號 (如: Facebook, Google+ ) 登入的會員，請輸入您註冊社群帳號時所使用的 E-mail
        帳號或手機號碼。我們將會寄送一封驗證電子郵件/SMS至您的信箱/手機。
    </p>
    ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "variant": "blue", "title": "\u78BA\u8A8D\u5BC4\u51FA", "block": true }, { "default": ($$result3) => renderTemplate`確認寄出` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/forget-password/form.astro", void 0);

const $$ForgetPassword = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Forget-password", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/forget-password.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/forget-password.astro";
const $$url = "/forget-password.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$ForgetPassword,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
