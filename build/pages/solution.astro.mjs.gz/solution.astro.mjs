/* empty css                                   */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../chunks/layouts_BCWl4s7t.mjs';
import { $ as $$Banner } from '../chunks/banner_H9CF1t-5.mjs';
import { $ as $$Script, a as $$ArticlesList, b as $$Follower } from '../chunks/script_qZKg_BHr.mjs';
import { $ as $$Video } from '../chunks/video_BBk1Z40B.mjs';
import { a as $$Card } from '../chunks/card_DzFjrCx_.mjs';
import '../chunks/index.320e173d_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業(1)", value: "tech-manufacturing", name: "industry", checked: false },
  { label: "零售與電商產業(5)", value: "retail-ecommerce", name: "industry", checked: false },
  { label: "餐飲與連鎖服務產業(2)", value: "food-service", name: "industry", checked: false },
  { label: "醫療與照護產業(2)", value: "healthcare", name: "industry", checked: false },
  { label: "教育與訓練產業(1)", value: "education", name: "industry", checked: false },
  { label: "建築與工程產業(1)", value: "construction", name: "industry", checked: false },
  { label: "旅宿與觀光產業(1)", value: "hospitality", name: "industry", checked: false },
  { label: "顧問服務產業(1)", value: "consulting", name: "industry", checked: false }
];
const child2 = [
  { label: "微型（1-10人）", value: "micro", name: "size", checked: false },
  { label: "小型（10-49人）", value: "small", name: "size", checked: false },
  { label: "中型（50-199人）", value: "medium", name: "size", checked: false },
  { label: "大型（200 人-500人）", value: "large", name: "size", checked: false },
  { label: "巨型（500人以上）", value: "enterprise", name: "size", checked: false }
];
const data = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  },
  {
    title: "主題類別",
    show: true,
    children: child2
  }
];

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Solution", "footerPages": ["\u89E3\u6C7A\u65B9\u6848"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "solutions-banner", "title": "\u89E3\u6C7A\u65B9\u6848", "mode": "dark" })}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "SolutionList", "title": "\u89E3\u6C7A\u65B9\u6848", "total": 10, "sortDate": [
    { text: "\u65B0\u4E0A\u5E02", value: "0" },
    { text: "\u89E3\u6C7A\u65B9\u6848", value: "1" }
  ], "category": data, "mode": "white" }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "link": `/solution/${index}`, "showPlayBack": index % 2 === 0 })}`)}` })}
    ${renderComponent($$result2, "Follower", $$Follower, {})}
` })}
${renderComponent($$result, "Script", $$Script, {})}
${renderComponent($$result, "Video", $$Video, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/solution/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/solution/index.astro";
const $$url = "/solution.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
