/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, b as addAttribute, s as spreadAttributes } from '../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$A, c as $$Link, b as $$Layouts } from '../chunks/layouts_Dei3z7tc.mjs';
import { $ as $$Picture, a as $$Banner } from '../chunks/banner_FomqbfBt.mjs';
import { $ as $$Script, a as $$ArticlesList, b as $$Follower } from '../chunks/script_Bhm660Hu.mjs';
import '../chunks/solution.9fe3e457_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業(1)", value: "tech-manufacturing", name: "industry", checked: false },
  { label: "零售與電商產業(5)", value: "retail-ecommerce", name: "industry", checked: false },
  { label: "餐飲與連鎖服務產業(2)", value: "food-service", name: "industry", checked: false },
  { label: "醫療與照護產業(2)", value: "healthcare", name: "industry", checked: false },
  { label: "教育與訓練產業(1)", value: "education", name: "industry", checked: false },
  { label: "建築與工程產業(1)", value: "construction", name: "industry", checked: false },
  { label: "旅宿與觀光產業(1)", value: "hospitality", name: "industry", checked: false },
  { label: "顧問服務產業(1)", value: "consulting", name: "industry", checked: false }
];
const child2 = [
  { label: "微型（1-10人）", value: "micro", name: "size", checked: false },
  { label: "小型（10-49人）", value: "small", name: "size", checked: false },
  { label: "中型（50-199人）", value: "medium", name: "size", checked: false },
  { label: "大型（200 人-500人）", value: "large", name: "size", checked: false },
  { label: "巨型（500人以上）", value: "enterprise", name: "size", checked: false }
];
const data = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  },
  {
    title: "主題類別",
    show: true,
    children: child2
  }
];

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$PlayBack = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$PlayBack;
  const { IDName, className, style, attribute = {}, Tag = "button", size = "48" } = Astro2.props;
  const cardClass = [
    "play-back",
    { "play-back-48": size === "48" },
    { "play-back-32": size === "32" },
    className
  ];
  const cardStyle = (size2) => {
    const data = {
      "48": {
        "--icon-width": "1.2rem",
        "--icon-height": "1.05rem",
        ...style
      },
      "32": {
        "--icon-width": "0.875rem",
        "--icon-height": "0.75rem",
        ...style
      }
    };
    return data[size2];
  };
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "id": IDName, "type": Tag === "button" ? "button" : void 0, "class:list": [cardClass], "style": cardStyle(size), "title": "play-back", "aria-label": "play-back", ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg${addAttribute([
    "play-back-icon",
    { "play-back-icon-48": size === "48" },
    { "play-back-icon-32": size === "32" }
  ], "class:list")} width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M15.2804 8.00913C15.9522 8.39302 15.9522 9.36172 15.2804 9.74561L1.49594 17.6224C0.829283 18.0034 -0.000195347 17.522 -0.000195313 16.7542L-0.000194625 1.00052C-0.000194591 0.232701 0.829288 -0.248665 1.49594 0.132283L15.2804 8.00913Z" fill="var(--color-white, #fff)"></path>
    </svg>
    <svg${addAttribute([
    "play-back-pause-icon",
    { "play-pause-back-icon-48": size === "48" },
    { "play-pause-back-icon-32": size === "32" }
  ], "class:list")} width="15" height="20" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="0.6" y="0.6" width="1.2" height="18" rx="0.6" fill="white" stroke="white" stroke-width="1.2"></rect>
        <rect x="12.6" y="0.6" width="1.2" height="18" rx="0.6" fill="white" stroke="white" stroke-width="1.2"></rect>
    </svg>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/playBack/playBack.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Card = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Card;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title = "iShops - \u958B\u5E97\u5E73\u53F0\uFF01",
    breif = "\u4E00\u7AD9\u5F0F\u958B\u5E97\u5E73\u53F0\uFF0C\u5168\u9762\u5F37\u5316\u60A8\u7684\u5546\u696D\u904B\u71DF\uFF0C\u589E\u52A0\u4F01\u696D\u71DF\u6536\uFF0C\u8B93\u4F01\u696D\u8B8A\u5F97\u66F4\u597D\uFF0C\u4EFF\u9020IG\u7684\u9650\u6642\u52D5\u614B\u98A8\u683C\u3002",
    logoImage = "/assets/logos/Business-Vertical-Light",
    img = "/assets/images/pages/solutions-bg-1",
    link = "",
    width = "100%",
    showPlayBack = true,
    // 響應式圖片斷點設定，依照不同螢幕尺寸載入對應圖片
    // 支援多種像素密度 (1x, 1.5x, 2x) 提供更清晰的顯示效果
    imgBreakpoints = [
      {
        width: 1280,
        // 桌面版斷點 (1280px+)
        img: "/assets/images/pages/solutions-bg-1",
        // 向後相容的預設圖片
        densities: {
          "1x": "/assets/images/pages/solutions-bg-1",
          // 標準解析度
          "1.5x": "/assets/images/pages/solutions-bg-1",
          // 1.5倍解析度
          "2x": "/assets/images/pages/solutions-bg-1"
          // 2倍解析度（高解析度螢幕）
        }
      },
      {
        width: 731,
        // 平板版斷點 (731px-1279px)
        img: "/assets/images/pages/solutions-bg-1",
        densities: {
          "1x": "/assets/images/pages/solutions-bg-1",
          "1.5x": "/assets/images/pages/solutions-bg-1",
          "2x": "/assets/images/pages/solutions-bg-1"
        }
      },
      {
        width: 0,
        // 手機版斷點 (730px 以下)
        img: "/assets/images/pages/solutions-bg-1",
        densities: {
          "1x": "/assets/images/pages/solutions-bg-1",
          "1.5x": "/assets/images/pages/solutions-bg-1",
          "2x": "/assets/images/pages/solutions-bg-1"
        }
      }
    ]
  } = Astro2.props;
  const cardStyle = {
    ...width ? { "--card-width": (!isNaN(width) ? `${parseFloat(width) / 16}rem` : width).toString() } : {},
    ...style
  };
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "solutions-card group"
  ], "class:list")}${addAttribute(cardStyle, "style")}${spreadAttributes(attribute)}>
    <div class="solutions-card-image-container">
        ${renderComponent($$result, "Picture", $$Picture, { "img": img, "className": "solutions-card-image", "alt": title, "loading": "lazy", "decoding": "async", "breakpoints": imgBreakpoints, "noWebp": true })}
        ${showPlayBack && renderTemplate`<div class="solutions-card-play-back">
                    ${renderComponent($$result, "PlayBack", $$PlayBack, { "size": "48" })}
                </div>`}
    </div>
    <div class="solutions-card-content">
        <div class="solutions-card-head">
            ${title && renderTemplate`${renderComponent($$result, "A", $$A, { "link": link, "title": title }, { "default": ($$result2) => renderTemplate`
                        <strong class="solutions-card-title">
                            ${title}
                        </strong>
                    ` })}`}
            ${breif && renderTemplate`<span class="solutions-card-breif">
                        ${breif}
                    </span>`}
        </div>
        <div class="solutions-card-footer">
            <div class="solutions-card-logo">
                ${renderComponent($$result, "Picture", $$Picture, { "img": logoImage, "alt": title, "type": "svg", "loading": "lazy", "decoding": "async", "noWebp": true })}
            </div>
            ${renderComponent($$result, "ALink", $$Link, { "link": link, "className": "solutions-card-link", "title": "\u4E86\u89E3\u66F4\u591A", "size": "16", "showArrow": true })}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/card.astro", void 0);

const $$Solution = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Solution" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "solutions-banner", "title": "\u89E3\u6C7A\u65B9\u6848", "mode": "dark" })}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "SolutionList", "title": "\u89E3\u6C7A\u65B9\u6848", "total": 10, "sortDate": [
    { text: "\u65B0\u4E0A\u5E02", value: "0" },
    { text: "\u89E3\u6C7A\u65B9\u6848", value: "1" }
  ], "category": data, "mode": "white" }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "showPlayBack": index % 2 === 0 })}`)}` })}
    ${renderComponent($$result2, "Follower", $$Follower, {})}
` })}
${renderComponent($$result, "Script", $$Script, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/solution.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/solution.astro";
const $$url = "/solution.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Solution,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
