/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Bjgbv9en.mjs';
import { b as $$Input, c as $$Link, $ as $$Button, d as $$A, a as $$Layouts } from '../chunks/layouts_PrzpUuZP.mjs';
import { $ as $$Form$1 } from '../chunks/form_PYguvSQ8.mjs';
import { $ as $$Divider } from '../chunks/divider_DuqZ0zu6.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_rL2IGu0B.mjs';
import { $ as $$PasswordInput } from '../chunks/passwordInput_8K1tyx1k.mjs';
import { $ as $$Checkbox } from '../chunks/checkbox_i_-Rm7pJ.mjs';
import { $ as $$SocialIcon } from '../chunks/SocialIcon_6ODmP4Ig.mjs';
import '../chunks/login.457bebb1_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "id": IDName, "title": "\u6703\u54E1\u767B\u5165", "class:list": [className], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u5E33\u865F", "infoText": "\u8ACB\u8F38\u5165\u96FB\u5B50\u90F5\u4EF6", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "type": "email", "inputmode": "email" })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u5BC6\u78BC", "block": true, "style": { "--form-input-group-content-gap": "0.75rem" } }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "PasswordInput", $$PasswordInput, {})}
        ${maybeRenderHead()}<div class="auth-check">
            ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`記住我` })}
            ${renderComponent($$result3, "ALink", $$Link, { "link": "/forget-password", "title": "\u5FD8\u8A18\u5BC6\u78BC\uFF1F" }, { "default": ($$result4) => renderTemplate`忘記密碼？` })}
        </div>
    ` })}
    ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`登入` })}
    <div class="auth-check-login">
        <span class="auth-check-login-label">尚未註冊會員?</span>
        ${renderComponent($$result2, "ALink", $$Link, { "link": "/register", "title": "\u7ACB\u5373\u8A3B\u518A" }, { "default": ($$result3) => renderTemplate`立即註冊` })}
    </div>
    ${renderComponent($$result2, "Divider", $$Divider, {}, { "default": ($$result3) => renderTemplate`或選擇其他方式登入` })}
    <div class="auth-other">
        ${renderComponent($$result2, "A", $$A, { "link": "", "className": "auth-other-Link", "title": "Google \u767B\u5165", "extend": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "SocialIcon", $$SocialIcon, { "type": "icon_google", "size": "lg" })}
        ` })}
        ${renderComponent($$result2, "A", $$A, { "link": "", "className": "auth-other-Link", "title": "Microsof \u767B\u5165", "extend": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "SocialIcon", $$SocialIcon, { "type": "icon_microsoft", "size": "lg" })}
        ` })}
    </div>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/login/form.astro", void 0);

const $$Login = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Login", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/login.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/login.astro";
const $$url = "/login.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Login,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
