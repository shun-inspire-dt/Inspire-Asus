/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, e as defineScriptVars } from '../chunks/astro/server_v5wg8FJS.mjs';
import { b as $$Input, c as $$Link, $ as $$Button, a as $$Layouts } from '../chunks/layouts_Ca0YPUcq.mjs';
import { $ as $$ComfirmCode } from '../chunks/comfirm-code_LysRW5oY.mjs';
import { $ as $$ScriptNext, a as $$Cookies, b as $$FetchWithAuth } from '../chunks/fetchWithAuth.copy_DZrASHv9.mjs';
import { $ as $$Form$1 } from '../chunks/form_CPN2Wti_.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_DI5El5nt.mjs';
import { $ as $$Textarea } from '../chunks/textarea_BoNmgoBZ.mjs';
import { $ as $$CheckboxGroup, a as $$ErrorText } from '../chunks/errorText_D1__1s5d.mjs';
import { $ as $$Checkbox } from '../chunks/checkbox_BvKLdD__.mjs';
import '../chunks/contactus.a1ed11f5_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "Contactus", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "type": 2, "title": "\u806F\u7D61\u6211\u5011", "style": style, "className": ["needs-validation", className], "attribute": {
    novalidate: "",
    "data-needs-loading": "true",
    "data-report-validity": "false",
    "data-invalid-scrolling": "true",
    "data-scroll-offset": "20",
    ...attribute
  } }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "name", "label": "\u806F\u7D61\u4EBA\u59D3\u540D", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "id": "name", "name": "name", "required": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "companyName", "label": "\u516C\u53F8\u540D\u7A31", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "id": "companyName", "name": "companyName", "required": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "position", "label": "\u8077\u7A31", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "id": "position", "name": "position", "required": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "email", "label": "\u516C\u53F8\u96FB\u5B50\u90F5\u4EF6", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "id": "email", "name": "email", "type": "email", "inputmode": "email", "autocomplete": "email", "required": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "tel", "label": "\u516C\u53F8\u96FB\u8A71", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "id": "tel", "name": "tel", "type": "tel", "inputmode": "tel", "required": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "comment", "label": "\u6211\u5011\u53EF\u4EE5\u5982\u4F55\u5354\u52A9\u60A8\uFF1F", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Textarea", $$Textarea, { "id": "comment", "name": "comment" })}
    ` })}
    ${renderComponent($$result2, "CheckboxGroup", $$CheckboxGroup, { "showTop": false }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Checkbox", $$Checkbox, { "required": true }, { "default": ($$result4) => renderTemplate`
            我同意華碩及華碩授權經銷商，透過上述表單所提供的電話/電子郵件與我聯繫，限用於商業用途和報價，並同意 "${renderComponent($$result4, "ALink", $$Link, { "link": "https://asusexperthub.com/service/terms", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`使用者條款` })}"
        ` })}
        ${renderComponent($$result3, "CheckboxErrorText", $$ErrorText, { "error": true })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, { "required": true }, { "default": ($$result4) => renderTemplate`
            我同意提供上述資訊給華碩，用以接收華碩新聞、活動、最新產品和服務信息等相關資訊，並同意 "${renderComponent($$result4, "ALink", $$Link, { "link": "https://asusexperthub.com/service/privacy", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`隱私權條款` })}"
        ` })}
        ${renderComponent($$result3, "CheckboxErrorText", $$ErrorText, { "error": true })}
    ` })}
    ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`送出` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/contactus/form.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$ScriptInline = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["<script>(function(){", `
    const authClient = new AuthClient({ baseURL, cookies });
    const Fetch = authClient.fetchWithAuth.bind(authClient);
    /** ---------- 實作 ---------- */
    // 全局 Toast 實例
    const toastEl = document.getElementById('toastModal');

    /**
     * API 請求封裝
     * @description 統一處理此頁面所需的 API 呼叫與 headers 設定
     */
    class API {
        headers = new Headers({
            'Content-Type': 'application/json',
            Authorization: \`Bearer \${authClient.cookies.get('access_token')}\`
        });

        /**
         * 範例 API（目前用於 demo）
         * @param {Record<string, any>} data - 表單送出時整理出的資料
         * @returns {Promise<{success: boolean, message?: string}>} API 回應
         */
        exampleAPI = async (data) => {
            console.log('data', data);
            const requestOptions = {
                method: 'GET',
                headers: this.headers
            };

            return await Fetch(baseURL + '/api/form/example-success', requestOptions)
                .then((response) => response.json())
                .then((result) => result)
                .catch((error) => {
                    console.error('Error:', error);
                    return { success: false, message: error.message || '失敗' };
                });
        };
    }

    /**
     * 聯絡我們表單流程
     * @description 綁定表單驗證、組裝表單資料並呼叫 API，最後用 Toast 顯示結果
     */
    class Form extends API {
        form = document.querySelector('#ContactusForm');

        /**
         * 初始化
         * @description 建立實例後立即綁定事件
         */
        constructor() {
            super();
            this.bindEvents();
        }

        /**
         * 建立表單驗證器
         * @description 使用 FormValidator 綁定 submit 驗證與 onValidSubmit 行為
         * @returns {FormValidator}
         */
        validator = () =>
            new FormValidator(this.form, {
                onValidSubmit: async ({ controls }) => {
                    /**
                     *  Form Data 資料會如下：
                     *  const formDataExample = {
                     *      companyName: "123123"
                     *      email: "122@gmail.com"
                     *      position: "12331"
                     *      name: "12323"
                     *      tel: "0912345678"
                     *      comment: "123123"
                     *  }; 
                    */
                    /**
                     * 組裝送出資料
                     * @param {Record<string, HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>} controls - 表單控制項集合
                     * @returns {Record<string, string>} 以 input 的 id 為 key、value 為值的物件
                     */
                    const formData = (controls) => {
                        const formData = {};
                        Object.entries(controls || {}).forEach(([key, el]) => {
                            if (!key || !el) return;
                            if (key.includes('checkbox')) return;
                            formData[key] = el.value;
                        });
                        return formData;
                    };
                    try {
                        const response = await this.exampleAPI(formData(controls));
                        if (response.success) {
                            toastEl.dispatchEvent(
                                new CustomEvent('fire', {
                                    detail: {
                                        icon: 'success',
                                        title: '表單已送出',
                                        text: '謝謝詢問，我們會透過Email或電話與您聯繫',
                                        link: {
                                            primaryText: '回首頁',
                                            primaryLink: '/',
                                            primaryVariant: 'blue'
                                        },
                                        hidePrevented: true
                                    }
                                })
                            );
                        } else {
                            toastEl.dispatchEvent(
                                new CustomEvent('fire', {
                                    detail: {
                                        icon: 'error',
                                        title: response.message || '失敗'
                                    }
                                })
                            );
                        }
                    } catch (error) {
                        console.error('Error From Submit:', error);
                        toastEl.dispatchEvent(
                            new CustomEvent('fire', {
                                detail: {
                                    icon: 'error',
                                    title: error.message || '失敗'
                                }
                            })
                        );
                    }
                }
            });
        /**
         * 綁定所有事件監聽器
         * @description 為各個 Form 和 Modal 綁定相應的事件處理器
         */
        bindEvents = () => {
            this.validator && this.validator();
        };
    }

    // 等待 DOM 加載完成後初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new Form());
    } else {
        new Form();
    }
})();</script>`], ["<script>(function(){", `
    const authClient = new AuthClient({ baseURL, cookies });
    const Fetch = authClient.fetchWithAuth.bind(authClient);
    /** ---------- 實作 ---------- */
    // 全局 Toast 實例
    const toastEl = document.getElementById('toastModal');

    /**
     * API 請求封裝
     * @description 統一處理此頁面所需的 API 呼叫與 headers 設定
     */
    class API {
        headers = new Headers({
            'Content-Type': 'application/json',
            Authorization: \\\`Bearer \\\${authClient.cookies.get('access_token')}\\\`
        });

        /**
         * 範例 API（目前用於 demo）
         * @param {Record<string, any>} data - 表單送出時整理出的資料
         * @returns {Promise<{success: boolean, message?: string}>} API 回應
         */
        exampleAPI = async (data) => {
            console.log('data', data);
            const requestOptions = {
                method: 'GET',
                headers: this.headers
            };

            return await Fetch(baseURL + '/api/form/example-success', requestOptions)
                .then((response) => response.json())
                .then((result) => result)
                .catch((error) => {
                    console.error('Error:', error);
                    return { success: false, message: error.message || '失敗' };
                });
        };
    }

    /**
     * 聯絡我們表單流程
     * @description 綁定表單驗證、組裝表單資料並呼叫 API，最後用 Toast 顯示結果
     */
    class Form extends API {
        form = document.querySelector('#ContactusForm');

        /**
         * 初始化
         * @description 建立實例後立即綁定事件
         */
        constructor() {
            super();
            this.bindEvents();
        }

        /**
         * 建立表單驗證器
         * @description 使用 FormValidator 綁定 submit 驗證與 onValidSubmit 行為
         * @returns {FormValidator}
         */
        validator = () =>
            new FormValidator(this.form, {
                onValidSubmit: async ({ controls }) => {
                    /**
                     *  Form Data 資料會如下：
                     *  const formDataExample = {
                     *      companyName: "123123"
                     *      email: "122@gmail.com"
                     *      position: "12331"
                     *      name: "12323"
                     *      tel: "0912345678"
                     *      comment: "123123"
                     *  }; 
                    */
                    /**
                     * 組裝送出資料
                     * @param {Record<string, HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>} controls - 表單控制項集合
                     * @returns {Record<string, string>} 以 input 的 id 為 key、value 為值的物件
                     */
                    const formData = (controls) => {
                        const formData = {};
                        Object.entries(controls || {}).forEach(([key, el]) => {
                            if (!key || !el) return;
                            if (key.includes('checkbox')) return;
                            formData[key] = el.value;
                        });
                        return formData;
                    };
                    try {
                        const response = await this.exampleAPI(formData(controls));
                        if (response.success) {
                            toastEl.dispatchEvent(
                                new CustomEvent('fire', {
                                    detail: {
                                        icon: 'success',
                                        title: '表單已送出',
                                        text: '謝謝詢問，我們會透過Email或電話與您聯繫',
                                        link: {
                                            primaryText: '回首頁',
                                            primaryLink: '/',
                                            primaryVariant: 'blue'
                                        },
                                        hidePrevented: true
                                    }
                                })
                            );
                        } else {
                            toastEl.dispatchEvent(
                                new CustomEvent('fire', {
                                    detail: {
                                        icon: 'error',
                                        title: response.message || '失敗'
                                    }
                                })
                            );
                        }
                    } catch (error) {
                        console.error('Error From Submit:', error);
                        toastEl.dispatchEvent(
                            new CustomEvent('fire', {
                                detail: {
                                    icon: 'error',
                                    title: error.message || '失敗'
                                }
                            })
                        );
                    }
                }
            });
        /**
         * 綁定所有事件監聽器
         * @description 為各個 Form 和 Modal 綁定相應的事件處理器
         */
        bindEvents = () => {
            this.validator && this.validator();
        };
    }

    // 等待 DOM 加載完成後初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new Form());
    } else {
        new Form();
    }
})();</script>`])), defineScriptVars({ baseURL: "https://shun-fast-api.zeabur.app" }));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/contactus/script-inline.astro", void 0);

const $$Contactus = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Contactus", "minMarginHeader": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}
${renderComponent($$result, "ComfirmCode", $$ComfirmCode, {})}
${renderComponent($$result, "ScriptNext", $$ScriptNext, {})}
${renderComponent($$result, "CookiesScript", $$Cookies, {})}
${renderComponent($$result, "FetchWithAuthScript", $$FetchWithAuth, {})}
${renderComponent($$result, "ScriptInline", $$ScriptInline, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/contactus.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/contactus.astro";
const $$url = "/contactus.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Contactus,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
