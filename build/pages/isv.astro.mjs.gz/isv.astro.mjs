/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_Bjgbv9en.mjs';
import { b as $$Input, c as $$Link, $ as $$Button, a as $$Layouts } from '../chunks/layouts_Cd0HYti7.mjs';
import { $ as $$Form$1 } from '../chunks/form_C8aySGCo.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_BrhXy4F4.mjs';
import { $ as $$Select } from '../chunks/select_DiDoX0Kg.mjs';
import { $ as $$CheckboxGroup } from '../chunks/checkboxGroup_DTdft3wi.mjs';
import { $ as $$Checkbox } from '../chunks/checkbox_E_e1IGFv.mjs';
import '../chunks/isv.41ea09ab_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "Isv", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "type": 2, "title": "\u6210\u70BA ISV \u5925\u4F34", "IDName": IDName, "class:list": [className], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u7522\u696D\u985E\u5225", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Select", $$Select, { "data": [
    { text: "\u96F2\u7AEF\u8207\u57FA\u790E\u8A2D\u65BD", value: "\u96F2\u7AEF\u8207\u57FA\u790E\u8A2D\u65BD" },
    { text: "\u4F01\u696D\u61C9\u7528", value: "\u4F01\u696D\u61C9\u7528" },
    { text: "\u8CC7\u6599\u4E2D\u5FC3", value: "\u8CC7\u6599\u4E2D\u5FC3" },
    { text: "\u5132\u5B58", value: "\u5132\u5B58" },
    { text: "\u5B89\u5168", value: "\u5B89\u5168" },
    { text: "\u5132\u5B58", value: "\u5132\u5B58" }
  ], "value": "\u96F2\u7AEF\u8207\u57FA\u790E\u8A2D\u65BD" })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u806F\u7D61\u4EBA\u59D3\u540D", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, {})}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u540D\u7A31", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, {})}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u8077\u7A31", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, {})}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u96FB\u5B50\u90F5\u4EF6", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "type": "email", "inputmode": "email" })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u96FB\u8A71", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "type": "tel", "inputmode": "tel" })}
    ` })}
    ${renderComponent($$result2, "CheckboxGroup", $$CheckboxGroup, { "showTop": false }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`
            我同意華碩及華碩授權經銷商，透過上述表單所提供的電話/電子郵件與我聯繫，限用於商業用途和報價，並同意 "${renderComponent($$result4, "ALink", $$Link, { "link": "", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`隱私權條款` })}"
        ` })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`
            我同意提供上述資訊給華碩，用以接收華碩新聞、活動、最新產品和服務信息等相關資訊，並同意 "${renderComponent($$result4, "ALink", $$Link, { "link": "", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`隱私權條款` })}"
        ` })}
    ` })}
    ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "size": "lg", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`送出` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/isv/form.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Isv = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["", "\n\n<script>\n    const toast = document.querySelector('#toastModal');\n    const form = document.querySelector('#IsvForm');\n\n    form.addEventListener('submit', (e) => {\n        e.preventDefault();\n        toast.dispatchEvent(\n            new CustomEvent('fire', {\n                detail: {\n                    icon: 'success',\n                    title: '\u8868\u55AE\u5DF2\u9001\u51FA',\n                    text: '\u8B1D\u8B1D\u8A62\u554F\uFF0C\u6211\u5011\u6703\u900F\u904EEmail\u6216\u96FB\u8A71\u8207\u60A8\u806F\u7E6B',\n                    link: {\n                        primaryText: '\u56DE\u9996\u9801',\n                        primaryLink: '/',\n                        primaryVariant: 'blue'\n                    },\n                    hidePrevented: true\n                }\n            })\n        );\n    });\n<\/script>"])), renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Isv", "minMarginHeader": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` }));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/isv.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/isv.astro";
const $$url = "/isv.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Isv,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
