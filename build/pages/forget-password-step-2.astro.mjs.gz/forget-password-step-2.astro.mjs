/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Button, a as $$Layouts } from '../chunks/layouts_DtGmLo_d.mjs';
import { $ as $$Form$1 } from '../chunks/form_DDRaYkw9.mjs';
import '../chunks/forget-password-step-2.41897f34_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "className": ["step-2-form-container", className], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M56 30C56 35.1423 54.4751 40.1691 51.6182 44.4448C48.7613 48.7205 44.7007 52.053 39.9498 54.0209C35.1989 55.9887 29.9712 56.5036 24.9277 55.5004C19.8842 54.4972 15.2514 52.0209 11.6152 48.3848C7.97907 44.7486 5.50281 40.1158 4.49959 35.0723C3.49638 30.0288 4.01127 24.8011 5.97914 20.0502C7.94702 15.2993 11.2795 11.2387 15.5552 8.38179C19.8309 5.52487 24.8577 4 30 4C33.4144 4 36.7953 4.67251 39.9498 5.97913C43.1042 7.28575 45.9705 9.2009 48.3848 11.6152C50.7991 14.0295 52.7142 16.8958 54.0209 20.0502C55.3275 23.2047 56 26.5856 56 30Z" fill="var(--color-green-600, #1A821C)"></path>
        <path d="M18 31.4762L26.6957 41L43 21" stroke="white" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
    <div class="step-2-head">
        <h2 class="step-2-title">密碼重設成功，請重新登入</h2>
    </div>
    ${renderComponent($$result2, "Button", $$Button, { "Tag": "a", "link": "/", "title": "\u91CD\u65B0\u767B\u5165", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`重新登入` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/forget-password-step-2/form.astro", void 0);

const $$ForgetPasswordStep2 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Forget-password-step-2", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/forget-password-step-2.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/forget-password-step-2.astro";
const $$url = "/forget-password-step-2.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$ForgetPasswordStep2,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
