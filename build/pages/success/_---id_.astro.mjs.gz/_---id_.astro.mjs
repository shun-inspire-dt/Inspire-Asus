/* empty css                                      */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, b as addAttribute, s as spreadAttributes } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { a as $$Layouts } from '../../chunks/layouts_CNnjnwpD.mjs';
import { $ as $$Relative$1, a as $$Relative$2 } from '../../chunks/relative_CjIcMPCj.mjs';
import { C as Content } from '../../chunks/content_LlPOr_hm.mjs';
import { $ as $$Article$1 } from '../../chunks/article_B6_Jg573.mjs';
import '../../chunks/_id_.5edb11ba_l0sNRNKZ.mjs';
import { $ as $$Card$1 } from '../../chunks/card_C630H2uv.mjs';
import { a as $$Card } from '../../chunks/card_C6mm8oVb.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Article = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Article;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MyArticle", $$Article$1, { "title": "\u83EF\u78A9 AI \u5546\u7528\u7B46\u96FB\uFF0C\u8CE6\u80FD\u53F0\u5317\u6CD5\u570B\u5BE6\u9A57\u6559\u80B2\u6A5F\u69CBLIFT\uFF0C\u958B\u5275\u5B78\u751F\u6C38\u7E8C\u5B78\u7FD2\u529B", "date": "2025/11/12", "buttonText": "\u56DE\u6210\u529F\u6848\u4F8B\u7E3D\u89BD\u9801", "buttonLink": "/success", "html": Content, "IDName": IDName, "className": ["success-article", className], "style": style, "attribute": attribute })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/success/[id]/article.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Relative = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Relative;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "MyRelative", $$Relative$1, { "IDName": "SolutionsRelative", "title": "\u76F8\u95DC\u65B9\u6848", "className": "solutions-section-relative", "type": 2, "count": 12 }, { "default": ($$result2) => renderTemplate`
        ${renderComponent($$result2, "SolutionsCard", $$Card, { "link": "/solutions/0", "showPlayBack": false })}
    ` })}
    ${renderComponent($$result, "MyRelative", $$Relative$1, { "IDName": "SuccessRelative", "title": "\u6210\u529F\u6848\u4F8B", "className": "success-section-relative", "count": 12 }, { "default": ($$result2) => renderTemplate`
        ${renderComponent($$result2, "NewsCard", $$Card$1, { "link": "/success/0", "showBreif": false })}
    ` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/success/[id]/relative.astro", void 0);

const $$Astro = createAstro("https://www.Asus.com.tw");
async function getStaticPaths() {
  return Array.from({ length: 10 }).map((_, index) => ({ params: { id: index } }));
}
const prerender = true;
const $$ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const { id } = Astro2.params;
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "SuccessDetail", "footerPages": ["\u6210\u529F\u6848\u4F8B"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Article", $$Article, {})}
    ${renderComponent($$result2, "Relative", $$Relative, {})}
` })}
${renderComponent($$result, "Script", $$Relative$2, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/success/[...id].astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/success/[...id].astro";
const $$url = "/success/[...id].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$,
    file: $$file,
    getStaticPaths,
    prerender,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
