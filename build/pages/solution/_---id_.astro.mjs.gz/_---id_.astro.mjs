/* empty css                                      */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate, F as Fragment, e as renderSlot } from '../../chunks/astro/server_Bjgbv9en.mjs';
import { j as $$Collapse, $ as $$Button, a as $$Layouts } from '../../chunks/layouts_k9LlQnqK.mjs';
import { $ as $$Relative$1, a as $$Relative$2 } from '../../chunks/relative_DW9HG5a4.mjs';
import { $ as $$Video } from '../../chunks/video_DPuns7Ed.mjs';
import { $ as $$Swiper } from '../../chunks/navigatiorArrow_C2-jrvGz.mjs';
import { $ as $$Picture } from '../../chunks/picture_GYxijd3h.mjs';
import { $ as $$Badge, a as $$PaginationArrow } from '../../chunks/paginationArrow_Cu6rjPMr.mjs';
import { $ as $$PlayBack, a as $$Card } from '../../chunks/card_BfZL5nam.mjs';
/* empty css                                   */
import { $ as $$NotificationIcon } from '../../chunks/notificationIcon_Dzg8kcFt.mjs';
import { $ as $$Title } from '../../chunks/title_oZPX-wc9.mjs';
import { $ as $$Card$1 } from '../../chunks/card_Bp4VRxVU.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro$d = createAstro("https://www.Asus.com.tw");
const $$Head = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$d, $$props, $$slots);
  Astro2.self = $$Head;
  const {
    IDName,
    className,
    style,
    attribute = {},
    subtitle = "\u6B23\u5275\u6578\u4F4D\u79D1\u6280\u6709\u9650\u516C\u53F8",
    title = "\u667A\u6167\u63A1\u8CFC\u53EB\u8CA8\u7CFB\u7D71",
    badges = ["\u79D1\u6280\u8207\u88FD\u9020\u7522\u696D", "\u96F6\u552E\u8207\u96FB\u5546\u7522\u696D"]
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "solutions-header"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <div class="solutions-head">
        <strong class="solutions-sub-title">${subtitle}</strong>
        <h1 class="solutions-title">${title}</h1>
    </div>
    <div class="solutions-tags">
        ${badges.map((x) => renderTemplate`${renderComponent($$result, "Badge", $$Badge, { "Tag": "a", "attribute": { href: Astro2.url.href, title }, "status": "link" }, { "default": ($$result2) => renderTemplate`${x}` })}`)}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/head.astro", void 0);

const $$Astro$c = createAstro("https://www.Asus.com.tw");
const $$Left = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$c, $$props, $$slots);
  Astro2.self = $$Left;
  const { IDName = "ProductsSwipers", className, style, attribute = {}, title, images } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Head", $$Head, { "className": "solutions-left-head" })}
${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Swiper", $$Swiper, { "IDName": "ProductsMain" }, { "default": ($$result2) => renderTemplate`${images.map((x, i) => renderTemplate`<div class="swiper-slide" data-toggle="video">
                    ${i === 5 && renderTemplate`<div class="solutions-card-video">
                            ${renderComponent($$result2, "PlayBack", $$PlayBack, { "size": "48", "attribute": {
    title,
    "data-toggle": "video",
    "data-bs-toggle": "modal",
    "data-bs-target": "#VideoModal",
    "data-auto": "false"
  } })}
                        </div>`}
                    ${renderComponent($$result2, "Picture", $$Picture, { "img": x, "width": 610, "height": 610, "type": "png", "alt": title, "noWebp": true })}
                </div>`)}` })}
    ${renderComponent($$result, "Swiper", $$Swiper, { "IDName": "ProductsThumb" }, { "default": ($$result2) => renderTemplate`${images.map((x, i) => renderTemplate`<div class="swiper-slide">
                    ${i === 5 && renderTemplate`<div class="solutions-card-video">
                            ${renderComponent($$result2, "PlayBack", $$PlayBack, { "size": "32", "attribute": {
    title,
    "data-toggle": "video",
    "data-bs-toggle": "modal",
    "data-bs-target": "#VideoModal",
    "data-auto": "false"
  } })}
                        </div>`}
                    ${renderComponent($$result2, "Picture", $$Picture, { "img": x, "width": 80, "height": 80, "type": "png", "alt": title, "noWebp": true })}
                </div>`)}
        
    `, "outspace": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outspace" }, { "default": ($$result3) => renderTemplate`
            <button type="button" data-direction="next">
                ${renderComponent($$result3, "PaginationArrow", $$PaginationArrow, { "direction": "right", "size": "16" })}
            </button>
        ` })}`, "outspace-left": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outspace-left" }, { "default": ($$result3) => renderTemplate`
            <button type="button" data-direction="prev">
                ${renderComponent($$result3, "PaginationArrow", $$PaginationArrow, { "direction": "left", "size": "16" })}
            </button>
        ` })}` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/left.astro", void 0);

const $$Astro$b = createAstro("https://www.Asus.com.tw");
const $$ChoiceButton = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$b, $$props, $$slots);
  Astro2.self = $$ChoiceButton;
  const {
    id,
    className,
    inputClassName,
    labelClassName,
    type = "checkbox",
    name,
    title,
    value,
    checked,
    required,
    disabled,
    readonly,
    attribute = {},
    inputAttribute = {},
    aria = {},
    inputAria = {}
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(id ? `${id}FromChoiceButton` : void 0, "id")}${addAttribute(["form-choice-button", className], "class:list")}${addAttribute(name, "data-name")}${spreadAttributes(attribute)}${spreadAttributes(aria)}>
    <input${addAttribute(id, "id")}${addAttribute(["btn-choice", inputClassName], "class:list")}${addAttribute(type, "type")}${addAttribute(name, "name")}${addAttribute(value, "value")}${addAttribute(checked, "checked")}${addAttribute(readonly, "readonly")}${addAttribute(disabled, "disabled")}${addAttribute(required, "required")} autocomplete="off"${addAttribute(title, "aria-label")}${spreadAttributes(inputAttribute)}${spreadAttributes(inputAria)}>
    <label${addAttribute(["btn-choice-label", labelClassName], "class:list")}${addAttribute(id, "for")}>
        ${renderSlot($$result, $$slots["default"])}
    </label>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/form/checkboxs/choiceButton.astro", void 0);

const $$Astro$a = createAstro("https://www.Asus.com.tw");
const $$ProductConfig = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$ProductConfig;
  const {
    IDName,
    className,
    style,
    attribute = {},
    title,
    price,
    variant,
    priceDescription,
    optionHint,
    showColorSelector,
    showNotificationIcon,
    showPriceTag = true,
    showPriceDescription,
    showOptionHint,
    disabled,
    value
  } = Astro2.props;
  const id = `FromProductConfig-${Math.floor(Math.random() * 1e3)}`;
  const variantAttr = variant ? { "data-variant": variant } : {};
  return renderTemplate`${renderComponent($$result, "ChoiceButton", $$ChoiceButton, { "id": IDName || id, "type": "checkbox", "name": "product-config", "inputClassName": "product-config-choice", "disabled": disabled, "value": value, "attribute": { "data-option": `${title} ${price}` } }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<span${addAttribute([className, { disabled }, `product-config group`], "class:list")}${addAttribute(style, "style")} role="button"${spreadAttributes(attribute)}${spreadAttributes(variantAttr)}>
        <div class="product-config-header">
            <div class="product-config-title">
                ${showColorSelector && renderTemplate`<span class="product-config-color-selector">
                            <span class="product-config-color-selector-circle"></span>
                        </span>`}
                ${showNotificationIcon && renderTemplate`<div class="product-config-notification" tabindex="0">
                        ${renderComponent($$result2, "NotificationIcon", $$NotificationIcon, {})}
                    </div>`}
                ${title}
            </div>
            ${showPriceTag && renderTemplate`<div class="product-config-price-tag">
                        <span class="product-config-price">${price}</span>
                        ${showPriceDescription && renderTemplate`<span class="product-config-price-description">${priceDescription}</span>`}
                    </div>`}
        </div>
        ${showOptionHint && renderTemplate`<p class="product-config-option-hint">${optionHint}</p>`}
    </span>
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/product/productConfig.astro", void 0);

const $$Astro$9 = createAstro("https://www.Asus.com.tw");
const $$Config = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$Config;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "solutions-config"], "class:list")}${addAttribute(style, "style")} data-choice-button="radio"${spreadAttributes(attribute)}>
    <label for="FromProductConfig-61FromChoiceButton" class="solutions-config-label">
        方案
    </label>
    <div class="solutions-config-list">
        ${renderComponent($$result, "ProductConfig", $$ProductConfig, { "title": "\u57FA\u790E\u7248", "price": "$10,000 / \u6708", "showColorSelector": false, "showOptionHint": false, "showPriceDescription": false, "value": "1" })}
        ${renderComponent($$result, "ProductConfig", $$ProductConfig, { "title": "\u9032\u968E\u7248", "price": "$11,000 / \u6708", "showColorSelector": false, "showOptionHint": false, "showPriceDescription": false, "value": "2" })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/config.astro", void 0);

const $$Astro$8 = createAstro("https://www.Asus.com.tw");
const $$Right = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$Right;
  const { IDName = "SolutionsRight", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, ":uno-solutions-right:"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Head", $$Head, { "className": "solutions-right-head" })}
    <div class="solutions-right-content">
        ${renderComponent($$result, "Config", $$Config, {})}
        ${renderComponent($$result, "Collapse", $$Collapse, { "title": "\u7522\u54C1\u8CC7\u8A0A", "show": true }, { "default": ($$result2) => renderTemplate`
            <p>用新創數位的尖端 AI 驅動系統，徹底改造您的供應鏈，革新傳統的電話與電子郵件溝通方式。透過 Aether 平台 無縫連接並下單，大幅降低成本與人力投入，讓您能專注於拓展核心業務。</p>
            <p>新創數位科技有限公司 專注於開發智慧化的供應鏈管理解決方案，提供完整工具組，優化採購流程的每一個環節。我們的 AI 系統運用先進演算法與機器學習，從需求預測到訂單履行，全面提升效率、降低成本並簡化操作。有了新創數位，您可以告別繁瑣的人工流程，擁抱更智慧、更靈活、能隨需求而動的供應鏈。</p>
            <p>我們的系統可與您現有的基礎設施無縫整合，提供即時的庫存狀態、訂單進度與供應商表現的可視化數據。透過新創數位的智慧採購解決方案，您能以數據為基礎做出決策，最大化供應鏈效率，取得競爭優勢。親身體驗 預測分析、自動化流程與智慧洞察 帶來的實際成果。我們的 AI 系統幫助您預測需求波動、識別潛在風險並提前應對，打造具韌性、快速回應的供應鏈。</p>
            <p>使用新創數位完整的供應鏈管理工具套件，釋放效率與盈利的新高度。從供應商關係管理到庫存優化，我們的系統提供端到端的可視化與控制力。簡化溝通、任務自動化、消除瓶頸，讓寶貴資源專注於戰略計畫。有了新創數位，您能將供應鏈從「成本中心」轉化為「競爭優勢」。</p>
            <p>我們以 創新 與 客戶滿意 為核心差異化。我們與客戶緊密合作，深入了解其獨特需求與挑戰，並量身打造解決方案。我們的專業團隊提供持續的支援與指導，確保順利導入並達到最佳效能。選擇新創數位，體驗智慧供應鏈管理為您的企業帶來的不同。</p>
            <p>立即聯繫我們，了解新創數位如何革新您的供應鏈，推動企業的永續成長。讓我們幫助您釋放供應鏈的全部潛能，透過 AI 驅動的解決方案，共同打造更智慧、更高效、更具韌性的供應鏈，助您在瞬息萬變的市場中持續成功。</p>
            <p>新創數位科技有限公司 —— 您值得信賴的智慧供應鏈管理合作夥伴。</p>
        ` })}
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/right.astro", void 0);

const $$Astro$7 = createAstro("https://www.Asus.com.tw");
const $$Top = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Top;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  const images = [...new Array(12).keys()].map(() => "/assets/images/pages/desktop-product-1");
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "solutions-top"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Left", $$Left, { "title": "\u667A\u6167\u63A1\u8CFC\u53EB\u8CA8\u7CFB\u7D71", "images": images, "className": "solutions-product-swipers" })}
    ${renderComponent($$result, "Right", $$Right, { "className": "solutions-top-right" })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/top.astro", void 0);

const $$Astro$6 = createAstro("https://www.Asus.com.tw");
const $$Feature = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Feature;
  const { IDName = "solutions-feature", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "solutions-feature"
  ], "class:list")}${addAttribute({ "--bg-image": `url("/assets/images/pages/feature-BG.png")`, ...style }, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Title", $$Title, { "title": "\u65B9\u6848\u7279\u8272" })}
    <div class="solutions-feature-container">
        <div class="solutions-feature-card-grid">
            ${Array.from({ length: 6 }).map((_, index) => renderTemplate`<div class="solutions-feature-card">
                        <b class="solutions-feature-card-title">特色標題</b>
                        <span class="solutions-feature-card-text">
                            特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容特色標題內容
                        </span>
                    </div>`)}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/feature.astro", void 0);

const $$Astro$5 = createAstro("https://www.Asus.com.tw");
const $$Relative = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Relative;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "MyRelative", $$Relative$1, { "IDName": "SolutionsRelative", "title": "\u76F8\u95DC\u89E3\u6C7A\u65B9\u6848", "className": "solutions-section-relative", "type": 1, "count": 12 }, { "default": ($$result2) => renderTemplate`
        ${renderComponent($$result2, "SolutionsCard", $$Card, { "link": "/solutions/0", "showPlayBack": false })}
    ` })}
    ${renderComponent($$result, "MyRelative", $$Relative$1, { "IDName": "SuccessRelative", "title": "\u6210\u529F\u6848\u4F8B", "className": "success-section-relative", "type": 3, "count": 12 }, { "default": ($$result2) => renderTemplate`
        ${renderComponent($$result2, "NewsCard", $$Card$1, { "link": "/success/0", "showBreif": false })}
    ` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/relative.astro", void 0);

const $$Astro$4 = createAstro("https://www.Asus.com.tw");
const $$Bookmark = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Bookmark;
  const {
    IDName,
    className,
    style,
    attribute = {},
    status = "Active",
    stroke = "Default",
    size,
    color
  } = Astro2.props;
  const svgPaths = {
    "Normal-Default": "M8 14.6811L14.8 19.762V1.2L1.2 1.2V19.762L8 14.6811ZM0 22V2C0 0.895433 0.895431 0 2 0H14C15.1046 0 16 0.895431 16 2V22L8 16.3711L0 22Z",
    "Normal-Thick": "M8 13.6811L13.8 17.762V2.2H2.2V17.762L8 13.6811ZM0 22V2C0 0.895433 0.895431 0 2 0H14C15.1046 0 16 0.895431 16 2V22L8 16.3711L0 22Z",
    "Active-Default": "M0 22V2C0 0.895433 0.895431 0 2 0H14C15.1046 0 16 0.895431 16 2V22L8 16.3711L0 22Z"
  };
  const currentPath = svgPaths[`${status}-${stroke}`] || svgPaths["Active-Default"];
  return renderTemplate`${maybeRenderHead()}<span${addAttribute(IDName, "id")}${addAttribute([className, "bookmark-icon", `bookmark-${status.toLowerCase()}`, `bookmark-${stroke.toLowerCase()}`], "class:list")}${addAttribute({
    ...style,
    "--icon-size": size ? `${size}px` : void 0,
    "--icon-color": color ? color.charAt(0) === "#" ? color : `var(--color-${color})` : void 0
  }, "style")}${spreadAttributes(attribute)}>
    <svg width="16" height="22" viewBox="0 0 16 22" fill="none" xmlns="http://www.w3.org/2000/svg" class="bookmark-svg">
        <path fill-rule="evenodd" clip-rule="evenodd"${addAttribute(currentPath, "d")} fill="var(--icon-color)"></path>
    </svg>
</span>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/common/icons/bookmark/bookmark.astro", void 0);

const $$Astro$3 = createAstro("https://www.Asus.com.tw");
const $$Follower = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Follower;
  const {
    IDName = "SolutionsFollower",
    className,
    style,
    attribute = {},
    title = "\u667A\u6167\u63A1\u8CFC\u53EB\u8CA8\u7CFB\u7D71",
    value = "0",
    option = "\u57FA\u790E\u7248 $10,000 / \u6708"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "uno-solutions-follower: min-h-3rem fixed top-[var(--header-height)] inset-x-0 z-50 bg-white"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    <form class="solutions-follower-form">
        <h2 class="solutions-follower-product-title">
            ${title}
        </h2>
        <div class="solutions-follower-product-controller">
            <div>
                <input type="hidden"${addAttribute(value, "value")} data-option>
                <span class="solutions-follower-product-price">${option}</span>
            </div>
            ${renderComponent($$result, "Button", $$Button, { "type": "submit", "title": "\u7ACB\u5373\u8AEE\u8A62", "variant": "blue", "size": "xs" }, { "default": ($$result2) => renderTemplate`立即諮詢` })}
            ${renderComponent($$result, "Button", $$Button, { "type": "button", "title": "\u7ACB\u5373\u8AEE\u8A62", "variant": "blue-outline", "size": "sm", "attribute": { "data-favorite": "true" } }, { "default": ($$result2) => renderTemplate`
                ${renderComponent($$result2, "Bookmark", $$Bookmark, { "stroke": "Thick", "status": "Normal" })}
                加入收藏
            ` })}
            <!-- 移除收藏狀態 -->
            ${renderComponent($$result, "Button", $$Button, { "type": "button", "title": "\u7ACB\u5373\u8AEE\u8A62", "variant": "blue-outline", "size": "sm", "attribute": { "data-favorite": "true" } }, { "default": ($$result2) => renderTemplate`
                ${renderComponent($$result2, "Bookmark", $$Bookmark, { "stroke": "Thick", "status": "Active" })}
                移除收藏
            ` })}
        </div>
    </form>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/follower.astro", void 0);

const $$Astro$2 = createAstro("https://www.Asus.com.tw");
const $$Toast = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Toast;
  const { IDName = "addToCartToast", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(["add-to-cart-toast-container", className], "class:list")}${spreadAttributes(attribute)}${addAttribute(style, "style")}>
    <div${addAttribute(IDName, "id")} class="toast hide" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-body :uno-add-to-cart-toast-body: flex items-center justify-center gap-1.25rem rounded-lg whitespace-nowrap text-white body-02-sh xl:body-03-sh">
            已加入詢問清單
            <button type="button" data-bs-dismiss="toast" aria-label="Close">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 2L2 14M2 2L14 14" stroke="var(--color-white, #fff)" stroke-linecap="round"></path>
                </svg>
            </button>
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/toast.astro", void 0);

const $$Astro$1 = createAstro("https://www.Asus.com.tw");
const $$Back = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Back;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([
    className,
    "solutions-back"
  ], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Button", $$Button, { "Tag": "a", "link": "/solutions", "title": "\u56DE\u5230\u89E3\u6C7A\u65B9\u6848\u7E3D\u89BD\u9801", "variant": "blue" }, { "default": ($$result2) => renderTemplate`回到解決方案總覽頁` })}
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/solutions/[id]/back.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://www.Asus.com.tw");
async function getStaticPaths() {
  return Array.from({ length: 10 }).map((_, index) => ({ params: { id: index } }));
}
const prerender = true;
const $$ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const { id } = Astro2.params;
  return renderTemplate(_a || (_a = __template(["", "\n", "\n", "\n", "\n", `

<script>
    const specInputs = document.querySelectorAll('input[type="checkbox"][name="product-config"]');
    specInputs.forEach((input) => {
        input.addEventListener('change', () => {
            const value = input.value;
            const option = input.getAttribute('data-option');
            const follower = document.querySelector('#SolutionsFollower');
            const field = follower?.querySelector('input[type="hidden"][data-option]');
            if (field) {
                field.value = value;
                const span = field?.nextElementSibling;
                if (span) span.textContent = option;
            }
        });
    });
<\/script>
<script>
    const toastTriggerForm = document.querySelector('#SolutionsFollower form');
    const toast = document.querySelector('#addToCartToast');
    document.addEventListener('DOMContentLoaded', () => {
        if (toastTriggerForm) {
            toastTriggerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                /** TODO: */
                if (toast) toast.dispatchEvent(new CustomEvent('call.toast'));
            });
        }
    });
<\/script>`])), renderComponent($$result, "Layouts", $$Layouts, { "IDName": "SolutionsDetail", "minMarginHeader": true, "footerPages": ["\u89E3\u6C7A\u65B9\u6848"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Top", $$Top, {})}
    ${renderComponent($$result2, "Feature", $$Feature, {})}
    ${renderComponent($$result2, "Relative", $$Relative, {})}
    ${renderComponent($$result2, "Back", $$Back, {})}
` }), renderComponent($$result, "Follower", $$Follower, {}), renderComponent($$result, "Script", $$Relative$2, {}), renderComponent($$result, "Toast", $$Toast, {}), renderComponent($$result, "Video", $$Video, {}));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/solution/[...id].astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/solution/[...id].astro";
const $$url = "/solution/[...id].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$,
    file: $$file,
    getStaticPaths,
    prerender,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
