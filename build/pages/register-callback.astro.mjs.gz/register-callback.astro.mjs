/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, F as Fragment } from '../chunks/astro/server_Bjgbv9en.mjs';
import { b as $$Input, c as $$Link, $ as $$Button$1, a as $$Layouts } from '../chunks/layouts_k9LlQnqK.mjs';
import { $ as $$Form$1 } from '../chunks/form_BgyQ-TUP.mjs';
import { $ as $$Button } from '../chunks/button_DRv7LvK0.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_CQlnL_EO.mjs';
import { $ as $$PasswordInput } from '../chunks/passwordInput_BHGsGiTO.mjs';
import { $ as $$CheckboxGroup } from '../chunks/checkboxGroup_CnF6GLbl.mjs';
import { $ as $$Checkbox } from '../chunks/checkbox_wf8xSkG5.mjs';
import '../chunks/register-callback.a493419a_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "id": IDName, "title": "\u6703\u54E1\u8A3B\u518A", "class:list": [className], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="thrid-party-registers-2">
        ${renderComponent($$result2, "LoginButton", $$Button, { "type": "google", "status": "registed" })}
    </div>
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u5E33\u865F", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "type": "email", "value": "service@gmail.com", "inputmode": "email", "readonly": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u5BC6\u78BC", "infoText": "\u5BC6\u78BC\u9700\u5305\u62EC8\u81F325\u4F4D\u5927\u5C0F\u5BEB\u5B57\u6BCD\u3001\u6578\u5B57\u53CA\u7B26\u865F\uFF0C\u4E14\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\u3002", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "PasswordInput", $$PasswordInput, {})}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u78BA\u8A8D\u5BC6\u78BC", "infoText": "\u8ACB\u518D\u6B21\u8F38\u5165\u5BC6\u78BC", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "PasswordInput", $$PasswordInput, {})}
    ` })}
    ${renderComponent($$result2, "CheckboxGroup", $$CheckboxGroup, {}, { "default": ($$result3) => renderTemplate`
        
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`
            我已閱讀並同意華碩 <b>ASUS EXPERTHUB</b> "${renderComponent($$result4, "ALink", $$Link, { "link": "https://asusexperthub.com/service/terms", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`使用者條款` })}"
        ` })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`
            我已閱讀並同意華碩 <b>ASUS EXPERTHUB</b> "${renderComponent($$result4, "ALink", $$Link, { "link": "https://asusexperthub.com/service/privacy", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`隱私權條款` })}"
        ` })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`我願意收到華碩相關新聞、產品及服務更新之訊息或行銷廣告。(非必填)` })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`我願意收到華碩雲端的相關新聞、產品及服務更新之訊息或行銷廣告。(非必填)` })}
    `, "title": ($$result3) => renderTemplate`${renderComponent($$result3, "Fragment", Fragment, { "slot": "title" }, { "default": ($$result4) => renderTemplate`我同意以下所有條款和隱私權政策` })}` })}
    ${renderComponent($$result2, "Button", $$Button$1, { "type": "submit", "variant": "blue", "title": "\u7ACB\u5373\u8A3B\u518A", "block": true }, { "default": ($$result3) => renderTemplate`立即註冊` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/register-callback/form.astro", void 0);

const $$RegisterCallback = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Register-callback", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/register-callback.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/register-callback.astro";
const $$url = "/register-callback.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$RegisterCallback,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
