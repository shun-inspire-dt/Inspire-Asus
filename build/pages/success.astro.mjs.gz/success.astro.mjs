/* empty css                              */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderComponent, r as renderScript, e as renderTemplate, F as Fragment } from '../js/astro/server.QBXP0SM9.js';
import { b as $$Layouts } from '../js/layouts.Bpyq1lYE.js';
import { a as $$Banner } from '../js/banner.CPJwz7T4.js';
import { b as $$Title, $ as $$ArticlesList, a as $$Follower } from '../js/articlesList.DroePms8.js';
import { $ as $$CollectionCard, a as $$Swiper, b as $$NavigatiorArrow, c as $$CollectionHarCard } from '../js/collectionHarCard.wzmHAQJg.js';
/* empty css                              */
import { $ as $$Card } from '../js/card.DxPfgYc1.js';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業(1)", value: "科技與製造產業", checked: false },
  { label: "零售與電商產業(5)", value: "零售與電商產業", checked: false },
  { label: "餐飲與連鎖服務產業(2)", value: "餐飲與連鎖服務產業", checked: false },
  { label: "醫療與照護產業(2)", value: "醫療與照護產業", checked: false },
  { label: "教育與訓練產業(1)", value: "教育與訓練產業", checked: false },
  { label: "建築與工程產業(1)", value: "建築與工程產業", checked: false },
  { label: "旅宿與觀光產業(1)", value: "旅宿與觀光產業", checked: false },
  { label: "顧問服務產業(1)", value: "顧問服務產業", checked: false }
];
const data = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  }
];

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Articles = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Articles;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "article-collection"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Title", $$Title, { "title": "\u7CBE\u9078\u6848\u4F8B" })}
    <div class="article-collection-inner">
        <div class="article-collection-top">
            ${renderComponent($$result, "CollectionCard", $$CollectionCard, { "showBreif": false })}
        </div>
        <div class="article-collection-bottom">
            ${renderComponent($$result, "Swiper", $$Swiper, { "IDName": "newsCollection", "swiperClassName": "news-collection-swiper" }, { "default": ($$result2) => renderTemplate`
                
                ${Array.from({ length: 3 }).map((_, index) => renderTemplate`<div class="swiper-slide" style="width: auto;">
                            ${renderComponent($$result2, "CollectionHarCard", $$CollectionHarCard, { "showBreif": false, "last": index === 2 })}
                        </div>`)}`, "outside": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outside" }, { "default": ($$result3) => renderTemplate`
                    <div class="article-collection-next-button" data-swiper-button-next>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "right" })}
                    </div>
                    <div class="article-collection-prev-button" data-swiper-button-prev>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "left" })}
                    </div>
                ` })}` })}
        </div>
    </div>
</div>

${renderScript($$result, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/success/articles.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/success/articles.astro", void 0);

const $$Success = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Success", "footerShowBorderTop": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "success-banner", "title": "\u6210\u529F\u6848\u4F8B", "mode": "dark" })}
    ${renderComponent($$result2, "Articles", $$Articles, {})}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "SuccessList", "title": "\u6210\u529F\u6848\u4F8B", "total": 10, "sortDate": [
    { text: "\u65B0\u4E0A\u5E02", value: "0" },
    { text: "\u65B0\u6848\u4F8B", value: "1" }
  ], "category": data }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "showBreif": false })}`)}` })}
    ${renderComponent($$result2, "Follower", $$Follower, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/success.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/success.astro";
const $$url = "/success.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Success,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
