/* empty css                                   */
import { c as createAstro, a as createComponent, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, r as renderComponent, d as renderTemplate, F as Fragment } from '../chunks/astro/server_v5wg8FJS.mjs';
import { a as $$Layouts } from '../chunks/layouts_2rr1OTfM.mjs';
import { $ as $$Banner } from '../chunks/banner_D4dx3PBM.mjs';
import { $ as $$Follower, a as $$SciptInline, b as $$ArticlesList } from '../chunks/scipt-inline_NrO92H3b.mjs';
import { $ as $$Title } from '../chunks/title_C418meuI.mjs';
import { $ as $$Swiper, a as $$NavigatiorArrow } from '../chunks/navigatiorArrow_DyOPDvK4.mjs';
import { $ as $$CollectionCard, a as $$CollectionHarCard } from '../chunks/collectionHarCard_DtkmzgaF.mjs';
/* empty css                                 */
import { $ as $$Card } from '../chunks/card_D7kSzIU0.mjs';
import { $ as $$Script } from '../chunks/script_CiBXlnxE.mjs';
export { renderers } from '../renderers.mjs';

const child1 = [
  { label: "科技與製造產業", value: "tech-manufacturing", name: "industry", checked: false, count: 1 },
  { label: "零售與電商產業", value: "retail-ecommerce", name: "industry", checked: false, count: 5 },
  { label: "餐飲與連鎖服務產業", value: "food-service", name: "industry", checked: false, count: 2 },
  { label: "醫療與照護產業", value: "healthcare", name: "industry", checked: false, count: 2 },
  { label: "教育與訓練產業", value: "education", name: "industry", checked: false, count: 1 },
  { label: "建築與工程產業", value: "construction", name: "industry", checked: false, count: 1 },
  { label: "旅宿與觀光產業", value: "hospitality", name: "industry", checked: false, count: 1 },
  { label: "顧問服務產業", value: "consulting", name: "industry", checked: false, count: 1 }
];
const data$1 = [
  {
    title: "產業類別",
    show: true,
    more: true,
    children: child1
  }
];

const data = [
  {
    title: "iShops - 開店平台！",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-01",
    logoImageType: "png",
    link: "/news/0",
    linkText: "了解更多"
  },
  {
    title: "CloudSync - 雲端同步系統",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-05",
    logoImageType: "png",
    link: "/news/1",
    linkText: "了解更多"
  },
  {
    title: "SecureGuard - 企業資安防護",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    link: "/news/2",
    logoImage: "/assets/images/pages/brands/Logo-12",
    logoImageType: "png",
    linkText: "了解更多"
  },
  {
    title: "DataFlow - 數據分析平台",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-18",
    logoImageType: "png",
    link: "/news/3",
    linkText: "了解更多"
  },
  {
    title: "TeamConnect - 協作管理工具",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-23",
    logoImageType: "png",
    link: "/news/4",
    linkText: "了解更多"
  },
  {
    title: "AutoFlow - 工作流程自動化",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-31",
    logoImageType: "png",
    link: "/news/5",
    linkText: "了解更多"
  },
  {
    title: "MobileFirst - 行動應用開發",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-07",
    logoImageType: "png",
    link: "/news/6",
    linkText: "了解更多"
  },
  {
    title: "SmartInventory - 智慧庫存管理",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-15",
    logoImageType: "png",
    link: "/news/7",
    linkText: "了解更多"
  },
  {
    title: "CustomerCare - 客戶關係管理",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-28",
    logoImageType: "png",
    link: "/news/8",
    linkText: "了解更多"
  },
  {
    title: "EcoTech - 綠色科技解決方案",
    date: "2025-12-24",
    label: "科技與製造",
    img: "/assets/images/pages/Article-card-image",
    logoImage: "/assets/images/pages/brands/Logo-35",
    logoImageType: "png",
    link: "/news/9",
    linkText: "了解更多"
  }
];

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Articles = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Articles;
  const { IDName, className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(IDName, "id")}${addAttribute([className, "article-collection"], "class:list")}${addAttribute(style, "style")}${spreadAttributes(attribute)}>
    ${renderComponent($$result, "Title", $$Title, { "title": "\u7CBE\u9078\u6848\u4F8B" })}
    <div class="article-collection-inner">
        <div class="article-collection-top">
            ${renderComponent($$result, "CollectionCard", $$CollectionCard, { "showBreif": false })}
        </div>
        <div class="article-collection-bottom">
            ${renderComponent($$result, "Swiper", $$Swiper, { "IDName": "newsCollection", "swiperClassName": "news-collection-swiper" }, { "default": ($$result2) => renderTemplate`
                
                ${Array.from({ length: 3 }).map((_, index) => renderTemplate`<div class="swiper-slide" style="width: auto;">
                            ${renderComponent($$result2, "CollectionHarCard", $$CollectionHarCard, { "showBreif": false, "last": index === 2 })}
                        </div>`)}`, "outside": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "outside" }, { "default": ($$result3) => renderTemplate`
                    <div class="article-collection-next-button" data-swiper-button-next>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "right" })}
                    </div>
                    <div class="article-collection-prev-button" data-swiper-button-prev>
                        ${renderComponent($$result3, "NavigatiorArrow", $$NavigatiorArrow, { "direction": "left" })}
                    </div>
                ` })}` })}
        </div>
    </div>
</div>`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/success/articles.astro", void 0);

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Success", "footerShowBorderTop": true, "footerPages": ["\u6210\u529F\u6848\u4F8B"] }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Banner", $$Banner, { "img": "success-banner", "title": "\u6210\u529F\u6848\u4F8B", "mode": "dark" })}
    ${renderComponent($$result2, "Articles", $$Articles, {})}
    ${renderComponent($$result2, "ArticlesList", $$ArticlesList, { "IDName": "SuccessList", "title": "\u6210\u529F\u6848\u4F8B", "total": 10, "sortDate": [
    { text: "\u65B0\u4E0A\u5E02", value: "0" },
    { text: "\u65B0\u6848\u4F8B", value: "1" }
  ], "category": data$1 }, { "default": ($$result3) => renderTemplate`${Array.from({ length: 10 }).map((_, index) => renderTemplate`${renderComponent($$result3, "Card", $$Card, { "link": `/success/${index}`, "showBreif": false })}`)}` })}
` })}
${renderComponent($$result, "Follower", $$Follower, {})}
${renderComponent($$result, "ScriptInline", $$SciptInline, { "data": data })}
${renderComponent($$result, "Script", $$Script, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/success/index.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/success/index.astro";
const $$url = "/success.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
