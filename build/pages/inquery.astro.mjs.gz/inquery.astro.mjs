/* empty css                                   */
import { a as createComponent, r as renderComponent, d as renderTemplate } from '../chunks/astro/server_v5wg8FJS.mjs';
import { d as data } from '../chunks/card_9JeEmzXH.mjs';
import { a as $$Layouts } from '../chunks/layouts_CAx5rqF_.mjs';
import { $ as $$ComfirmCode } from '../chunks/comfirm-code_B44qRTF_.mjs';
import { $ as $$ScriptNext, a as $$Cookies, b as $$FetchWithAuth } from '../chunks/fetchWithAuth.copy_B13ldWhB.mjs';
import { $ as $$ScriptInline, a as $$Form } from '../chunks/script-inline_C7oeOaXL.mjs';
/* empty css                                     */
export { renderers } from '../renderers.mjs';

const $$Inquery = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Inquery", "minMarginHeader": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, { "data": data })}
` })}
${renderComponent($$result, "ComfirmCode", $$ComfirmCode, {})}
${renderComponent($$result, "ScriptNext", $$ScriptNext, {})}
${renderComponent($$result, "CookiesScript", $$Cookies, {})}
${renderComponent($$result, "FetchWithAuthScript", $$FetchWithAuth, {})}
${renderComponent($$result, "ScriptInline", $$ScriptInline, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro";
const $$url = "/inquery.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Inquery,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
