/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, F as Fragment, e as defineScriptVars } from '../chunks/astro/server_v5wg8FJS.mjs';
import { $ as $$Card, d as data } from '../chunks/card__-4K3i21.mjs';
import { b as $$Input, $ as $$Button, a as $$Layouts } from '../chunks/layouts_Ca0YPUcq.mjs';
import { $ as $$ComfirmCode } from '../chunks/comfirm-code_LysRW5oY.mjs';
import { $ as $$ScriptNext, a as $$Cookies, b as $$FetchWithAuth } from '../chunks/fetchWithAuth.copy_DZrASHv9.mjs';
import { $ as $$Form$1 } from '../chunks/form_CPN2Wti_.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_DI5El5nt.mjs';
import { $ as $$CustomSelect } from '../chunks/customSelect_DOO6CwVe.mjs';
import { $ as $$Textarea } from '../chunks/textarea_BoNmgoBZ.mjs';
import '../chunks/inquery.30af039e_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "Inquery", className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "type": 2, "display": "grid", "title": "\u8AEE\u8A62\u6E05\u55AE", "block": true, "className": ["needs-validation", className], "attribute": { novalidate: "", "data-needs-loading": "true", "data-report-validity": "false", ...attribute }, "style": style }, { "default": ($$result2) => renderTemplate`
    
    
    ${maybeRenderHead()}<div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "companyName", "label": "\u516C\u53F8\u540D\u7A31", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "companyName", "name": "companyName", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "taxId", "label": "\u7D71\u7DE8", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "taxId", "name": "taxId", "type": "text", "inputmode": "numeric", "minLength": 8, "maxLength": 8, "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "department", "label": "\u90E8\u9580", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Select", $$CustomSelect, { "id": "department", "name": "department", "data": [
    { text: "IT\u90E8\u9580", value: "IT\u90E8\u9580" },
    { text: "\u8CA1\u52D9\u90E8\u9580", value: "\u8CA1\u52D9\u90E8\u9580" }
  ], "value": "IT\u90E8\u9580", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "position", "label": "\u8077\u7A31", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "position", "name": "position", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "tel", "label": "\u516C\u53F8\u96FB\u8A71", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "tel", "name": "tel", "type": "tel", "inputmode": "tel", "required": true })}
        ` })}
    </div>
    <div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "name", "label": "\u806F\u7D61\u59D3\u540D", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "name", "name": "name", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "cellphone", "label": "\u806F\u7D61\u624B\u6A5F", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "cellphone", "name": "cellphone", "type": "tel", "inputmode": "tel", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "email", "label": "\u806F\u7D61\u4FE1\u7BB1", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "id": "email", "name": "email", "type": "email", "inputmode": "email", "required": true })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "comment", "label": "\u5099\u8A3B", "block": true }, { "default": ($$result3) => renderTemplate`
            
            ${renderComponent($$result3, "Textarea", $$Textarea, { "id": "comment", "name": "comment", "style": { "min-height": "8.625rem" } })}
        `, "label-right": ($$result3) => renderTemplate`${renderComponent($$result3, "Fragment", Fragment, { "slot": "label-right" }, { "default": ($$result4) => renderTemplate`
                <small>&nbsp;(非必填)</small>
            ` })}` })}
        <div class="form-button-container">
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "className": "form-button", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`
                送出
            ` })}
        </div>
    </div>
`, "sub-title": ($$result2) => renderTemplate`<div class="inquery-form-head">
        <h2 class="inquery-title">聯絡資訊</h2>
    </div>`, "top": ($$result2) => renderTemplate`<div class="inquery-cart">
        <div class="inquery-form-head" slot="sub-title">
            <h2 class="inquery-title">
                方案清單
            </h2>
            <span class="inquery-cart-amount">
                合計詢問
                <b class="inquery-cart-amount-number">2</b>
                個方案
            </span>
        </div>
        <div class="w-full flex flex-col items-center gap-1.5rem">
            ${data.map((x) => renderTemplate`${renderComponent($$result2, "Card", $$Card, { "id": x.id, "title": x.title, "label": x.label, "brief": x.brief, "amount": x.amount, "img": x.img, "required": true })}`)}
        </div>
    </div>` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/inquery/form.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$ScriptInline = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["<script>(function(){", "\n    const authClient = new AuthClient({ baseURL, cookies });\n    const Fetch = authClient.fetchWithAuth.bind(authClient);\n    /** ---------- 實作 ---------- */\n    // 全局 Toast 實例\n    const toastEl = document.getElementById('toastModal');\n\n    /**\n     * API 請求封裝\n     * @description 統一處理此頁面所需的 API 呼叫與 headers 設定\n     */\n    class API {\n        headers = new Headers({\n            'Content-Type': 'application/json',\n            Authorization: `Bearer ${authClient.cookies.get('access_token')}`\n        });\n\n        /**\n         * 範例 API（目前用於 demo）\n         * @param {Record<string, any>} data - 表單送出時整理出的資料\n         * @returns {Promise<{success: boolean, message?: string}>} API 回應\n         */\n        exampleAPI = async (data) => {\n            console.log('data', data);\n            const requestOptions = {\n                method: 'GET',\n                headers: this.headers\n            };\n\n            return await Fetch(baseURL + '/api/form/example-success', requestOptions)\n                .then((response) => response.json())\n                .then((result) => result)\n                .catch((error) => {\n                    console.error('Error:', error);\n                    return { success: false, message: error.message || '失敗' };\n                });\n        };\n    }\n\n    /**\n     * 諮詢表單流程\n     * @description 綁定表單驗證、組裝表單資料並呼叫 API，最後用 Toast 顯示結果\n     */\n    class Form extends API {\n        form = document.querySelector('#InqueryForm');\n\n        /**\n         * 初始化\n         * @description 建立實例後立即綁定事件\n         */\n        constructor() {\n            super();\n            this.bindEvents();\n        }\n\n        /**\n         * 建立表單驗證器\n         * @description 使用 FormValidator 綁定 submit 驗證與 onValidSubmit 行為\n         * @returns {FormValidator}\n         */\n        validator = () =>\n            new FormValidator(this.form, {\n                onValidSubmit: async ({ controls }) => {\n                    /**\n                     *  Form Data 資料會如下：\n                     *  const formDataExample = {\n                        isAll: '1',\n                        data: {\n                            name: 'asd',\n                            tel: '0912345678',\n                            department: 'IT部門',\n                            position: '12312312',\n                            cellphone: '0912345678',\n                            email: '12@gmail.com',\n                            comment: 'asdasdasd',\n                            companyName: '123',\n                            taxId: '12312313',\n                            products: [\n                                { id: 1, qty: 2 },\n                                { id: 2, qty: 1 },\n                                { id: 3, qty: 3 }\n                            ]\n                        }\n                    }; */\n                    /**\n                     * 組裝送出資料\n                     * @param {Record<string, HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>} controls - 表單控制項集合\n                     * @returns {{isAll: string, data: Record<string, string | {id: number, qty: number}[]>}} 送出 payload\n                     */\n                    const formData = (controls) => {\n                        const formData = {\n                            isAll: '1',\n                            data: {}\n                        };\n                        const products = [];\n                        Object.entries(controls || {}).forEach(([key, el]) => {\n                            if (!key || !el) return;\n\n                            if (key.includes('inquery-amount-')) {\n                                const id = Number(el.dataset.id);\n                                const qty = Number(el.value);\n                                if (isFinite(id) && isFinite(qty)) {\n                                    products.push({ id, qty });\n                                }\n                                return;\n                            }\n                            formData['data'][key] = el.value;\n                        });\n                        formData['data']['products'] = products;\n                        return formData;\n                    };\n                    try {\n                        const response = await this.exampleAPI(formData(controls));\n                        if (response.success) {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'success',\n                                        title: '表單已送出',\n                                        text: '謝謝詢問，我們會透過Email或電話與您聯繫',\n                                        link: {\n                                            primaryText: '回首頁',\n                                            primaryLink: '/',\n                                            primaryVariant: 'blue'\n                                        },\n                                        hidePrevented: true\n                                    }\n                                })\n                            );\n                        } else {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'error',\n                                        title: response.message || '失敗'\n                                    }\n                                })\n                            );\n                        }\n                    } catch (error) {\n                        console.error('Error From Submit:', error);\n                        toastEl.dispatchEvent(\n                            new CustomEvent('fire', {\n                                detail: {\n                                    icon: 'error',\n                                    title: error.message || '失敗'\n                                }\n                            })\n                        );\n                    }\n                }\n            });\n        /**\n         * 綁定所有事件監聽器\n         * @description 為各個 Form 和 Modal 綁定相應的事件處理器\n         */\n        bindEvents = () => {\n            this.validator && this.validator();\n        };\n    }\n\n    // 等待 DOM 加載完成後初始化\n    if (document.readyState === 'loading') {\n        document.addEventListener('DOMContentLoaded', () => new Form());\n    } else {\n        new Form();\n    }\n})();</script>"], ["<script>(function(){", "\n    const authClient = new AuthClient({ baseURL, cookies });\n    const Fetch = authClient.fetchWithAuth.bind(authClient);\n    /** ---------- 實作 ---------- */\n    // 全局 Toast 實例\n    const toastEl = document.getElementById('toastModal');\n\n    /**\n     * API 請求封裝\n     * @description 統一處理此頁面所需的 API 呼叫與 headers 設定\n     */\n    class API {\n        headers = new Headers({\n            'Content-Type': 'application/json',\n            Authorization: \\`Bearer \\${authClient.cookies.get('access_token')}\\`\n        });\n\n        /**\n         * 範例 API（目前用於 demo）\n         * @param {Record<string, any>} data - 表單送出時整理出的資料\n         * @returns {Promise<{success: boolean, message?: string}>} API 回應\n         */\n        exampleAPI = async (data) => {\n            console.log('data', data);\n            const requestOptions = {\n                method: 'GET',\n                headers: this.headers\n            };\n\n            return await Fetch(baseURL + '/api/form/example-success', requestOptions)\n                .then((response) => response.json())\n                .then((result) => result)\n                .catch((error) => {\n                    console.error('Error:', error);\n                    return { success: false, message: error.message || '失敗' };\n                });\n        };\n    }\n\n    /**\n     * 諮詢表單流程\n     * @description 綁定表單驗證、組裝表單資料並呼叫 API，最後用 Toast 顯示結果\n     */\n    class Form extends API {\n        form = document.querySelector('#InqueryForm');\n\n        /**\n         * 初始化\n         * @description 建立實例後立即綁定事件\n         */\n        constructor() {\n            super();\n            this.bindEvents();\n        }\n\n        /**\n         * 建立表單驗證器\n         * @description 使用 FormValidator 綁定 submit 驗證與 onValidSubmit 行為\n         * @returns {FormValidator}\n         */\n        validator = () =>\n            new FormValidator(this.form, {\n                onValidSubmit: async ({ controls }) => {\n                    /**\n                     *  Form Data 資料會如下：\n                     *  const formDataExample = {\n                        isAll: '1',\n                        data: {\n                            name: 'asd',\n                            tel: '0912345678',\n                            department: 'IT部門',\n                            position: '12312312',\n                            cellphone: '0912345678',\n                            email: '12@gmail.com',\n                            comment: 'asdasdasd',\n                            companyName: '123',\n                            taxId: '12312313',\n                            products: [\n                                { id: 1, qty: 2 },\n                                { id: 2, qty: 1 },\n                                { id: 3, qty: 3 }\n                            ]\n                        }\n                    }; */\n                    /**\n                     * 組裝送出資料\n                     * @param {Record<string, HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>} controls - 表單控制項集合\n                     * @returns {{isAll: string, data: Record<string, string | {id: number, qty: number}[]>}} 送出 payload\n                     */\n                    const formData = (controls) => {\n                        const formData = {\n                            isAll: '1',\n                            data: {}\n                        };\n                        const products = [];\n                        Object.entries(controls || {}).forEach(([key, el]) => {\n                            if (!key || !el) return;\n\n                            if (key.includes('inquery-amount-')) {\n                                const id = Number(el.dataset.id);\n                                const qty = Number(el.value);\n                                if (isFinite(id) && isFinite(qty)) {\n                                    products.push({ id, qty });\n                                }\n                                return;\n                            }\n                            formData['data'][key] = el.value;\n                        });\n                        formData['data']['products'] = products;\n                        return formData;\n                    };\n                    try {\n                        const response = await this.exampleAPI(formData(controls));\n                        if (response.success) {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'success',\n                                        title: '表單已送出',\n                                        text: '謝謝詢問，我們會透過Email或電話與您聯繫',\n                                        link: {\n                                            primaryText: '回首頁',\n                                            primaryLink: '/',\n                                            primaryVariant: 'blue'\n                                        },\n                                        hidePrevented: true\n                                    }\n                                })\n                            );\n                        } else {\n                            toastEl.dispatchEvent(\n                                new CustomEvent('fire', {\n                                    detail: {\n                                        icon: 'error',\n                                        title: response.message || '失敗'\n                                    }\n                                })\n                            );\n                        }\n                    } catch (error) {\n                        console.error('Error From Submit:', error);\n                        toastEl.dispatchEvent(\n                            new CustomEvent('fire', {\n                                detail: {\n                                    icon: 'error',\n                                    title: error.message || '失敗'\n                                }\n                            })\n                        );\n                    }\n                }\n            });\n        /**\n         * 綁定所有事件監聽器\n         * @description 為各個 Form 和 Modal 綁定相應的事件處理器\n         */\n        bindEvents = () => {\n            this.validator && this.validator();\n        };\n    }\n\n    // 等待 DOM 加載完成後初始化\n    if (document.readyState === 'loading') {\n        document.addEventListener('DOMContentLoaded', () => new Form());\n    } else {\n        new Form();\n    }\n})();</script>"])), defineScriptVars({ baseURL: "https://shun-fast-api.zeabur.app" }));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/inquery/script-inline.astro", void 0);

const $$Inquery = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Inquery", "minMarginHeader": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, { "data": data })}
` })}
${renderComponent($$result, "ComfirmCode", $$ComfirmCode, {})}
${renderComponent($$result, "ScriptNext", $$ScriptNext, {})}
${renderComponent($$result, "CookiesScript", $$Cookies, {})}
${renderComponent($$result, "FetchWithAuthScript", $$FetchWithAuth, {})}
${renderComponent($$result, "ScriptInline", $$ScriptInline, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro";
const $$url = "/inquery.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Inquery,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
