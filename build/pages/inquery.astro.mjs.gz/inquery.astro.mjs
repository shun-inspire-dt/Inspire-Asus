/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Bjgbv9en.mjs';
import { b as $$Input, $ as $$Button, a as $$Layouts } from '../chunks/layouts_ZjeOk_Se.mjs';
import { $ as $$Form$1, a as $$InputGroup } from '../chunks/inputGroup_DQ8Q0AvO.mjs';
import { $ as $$Select } from '../chunks/select_rR_HL6HG.mjs';
import { $ as $$Textarea } from '../chunks/textarea_CSYt6kcf.mjs';
import '../chunks/inquery.30af039e_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "Inquery", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "type": 2, "display": "grid", "title": "\u8AEE\u8A62\u6E05\u55AE", "block": true, "class:list": [className], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    
    ${maybeRenderHead()}<div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u540D\u7A31", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u7D71\u7DE8", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "text", "inputmode": "numeric", "minLength": 8, "maxLength": 8 })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u90E8\u9580", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Select", $$Select, { "data": [
    { text: "IT\u90E8\u9580", value: "IT\u90E8\u9580" },
    { text: "\u8CA1\u52D9\u90E8\u9580", value: "\u8CA1\u52D9\u90E8\u9580" }
  ], "value": "IT\u90E8\u9580" })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u8077\u7A31", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u96FB\u8A71", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "tel", "inputmode": "tel" })}
        ` })}
    </div>
    <div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u806F\u7D61\u59D3\u540D", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u806F\u7D61\u624B\u6A5F", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "tel", "inputmode": "tel" })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u806F\u7D61\u4FE1\u7BB1", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "email", "inputmode": "email" })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u5099\u8A3B", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Textarea", $$Textarea, { "style": { "min-height": "8.625rem" } })}
        ` })}
        <div class="flex items-center justify-end">
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "className": "form-button", "size": "lg", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`送出` })}
        </div>
    </div>
`, "sub-title": ($$result2) => renderTemplate`<h2 class="inquery-title">
        聯絡資訊
    </h2>` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/inquery/form.astro", void 0);

const $$Inquery = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Inquery", "minMarginHeader": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro";
const $$url = "/inquery.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Inquery,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
