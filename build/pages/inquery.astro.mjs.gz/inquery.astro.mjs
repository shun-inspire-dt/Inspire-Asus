/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Bjgbv9en.mjs';
import { $ as $$Card, d as data } from '../chunks/card_Ctr5X5hi.mjs';
import { b as $$Input, $ as $$Button, a as $$Layouts } from '../chunks/layouts_DEVhm48G.mjs';
import { $ as $$Form$1 } from '../chunks/form_DDRaYkw9.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_BLOdawgV.mjs';
import { $ as $$Select } from '../chunks/select_lMvadGr0.mjs';
import { $ as $$Textarea } from '../chunks/textarea_BHuFkj7I.mjs';
import '../chunks/inquery.30af039e_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "Inquery", className, style, attribute = {}, data = [] } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "type": 2, "display": "grid", "title": "\u8AEE\u8A62\u6E05\u55AE", "block": true, "class:list": [className], "style": style, ...attribute }, { "default": ($$result2) => renderTemplate`
    
    
    ${maybeRenderHead()}<div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u540D\u7A31", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u7D71\u7DE8", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "text", "inputmode": "numeric", "minLength": 8, "maxLength": 8 })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u90E8\u9580", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Select", $$Select, { "data": [
    { text: "IT\u90E8\u9580", value: "IT\u90E8\u9580" },
    { text: "\u8CA1\u52D9\u90E8\u9580", value: "\u8CA1\u52D9\u90E8\u9580" }
  ], "value": "IT\u90E8\u9580" })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u8077\u7A31", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u516C\u53F8\u96FB\u8A71", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "tel", "inputmode": "tel" })}
        ` })}
    </div>
    <div class="section-form-grid-item">
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u806F\u7D61\u59D3\u540D", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, {})}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u806F\u7D61\u624B\u6A5F", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "tel", "inputmode": "tel" })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u806F\u7D61\u4FE1\u7BB1", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Input", $$Input, { "type": "email", "inputmode": "email" })}
        ` })}
        ${renderComponent($$result2, "InputGroup", $$InputGroup, { "label": "\u5099\u8A3B", "block": true }, { "default": ($$result3) => renderTemplate`
            ${renderComponent($$result3, "Textarea", $$Textarea, { "style": { "min-height": "8.625rem" } })}
        ` })}
        <div class="form-button-container">
            ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "className": "form-button", "title": "\u9001\u51FA", "variant": "blue", "block": true }, { "default": ($$result3) => renderTemplate`
                送出
            ` })}
        </div>
    </div>
`, "sub-title": ($$result2) => renderTemplate`<div class="inquery-form-head">
        <h2 class="inquery-title">聯絡資訊</h2>
    </div>`, "top": ($$result2) => renderTemplate`<div class="inquery-cart">
        <div class="inquery-form-head" slot="sub-title">
            <h2 class="inquery-title">
                方案清單
            </h2>
            <span class="inquery-cart-amount">合計詢問 <b class="inquery-cart-amount-number">2</b> 個方案</span>
        </div>
        <div class="w-full flex flex-col items-center gap-1.5rem">
            ${data.map((x) => renderTemplate`${renderComponent($$result2, "Card", $$Card, { "id": x.id, "title": x.title, "label": x.label, "brief": x.brief, "amount": x.amount, "img": x.img })}`)}
        </div>
    </div>` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/inquery/form.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Inquery = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["", "\n\n<script>\n    const toast = document.querySelector('#toastModal');\n    const form = document.querySelector('#InqueryForm');\n\n    form.addEventListener('submit', (e) => {\n        e.preventDefault();\n        toast.dispatchEvent(\n            new CustomEvent('fire', {\n                detail: {\n                    icon: 'success',\n                    title: '\u8868\u55AE\u5DF2\u9001\u51FA',\n                    text: '\u8B1D\u8B1D\u8A62\u554F\uFF0C\u6211\u5011\u6703\u900F\u904EEmail\u6216\u96FB\u8A71\u8207\u60A8\u806F\u7E6B',\n                    link: {\n                        primaryText: '\u56DE\u9996\u9801',\n                        primaryLink: '/',\n                        primaryVariant: 'blue'\n                    },\n                    hidePrevented: true\n                }\n            })\n        );\n    });\n<\/script>"])), renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Inquery", "minMarginHeader": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, { "data": data })}
` }));
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/inquery.astro";
const $$url = "/inquery.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Inquery,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
