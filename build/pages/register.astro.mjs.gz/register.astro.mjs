/* empty css                                   */
import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, F as Fragment } from '../chunks/astro/server_v5wg8FJS.mjs';
import { b as $$Input, c as $$Link, $ as $$Button$1, a as $$Layouts } from '../chunks/layouts_CAx5rqF_.mjs';
import { $ as $$ComfirmCode } from '../chunks/comfirm-code_B44qRTF_.mjs';
import { $ as $$ScriptNext, a as $$Cookies, b as $$FetchWithAuth } from '../chunks/fetchWithAuth.copy_B13ldWhB.mjs';
import { $ as $$Form$1 } from '../chunks/form_DG_mWF--.mjs';
import { $ as $$Divider } from '../chunks/divider_CA0XSYjO.mjs';
import { $ as $$Button, a as $$ScriptInline } from '../chunks/script-inline_9fdPWFXv.mjs';
import { $ as $$InputGroup } from '../chunks/inputGroup_DYD_Fq9Y.mjs';
import { $ as $$PasswordInput } from '../chunks/passwordInput_BrlwYAEA.mjs';
import { $ as $$CheckboxGroup, a as $$ErrorText } from '../chunks/errorText_twUVBtAy.mjs';
import { $ as $$Checkbox } from '../chunks/checkbox_CezxJCXT.mjs';
import '../chunks/register.564c09c5_l0sNRNKZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://www.Asus.com.tw");
const $$Form = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Form;
  const { IDName = "Register", className, style, attribute = {} } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "MySectionForm", $$Form$1, { "IDName": IDName, "title": "\u6703\u54E1\u8A3B\u518A", "className": ["needs-validation", className], "style": style, "attribute": { novalidate: "", "data-needs-loading": "true", "data-report-validity": "false", ...attribute } }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead()}<div class="thrid-party-registers">
        ${renderComponent($$result2, "LoginButton", $$Button, { "type": "google" })}
        ${renderComponent($$result2, "LoginButton", $$Button, { "type": "microsoft" })}
    </div>
    ${renderComponent($$result2, "Divider", $$Divider, {}, { "default": ($$result3) => renderTemplate`或選擇其他方式註冊` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "account", "label": "\u5E33\u865F", "infoText": "\u8ACB\u8F38\u5165\u96FB\u5B50\u90F5\u4EF6", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "Input", $$Input, { "id": "account", "type": "email", "inputmode": "email", "required": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "password", "label": "\u5BC6\u78BC", "infoText": "\u5BC6\u78BC\u9700\u5305\u62EC8\u81F325\u4F4D\u5927\u5C0F\u5BEB\u5B57\u6BCD\u3001\u6578\u5B57\u53CA\u7B26\u865F\uFF0C\u4E14\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\u3002", "errorText": "", "error": true, "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "PasswordInput", $$PasswordInput, { "inputId": "password", "inputAttribute": { pattern: `(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[^A-Za-z0-9])[!-~]{8,25}` }, "required": true })}
    ` })}
    ${renderComponent($$result2, "InputGroup", $$InputGroup, { "inputID": "confirm-password", "label": "\u78BA\u8A8D\u5BC6\u78BC", "infoText": "\u8ACB\u60A8\u518D\u6B21\u8F38\u5165\u60A8\u7684\u5BC6\u78BC", "error": true, "errorText": "", "block": true }, { "default": ($$result3) => renderTemplate`
        ${renderComponent($$result3, "PasswordInput", $$PasswordInput, { "inputId": "confirm-password", "inputAttribute": {
    "data-valid": "confirm",
    "data-target": "#password"
  }, "required": true })}
    ` })}
    ${renderComponent($$result2, "CheckboxGroup", $$CheckboxGroup, {}, { "default": ($$result3) => renderTemplate`
        
        ${renderComponent($$result3, "Checkbox", $$Checkbox, { "required": true }, { "default": ($$result4) => renderTemplate`
            我已閱讀並同意華碩 <b>ASUS EXPERTHUB</b> "${renderComponent($$result4, "ALink", $$Link, { "link": "https://asusexperthub.com/service/terms", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`使用者條款` })}"
        ` })}
        ${renderComponent($$result3, "CheckboxErrorText", $$ErrorText, { "error": true })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, { "required": true }, { "default": ($$result4) => renderTemplate`
            我已閱讀並同意華碩 <b>ASUS EXPERTHUB</b> "${renderComponent($$result4, "ALink", $$Link, { "link": "https://asusexperthub.com/service/privacy", "showArrow": false, "extend": true }, { "default": ($$result5) => renderTemplate`隱私權條款` })}"
        ` })}
        ${renderComponent($$result3, "CheckboxErrorText", $$ErrorText, { "error": true })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`我願意收到華碩相關新聞、產品及服務更新之訊息或行銷廣告。(非必填)` })}
        ${renderComponent($$result3, "Checkbox", $$Checkbox, {}, { "default": ($$result4) => renderTemplate`我願意收到華碩雲端的相關新聞、產品及服務更新之訊息或行銷廣告。(非必填)` })}
    `, "title": ($$result3) => renderTemplate`${renderComponent($$result3, "Fragment", Fragment, { "slot": "title" }, { "default": ($$result4) => renderTemplate`我同意以下所有條款和隱私權政策` })}` })}
    ${renderComponent($$result2, "Button", $$Button$1, { "type": "submit", "variant": "blue", "title": "\u7ACB\u5373\u8A3B\u518A", "block": true }, { "default": ($$result3) => renderTemplate`立即註冊` })}
` })}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/components/pages/register/form.astro", void 0);

const $$Register = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layouts", $$Layouts, { "IDName": "Register", "minMarginHeader": true, "isMemberFooter": true }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Form", $$Form, {})}
` })}
${renderComponent($$result, "ComfirmCode", $$ComfirmCode, {})}
${renderComponent($$result, "ScriptNext", $$ScriptNext, {})}
${renderComponent($$result, "CookiesScript", $$Cookies, {})}
${renderComponent($$result, "FetchWithAuthScript", $$FetchWithAuth, {})}
${renderComponent($$result, "ScriptInline", $$ScriptInline, {})}`;
}, "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/register.astro", void 0);

const $$file = "/Users/wangzhengshun/Desktop/shunshun/Project/Asus/Asus-astro/src/pages/register.astro";
const $$url = "/register.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Register,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
